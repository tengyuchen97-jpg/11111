package com.tengcd.czr.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.NavPillDark
import com.tengcd.czr.ui.theme.NavPillLight
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/** 一个导航项:图标 + 手写体文字 */
data class NavEntry(
    val label: String,
    val icon: ImageVector,
    val selected: Boolean,
    val onClick: () -> Unit
)

/**
 * 底部悬浮胶囊导航栏。
 * 整体是一颗大圆角玻璃条,里面三等分;
 * 选中项在图标外面垫一块浅色圆角块,图标和文字变蓝。
 */
@Composable
fun BottomNavBar(
    dark: Boolean,
    entries: List<NavEntry>,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(78.dp)
            .liquidGlass(dark, corner = 36)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        entries.forEach { entry ->
            NavItem(entry = entry, dark = dark)
        }
    }
}

@Composable
private fun RowScope.NavItem(entry: NavEntry, dark: Boolean) {
    val activeColor = AccentBlue
    val idleColor = if (dark) TextPrimaryDark else TextPrimaryLight
    val pillColor = if (dark) NavPillDark else NavPillLight

    Column(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(RoundedCornerShape(26.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { entry.onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 图标 + 选中时的浅色底块
        Box(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .height(36.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(if (entry.selected) pillColor else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = entry.icon,
                contentDescription = entry.label,
                tint = if (entry.selected) activeColor else idleColor,
                modifier = Modifier.size(21.dp)
            )
        }

        Spacer(Modifier.height(3.dp))

        Text(
            text = entry.label,
            style = TextStyle(
                fontFamily = TitleFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                lineHeight = 15.sp
            ),
            color = if (entry.selected) activeColor else idleColor
        )
    }
}
