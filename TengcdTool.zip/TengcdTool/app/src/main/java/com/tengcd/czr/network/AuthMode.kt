package com.tengcd.czr.network

/**
 * 卡密校验方式的总开关。
 *
 * 两份工程唯一的差别就在这一个常量:
 *   LOCAL_CARD = false  → 对接 T3 网络验证版(默认)
 *   LOCAL_CARD = true   → 本地卡密版,不联网、断网也能进
 *
 * 本地版里所有联网校验(登录 / 查询 / 解绑 / 心跳 / 公告)都会被跳过,
 * 卡密由 [LocalCardGate] 在本地比对。
 */
object AuthMode {

    const val LOCAL_CARD: Boolean = true

    /** 本地版的公告(不联网,页面上的公告栏显示这一句) */
    const val LOCAL_NOTICE: String = "本地卡密版：不联网校验，输入卡密即可进入。"
}
