package com.tengcd.czr.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process
import java.io.File

/**
 * 目标应用相关:装没装、跑没跑、uid 一不一样、数据目录能不能读。
 */
object PackageUtil {

    fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (t: Throwable) {
        false
    }

    fun versionName(context: Context, pkg: String): String? = try {
        context.packageManager.getPackageInfo(pkg, 0).versionName
    } catch (t: Throwable) {
        null
    }

    fun uidOf(context: Context, pkg: String): Int = try {
        context.packageManager.getApplicationInfo(pkg, 0).uid
    } catch (t: Throwable) {
        -1
    }

    fun selfUid(): Int = Process.myUid()

    /** 同一个 sharedUserId 下,两个包 uid 会一致;不一致就没法用进程注入 */
    fun sameUid(context: Context, pkg: String): Boolean {
        val other = uidOf(context, pkg)
        return other != -1 && other == selfUid()
    }

    fun sourceDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).sourceDir
    } catch (t: Throwable) {
        null
    }

    fun dataDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).dataDir
    } catch (t: Throwable) {
        null
    }

    fun nativeLibDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).nativeLibraryDir
    } catch (t: Throwable) {
        null
    }

    fun launch(context: Context, pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            context.startActivity(intent)
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** 扫描 /proc,按 cmdline 找 pid;一个包可能有多个进程 */
    fun findPids(pkg: String): List<Int> {
        val result = ArrayList<Int>()
        val proc = File("/proc")
        val entries = proc.list() ?: return result
        for (name in entries) {
            val pid = name.toIntOrNull() ?: continue
            val cmdline = readCmdline(pid) ?: continue
            if (cmdline == pkg || cmdline.startsWith("$pkg:")) {
                result.add(pid)
            }
        }
        result.sort()
        return result
    }

    fun readCmdline(pid: Int): String? = try {
        val text = File("/proc/$pid/cmdline").readBytes()
        var end = 0
        while (end < text.size && text[end] != 0.toByte()) end++
        String(text, 0, end, Charsets.UTF_8).trim()
    } catch (t: Throwable) {
        null
    }

    fun readUidOfPid(pid: Int): Int = try {
        val status = File("/proc/$pid/status").readLines()
        var uid = -1
        for (line in status) {
            if (line.startsWith("Uid:")) {
                val parts = line.substring(4).trim().split(Regex("\\s+"))
                uid = parts.firstOrNull()?.toIntOrNull() ?: -1
                break
            }
        }
        uid
    } catch (t: Throwable) {
        -1
    }

    fun processNameOfPid(pid: Int): String = try {
        val line = File("/proc/$pid/cmdline").readText(Charsets.UTF_8)
        line.replace('\u0000', ' ').trim()
    } catch (t: Throwable) {
        ""
    }

    fun isRunning(pkg: String): Boolean = findPids(pkg).isNotEmpty()

    fun installedTargets(context: Context): List<Pair<String, String>> {
        val pm: PackageManager = context.packageManager
        val list = ArrayList<Pair<String, String>>()
        val pkgs = pm.getInstalledPackages(0)
        for (info in pkgs) {
            val p = info.packageName
            if (p == context.packageName) continue
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            } catch (t: Throwable) {
                p
            }
            list.add(p to label)
        }
        return list
    }
}
