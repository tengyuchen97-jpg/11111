package com.tengcd.czr.xposed

import android.content.Context
import android.net.Uri

/**
 * 跟「遄懂框架」App 对接。
 *
 * 框架那边开了个导出用的 ContentProvider(content://com.tengcd.hx.status/state),
 * 一次返回这些列:
 *   activated : 框架里是不是已经把模块勾到目标游戏上(0/1)
 *   version   : 框架自报的 Xposed 版本号
 *   scope     : 已勾选的作用域包名,逗号分隔
 *   module    : 模块总开关(0/1)
 *   xposed    : 框架总开关(0/1)
 *
 * 认框架**只看谁提供了这个 authority**,不写死包名 —— 这样老的独立框架
 * (com.tengcd.hx)和新的虚拟空间版框架(包名跟盒子一样)都能认出来。
 */
object HxBridge {

    /** 老框架的包名,只做兜底用 */
    const val HX_PACKAGE = "com.tengcd.hx"

    /** 本模块自己的包名(框架里勾的就是它) */
    const val MODULE_PACKAGE = "com.tengcd.czr"
    private const val AUTHORITY = "com.tengcd.hx.status"

    data class HxState(
        val installed: Boolean = false,
        val activated: Boolean = false,
        val version: Int = 0,
        val scope: String = "",
        val moduleEnabled: Boolean = false,
        val xpEnabled: Boolean = false,
        val providerPackage: String = ""
    )

    @Volatile
    private var cachedAt: Long = 0L

    @Volatile
    private var cached = HxState()

    fun state(ctx: Context): HxState {
        val now = System.currentTimeMillis()
        if (cachedAt != 0L && now - cachedAt < 3000L) return cached
        val result = query(ctx)
        cached = result
        cachedAt = now
        return result
    }

    fun isInstalled(ctx: Context): Boolean = state(ctx).installed

    fun isActive(ctx: Context): Boolean = state(ctx).activated

    /** 框架在位时,把它的状态当成「已激活」用 */
    fun activeOrFalse(ctx: Context): Boolean = runCatching { isActive(ctx) }.getOrDefault(false)

    /**
     * 更准一点的判定:框架里勾的作用域里,到底有没有这个目标游戏。
     * 勾了就算激活(哪怕总开关信息读不到),没勾就不算。
     */
    fun activeFor(ctx: Context, target: String): Boolean = runCatching {
        val st = state(ctx)
        if (!st.installed) return@runCatching false
        if (st.activated) return@runCatching true
        if (target.isBlank()) return@runCatching false
        val scope = st.scope.split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }
        (scope.contains(target) || scope.contains("all")) && (st.moduleEnabled || st.xpEnabled)
    }.getOrDefault(false)

    /** 哪个 App 提供了状态接口(装了多个框架时以真正装上并注册了的为准) */
    fun providerPackage(ctx: Context): String? = runCatching {
        @Suppress("DEPRECATION")
        ctx.packageManager.resolveContentProvider(AUTHORITY, 0)?.packageName
    }.getOrNull()

    private fun legacyInstalled(ctx: Context): Boolean = runCatching {
        @Suppress("DEPRECATION")
        ctx.packageManager.getPackageInfo(HX_PACKAGE, 0)
        true
    }.getOrDefault(false)

    /**
     * 直接问框架(盒子)自己的模块管理接口。
     * 只在注入器被装进框架里跑的时候才读得到 —— 用来在 ContentProvider 那一路
     * 读不到的时候兜底,保证框架里勾没勾、勾了什么都能如实显示。
     */
    private fun boxState(target: String): HxState? = runCatching {
        val mgrCls = Class.forName("top.niunaijun.blackbox.fake.frameworks.BXposedManager")
        val mgr = mgrCls.getMethod("get").invoke(null) ?: return@runCatching null
        fun bool(name: String, arg: String? = null): Boolean = runCatching {
            val m = if (arg == null) mgrCls.getMethod(name) else mgrCls.getMethod(name, String::class.java)
            val v = if (arg == null) m.invoke(mgr) else m.invoke(mgr, arg)
            v as? Boolean ?: false
        }.getOrDefault(false)
        @Suppress("UNCHECKED_CAST")
        fun scopeOf(pkg: String): List<String> = runCatching {
            val m = mgrCls.getMethod("getModuleScope", String::class.java)
            (m.invoke(mgr, pkg) as? List<Any?>)?.mapNotNull { it as? String } ?: emptyList()
        }.getOrDefault(emptyList())

        val xp = bool("isXPEnable")
        val module = bool("isModuleEnable", MODULE_PACKAGE)
        val scope = scopeOf(MODULE_PACKAGE).joinToString(",")
        val hit = target.isNotBlank() && scopeOf(MODULE_PACKAGE).contains(target)
        HxState(
            installed = true,
            activated = xp && module && (hit || scope.isNotBlank()),
            version = 0,
            scope = scope,
            moduleEnabled = module,
            xpEnabled = xp,
            providerPackage = "framework"
        )
    }.getOrNull()

    private fun query(ctx: Context): HxState {
        val pkg = providerPackage(ctx).orEmpty()
        if (pkg.isBlank()) {
            // 没有 provider:先看是不是在框架里跑(直接问盒子),
            // 再退回到「装没装老框架」的判断
            boxState("")?.let { return it }
            return HxState(installed = legacyInstalled(ctx))
        }

        val uri = Uri.parse("content://$AUTHORITY/state")
        val cursor = runCatching {
            ctx.contentResolver.query(uri, null, null, null, null)
        }.getOrNull() ?: return boxState("") ?: HxState(installed = true, providerPackage = pkg)

        return cursor.use { c ->
            if (!c.moveToFirst()) return@use HxState(installed = true, providerPackage = pkg)
            fun int(col: String, def: Int = 0): Int =
                runCatching {
                    val idx = c.getColumnIndex(col)
                    if (idx >= 0) c.getInt(idx) else def
                }.getOrDefault(def)
            fun str(col: String, def: String = ""): String =
                runCatching {
                    val idx = c.getColumnIndex(col)
                    if (idx >= 0) c.getString(idx) ?: def else def
                }.getOrDefault(def)

            val module = int("module") == 1
            val xp = int("xposed") == 1
            val scope = str("scope")
            val activated = int("activated") == 1 ||
                (xp && module && scope.isNotBlank() && scope != "all")
            HxState(
                installed = true,
                activated = activated,
                version = int("version"),
                scope = scope,
                moduleEnabled = module,
                xpEnabled = xp,
                providerPackage = pkg
            )
        }
    }
}
