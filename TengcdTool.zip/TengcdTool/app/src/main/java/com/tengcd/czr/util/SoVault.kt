package com.tengcd.czr.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 内置 so 的保险柜。
 *
 * 目的:别人把你的安装包解开,从 assets 里抽出来的不是 so,而是一段解不开的密文;
 * 就算他把这段密文拷到自己工程里,没有本工程的内置密钥也装不上。
 *
 * 做法:
 *  - 每份 so 单独一把钥匙(由内置主密钥 + 文件名派生),AES-256-CTR 加密 + HMAC-SHA256 校验;
 *  - 主密钥拆成四段、和掩码异或后藏在代码里,不在任何文件里出现明文;
 *  - 可选签名门:把 SIG_PIN 填成你自己证书的 SHA-256 之后,
 *    换签名(重打包)的包连解密这一步都过不去。
 *
 * 文件格式(全部大端):
 *   0..3    "TCD2"
 *   4       版本 = 1
 *   5..20   IV,16 字节
 *   21..24  密文长度,int32
 *   25..    密文
 *   末 32 字节 HMAC-SHA256(前面全部内容)
 */
object SoVault {

    /** 加密后的资产文件后缀:assets/so/v0.26.so -> assets/so/v0.26.so.enc */
    const val ENC_SUFFIX = ".enc"

    private const val MAGIC = "TCD2"
    private const val VERSION = 1
    private const val IV_LEN = 16
    private const val TAG_LEN = 32
    private const val HEADER_LEN = 4 + 1 + IV_LEN + 4

    /**
     * 主密钥(拆四段 + 掩码异或还原)。
     * 换密钥 = 所有 .enc 都要重新加密,别随便动。
     */
    private val K1 = "6044c62328c79f79"
    private val K2 = "d7a0c6228ef309d4"
    private val K3 = "ff9eab9352589e8e"
    private val K4 = "ba18db2d308aca80"
    private val MASK = "337d501fc4e9085bc02931bbedec9218fbc6eb0e251b983c61641dfa3557a103"

    /**
     * 签名门:填成你自己 keystore 证书的 SHA-256(大写、无冒号,64 位十六进制),
     * 留空 = 只靠内置密钥,不校验签名。
     *
     * ⚠️ AIDE 默认那套 "Android 调试证书" 是公开的测试证书,拿来绑等于没绑,
     * 所以这里默认留空;等你用自己的 keystore 打包之后,把证书指纹填进来才有意义。
     */
    private const val SIG_PIN = ""

    private val masterKey: ByteArray by lazy {
        val mixed = hexToBytes(K1 + K2 + K3 + K4)
        val mask = hexToBytes(MASK)
        val secret = ByteArray(mixed.size) { i ->
            (mixed[i].toInt() xor mask[i % mask.size].toInt()).toByte()
        }
        sha256(secret + "|TCD-SO-V2".toByteArray(Charsets.US_ASCII))
    }

    // ---------------- 对外 ----------------

    /**
     * 从 assets 解出一份 so。
     *
     * 两种放法都认,顺序是「先密文、后明文」:
     *  1) <variant>.so.enc —— 走解密(HMAC + AES-CTR);解不开不直接放弃,继续看下一行;
     *  2) <variant>.so     —— 明文直接读(你自己改 so 的时候,丢明文进 assets 就能用)。
     *
     * 两份同时存在时以密文为准;只有密文坏了才退回明文。
     * 都能用这件事是为了让你改的时候用明文、出包的时候换密文,不用改代码。
     */
    fun readAsset(context: Context, variant: String): ByteArray? {
        val encName = "$variant.so$ENC_SUFFIX"
        val plainName = "$variant.so"

        // ① 密文
        val enc = runCatching {
            context.assets.open("$ASSET_DIR/$encName").use { it.readBytes() }
        }.getOrNull()
        if (enc != null && enc.size > HEADER_LEN + TAG_LEN) {
            val out = decrypt(enc, encName)
            if (out != null && isElf(out) && out.size > PLACEHOLDER_MAX) return out
        }

        // ② 明文(密文不存在 / 密文解不开都会落这里)
        val plain = runCatching {
            context.assets.open("$ASSET_DIR/$plainName").use { it.readBytes() }
        }.getOrNull() ?: return null
        return if (isElf(plain) && plain.size > PLACEHOLDER_MAX) plain else null
    }

    /** 小于这个大小的一律算空白占位(ELF 头 + 空段 = 320 字节),不当真 so 用 */
    private const val PLACEHOLDER_MAX = 4096

    private const val ASSET_DIR = "so"

    /** 这段字节是不是一份 ELF */
    fun isElf(bytes: ByteArray): Boolean = bytes.size >= 20 &&
        bytes[0] == 0x7F.toByte() && bytes[1] == 'E'.code.toByte() &&
        bytes[2] == 'L'.code.toByte() && bytes[3] == 'F'.code.toByte()

    /** 解密一段密文;entryName + 包名参与派生密钥,换名字 / 换包名都解不开 */
    fun decrypt(raw: ByteArray, entryName: String): ByteArray? {
        if (raw.size < HEADER_LEN + TAG_LEN) return null
        if (String(raw, 0, 4, Charsets.US_ASCII) != MAGIC) return null
        if (raw[4].toInt() != VERSION) return null

        val iv = raw.copyOfRange(5, 5 + IV_LEN)
        val len = beInt(raw, 21)
        if (len <= 0 || raw.size != HEADER_LEN + len + TAG_LEN) return null

        val bodyEnd = HEADER_LEN + len
        val ct = raw.copyOfRange(HEADER_LEN, bodyEnd)
        val tag = raw.copyOfRange(bodyEnd, bodyEnd + TAG_LEN)

        val expect = hmac(raw, 0, bodyEnd, macKey(entryName))
        if (!MessageDigest.isEqual(expect, tag)) return null

        return try {
            val cipher = Cipher.getInstance("AES/CTR/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(fileKey(entryName), "AES"), IvParameterSpec(iv))
            cipher.doFinal(ct)
        } catch (t: Throwable) {
            null
        }
    }

    /** 解密并落盘(私有目录,只有本应用能读) */
    fun unpackTo(context: Context, variant: String, dst: File): Boolean {
        val bytes = readAsset(context, variant) ?: return false
        if (!isElf(bytes) || bytes.size <= 4096) return false
        return try {
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            tmp.outputStream().use { it.write(bytes) }
            makeOwnerOnly(tmp)
            if (tmp.length() <= 0L) {
                tmp.delete()
                false
            } else {
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    false
                } else {
                    makeOwnerOnly(dst)
                    true
                }
            }
        } catch (t: Throwable) {
            false
        }
    }

    /** 只给自己读:别让同机其它应用(或 shell)顺手拷走 */
    fun makeOwnerOnly(file: File) {
        runCatching {
            file.setReadable(false, false)
            file.setWritable(false, false)
            file.setExecutable(false, false)
            file.setReadable(true, true)
            file.setWritable(true, true)
            file.setExecutable(true, true)
        }
    }

    // ---------------- 签名门 ----------------

    /** 当前安装包的签名证书 SHA-256(大写、无冒号);取不到返回空串 */
    fun certSha256(pm: PackageManager, pkg: String): String = try {
        val certs: Array<android.content.pm.Signature> =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                val signing = info.signingInfo
                when {
                    signing == null -> emptyArray()
                    signing.hasMultipleSigners() -> signing.apkContentsSigners
                    else -> signing.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
            }
        certs.firstOrNull()?.let { hexUpper(sha256(it.toByteArray())) }.orEmpty()
    } catch (t: Throwable) {
        ""
    }

    /**
     * 签名门是否放行。SIG_PIN 留空 = 不校验(默认);
     * 填了之后,证书对不上就直接拒绝解密,连明文都不会落地。
     */
    fun signatureAllowed(context: Context, ownerPackage: String): Boolean {
        if (SIG_PIN.isBlank()) return true
        val actual = certSha256(context.packageManager, ownerPackage)
        if (actual.isBlank()) return true
        return actual.equals(SIG_PIN, ignoreCase = true)
    }

    fun hasPin(): Boolean = SIG_PIN.isNotBlank()

    // ---------------- 内部 ----------------

    /**
     * 包名也混进密钥派生。
     * 意思很直接:别人把 assets 里的 .enc 抽走、塞进自己的工程,包名不一样 ->
     * 派生出来的钥匙就不同 -> HMAC 直接对不上,解出来连 ELF 头都没有,装不上。
     * ⚠️ 改包名必须用 tools/enc_so.py 重新加密一遍(脚本里同一个 APP_ID)。
     */
    private const val APP_ID = "com.tengcd.czr"

    private fun fileKey(entryName: String): ByteArray =
        hmacBytes("k|$APP_ID|$entryName".toByteArray(), masterKey)

    private fun macKey(entryName: String): ByteArray =
        hmacBytes("m|$APP_ID|$entryName".toByteArray(), masterKey)

    private fun hmac(data: ByteArray, offset: Int, len: Int, key: ByteArray): ByteArray = try {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        mac.update(data, offset, len)
        mac.doFinal()
    } catch (t: Throwable) {
        ByteArray(0)
    }

    private fun hmacBytes(data: ByteArray, key: ByteArray): ByteArray = hmac(data, 0, data.size, key)

    private fun sha256(data: ByteArray): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(data)

    private fun beInt(raw: ByteArray, offset: Int): Int =
        ((raw[offset].toInt() and 0xFF) shl 24) or
            ((raw[offset + 1].toInt() and 0xFF) shl 16) or
            ((raw[offset + 2].toInt() and 0xFF) shl 8) or
            (raw[offset + 3].toInt() and 0xFF)

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.trim()
        val out = ByteArray(clean.length / 2)
        for (i in out.indices) {
            out[i] = ((Character.digit(clean[i * 2], 16) shl 4) or
                Character.digit(clean[i * 2 + 1], 16)).toByte()
        }
        return out
    }

    private fun hexUpper(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append("0123456789ABCDEF"[v ushr 4])
            sb.append("0123456789ABCDEF"[v and 0x0F])
        }
        return sb.toString()
    }

    /** 读流式输入(assets/ZipInputStream 都行) */
    fun readAll(input: InputStream): ByteArray = input.use { it.readBytes() }
}
