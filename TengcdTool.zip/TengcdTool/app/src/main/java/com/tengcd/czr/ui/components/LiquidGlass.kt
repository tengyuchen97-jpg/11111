package com.tengcd.czr.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tengcd.czr.i18n.LocalStrings
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.GlassBorderDark
import com.tengcd.czr.ui.theme.GlassBorderLight
import com.tengcd.czr.ui.theme.GlassFillDark
import com.tengcd.czr.ui.theme.GlassFillLight
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.WarnOrange

/**
 * 液态玻璃。原理就是:半透明渐变底 + 一道高光描边 + 柔和外阴影,
 * 不用真模糊(能在低端机上跑得动)。要真模糊的话把 Modifier.blur 叠上去也行。
 */
fun Modifier.liquidGlass(dark: Boolean, corner: Int = 24): Modifier = this
    .shadow(
        elevation = if (dark) 6.dp else 14.dp,
        shape = RoundedCornerShape(corner.dp),
        clip = false,
        ambientColor = if (dark) Color(0x66000000) else Color(0x1A7B5CFF),
        spotColor = if (dark) Color(0x66000000) else Color(0x227B5CFF)
    )
    .clip(RoundedCornerShape(corner.dp))
    .background(
        Brush.linearGradient(
            colors = if (dark) {
                listOf(Color(0x26FFFFFF), Color(0x0DFFFFFF))
            } else {
                listOf(Color(0xD9FFFFFF), Color(0x80FFFFFF))
            }
        )
    )
    .border(
        width = 1.dp,
        brush = Brush.linearGradient(
            colors = if (dark) {
                listOf(GlassBorderDark, Color(0x0DFFFFFF))
            } else {
                listOf(GlassBorderLight, Color(0x33FFFFFF))
            }
        ),
        shape = RoundedCornerShape(corner.dp)
    )

@Composable
fun GlassCard(
    dark: Boolean,
    modifier: Modifier = Modifier,
    corner: Int = 24,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .liquidGlass(dark, corner)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        content = content
    )
}

@Composable
fun SectionHeader(icon: ImageVector, title: String, dark: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(AccentBlue.copy(alpha = if (dark) 0.28f else 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AccentBlue,
                modifier = Modifier.size(17.dp)
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
    }
}

/** 一行"标签 —— 状态"。dot = true 时左边带个状态圆点 */
@Composable
fun StatusRow(
    label: String,
    value: String,
    dark: Boolean,
    dot: Boolean = false,
    ok: Boolean = true,
    warn: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
        Spacer(Modifier.width(8.dp))
        Box(modifier = Modifier.weight(1f))
        if (dot) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (ok && !warn) OkGreen else WarnOrange)
            )
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = when {
                // 状态行:就绪/激活 → 绿,未激活/未就绪 → 黄
                !dot -> if (dark) TextSecondaryDark else TextSecondaryLight
                ok && !warn -> OkGreen
                else -> WarnOrange
            }
        )
    }
}

/** 胶囊切换:框架注入 / 进程注入 */
@Composable
fun SegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    dark: Boolean,
    onSelect: (Int) -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (dark) Color(0x1FFFFFFF) else Color(0x59FFFFFF)
            )
            .border(1.dp, if (dark) GlassBorderDark else GlassBorderLight, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { index, text ->
            val selected = index == selectedIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(shape)
                    .then(
                        if (selected) {
                            Modifier
                                .shadow(
                                    elevation = 6.dp,
                                    shape = shape,
                                    clip = false,
                                    ambientColor = AccentBlue.copy(alpha = 0.4f),
                                    spotColor = AccentBlue.copy(alpha = 0.4f)
                                )
                                .background(Brush.horizontalGradient(listOf(AccentBlue, Color(0xFF5B8CFF))))
                        } else {
                            Modifier
                        }
                    )
                    .clickable { onSelect(index) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selected) Color.White else if (dark) TextSecondaryDark else TextSecondaryLight
                )
            }
        }
    }
}

@Composable
fun PrimaryActionButton(
    text: String,
    icon: ImageVector?,
    enabled: Boolean,
    dark: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(shape)
            .background(
                if (enabled) {
                    Brush.horizontalGradient(listOf(AccentBlue, Color(0xFF4F7BFF)))
                } else {
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xFF9FA8C4).copy(alpha = 0.6f),
                            Color(0xFF9FA8C4).copy(alpha = 0.6f)
                        )
                    )
                }
            )
            .clickable(enabled = enabled) { onClick() },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.titleMedium, color = Color.White)
    }
}

@Composable
fun SecondaryActionButton(
    text: String,
    icon: ImageVector?,
    dark: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .liquidGlass(dark, 50)
            .clickable(enabled = enabled) { onClick() },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (dark) TextPrimaryDark else TextPrimaryLight,
                modifier = Modifier.size(19.dp)
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text,
            style = MaterialTheme.typography.titleMedium,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
    }
}

@Composable
fun KeyValueRow(label: String, value: String, dark: Boolean, valueColor: Color? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = valueColor ?: if (dark) TextPrimaryDark else TextPrimaryLight,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun EmptyHint(text: String, dark: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Filled.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (dark) TextSecondaryDark else TextSecondaryLight,
            modifier = Modifier.size(14.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )
    }
}

/** 玻璃底 + 圆角的图标按钮(标题栏那颗月亮用的就是它) */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    dark: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .liquidGlass(dark, 50)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (dark) TextPrimaryDark else TextPrimaryLight,
            modifier = Modifier.size(18.dp)
        )
    }
}

/**
 * SO 变体选择器:一排胶囊,横向可滑。选中的那个高亮,
 * 点哪个就是哪个 —— 注入时用的就是它。
 */
@Composable
fun SoVariantChips(
    options: List<String>,
    selected: String,
    active: Boolean,
    dark: Boolean,
    onSelect: (String) -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        options.forEach { name ->
            val isSelected = active && name == selected
            Box(
                modifier = Modifier
                    .clip(shape)
                    .then(
                        if (isSelected) {
                            Modifier
                                .background(
                                    Brush.horizontalGradient(listOf(OkGreen, Color(0xFF34C77B)))
                                )
                                .border(1.dp, OkGreen, shape)
                        } else {
                            Modifier.liquidGlass(dark, 50)
                        }
                    )
                    .clickable { onSelect(name) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSelected) {
                        Color.White
                    } else {
                        if (dark) TextPrimaryDark else TextPrimaryLight
                    }
                )
            }
        }
    }
}

/** 目标应用:名字标红,包名单独占一个框 */
@Composable
fun TargetAppBadge(label: String, pkg: String, dark: Boolean) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            color = ErrRed,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .clip(shape)
                .border(1.dp, ErrRed.copy(alpha = 0.55f), shape)
                .background(ErrRed.copy(alpha = if (dark) 0.16f else 0.08f))
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Text(
                text = pkg,
                style = MaterialTheme.typography.bodySmall,
                color = ErrRed,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

/** 路径展示:等宽字体 + 细边框,长路径自动折行 */
@Composable
fun PathBox(text: String, dark: Boolean, accent: Color = AccentBlue) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, accent.copy(alpha = 0.45f), shape)
            .background(accent.copy(alpha = if (dark) 0.12f else 0.07f))
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = if (dark) TextPrimaryDark else TextPrimaryLight,
            fontFamily = FontFamily.Monospace
        )
    }
}

/**
 * SO 来源选择:内置 / 本地。
 * 点哪个哪个就亮起来(选中的是绿色实底),不再是一排灰扑扑的按钮。
 */
@Composable
fun SoSourceChips(
    dark: Boolean,
    builtinActive: Boolean,
    localReady: Boolean,
    onBuiltin: () -> Unit,
    onLocal: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SoSourceChip(
            text = LocalStrings.current.soSourceBuiltin,
            selected = builtinActive,
            enabled = true,
            dark = dark,
            shape = shape,
            modifier = Modifier.weight(1f),
            onClick = onBuiltin
        )
        SoSourceChip(
            text = LocalStrings.current.soSourceLocal,
            selected = !builtinActive,
            enabled = true,
            dark = dark,
            shape = shape,
            modifier = Modifier.weight(1f),
            onClick = onLocal
        )
    }
}

@Composable
private fun SoSourceChip(
    text: String,
    selected: Boolean,
    enabled: Boolean,
    dark: Boolean,
    shape: androidx.compose.ui.graphics.Shape,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(shape)
            .then(
                if (selected) {
                    Modifier
                        .background(Brush.horizontalGradient(listOf(OkGreen, Color(0xFF34C77B))))
                        .border(1.dp, OkGreen, shape)
                } else {
                    Modifier.liquidGlass(dark, 50)
                }
            )
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) Color.White else if (dark) TextPrimaryDark else TextPrimaryLight
        )
    }
}
