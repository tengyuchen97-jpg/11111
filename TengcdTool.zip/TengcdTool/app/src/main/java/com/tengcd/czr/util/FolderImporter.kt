package com.tengcd.czr.util

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * 本机文件夹 -> 目标应用私有目录 的整包导入。
 *
 * 目标:/storage/emulated/0/Android/data/com.pi.czrxdfirst/files
 *
 * 流程:SAF 选文件夹 -> 全部读进缓存目录做暂存 -> 清空目标目录 -> 把暂存内容写过去。
 * 写入走两条通道:
 *   1) 直写:本应用和目标应用同一个 uid(sharedUserId)时,/Android/data/<包名> 归我们所有,直接 File IO
 *   2) root:su 跑一段脚本,rm -rf 目标目录后再 cp -rf,最后 chown 回目标 uid
 * 两条都不通就明说写不进去,不留半截文件。
 */
object FolderImporter {

    /** 目标目录,固定写死 */
    const val TARGET_PATH = "/storage/emulated/0/Android/data/com.pi.czrxdfirst/files"

    /** 目标应用包名(取 uid 用) */
    const val TARGET_PACKAGE = "com.pi.czrxdfirst"

    data class Summary(val folderName: String, val files: Int, val bytes: Long)

    data class Progress(val copied: Int, val total: Int, val bytes: Long)

    data class Outcome(
        val ok: Boolean,
        val copied: Int,
        val bytes: Long,
        val channel: String,
        val error: String? = null
    )

    fun targetDir(): File = File(TARGET_PATH)

    fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
        bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
        bytes >= 1024L -> String.format("%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    fun canUseDirect(): Boolean = try {
        val dir = targetDir()
        if (dir.exists()) dir.canWrite() && dir.canRead() else {
            val parent = dir.parentFile
            parent != null && (parent.exists() && parent.canWrite() || (!parent.exists() && parent.mkdirs()))
        }
    } catch (t: Throwable) {
        false
    }

    fun hasRoot(): Boolean = ShellUtil.hasRoot()

    /** 数一下这个文件夹里有多少文件、多大 */
    fun summary(context: Context, treeUri: Uri): Summary? {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        var files = 0
        var bytes = 0L
        walk(root) { _, doc ->
            if (doc.isFile) {
                files++
                bytes += doc.length()
            }
        }
        return Summary(root.name ?: "已选文件夹", files, bytes)
    }

    private fun walk(
        dir: DocumentFile,
        depth: Int = 0,
        prefix: String = "",
        visit: (String, DocumentFile) -> Unit
    ) {
        if (depth > 24) return
        val children = try {
            dir.listFiles()
        } catch (t: Throwable) {
            emptyArray()
        }
        for (child in children) {
            val name = child.name ?: continue
            val path = if (prefix.isEmpty()) name else "$prefix/$name"
            visit(path, child)
            if (child.isDirectory) walk(child, depth + 1, path, visit)
        }
    }

    /**
     * 把选中的文件夹整个读进缓存目录(先落盘再写目标,避免边读边写写到一半失败留残缺)。
     * 返回 (暂存目录, 统计)
     */
    fun stage(
        context: Context,
        treeUri: Uri,
        onProgress: (Progress) -> Unit = {}
    ): Pair<File, Summary>? {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        val sum = summary(context, treeUri) ?: return null

        val stageDir = File(context.cacheDir, "import_stage")
        try {
            stageDir.deleteRecursively()
        } catch (t: Throwable) {
        }
        if (!stageDir.mkdirs() && !stageDir.isDirectory) return null

        var copied = 0
        var bytes = 0L
        var failed = 0

        walk(root) { rel, doc ->
            val out = File(stageDir, rel)
            try {
                if (doc.isDirectory) {
                    out.mkdirs()
                } else if (doc.isFile) {
                    out.parentFile?.mkdirs()
                    val input = context.contentResolver.openInputStream(doc.uri)
                    if (input == null) {
                        failed++
                    } else {
                        input.use { i ->
                            out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                        }
                        copied++
                        bytes += out.length()
                    }
                }
            } catch (t: Throwable) {
                failed++
            }
            onProgress(Progress(copied, sum.files, bytes))
        }

        if (copied == 0 && sum.files > 0) return null
        return stageDir to Summary(sum.folderName, copied, bytes)
    }

    /**
     * 真正执行导入:清空目标目录,再把暂存内容整个写过去。
     */
    fun import(
        context: Context,
        treeUri: Uri,
        onProgress: (Progress) -> Unit = {}
    ): Outcome {
        val staged = stage(context, treeUri, onProgress)
            ?: return Outcome(false, 0, 0, "none", "源文件夹读不出来(可能是权限或空文件夹)")

        val stageDir = staged.first
        val sum = staged.second
        val target = targetDir()

        // 通道 1:直写
        if (canUseDirect()) {
            val direct = tryDirect(stageDir, target, sum, onProgress)
            if (direct != null) return direct
        }

        // 通道 2:root
        if (hasRoot()) {
            val root = tryRoot(context, stageDir, target, sum)
            if (root != null) return root
        }

        return Outcome(false, 0, 0, "none", "目标目录写不进去")
    }

    private fun tryDirect(
        stageDir: File,
        target: File,
        sum: Summary,
        onProgress: (Progress) -> Unit
    ): Outcome? = try {
        if (target.exists()) {
            val kids = target.listFiles()
            if (kids == null) {
                null
            } else {
                for (kid in kids) {
                    if (!kid.deleteRecursively()) throw IllegalStateException("删不掉 ${kid.name}")
                }
                if (!target.isDirectory && !target.mkdirs()) throw IllegalStateException("建不了目标目录")
                copyInto(stageDir, target, sum, onProgress)
            }
        } else {
            if (!target.mkdirs() && !target.isDirectory) throw IllegalStateException("建不了目标目录")
            copyInto(stageDir, target, sum, onProgress)
        }
    } catch (t: Throwable) {
        null
    }

    private fun copyInto(
        src: File,
        dst: File,
        sum: Summary,
        onProgress: (Progress) -> Unit
    ): Outcome {
        var files = 0
        var bytes = 0L
        val stack = ArrayDeque<Pair<File, File>>()
        stack.addLast(src to dst)
        while (stack.isNotEmpty()) {
            val (s, d) = stack.removeLast()
            val children = s.listFiles() ?: continue
            for (child in children) {
                val out = File(d, child.name)
                if (child.isDirectory) {
                    if (!out.exists()) out.mkdirs()
                    stack.addLast(child to out)
                } else {
                    child.inputStream().use { i ->
                        out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                    }
                    files++
                    bytes += out.length()
                    onProgress(Progress(files, sum.files, bytes))
                }
            }
        }
        return Outcome(true, files, bytes, "direct")
    }

    private fun tryRoot(
        context: Context,
        stageDir: File,
        target: File,
        sum: Summary
    ): Outcome? {
        return try {
            val uid = PackageUtil.uidOf(context, TARGET_PACKAGE).let {
                if (it < 0) PackageUtil.selfUid() else it
            }
            val script = File(context.cacheDir, "zaka_import.sh")
            script.writeText(
                buildString {
                    appendLine("#!/system/bin/sh")
                    appendLine("TARGET='${target.absolutePath}'")
                    appendLine("STAGE='${stageDir.absolutePath}'")
                    appendLine("rm -rf \"\$TARGET\"")
                    appendLine("mkdir -p \"\$TARGET\"")
                    appendLine("cp -rf \"\$STAGE/.\" \"\$TARGET/\" 2>/dev/null")
                    appendLine("chown -R $uid:$uid \"\$TARGET\" 2>/dev/null")
                    appendLine("chmod -R 0771 \"\$TARGET\" 2>/dev/null")
                    appendLine("restorecon -R \"\$TARGET\" 2>/dev/null")
                    appendLine("ls -A \"\$TARGET\" | wc -l")
                }
            )
            val r = ShellUtil.exec("su -c \"sh '${script.absolutePath}'\"", 120_000)
            if (!r.ok) return null
            val count = r.output.lineSequence()
                .mapNotNull { it.trim().toIntOrNull() }
                .lastOrNull() ?: 0
            if (count <= 0) return null
            Outcome(true, sum.files, sum.bytes, "root")
        } catch (t: Throwable) {
            null
        }
    }

    fun cleanup(context: Context) {
        try {
            File(context.cacheDir, "import_stage").deleteRecursively()
        } catch (t: Throwable) {
        }
    }
}
