package com.tengcd.czr.network

import java.util.Base64

/**
 * T3 网络验证的后台参数 + 编解码。
 *
 * 官方协议(与 T3 官方 SDK 一致):
 *   1. 接口地址 = 验证服务器 + "/" + 该接口的 VIP 调用码,例如
 *      https://w.t3yanzheng.com/47D4910970418F2E
 *   2. 每个参数的**值**先做自定义 Base64 编码,再转成 HEX 十六进制字符串;
 *   3. 签名 s = HEX(自定义Base64(md5("k=已编码值&k=已编码值&" + appkey)));
 *   4. 表单 POST 提交,返回内容用自定义 Base64 解码后就是 JSON。
 */
object T3Panel {

    /** 主力验证服务器(客户端写死,界面上不提供修改入口) */
    const val SERVER = "https://w.t3yanzheng.com"

    /** 接口加密验证 APPKEY */
    const val APPKEY = "f736fd5efeb7a9ab1b6bdfcc7b364a78"

    /** Base64 自定义编码集(后台「Base64算法编码集」,必须是 64 位) */
    const val B64_CHARSET =
        "kXcZ3OBKtPVsR5w1Fdmjl2GLg4SYfNhrUWopiI6+z/TnvbauQeCy9Aq8HMJ70DEx"

    /** 标准 Base64 字符表,后台如果没自定义编码集就是这个 */
    const val STANDARD_B64 =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    /** RC4 加解密密钥 */
    const val RC4_KEY = "7lo18aX1QialEA5"

    /** 登录状态码有效期(秒) */
    const val TTL = 3600L

    // 各接口的 VIP 调用码
    const val CODE_LOGIN = "47D4910970418F2E"      // 单码卡密登录
    const val CODE_HEARTBEAT = "9542275815E7B7CE"  // 单码卡密心跳
    const val CODE_NOTICE = "3C223920FC8D1028"     // 获取程序公告
    const val CODE_LATEST = "32BAF86A30D5CC25"     // 获取最新版序号
    const val CODE_CHECK_VER = "FAE896FF9D204BEE"  // 检测版本是否最新版
    const val CODE_UNBIND = "0CAD0675444DC587"     // 解绑或换绑机器码(后台接口详情给的)

    /** 接口参数名(后台接口详情里定义的) */
    const val P_CARD = "kami"
    const val P_DEVICE = "imei"
    const val P_STATE = "statecode"
    const val P_VER = "ver"

    fun codeOf(action: String): String = when (action) {
        "login" -> CODE_LOGIN
        "heartbeat" -> CODE_HEARTBEAT
        "notice" -> CODE_NOTICE
        "latest" -> CODE_LATEST
        "checkver" -> CODE_CHECK_VER
        "unbind" -> CODE_UNBIND
        "query" -> CODE_LOGIN
        else -> CODE_LOGIN
    }

    /** 编码集必须 64 个互不相同的字符,否则映射一定是错的 */
    fun usableCharset(charset: String): Boolean {
        val cs = charset.trim()
        return cs.length == 64 && cs.toSet().size == 64
    }

    // ---------------- 自定义 Base64 ----------------

    /** 标准 Base64 -> 自定义编码集 */
    fun encodeText(text: String, charset: String): String {
        val cs = if (usableCharset(charset)) charset.trim() else STANDARD_B64
        val std = Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(std.length)
        for (c in std) {
            val idx = STANDARD_B64.indexOf(c)
            sb.append(if (idx >= 0) cs[idx] else c)
        }
        return sb.toString()
    }

    /** 自定义编码集 -> 标准 Base64 -> 原文 */
    fun decodeText(text: String, charset: String): String? {
        val cs = if (usableCharset(charset)) charset.trim() else STANDARD_B64
        val clean = text.trim().trim('"').replace("\r", "").replace("\n", "").replace(" ", "")
        if (clean.isEmpty()) return null
        val sb = StringBuilder(clean.length)
        for (c in clean) {
            val idx = cs.indexOf(c)
            sb.append(if (idx >= 0) STANDARD_B64[idx] else c)
        }
        return try {
            String(Base64.getMimeDecoder().decode(sb.toString()), Charsets.UTF_8)
        } catch (t: Throwable) {
            null
        }
    }

    /** 参数值编码:自定义 Base64 之后再转 HEX(官方 SDK 的 base64 模式) */
    fun encodeValue(value: String, charset: String): String =
        encodeText(value, charset).toByteArray(Charsets.UTF_8).joinToString("") {
            "%02x".format(it.toInt() and 0xFF)
        }

    // ---------------- RC4 ----------------

    fun rc4(data: ByteArray): ByteArray = rc4(RC4_KEY.toByteArray(Charsets.UTF_8), data)

    fun rc4(key: ByteArray, data: ByteArray): ByteArray {
        val s = IntArray(256) { it }
        var j = 0
        for (i in 0 until 256) {
            j = (j + s[i] + (key[i % key.size].toInt() and 0xFF)) and 0xFF
            val tmp = s[i]; s[i] = s[j]; s[j] = tmp
        }
        val out = ByteArray(data.size)
        var i = 0; j = 0
        for (k in data.indices) {
            i = (i + 1) and 0xFF
            j = (j + s[i]) and 0xFF
            val tmp = s[i]; s[i] = s[j]; s[j] = tmp
            out[k] = (data[k].toInt() xor s[(s[i] + s[j]) and 0xFF]).toByte()
        }
        return out
    }

    /**
     * 解析服务端返回:依次尝试
     *   自定义 Base64 -> 自定义 Base64 后 RC4 -> 标准 Base64 -> 标准 Base64 后 RC4
     *
     * 注意:以前判「解开了」的标准是 `p.contains("=")`,太松了——
     * base64 自身带 '=' 填充,乱码里也常有 '='。现在只认两种形状:
     * 真 JSON(以 { 开头),或者规范的 k=v&k=v。
     */
    fun decodePayload(raw: String, charset: String): String? {
        val text = raw.trim().trim('"')
        if (text.isEmpty()) return null
        if (text.startsWith("{") || text.startsWith("[")) return text

        for (cs in listOf(charset, STANDARD_B64)) {
            val plain = decodeText(text, cs) ?: continue
            val p = plain.trim()
            if (p.startsWith("{")) return p
            if (looksLikeKv(p)) return p
            val un = String(rc4(p.toByteArray(Charsets.UTF_8)), Charsets.UTF_8).trim()
            if (un.startsWith("{")) return un
            if (looksLikeKv(un)) return un
        }
        return null
    }

    private val KV_KEY = Regex("^[A-Za-z][A-Za-z0-9_]{0,23}$")

    private val KV_KNOWN = setOf(
        "code", "status", "msg", "message", "info", "data", "token", "statecode",
        "success", "ok", "ret", "errcode", "errmsg", "tips", "notice"
    )

    /** 判断一段文本是不是 "key=value&key=value" 这种老式返回 */
    fun looksLikeKv(text: String): Boolean {
        if (text.isEmpty() || text.length > 2048) return false
        if (!text.contains("=") || text.contains("<") || text.contains("{") || text.contains(" ")) return false
        var known = false
        for (pair in text.split("&")) {
            val idx = pair.indexOf('=')
            if (idx <= 0) return false
            val key = pair.substring(0, idx)
            if (!KV_KEY.matches(key)) return false
            if (key in KV_KNOWN) known = true
        }
        return known
    }
}
