package com.tengcd.czr.util

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 「保存旧数据」:把目标应用的整个外部数据目录压成一个 zip,落到 /storage/emulated/0/遄懂/。
 *
 * 安卓 11 起普通应用读不到别的应用的 /Android/data/<包名>,所以读取走特权通道
 * (root 优先,其次 Shizuku):先让特权身份把源目录整份 cp 到暂存目录,
 * app 再从暂存目录读出来打 zip,最后把 zip 拷到目标目录。
 *
 * zip 里第一层是包名目录(解压到 /storage/emulated/0/Android/data/ 就能原样还原)。
 */
object OldDataBackup {

    /** 要备份的旧数据目录 */
    const val SOURCE_DIR = "/storage/emulated/0/Android/data/com.pi.czrxdfirst"

    /** 备份文件落到这里(没有就自动建) */
    const val DEST_DIR = "/storage/emulated/0/遄懂"

    const val DEFAULT_BASE_NAME = "旧数据"

    private const val COPY_TIMEOUT_MS = 600_000L
    private const val DEPLOY_TIMEOUT_MS = 120_000L

    data class Progress(val files: Int, val total: Int, val bytes: Long)

    data class Outcome(
        val ok: Boolean,
        /** 成功时的 zip 绝对路径 */
        val zipPath: String = "",
        val files: Int = 0,
        val bytes: Long = 0L,
        /** 失败原因码:no_source / no_channel / zip_failed / deploy_failed */
        val error: String? = null
    )

    /** 用户输入的名字洗一遍:去掉 .zip 后缀和路径非法字符,空就用默认名 */
    fun sanitizeName(raw: String): String {
        val trimmed = raw.trim()
            .removeSuffix(".zip")
            .removeSuffix(".ZIP")
            .trim()
        val cleaned = trimmed.replace(Regex("[\\\\/:*?\"<>|\u0000-\u001f]"), "_").trim()
        return if (cleaned.isBlank()) DEFAULT_BASE_NAME else cleaned.take(80)
    }

    /** 源目录在不在:先直接看(app 有权限时最快),不行再问特权通道 */
    private fun sourceAvailable(context: Context): Boolean {
        val direct = File(SOURCE_DIR)
        if (direct.isDirectory && runCatching { direct.list() != null }.getOrDefault(false)) {
            return true
        }
        val r = ShellUtil.execPrivileged(
            context,
            "if [ -d ${shq(SOURCE_DIR)} ]; then echo YES; fi",
            8_000L
        ) ?: return false
        return r.output.contains("YES")
    }

    /**
     * 整份流程。跑在 IO 线程上,别在主线程调。
     */
    fun run(context: Context, rawName: String, onProgress: (Progress) -> Unit = {}): Outcome {
        val baseName = sanitizeName(rawName)
        val zipName = "$baseName.zip"

        // 看得见就直接用;看不见先看有没有特权通道,没有就别跑下去(提示要 root / Shizuku)
        val directVisible = runCatching {
            val dir = File(SOURCE_DIR)
            dir.isDirectory && dir.list() != null
        }.getOrDefault(false)
        if (!directVisible) {
            if (!ShellUtil.hasRoot() && !ShizukuShell.granted()) {
                return Outcome(false, error = "no_channel")
            }
            if (!sourceAvailable(context)) return Outcome(false, error = "no_source")
        }

        val workRoot = context.getExternalFilesDir(null) ?: context.cacheDir
        val stage = File(workRoot, "olddata_stage")
        val zipFile = File(workRoot, "olddata_out.zip")

        try {
            // 一、把源目录整份搬到暂存目录
            if (!stageSource(context, stage)) {
                return Outcome(false, error = "no_channel")
            }

            // 二、打成 zip(顶层放包名目录,解压就还原)
            val topDir = File(SOURCE_DIR).name.ifBlank { "com.pi.czrxdfirst" }
            val zipped = runCatching { zipTree(stage, topDir, zipFile, onProgress) }
                .getOrElse { null } ?: return Outcome(false, error = "zip_failed")
            if (zipFile.length() <= 0L) return Outcome(false, error = "zip_failed")

            // 三、落到目标目录
            val destPath = deploy(context, zipFile, zipName)
                ?: return Outcome(false, error = "deploy_failed")

            return Outcome(true, zipPath = destPath, files = zipped.first, bytes = zipped.second)
        } finally {
            runCatching { stage.deleteRecursively() }
            runCatching { zipFile.delete() }
        }
    }

    /**
     * 特权拷贝:root / Shizuku 把 SOURCE_DIR 里所有内容 cp 到 stage。
     * 先把暂存目录放本应用的外部私有目录(特权身份读写都通);
     * 万一那一路被挡,再退回公共目录下的隐藏暂存夹。
     */
    private fun stageSource(context: Context, stage: File): Boolean {
        runCatching { stage.deleteRecursively() }
        // 一、app 自己读得到就直接拷(安卓 10 及以下、或已放开所有文件访问的机器)
        if (copyDirect(File(SOURCE_DIR), stage) && hasContent(stage)) return true
        runCatching { stage.deleteRecursively() }
        // 二、特权通道
        if (copyTo(context, stage)) return hasContent(stage)

        val alt = File(DEST_DIR, ".stage_tmp")
        runCatching { alt.deleteRecursively() }
        if (copyTo(context, alt) && hasContent(alt)) {
            runCatching { alt.copyRecursively(stage, overwrite = true) }
            runCatching { alt.deleteRecursively() }
            return hasContent(stage)
        }
        runCatching { alt.deleteRecursively() }
        return false
    }

    private fun hasContent(dir: File): Boolean = runCatching {
        (dir.listFiles() ?: emptyArray()).isNotEmpty()
    }.getOrDefault(false)

    /** app 自己直读源目录往暂存里拷;一个文件都没拷到就当这条通道不可用 */
    private fun copyDirect(source: File, stage: File): Boolean {
        if (!source.isDirectory) return false
        var copied = 0
        val stack = ArrayDeque<Pair<File, File>>()
        stack.addLast(source to stage)
        val buffer = ByteArray(256 * 1024)
        while (stack.isNotEmpty()) {
            val (from, to) = stack.removeLast()
            val children = runCatching { from.listFiles() }.getOrNull() ?: continue
            if (!to.isDirectory) to.mkdirs()
            for (child in children) {
                val out = File(to, child.name)
                if (runCatching { child.isDirectory }.getOrDefault(false)) {
                    stack.addLast(child to out)
                } else {
                    val ok = runCatching {
                        out.parentFile?.mkdirs()
                        child.inputStream().use { input ->
                            out.outputStream().use { output -> input.copyTo(output, buffer.size) }
                        }
                        true
                    }.getOrDefault(false)
                    if (ok) copied++
                }
            }
        }
        return copied > 0
    }

    /** 跑一次 cp 脚本;返回成功与否看命令退出码 */
    private fun copyTo(context: Context, stage: File): Boolean {
        val scriptDir = context.getExternalFilesDir(null) ?: context.cacheDir
        val script = File(scriptDir, "zaka_olddata_copy.sh")
        return runCatching {
            script.writeText(
                buildString {
                    appendLine("#!/system/bin/sh")
                    appendLine("SRC=${shq(SOURCE_DIR)}")
                    appendLine("STAGE=${shq(stage.absolutePath)}")
                    appendLine("rm -rf \"\$STAGE\" 2>/dev/null")
                    appendLine("mkdir -p \"\$STAGE\" || exit 3")
                    appendLine("cp -rf \"\$SRC/.\" \"\$STAGE/\" 2>/dev/null")
                    appendLine("chmod -R 0777 \"\$STAGE\" 2>/dev/null")
                    appendLine("find \"\$STAGE\" -mindepth 1 | wc -l")
                }
            )
            val r = ShellUtil.execPrivileged(context, "sh ${shq(script.absolutePath)}", COPY_TIMEOUT_MS)
                ?: return false
            val count = r.output.lineSequence()
                .mapNotNull { it.trim().toIntOrNull() }
                .lastOrNull() ?: 0
            count > 0
        }.getOrDefault(false)
    }

    /** 遍历暂存目录压成 zip,返回 (文件数, 原始字节数) */
    private fun zipTree(
        stage: File,
        topDir: String,
        zipFile: File,
        onProgress: (Progress) -> Unit
    ): Pair<Int, Long> {
        val total = countFiles(stage)
        var files = 0
        var bytes = 0L
        val buffer = ByteArray(256 * 1024)

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile), 256 * 1024)).use { zos ->
            zos.putNextEntry(ZipEntry("$topDir/"))
            zos.closeEntry()

            val stack = ArrayDeque<Pair<File, String>>()
            stack.addLast(stage to topDir)
            while (stack.isNotEmpty()) {
                val (dir, prefix) = stack.removeLast()
                val children = dir.listFiles() ?: continue
                for (child in children) {
                    val entryName = "$prefix/${child.name}"
                    if (child.isDirectory) {
                        runCatching {
                            zos.putNextEntry(ZipEntry("$entryName/"))
                            zos.closeEntry()
                        }
                        stack.addLast(child to entryName)
                    } else if (child.isFile) {
                        try {
                            zos.putNextEntry(ZipEntry(entryName))
                            child.inputStream().use { input ->
                                while (true) {
                                    val read = input.read(buffer)
                                    if (read <= 0) break
                                    zos.write(buffer, 0, read)
                                    bytes += read.toLong()
                                }
                            }
                            zos.closeEntry()
                            files++
                        } catch (t: Throwable) {
                            // 单个文件读不了就跳过,别整包报废
                            runCatching { zos.closeEntry() }
                        }
                        onProgress(Progress(files, total.coerceAtLeast(files), bytes))
                    }
                }
            }
        }
        return files to bytes
    }

    private fun countFiles(dir: File): Int {
        var count = 0
        val stack = ArrayDeque<File>()
        stack.addLast(dir)
        while (stack.isNotEmpty()) {
            val cur = stack.removeLast()
            val children = cur.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) stack.addLast(child) else count++
            }
        }
        return count
    }

    /**
     * 把 zip 放到 /storage/emulated/0/遄懂/<名字>.zip。
     * 先试应用自己直写(有「所有文件访问」就能成),不行再走特权通道。
     * 返回最终路径,失败返回 null。
     */
    private fun deploy(context: Context, zipFile: File, zipName: String): String? {
        val destDir = File(DEST_DIR)
        val dest = File(destDir, zipName)
        val destPath = dest.absolutePath

        // 一、直写
        val direct = runCatching {
            if (!destDir.isDirectory && !destDir.mkdirs() && !destDir.isDirectory) return@runCatching false
            zipFile.inputStream().use { input ->
                dest.outputStream().use { output -> input.copyTo(output, 256 * 1024) }
            }
            dest.length() > 0L
        }.getOrDefault(false)
        if (direct) {
            runCatching { android.media.MediaScannerConnection.scanFile(context, arrayOf(destPath), null, null) }
            return destPath
        }

        // 二、特权通道
        val scriptDir = context.getExternalFilesDir(null) ?: context.cacheDir
        val script = File(scriptDir, "zaka_olddata_deploy.sh")
        val ok = runCatching {
            script.writeText(
                buildString {
                    appendLine("#!/system/bin/sh")
                    appendLine("SRC=${shq(zipFile.absolutePath)}")
                    appendLine("DIR=${shq(DEST_DIR)}")
                    appendLine("OUT=${shq(destPath)}")
                    appendLine("mkdir -p \"\$DIR\" || exit 2")
                    appendLine("cp -f \"\$SRC\" \"\$OUT\" || exit 3")
                    appendLine("chmod 0666 \"\$OUT\" 2>/dev/null")
                    appendLine("ls -l \"\$OUT\" 2>/dev/null")
                }
            )
            val r = ShellUtil.execPrivileged(context, "sh ${shq(script.absolutePath)}", DEPLOY_TIMEOUT_MS)
                ?: return@runCatching false
            if (!r.ok) return@runCatching false
            // 再核一次:文件真在、且不是 0 字节
            val check = ShellUtil.execPrivileged(
                context,
                "wc -c < ${shq(destPath)} 2>/dev/null",
                15_000L
            )
            val size = check?.output?.trim()?.lineSequence()
                ?.mapNotNull { it.trim().toLongOrNull() }?.lastOrNull() ?: 0L
            size > 0L
        }.getOrDefault(false)

        if (!ok) return null
        runCatching { android.media.MediaScannerConnection.scanFile(context, arrayOf(destPath), null, null) }
        return destPath
    }

    /** 单引号安全:路径里带单引号也不会把 sh 脚本打断 */
    private fun shq(raw: String): String = "'" + raw.replace("'", "'\\''") + "'"
}
