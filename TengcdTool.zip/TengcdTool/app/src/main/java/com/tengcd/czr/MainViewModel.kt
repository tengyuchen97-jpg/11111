package com.tengcd.czr

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.i18n.Strings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.inject.PtraceInjectFailure
import com.tengcd.czr.network.CardQueryInfo
import com.tengcd.czr.network.LocalCardGate
import com.tengcd.czr.network.NetworkClient
import com.tengcd.czr.network.T3Client
import com.tengcd.czr.network.T3Config
import com.tengcd.czr.service.HandoffWakeReceiver
import com.tengcd.czr.service.InjectService
import com.tengcd.czr.ui.message
import com.tengcd.czr.util.FolderImporter
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import com.tengcd.czr.util.ServiceState
import com.tengcd.czr.util.ShareCodec
import com.tengcd.czr.util.ShizukuShell
import com.tengcd.czr.util.ShellUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    val strings: LocalizedStrings by lazy { Strings.of(Locale.getDefault().language) }

    init {
        val ctx = getApplication<Application>()
        InjectionPrefs.init(ctx)
        ModuleStore.ensureBundled(ctx)
        ServiceState.syncFromPrefs()

        _state.update {
            it.copy(
                darkTheme = InjectionPrefs.darkTheme,
                mode = InjectionMode.from(InjectionPrefs.injectionMode),
                cardKey = InjectionPrefs.cardKey,
                localCardMode = InjectionPrefs.localCardMode,
                targetPackage = InjectionPrefs.targetPackage,
                importTargetPath = InjectionPrefs.importTargetPath
                    .ifBlank { FolderImporter.DEFAULT_TARGET_PATH },
                importReplaceAll = InjectionPrefs.importReplaceAll,
                t3BaseUrl = InjectionPrefs.t3BaseUrl,
                t3AppId = InjectionPrefs.t3AppId,
                t3AppKey = InjectionPrefs.t3AppKey,
                t3AesKey = InjectionPrefs.t3AesKey,
                loginCard = InjectionPrefs.t3Card,
                loginToken = InjectionPrefs.t3Token,
                loggedIn = tokenStillValid()
            )
        }

        restoreImportDirs()
        observeServiceState()
        InjectService.start(ctx)
        refreshRuntime()
    }

    // ---------------- 对外入口 ----------------

    fun onAction(action: UiAction) {
        when (action) {
            is UiAction.SelectTab -> _state.update { it.copy(tab = action.tab) }
            UiAction.ToggleTheme -> {
                val next = !_state.value.darkTheme
                InjectionPrefs.darkTheme = next
                _state.update { it.copy(darkTheme = next) }
            }
            UiAction.Inject -> inject()
            UiAction.LaunchTarget -> launchTarget()
            UiAction.RefreshRuntime -> refreshRuntime()
            UiAction.StartService -> InjectService.start(getApplication())
            is UiAction.SetMode -> {
                InjectionPrefs.injectionMode = action.mode.value
                _state.update { it.copy(mode = action.mode) }
            }
            is UiAction.SelectSoVariant -> selectSoVariant(action.variant)
            UiAction.PickLocalSo -> emit(UiEvent.PickLocalSoFile)
            UiAction.UseBuiltinSo -> useBuiltinSo()
            UiAction.UseLocalSo -> useLocalSo()
            UiAction.ClearLocalSo -> clearLocalSo()
            is UiAction.CardKeyChanged -> _state.update { it.copy(cardKey = action.text) }
            UiAction.QueryCard -> queryCard()
            UiAction.UnbindCard -> unbindCard()
            UiAction.ToggleLocalCardMode -> {
                val next = !_state.value.localCardMode
                InjectionPrefs.localCardMode = next
                _state.update { it.copy(localCardMode = next, cardInfo = null) }
            }
            UiAction.GenerateShareCode -> generateShareCode()
            UiAction.DismissDialog -> Unit
            UiAction.PickImportSource -> pickImportDir(forTarget = false)
            UiAction.PickImportTarget -> pickImportDir(forTarget = true)
            is UiAction.SetImportPath -> setImportPath(action.forTarget, action.path)
            UiAction.ClearImportSource -> clearImportSource()
            UiAction.ToggleImportReplaceAll -> {
                val next = !_state.value.importReplaceAll
                InjectionPrefs.importReplaceAll = next
                _state.update { it.copy(importReplaceAll = next) }
            }
            UiAction.RunImport -> runImport()
            UiAction.GrantShizuku -> grantShizuku()
            is UiAction.LoginCardChanged ->
                _state.update { it.copy(loginCard = action.text, loginError = null) }
            UiAction.Login -> login()
            UiAction.Logout -> logout()
            UiAction.ToggleT3Settings ->
                _state.update { it.copy(showT3Settings = !it.showT3Settings) }
            is UiAction.SetT3Field -> {
                _state.update {
                    when (action.field) {
                        T3Field.BASE_URL -> it.copy(t3BaseUrl = action.text)
                        T3Field.APP_ID -> it.copy(t3AppId = action.text)
                        T3Field.APP_KEY -> it.copy(t3AppKey = action.text)
                        T3Field.AES_KEY -> it.copy(t3AesKey = action.text)
                    }
                }
            }
            UiAction.SaveT3Config -> saveT3Config()
        }
    }

    // ---------------- T3 网络验证 ----------------

    /** 上次的 token 还没过期就直接进首页 */
    private fun tokenStillValid(): Boolean {
        val token = InjectionPrefs.t3Token
        if (token.isBlank()) return false
        val expire = InjectionPrefs.t3Expire
        return expire <= 0L || expire > System.currentTimeMillis()
    }

    private fun saveT3Config() {
        val cur = _state.value
        InjectionPrefs.t3BaseUrl = cur.t3BaseUrl
        InjectionPrefs.t3AppId = cur.t3AppId
        InjectionPrefs.t3AppKey = cur.t3AppKey
        InjectionPrefs.t3AesKey = cur.t3AesKey
        _state.update {
            it.copy(
                t3BaseUrl = InjectionPrefs.t3BaseUrl,
                t3AppId = InjectionPrefs.t3AppId,
                t3AppKey = InjectionPrefs.t3AppKey,
                t3AesKey = InjectionPrefs.t3AesKey,
                showT3Settings = false,
                loginError = null
            )
        }
        emit(UiEvent.Toast(strings.loginServerSaved))
    }

    private fun login() {
        val cur = _state.value
        if (cur.loginBusy) return
        val card = cur.loginCard.trim()
        if (card.isEmpty()) {
            _state.update { it.copy(loginError = strings.loginEmpty) }
            return
        }
        val config = T3Config(
            baseUrl = cur.t3BaseUrl.trim().trimEnd('/'),
            appId = cur.t3AppId.trim(),
            appKey = cur.t3AppKey.trim(),
            aesKey = cur.t3AesKey.trim()
        )
        if (!config.ready) {
            _state.update {
                it.copy(loginError = strings.loginNeedServer, showT3Settings = true)
            }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(loginBusy = true, loginError = null) }
            val ctx = getApplication<Application>()
            val device = T3Client.deviceId(ctx)
            val result = T3Client.login(ctx, config, card, device)
            if (result.ok) {
                InjectionPrefs.t3Token = result.token
                InjectionPrefs.t3Expire = result.expireAt
                InjectionPrefs.t3Card = card
                InjectionPrefs.cardKey = card
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loggedIn = true,
                        loginError = null,
                        loginToken = result.token,
                        loginExpire = result.expireText,
                        cardKey = card,
                        tab = AppTab.HOME
                    )
                }
                emit(UiEvent.Toast(strings.loginSuccess))
                refreshRuntime()
            } else {
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loginError = result.message.ifBlank { strings.loginFailed }
                    )
                }
            }
        }
    }

    private fun logout() {
        viewModelScope.launch {
            val config = T3Config.fromPrefs()
            val token = InjectionPrefs.t3Token
            val ctx = getApplication<Application>()
            if (config.ready && token.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    runCatching { T3Client.heartbeat(config, token, T3Client.deviceId(ctx)) }
                }
            }
            InjectionPrefs.t3Token = ""
            InjectionPrefs.t3Expire = 0L
            _state.update {
                it.copy(
                    loggedIn = false,
                    loginToken = "",
                    loginExpire = "",
                    loginError = null,
                    tab = AppTab.HOME,
                    cardInfo = null
                )
            }
        }
    }

    // ---------------- 运行态 ----------------

    private fun observeServiceState() {
        viewModelScope.launch {
            ServiceState.frameworkActive.collect { active ->
                _state.update { it.copy(frameworkActive = active) }
            }
        }
        viewModelScope.launch {
            ServiceState.serviceRunning.collect { running ->
                _state.update { it.copy(serviceRunning = running) }
            }
        }
    }

    fun refreshRuntime() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val target = InjectionPrefs.targetPackage
            val info = withContext(Dispatchers.IO) {
                val pids = PackageUtil.findPids(target)
                val dataDir = PackageUtil.dataDir(ctx, target)
                val label = try {
                    val pm = ctx.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(target, 0)).toString()
                } catch (t: Throwable) {
                    ""
                }
                RuntimeInfo(
                    installed = PackageUtil.isInstalled(ctx, target),
                    label = label,
                    pids = pids,
                    dirWritable = PermissionUtil.canWriteDir(File(dataDir ?: "", "files")),
                    sameUid = PackageUtil.sameUid(ctx, target),
                    rootAvailable = FolderImporter.hasRoot(),
                    channel = FolderImporter.channelState(
                        ctx,
                        InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH }
                    ),
                    importDirWritable = FolderImporter.canWrite(
                        File(InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH })
                    )
                )
            }
            _state.update {
                it.copy(
                    targetPackage = target,
                    targetLabel = info.label,
                    targetInstalled = info.installed,
                    targetRunning = info.pids.isNotEmpty(),
                    targetPid = info.pids.firstOrNull() ?: -1,
                    targetDirAccessible = info.dirWritable,
                    sameUid = info.sameUid,
                    localModuleReady = ModuleStore.isDownloaded(ctx),
                    localModulePath = ModuleStore.effectiveFile(ctx).absolutePath,
                    moduleVersion = InjectionPrefs.moduleVersion,
                    moduleMd5 = InjectionPrefs.moduleMd5,
                    remoteVersion = InjectionPrefs.remoteVersion,
                    soVariants = ModuleStore.BUILTIN_VARIANTS,
                    selectedSo = InjectionPrefs.soVariant,
                    soSource = InjectionPrefs.soSource,
                    activeSoPath = InjectionPrefs.modulePath,
                    localSoSourcePath = InjectionPrefs.localSoSourcePath,
                    localSoReady = ModuleStore.localFile(ctx).isFile,
                    soSize = ModuleStore.currentInfo(ctx).size,
                    soValid = ModuleStore.currentInfo(ctx).ready,
                    soPlaceholder = ModuleStore.currentInfo(ctx).placeholder,
                    frameworkError = InjectionPrefs.frameworkError,
                    frameworkLoadedPath = InjectionPrefs.frameworkPath,
                    writeChannel = info.channel.label,
                    writeChannelReady = info.channel.ready,
                    shizukuInstalled = info.channel.shizukuInstalled,
                    shizukuGranted = info.channel.shizukuGranted,
                    sdkInt = info.channel.sdkInt,
                    frameworkInstalled = XposedDetector.isFrameworkInstalled(ctx),
                    frameworkActive = InjectionPrefs.frameworkActive,
                    serviceRunning = ServiceState.serviceRunning.value,
                    rootAvailable = info.rootAvailable,
                    targetDirWritable = info.importDirWritable
                )
            }
        }
    }

    private data class RuntimeInfo(
        val installed: Boolean,
        val label: String,
        val pids: List<Int>,
        val dirWritable: Boolean,
        val sameUid: Boolean,
        val rootAvailable: Boolean,
        val importDirWritable: Boolean,
        val channel: FolderImporter.ChannelState
    )

    // ---------------- 写入通道 ----------------

    /** 申请 Shizuku 授权(界面收到事件后拉起授权框) */
    private fun grantShizuku() {
        val ctx = getApplication<Application>()
        if (!ShizukuShell.installed(ctx)) {
            emit(UiEvent.Toast(strings.shizukuNotInstalled))
            return
        }
        if (!ShizukuShell.alive()) {
            emit(UiEvent.Toast(strings.shizukuNotRunning))
            return
        }
        if (ShizukuShell.granted()) {
            emit(UiEvent.Toast(strings.shizukuGranted))
            refreshRuntime()
            return
        }
        emit(UiEvent.RequestShizukuPermission)
    }

    /** 授权结果回来 */
    fun onShizukuResult(granted: Boolean) {
        emit(UiEvent.Toast(if (granted) strings.shizukuGranted else strings.shizukuDenied))
        refreshRuntime()
    }

    // ---------------- 注入 ----------------

    private fun inject() {
        val current = _state.value
        if (current.injecting) return

        // 注入前不再弹任何"请更新 / 请先准备"的对话框,也不再拿"模块没就绪"拦人:
        // 直接用当前选中的那份 SO 往里打,缺的东西下面现补。
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }
        if (current.mode == InjectionMode.PROCESS && !current.targetRunning) {
            emit(UiEvent.Toast(strings.targetNotRunning))
            return
        }

        viewModelScope.launch {
            val ctx = getApplication<Application>()
            withContext(Dispatchers.IO) {
                // 本机 SO 被删了就自动退回内置;内置变体没铺过的现铺一遍
                if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                    !ModuleStore.localFile(ctx).isFile
                ) {
                    InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
                }
                ModuleStore.ensureBundled(ctx)
                ModuleStore.refreshPrefs(ctx)
            }
            _state.update { it.copy(injecting = true) }
            emit(UiEvent.Toast(strings.injectRunning))
            ServiceState.lastInjectOk.value = null
            InjectService.inject(
                getApplication(),
                current.mode,
                current.targetPackage
            )
            val ok = awaitInjectResult()
            val raw = ServiceState.lastInjectDetail.value
            val kind = raw
                ?.let { runCatching { PtraceInjectFailure.valueOf(it.substringBefore(':')) }.getOrNull() }
                ?: PtraceInjectFailure.UNKNOWN
            val detail = raw?.substringAfter(':', "")?.trim()?.takeIf { it.isNotEmpty() }
            _state.update { it.copy(injecting = false, injectDetail = detail) }
            if (ok == true) {
                emit(UiEvent.Toast(strings.injectDone))
            } else {
                emit(UiEvent.Toast(kind.message(strings)))
            }
            refreshRuntime()
        }
    }

    private suspend fun awaitInjectResult(): Boolean? {
        repeat(25) {
            delay(300)
            ServiceState.lastInjectOk.value?.let { return it }
        }
        return ServiceState.lastInjectOk.value
    }

    private fun launchTarget() {
        val current = _state.value
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.installTargetFirst))
            return
        }
        val ctx = getApplication<Application>()
        val launched = PackageUtil.launch(ctx, current.targetPackage)
        if (!launched) {
            emit(UiEvent.Toast(strings.targetNotFound))
            return
        }
        if (current.mode == InjectionMode.PROCESS) {
            viewModelScope.launch {
                delay(3000)
                HandoffWakeReceiver.send(ctx, current.mode, current.targetPackage)
                refreshRuntime()
            }
        }
    }

    // ---------------- SO 选择 ----------------

    /** 选中哪个变体,注入就用哪个 */
    private fun selectSoVariant(variant: String) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, variant) }
            _state.update {
                it.copy(
                    selectedSo = variant,
                    soSource = InjectionPrefs.SO_SOURCE_BUILTIN,
                    activeSoPath = InjectionPrefs.modulePath
                )
            }
            emit(UiEvent.Toast(strings.soSwitchedTo + " " + variant))
            refreshRuntime()
        }
    }

    /** 从"本机 SO"切回内置变体 */
    private fun useBuiltinSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, _state.value.selectedSo) }
            emit(UiEvent.Toast(strings.soSwitchedBuiltin))
            refreshRuntime()
        }
    }

    /** 已经导入过本机 SO 的话,直接切过去用,不必再选一次文件 */
    private fun useLocalSo() {
        val ctx = getApplication<Application>()
        if (!ModuleStore.localFile(ctx).isFile) {
            emit(UiEvent.PickLocalSoFile)
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoSwitched))
            refreshRuntime()
        }
    }

    private fun clearLocalSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.clearLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoCleared))
            refreshRuntime()
        }
    }

    /** 界面把用户从本机挑中的那个 so 交过来(文件选择器回调) */
    fun onLocalSoPicked(uri: Uri?) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val input = ctx.contentResolver.openInputStream(uri)
                        ?: return@withContext null
                    ModuleStore.importLocalSo(ctx, input, uri.toString())
                } catch (t: Throwable) {
                    null
                }
            }
            if (saved == null) {
                emit(UiEvent.Toast(strings.localSoFailed))
            } else {
                emit(UiEvent.Toast(strings.localSoLoaded))
            }
            refreshRuntime()
        }
    }

    // ---------------- 卡密 ----------------

    private fun queryCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (_state.value.localCardMode) {
                LocalCardGate.bind(ctx, card)
                val info = LocalCardGate.query(ctx, card)
                _state.update { it.copy(cardQuerying = false, cardInfo = info) }
                InjectionPrefs.cardKey = card
                if (!info.valid) emit(UiEvent.Toast(strings.cardInvalid))
                return@launch
            }

            val result = NetworkClient.queryCard(apiBase(), card, LocalCardGate.deviceId(ctx))
            val info = parseCardInfo(card, result.ok, result.body)
            _state.update { it.copy(cardQuerying = false, cardInfo = info) }
            if (info == null) {
                emit(UiEvent.Toast(strings.requestFailed))
            } else {
                if (info.valid) InjectionPrefs.cardKey = card
                else if (info.banned) emit(UiEvent.Toast(strings.banned))
                else emit(UiEvent.Toast(strings.cardInvalid))
            }
        }
    }

    private fun unbindCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }
            if (_state.value.localCardMode) {
                val ok = LocalCardGate.unbind(ctx, card)
                _state.update {
                    it.copy(cardQuerying = false, cardInfo = LocalCardGate.query(ctx, card))
                }
                emit(UiEvent.Toast(if (ok) strings.unbindSuccess else strings.cardInvalid))
                return@launch
            }
            val result = NetworkClient.unbindCard(apiBase(), card, LocalCardGate.deviceId(ctx))
            _state.update { it.copy(cardQuerying = false) }
            if (result.ok) {
                emit(UiEvent.Toast(strings.unbindSuccess))
                queryCard()
            } else {
                emit(UiEvent.Toast(strings.requestFailed))
            }
        }
    }

    private fun parseCardInfo(card: String, ok: Boolean, body: String): CardQueryInfo? {
        if (!ok) return null
        return try {
            var json = JSONObject(body.trim())
            if (json.optJSONObject("data") != null) json = json.optJSONObject("data")!!
            val valid = json.optBoolean("valid", json.optInt("code", 1) == 0)
            CardQueryInfo(
                card = card,
                expireTime = json.optString("expire", json.optString("expire_time", "")),
                remainCount = json.optInt("remain", json.optInt("count", -1)),
                unbindCount = json.optInt("unbind_count", -1),
                boundDevice = json.optString("device", json.optString("bound_device", "")),
                banned = json.optBoolean("banned", false),
                valid = valid,
                message = json.optString("message", json.optString("msg", ""))
            )
        } catch (t: Throwable) {
            null
        }
    }

    private fun apiBase(): String {
        val url = InjectionPrefs.configUrl
        val idx = url.indexOf("/api")
        return if (idx > 0) url.substring(0, idx) else url.substringBeforeLast('/', url)
    }

    private fun generateShareCode() {
        val payload = buildString {
            append("pkg=").append(InjectionPrefs.targetPackage).append(';')
            append("so=").append(_state.value.localModulePath ?: "").append(';')
            append("card=").append(_state.value.cardKey)
        }
        val code = ShareCodec.encode(payload)
        _state.update { it.copy(shareCode = code) }
        emit(UiEvent.Toast(strings.copied))
    }


    // ---------------- 资源导入(左源文件夹 -> 右目标文件夹 覆盖) ----------------

    private fun pickImportDir(forTarget: Boolean) = emit(UiEvent.PickFolderTree(forTarget))

    /** 界面把选中的源文件夹交过来(SAF 回调) */
    fun onImportSourcePicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (t: Throwable) {
                // 有些 ROM 的 DocumentsUI 不给持久权限,这一轮能读就行
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importSourceUri = uri.toString()
            _state.update {
                it.copy(
                    importSourceUri = uri.toString(),
                    importSourcePath = stat.path,
                    importSourceName = stat.name,
                    importSourceFiles = stat.files,
                    importSourceDirs = stat.dirs,
                    importSourceBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importSourcePicked + " · " + stat.files + " " + strings.importFileUnit))
            }
        }
    }

    /** 界面把选中的目标文件夹交过来(SAF 回调) */
    fun onImportTargetPicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (t: Throwable) {
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importTargetUri = uri.toString()
            InjectionPrefs.importTargetPath = ""
            _state.update {
                it.copy(
                    importTargetUri = uri.toString(),
                    importTargetPath = stat.path,
                    importTargetName = stat.name,
                    importTargetFiles = stat.files,
                    importTargetBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importTargetPicked))
            }
            refreshRuntime()
        }
    }

    /** 手输绝对路径(Android/data 这类 SAF 选不到的地方走这条) */
    private fun setImportPath(forTarget: Boolean, raw: String) {
        val path = raw.trim().trimEnd('/')
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            if (path.isBlank()) {
                if (forTarget) {
                    InjectionPrefs.importTargetUri = null
                    InjectionPrefs.importTargetPath = ""
                    _state.update {
                        it.copy(
                            importTargetUri = null, importTargetPath = "",
                            importTargetName = "", importTargetFiles = 0, importTargetBytes = 0
                        )
                    }
                }
                return@launch
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statPath(File(path)) }
            if (forTarget) {
                InjectionPrefs.importTargetUri = null
                InjectionPrefs.importTargetPath = path
                _state.update {
                    it.copy(
                        importTargetUri = null,
                        importTargetPath = path,
                        importTargetName = stat.name,
                        importTargetFiles = stat.files,
                        importTargetBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(
                    UiEvent.Toast(
                        if (File(path).isDirectory) strings.importTargetSet
                        else strings.importTargetWillCreate
                    )
                )
            } else {
                if (!File(path).isDirectory) {
                    emit(UiEvent.Toast(strings.importNoAccess))
                    return@launch
                }
                InjectionPrefs.importSourceUri = null
                _state.update {
                    it.copy(
                        importSourceUri = null,
                        importSourcePath = path,
                        importSourceName = stat.name,
                        importSourceFiles = stat.files,
                        importSourceDirs = stat.dirs,
                        importSourceBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(UiEvent.Toast(strings.importSourcePicked))
            }
            refreshRuntime()
        }
    }

    private fun clearImportSource() {
        InjectionPrefs.importSourceUri = null
        _state.update {
            it.copy(
                importSourceUri = null,
                importSourcePath = "",
                importSourceName = "",
                importSourceFiles = 0,
                importSourceDirs = 0,
                importSourceBytes = 0L,
                importFinished = false,
                importFailed = false,
                importMessage = null
            )
        }
    }

    /** 冷启动把上次的源/目标找回来 */
    private fun restoreImportDirs() {
        InjectionPrefs.importSourceUri?.let { onImportSourcePicked(Uri.parse(it), silent = true) }
        val targetUri = InjectionPrefs.importTargetUri
        if (!targetUri.isNullOrBlank()) {
            onImportTargetPicked(Uri.parse(targetUri), silent = true)
        } else {
            _state.update { it.copy(importTargetPath = InjectionPrefs.importTargetPath) }
        }
    }

    private fun buildSource(cur: UiState): FolderImporter.Source? {
        val uri = cur.importSourceUri
        if (!uri.isNullOrBlank()) return FolderImporter.Source.Tree(Uri.parse(uri))
        val path = cur.importSourcePath
        if (path.isNotBlank() && File(path).isDirectory) return FolderImporter.Source.Path(File(path))
        return null
    }

    private fun buildTarget(cur: UiState): FolderImporter.Target? {
        val uri = cur.importTargetUri
        if (!uri.isNullOrBlank()) return FolderImporter.Target.Tree(Uri.parse(uri))
        val path = cur.importTargetPath
        if (path.isNotBlank()) return FolderImporter.Target.Path(File(path))
        return null
    }

    private fun runImport() {
        val cur = _state.value
        if (cur.importing) return
        val source = buildSource(cur)
        if (source == null) {
            emit(UiEvent.Toast(strings.importPickNone))
            return
        }
        val target = buildTarget(cur)
        if (target == null) {
            emit(UiEvent.Toast(strings.importTargetMissing))
            return
        }
        val ctx = getApplication<Application>()
        // 安卓 12 以上写别的应用目录要先有通道,没有就直说"尚未就绪",别跑了才报错
        val targetPath = (target as? FolderImporter.Target.Path)?.dir?.absolutePath
            ?: (target as? FolderImporter.Target.Tree)?.let { FolderImporter.displayPath(ctx, it.uri) }
        val channel = FolderImporter.channelState(ctx, targetPath)
        if (!channel.ready) {
            emit(UiEvent.Toast(strings.importNotReady))
            return
        }
        viewModelScope.launch {
            _state.update {
                it.copy(
                    importing = true,
                    importFinished = false,
                    importFailed = false,
                    importProgressFiles = 0,
                    importProgressTotal = cur.importSourceFiles,
                    importProgressBytes = 0L,
                    importChannelLabel = null,
                    importMessage = null
                )
            }
            val outcome = withContext(Dispatchers.IO) {
                FolderImporter.run(ctx, source, target, cur.importReplaceAll) { p ->
                    _state.update {
                        it.copy(
                            importProgressFiles = p.copied,
                            importProgressBytes = p.bytes,
                            importProgressTotal = if (p.total > 0) p.total else it.importProgressTotal
                        )
                    }
                }
            }
            val channelLabel = when (outcome.channel) {
                FolderImporter.CHANNEL_SAF -> strings.importChannelSaf
                FolderImporter.CHANNEL_DIRECT -> strings.importChannelDirect
                FolderImporter.CHANNEL_ROOT -> strings.importChannelRoot
                else -> "-"
            }
            _state.update {
                it.copy(
                    importing = false,
                    importFinished = true,
                    importFailed = !outcome.ok,
                    importProgressFiles = outcome.copied,
                    importProgressBytes = outcome.bytes,
                    importChannelLabel = channelLabel,
                    importMessage = if (outcome.ok) {
                        strings.importDone + " · " + outcome.copied + " " + strings.importFileUnit +
                            " · " + FolderImporter.formatSize(outcome.bytes)
                    } else {
                        strings.importFailedMsg + ": " +
                            (outcome.error ?: strings.importNoAccess)
                    }
                )
            }
            emit(UiEvent.Toast(if (outcome.ok) strings.importDone else strings.importFailedMsg))
            refreshRuntime()
        }
    }

    // ---------------- 小工具 ----------------

    private fun emit(event: UiEvent) {
        _events.trySend(event)
    }

    fun progressPercent(): Int = (_state.value.downloadProgress * 100f).roundToInt()
}
