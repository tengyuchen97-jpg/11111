package com.tengcd.czr

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.i18n.Strings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.inject.PtraceInjectFailure
import com.tengcd.czr.network.CardQueryInfo
import com.tengcd.czr.network.ConfigParser
import com.tengcd.czr.network.LocalCardGate
import com.tengcd.czr.network.NetworkClient
import com.tengcd.czr.network.RemoteConfig
import com.tengcd.czr.network.SoDownloader
import com.tengcd.czr.service.HandoffWakeReceiver
import com.tengcd.czr.service.InjectService
import com.tengcd.czr.ui.message
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import com.tengcd.czr.util.ServiceState
import com.tengcd.czr.util.ShareCodec
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    val strings: LocalizedStrings by lazy { Strings.of(Locale.getDefault().language) }

    init {
        val ctx = getApplication<Application>()
        InjectionPrefs.init(ctx)
        ModuleStore.ensureBundled(ctx)
        ServiceState.syncFromPrefs()

        _state.update {
            it.copy(
                darkTheme = InjectionPrefs.darkTheme,
                mode = InjectionMode.from(InjectionPrefs.injectionMode),
                cardKey = InjectionPrefs.cardKey,
                localCardMode = InjectionPrefs.localCardMode,
                targetPackage = InjectionPrefs.targetPackage
            )
        }

        observeServiceState()
        InjectService.start(ctx)
        refreshRuntime()
        loadConfigIfNeeded()
    }

    // ---------------- 对外入口 ----------------

    fun onAction(action: UiAction) {
        when (action) {
            is UiAction.SelectTab -> _state.update { it.copy(tab = action.tab) }
            UiAction.ToggleTheme -> {
                val next = !_state.value.darkTheme
                InjectionPrefs.darkTheme = next
                _state.update { it.copy(darkTheme = next) }
            }
            UiAction.CheckUpdate -> checkUpdate()
            UiAction.DownloadModule -> downloadModule()
            UiAction.Inject -> inject()
            UiAction.LaunchTarget -> launchTarget()
            UiAction.RefreshRuntime -> refreshRuntime()
            UiAction.StartService -> InjectService.start(getApplication())
            is UiAction.SetMode -> {
                InjectionPrefs.injectionMode = action.mode.value
                _state.update { it.copy(mode = action.mode) }
            }
            is UiAction.SelectSoVariant -> selectSoVariant(action.variant)
            UiAction.PickLocalSo -> emit(UiEvent.PickLocalSoFile)
            UiAction.UseBuiltinSo -> useBuiltinSo()
            UiAction.ClearLocalSo -> clearLocalSo()
            is UiAction.CardKeyChanged -> _state.update { it.copy(cardKey = action.text) }
            UiAction.QueryCard -> queryCard()
            UiAction.UnbindCard -> unbindCard()
            UiAction.ToggleLocalCardMode -> {
                val next = !_state.value.localCardMode
                InjectionPrefs.localCardMode = next
                _state.update { it.copy(localCardMode = next, cardInfo = null) }
            }
            UiAction.GenerateShareCode -> generateShareCode()
            UiAction.DismissDialog -> Unit
        }
    }

    // ---------------- 运行态 ----------------

    private fun observeServiceState() {
        viewModelScope.launch {
            ServiceState.frameworkActive.collect { active ->
                _state.update { it.copy(frameworkActive = active) }
            }
        }
        viewModelScope.launch {
            ServiceState.serviceRunning.collect { running ->
                _state.update { it.copy(serviceRunning = running) }
            }
        }
    }

    fun refreshRuntime() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val target = InjectionPrefs.targetPackage
            val info = withContext(Dispatchers.IO) {
                val pids = PackageUtil.findPids(target)
                val dataDir = PackageUtil.dataDir(ctx, target)
                val label = try {
                    val pm = ctx.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(target, 0)).toString()
                } catch (t: Throwable) {
                    ""
                }
                RuntimeInfo(
                    installed = PackageUtil.isInstalled(ctx, target),
                    label = label,
                    pids = pids,
                    dirWritable = PermissionUtil.canWriteDir(File(dataDir ?: "", "files")),
                    sameUid = PackageUtil.sameUid(ctx, target)
                )
            }
            _state.update {
                it.copy(
                    targetPackage = target,
                    targetLabel = info.label,
                    targetInstalled = info.installed,
                    targetRunning = info.pids.isNotEmpty(),
                    targetPid = info.pids.firstOrNull() ?: -1,
                    targetDirAccessible = info.dirWritable,
                    sameUid = info.sameUid,
                    localModuleReady = ModuleStore.isDownloaded(ctx),
                    localModulePath = ModuleStore.effectiveFile(ctx).absolutePath,
                    moduleVersion = InjectionPrefs.moduleVersion,
                    moduleMd5 = InjectionPrefs.moduleMd5,
                    remoteVersion = InjectionPrefs.remoteVersion,
                    soVariants = ModuleStore.BUILTIN_VARIANTS,
                    selectedSo = InjectionPrefs.soVariant,
                    soSource = InjectionPrefs.soSource,
                    activeSoPath = InjectionPrefs.modulePath,
                    localSoSourcePath = InjectionPrefs.localSoSourcePath,
                    localSoReady = ModuleStore.localFile(ctx).isFile,
                    frameworkInstalled = XposedDetector.isFrameworkInstalled(ctx),
                    frameworkActive = InjectionPrefs.frameworkActive,
                    serviceRunning = ServiceState.serviceRunning.value
                )
            }
        }
    }

    private data class RuntimeInfo(
        val installed: Boolean,
        val label: String,
        val pids: List<Int>,
        val dirWritable: Boolean,
        val sameUid: Boolean
    )

    // ---------------- 更新 ----------------

    private fun loadConfigIfNeeded() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            if (InjectionPrefs.remoteVersion != null) {
                refreshRuntime()
            }
            val result = NetworkClient.fetchConfig(InjectionPrefs.configUrl)
            val config = if (result.ok) ConfigParser.parse(result.body) else null
            if (config != null) {
                applyConfig(config)
                _state.update { it.copy(announcementLoading = false) }
            } else {
                _state.update {
                    it.copy(
                        announcementLoading = false,
                        announcementFailed = InjectionPrefs.announcement == null,
                        announcement = InjectionPrefs.announcement
                    )
                }
            }
        }
    }

    private fun applyConfig(config: RemoteConfig) {
        if (config.announcement.isNotBlank()) {
            InjectionPrefs.announcement = config.announcement
        }
        if (config.version.isNotBlank()) {
            InjectionPrefs.remoteVersion = config.version
        }
        if (config.targetPackage.isNotBlank()) {
            InjectionPrefs.targetPackage = config.targetPackage
        }
        if (config.soUrl.isNotBlank()) {
            InjectionPrefs.soUrl = config.soUrl
        }
        _state.update {
            it.copy(
                announcement = InjectionPrefs.announcement,
                announcementFailed = false,
                remoteVersion = InjectionPrefs.remoteVersion
            )
        }
    }

    private fun checkUpdate() {
        viewModelScope.launch {
            _state.update { it.copy(checking = true) }
            emit(UiEvent.Toast(strings.fetchingVersion))
            val ctx = getApplication<Application>()
            val result = NetworkClient.fetchConfig(InjectionPrefs.configUrl)
            val config = if (result.ok) ConfigParser.parse(result.body) else null
            _state.update { it.copy(checking = false) }

            if (config == null) {
                emit(UiEvent.Toast(strings.networkFailed))
                return@launch
            }
            applyConfig(config)

            if (config.soUrl.isBlank()) {
                emit(UiEvent.Toast(strings.updateMissingUrl))
                return@launch
            }
            // moduleVersion 现在是"当前选中的 SO 名字",版本比较要用远端记录的那个
            val current = InjectionPrefs.remoteVersion
            val upToDate = current != null && current == config.version && ModuleStore.isDownloaded(ctx)
            if (upToDate) {
                emit(UiEvent.Toast(strings.currentIsLatest))
            } else {
                emit(
                    UiEvent.Dialog(
                        title = strings.foundNewVersion,
                        message = if (config.updateLog.isNotBlank()) config.updateLog else strings.moduleHasUpdate,
                        confirmText = strings.downloadNow,
                        cancelText = strings.cancel,
                        confirm = { downloadModule() }
                    )
                )
            }
            refreshRuntime()
        }
    }

    private fun downloadModule() {
        if (_state.value.downloading) return
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val config = RemoteConfig(
                version = InjectionPrefs.remoteVersion ?: "",
                soUrl = InjectionPrefs.soUrl ?: "",
                soMd5 = InjectionPrefs.moduleMd5 ?: ""
            )
            _state.update {
                it.copy(downloading = true, downloadProgress = 0f, downloadedBytes = 0, totalBytes = 0)
            }
            val result = SoDownloader.download(ctx, config) { done, total ->
                _state.update {
                    it.copy(
                        downloadedBytes = done,
                        totalBytes = total,
                        downloadProgress = if (total > 0) done.toFloat() / total.toFloat() else 0f
                    )
                }
            }
            _state.update { it.copy(downloading = false) }
            when {
                result.ok -> {
                    emit(UiEvent.Toast(strings.moduleUpdateSuccess))
                    InjectionPrefs.frameworkActive = false
                }
                result.message == "md5_mismatch" -> emit(UiEvent.Toast(strings.verifyFailedKeepOriginal))
                result.message == "missing_url" -> emit(UiEvent.Toast(strings.updateMissingUrl))
                result.message == "write_failed" -> emit(UiEvent.Toast(strings.moduleReplaceFailed))
                else -> emit(UiEvent.Toast(strings.downloadFailed))
            }
            refreshRuntime()
        }
    }

    // ---------------- 注入 ----------------

    private fun inject() {
        val current = _state.value
        if (current.injecting) return

        // 注入前不再弹任何"请更新 / 请先准备"的对话框,也不再拿"模块没就绪"拦人:
        // 直接用当前选中的那份 SO 往里打,缺的东西下面现补。
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }
        if (current.mode == InjectionMode.PROCESS && !current.targetRunning) {
            emit(UiEvent.Toast(strings.targetNotRunning))
            return
        }

        viewModelScope.launch {
            val ctx = getApplication<Application>()
            withContext(Dispatchers.IO) {
                // 本机 SO 被删了就自动退回内置;内置变体没铺过的现铺一遍
                if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                    !ModuleStore.localFile(ctx).isFile
                ) {
                    InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
                }
                ModuleStore.ensureBundled(ctx)
                ModuleStore.refreshPrefs(ctx)
            }
            _state.update { it.copy(injecting = true) }
            emit(UiEvent.Toast(strings.injectRunning))
            ServiceState.lastInjectOk.value = null
            InjectService.inject(
                getApplication(),
                current.mode,
                current.targetPackage
            )
            val ok = awaitInjectResult()
            _state.update { it.copy(injecting = false) }
            if (ok == true) {
                emit(UiEvent.Toast(strings.injectDone))
            } else {
                val kind = ServiceState.lastInjectDetail.value
                    ?.let { runCatching { PtraceInjectFailure.valueOf(it.substringBefore(':')) }.getOrNull() }
                    ?: PtraceInjectFailure.UNKNOWN
                emit(UiEvent.Toast(kind.message(strings)))
            }
            refreshRuntime()
        }
    }

    private suspend fun awaitInjectResult(): Boolean? {
        repeat(25) {
            delay(300)
            ServiceState.lastInjectOk.value?.let { return it }
        }
        return ServiceState.lastInjectOk.value
    }

    private fun launchTarget() {
        val current = _state.value
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.installTargetFirst))
            return
        }
        val ctx = getApplication<Application>()
        val launched = PackageUtil.launch(ctx, current.targetPackage)
        if (!launched) {
            emit(UiEvent.Toast(strings.targetNotFound))
            return
        }
        if (current.mode == InjectionMode.PROCESS) {
            viewModelScope.launch {
                delay(3000)
                HandoffWakeReceiver.send(ctx, current.mode, current.targetPackage)
                refreshRuntime()
            }
        }
    }

    // ---------------- SO 选择 ----------------

    /** 选中哪个变体,注入就用哪个 */
    private fun selectSoVariant(variant: String) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, variant) }
            _state.update {
                it.copy(
                    selectedSo = variant,
                    soSource = InjectionPrefs.SO_SOURCE_BUILTIN,
                    activeSoPath = InjectionPrefs.modulePath
                )
            }
            emit(UiEvent.Toast(strings.soSwitchedTo + " " + variant))
            refreshRuntime()
        }
    }

    /** 从"本机 SO"切回内置变体 */
    private fun useBuiltinSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, _state.value.selectedSo) }
            emit(UiEvent.Toast(strings.soSwitchedBuiltin))
            refreshRuntime()
        }
    }

    private fun clearLocalSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.clearLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoCleared))
            refreshRuntime()
        }
    }

    /** 界面把用户从本机挑中的那个 so 交过来(文件选择器回调) */
    fun onLocalSoPicked(uri: Uri?) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val input = ctx.contentResolver.openInputStream(uri)
                        ?: return@withContext null
                    ModuleStore.importLocalSo(ctx, input, uri.toString())
                } catch (t: Throwable) {
                    null
                }
            }
            if (saved == null) {
                emit(UiEvent.Toast(strings.localSoFailed))
            } else {
                emit(UiEvent.Toast(strings.localSoLoaded))
            }
            refreshRuntime()
        }
    }

    // ---------------- 卡密 ----------------

    private fun queryCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (_state.value.localCardMode) {
                LocalCardGate.bind(ctx, card)
                val info = LocalCardGate.query(ctx, card)
                _state.update { it.copy(cardQuerying = false, cardInfo = info) }
                InjectionPrefs.cardKey = card
                if (!info.valid) emit(UiEvent.Toast(strings.cardInvalid))
                return@launch
            }

            val result = NetworkClient.queryCard(apiBase(), card, LocalCardGate.deviceId(ctx))
            val info = parseCardInfo(card, result.ok, result.body)
            _state.update { it.copy(cardQuerying = false, cardInfo = info) }
            if (info == null) {
                emit(UiEvent.Toast(strings.requestFailed))
            } else {
                if (info.valid) InjectionPrefs.cardKey = card
                else if (info.banned) emit(UiEvent.Toast(strings.banned))
                else emit(UiEvent.Toast(strings.cardInvalid))
            }
        }
    }

    private fun unbindCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }
            if (_state.value.localCardMode) {
                val ok = LocalCardGate.unbind(ctx, card)
                _state.update {
                    it.copy(cardQuerying = false, cardInfo = LocalCardGate.query(ctx, card))
                }
                emit(UiEvent.Toast(if (ok) strings.unbindSuccess else strings.cardInvalid))
                return@launch
            }
            val result = NetworkClient.unbindCard(apiBase(), card, LocalCardGate.deviceId(ctx))
            _state.update { it.copy(cardQuerying = false) }
            if (result.ok) {
                emit(UiEvent.Toast(strings.unbindSuccess))
                queryCard()
            } else {
                emit(UiEvent.Toast(strings.requestFailed))
            }
        }
    }

    private fun parseCardInfo(card: String, ok: Boolean, body: String): CardQueryInfo? {
        if (!ok) return null
        return try {
            var json = JSONObject(body.trim())
            if (json.optJSONObject("data") != null) json = json.optJSONObject("data")!!
            val valid = json.optBoolean("valid", json.optInt("code", 1) == 0)
            CardQueryInfo(
                card = card,
                expireTime = json.optString("expire", json.optString("expire_time", "")),
                remainCount = json.optInt("remain", json.optInt("count", -1)),
                unbindCount = json.optInt("unbind_count", -1),
                boundDevice = json.optString("device", json.optString("bound_device", "")),
                banned = json.optBoolean("banned", false),
                valid = valid,
                message = json.optString("message", json.optString("msg", ""))
            )
        } catch (t: Throwable) {
            null
        }
    }

    private fun apiBase(): String {
        val url = InjectionPrefs.configUrl
        val idx = url.indexOf("/api")
        return if (idx > 0) url.substring(0, idx) else url.substringBeforeLast('/', url)
    }

    private fun generateShareCode() {
        val payload = buildString {
            append("pkg=").append(InjectionPrefs.targetPackage).append(';')
            append("so=").append(_state.value.localModulePath ?: "").append(';')
            append("card=").append(_state.value.cardKey)
        }
        val code = ShareCodec.encode(payload)
        _state.update { it.copy(shareCode = code) }
        emit(UiEvent.Toast(strings.copied))
    }

    // ---------------- 小工具 ----------------

    private fun emit(event: UiEvent) {
        _events.trySend(event)
    }

    fun progressPercent(): Int = (_state.value.downloadProgress * 100f).roundToInt()
}
