package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.EmptyHint
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.SoVariantChips
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.components.TargetAppBadge
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.WarnOrange

@Composable
fun UpdateScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // ---------------- 公告 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Campaign, s.announcement, dark)
            Spacer(Modifier.height(10.dp))
            Text(
                text = state.announcement
                    ?: when {
                        state.announcementLoading -> s.announcementLoading
                        state.announcementFailed -> s.announcementFailed
                        else -> s.announcementEmpty
                    },
                style = MaterialTheme.typography.bodyMedium,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 本机 SO(公告下面) ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.FolderOpen, s.localSoTitle, dark)
            Spacer(Modifier.height(8.dp))
            Text(
                text = s.localSoDesc,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(10.dp))

            if (state.localSoReady) {
                KeyValueRow(
                    label = s.soSourceLabel,
                    value = "${s.soLocal} · ${s.soReady}",
                    dark = dark,
                    valueColor = OkGreen
                )
                state.localSoSourcePath?.let {
                    Spacer(Modifier.height(6.dp))
                    PathBox(text = "${s.localSoSourcePathLabel}: $it", dark = dark)
                }
                state.activeSoPath?.takeIf { state.soSource == "local" }?.let {
                    Spacer(Modifier.height(6.dp))
                    PathBox(text = "${s.localSoStagedPathLabel}: $it", dark = dark, accent = OkGreen)
                }
            } else {
                EmptyHint(s.localSoNone, dark)
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SecondaryActionButton(
                    text = s.localSoPick,
                    icon = Icons.Filled.FolderOpen,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.PickLocalSo) }

                if (state.localSoReady) {
                    SecondaryActionButton(
                        text = s.localSoClear,
                        icon = Icons.Filled.Delete,
                        dark = dark,
                        modifier = Modifier.weight(1f)
                    ) { onAction(UiAction.ClearLocalSo) }
                }
            }

            if (state.soSource == "local") {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(
                        text = s.localSoUseHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = OkGreen
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 模块概览(SO 选择 + 目标应用都在这里面) ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Widgets, s.moduleOverview, dark)
            Spacer(Modifier.height(8.dp))
            StatusRow(
                label = s.localModule,
                value = if (state.localModuleReady) s.statusReady else s.moduleNotDownloaded,
                dark = dark,
                dot = true,
                ok = state.localModuleReady
            )
            StatusRow(
                label = s.frameworkStatus,
                value = if (state.frameworkActive && state.frameworkInstalled) {
                    s.statusActivated
                } else {
                    s.statusNotActivated
                },
                dark = dark,
                dot = true,
                ok = state.frameworkActive && state.frameworkInstalled
            )
            StatusRow(
                label = s.remoteModuleVersion,
                value = state.remoteVersion ?: "-",
                dark = dark
            )
            state.moduleVersion?.let {
                KeyValueRow(s.moduleVersionLabel, it, dark)
            }
            KeyValueRow(
                label = if (state.serviceRunning) s.serviceRunning else s.serviceStopped,
                value = if (state.targetRunning) "${s.targetProcess}: ${state.targetPid}" else s.targetNotRunning,
                dark = dark,
                valueColor = if (state.serviceRunning) OkGreen else WarnOrange
            )

            Spacer(Modifier.height(12.dp))

            // ---- SO 选择 ----
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    text = s.soSelect,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = s.soSourceLabel + ": " + when (state.soSource) {
                        "local" -> s.soLocal
                        "remote" -> s.soRemote
                        else -> s.soBuiltin + " " + state.selectedSo
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.soSource == "local") OkGreen else TextSecondaryLight
                )
            }
            Spacer(Modifier.height(10.dp))
            SoVariantChips(
                options = state.soVariants,
                selected = state.selectedSo,
                active = state.soSource != "local",
                dark = dark
            ) { variant -> onAction(UiAction.SelectSoVariant(variant)) }

            Spacer(Modifier.height(12.dp))

            // ---- 目标应用:名字标红,包名放框里 ----
            TargetAppBadge(
                label = state.targetLabel.ifBlank { state.targetPackage }.ifBlank { "-" },
                pkg = state.targetPackage,
                dark = dark
            )
        }

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SecondaryActionButton(
                text = if (state.checking) s.checking else s.checkUpdate,
                icon = Icons.Filled.Refresh,
                dark = dark,
                modifier = Modifier.weight(1f),
                enabled = !state.checking
            ) { onAction(UiAction.CheckUpdate) }

            SecondaryActionButton(
                text = s.launchGame,
                icon = Icons.Filled.PlayArrow,
                dark = dark,
                modifier = Modifier.weight(1f)
            ) { onAction(UiAction.LaunchTarget) }
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = state.activeSoPath?.let { "${s.localPath} $it" } ?: s.pageDownloadModule,
            style = MaterialTheme.typography.bodySmall,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )

        Spacer(Modifier.height(28.dp))
    }
}
