package com.tengcd.czr.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import com.tengcd.czr.util.ServiceState
import java.io.File
import java.io.FileNotFoundException

/**
 * 对外的 so 分发口(内容提供者)。
 *
 *  - openFile(uri)         : 把模块 so 以文件流的形式给出去
 *  - query(uri)            : 版本 / md5 / 路径
 *  - call("get_module_path"): 直接拿路径
 *  - call("get_handoff")   : 拿 路径 + 目标包名
 *  - call("report_active") : 目标进程里的 HookInit 报告模块加载成功
 */
class SoProvider : ContentProvider() {

    override fun onCreate(): Boolean {
        context?.let { InjectionPrefs.init(it) }
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val ctx = context
        val cursor = MatrixCursor(arrayOf("path", "version", "md5", "size", "target"))
        val file = ctx?.let { ModuleStore.moduleFile(it) } ?: File("")
        cursor.addRow(
            arrayOf(
                file.absolutePath,
                InjectionPrefs.moduleVersion ?: "",
                if (file.isFile) Md5Util.md5(file) else "",
                if (file.isFile) file.length() else 0L,
                InjectionPrefs.targetPackage
            )
        )
        return cursor
    }

    override fun getType(uri: Uri): String = "application/vnd.android.package-archive"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0

    @Throws(FileNotFoundException::class)
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException("no context")
        val file = ModuleStore.moduleFile(ctx)
        if (!file.isFile) throw FileNotFoundException("module not ready")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val bundle = Bundle()
        when (method) {
            "get_module_path" -> {
                bundle.putString("path", InjectionPrefs.modulePath)
                bundle.putString("version", InjectionPrefs.moduleVersion)
                bundle.putString("target", InjectionPrefs.targetPackage)
                bundle.putBoolean("framework_active", InjectionPrefs.frameworkActive)
                ServiceState.syncFromPrefs()
            }
            "get_handoff" -> {
                val ctx = context
                if (ctx != null) {
                    ModuleStore.refreshPrefs(ctx)
                }
                val handoff = if (ctx != null) ModuleStore.readHandoff(ctx) else null
                val info = if (ctx != null) ModuleStore.currentInfo(ctx) else null
                bundle.putString("path", handoff?.path ?: InjectionPrefs.modulePath)
                bundle.putString(
                    "variant",
                    handoff?.variant ?: InjectionPrefs.soVariant
                )
                bundle.putString("target", handoff?.target ?: InjectionPrefs.targetPackage)
                bundle.putString("version", InjectionPrefs.moduleVersion)
                bundle.putString("md5", InjectionPrefs.moduleMd5)
                bundle.putLong("size", info?.size ?: 0L)
                bundle.putBoolean("ready", info?.ready ?: false)
            }
            "report_state" -> {
                val ok = arg == "ok"
                val detail = extras?.getString("detail")
                val process = extras?.getString("process").orEmpty()
                if (ok) {
                    InjectionPrefs.frameworkActive = true
                    InjectionPrefs.frameworkActiveAt = System.currentTimeMillis()
                    InjectionPrefs.frameworkError = null
                    InjectionPrefs.frameworkProcess = process
                    ServiceState.frameworkActive.value = true
                    val path = extras?.getString("path")
                    if (!path.isNullOrBlank()) InjectionPrefs.frameworkPath = path
                } else {
                    // 目标进程明确报失败 -> 立刻把「已激活」撤掉,别让界面挂着假状态
                    InjectionPrefs.frameworkActive = false
                    InjectionPrefs.frameworkActiveAt = 0L
                    InjectionPrefs.frameworkError = detail ?: "目标进程里模块没加载起来"
                    InjectionPrefs.frameworkProcess = process
                    ServiceState.onReportedFailure(InjectionPrefs.frameworkError)
                }
                bundle.putBoolean("ok", true)
            }
            "report_active" -> {
                // 只有目标进程报上来的激活才算数
                if (arg.isNullOrBlank() || arg == InjectionPrefs.targetPackage) {
                    ServiceState.onReportedActive()
                }
                bundle.putBoolean("ok", true)
            }
            "clear_active" -> {
                InjectionPrefs.frameworkActive = false
                ServiceState.frameworkActive.value = false
                bundle.putBoolean("ok", true)
            }
        }
        return bundle
    }
}
