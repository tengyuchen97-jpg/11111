package com.tengcd.czr

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdateAlt
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tengcd.czr.i18n.LocalStrings
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.DownloadProgressDialog
import com.tengcd.czr.ui.components.GlassIconButton
import com.tengcd.czr.ui.components.LiquidGlassDialog
import com.tengcd.czr.ui.screens.CardKeyScreen
import com.tengcd.czr.ui.screens.InjectScreen
import com.tengcd.czr.ui.screens.UpdateScreen
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.HonffxTheme
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.appBackgroundBrush

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            HonffxTheme(darkTheme = state.darkTheme) {
                CompositionLocalProvider(LocalStrings provides viewModel.strings) {
                    HonffxApp(viewModel, state)
                }
            }
        }
    }
}

@Composable
private fun HonffxApp(vm: MainViewModel, state: UiState) {
    val s = LocalStrings.current
    val context = LocalContext.current
    var dialog by remember { mutableStateOf<UiEvent.Dialog?>(null) }

    // 选本机的 so:走系统文件选择器,选完把 uri 交给 ViewModel 收进私有目录
    val soPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> vm.onLocalSoPicked(uri) }

    LaunchedEffect(Unit) {
        vm.events.collect { event ->
            when (event) {
                is UiEvent.Toast ->
                    Toast.makeText(context, event.text, Toast.LENGTH_SHORT).show()
                is UiEvent.Dialog ->
                    dialog = event
                UiEvent.PickLocalSoFile -> {
                    try {
                        soPicker.launch(arrayOf("*/*"))
                    } catch (t: Throwable) {
                        Toast.makeText(context, s.localSoFailed, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    LaunchedEffect(state.tab) {
        vm.refreshRuntime()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(appBackgroundBrush(state.darkTheme))
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = { TopBar(state, s) { vm.onAction(it) } },
            bottomBar = { BottomBar(state, s) { vm.onAction(it) } }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                when (state.tab) {
                    AppTab.UPDATE -> UpdateScreen(state, s, vm::onAction)
                    AppTab.INJECT -> InjectScreen(state, s, vm::onAction)
                    AppTab.CARD -> CardKeyScreen(state, s, vm::onAction)
                }
            }
        }

        if (state.downloading) {
            DownloadProgressDialog(
                dark = state.darkTheme,
                title = s.downloadingModule,
                message = "${(state.downloadProgress * 100).toInt()}%  ·  " +
                    "${state.downloadedBytes / 1024}KB / ${state.totalBytes / 1024}KB",
                progress = state.downloadProgress,
                indeterminate = state.totalBytes <= 0
            )
        }

        dialog?.let { dlg ->
            LiquidGlassDialog(
                dark = state.darkTheme,
                title = dlg.title,
                message = dlg.message,
                confirmText = dlg.confirmText,
                cancelText = dlg.cancelText,
                onConfirm = {
                    dialog = null
                    dlg.confirm?.invoke()
                },
                onDismiss = { dialog = null }
            )
        }
    }
}

@Composable
private fun TopBar(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 34.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = s.appTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = TitleFontFamily,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
        Spacer(Modifier.weight(1f))
        GlassIconButton(
            icon = Icons.Filled.Refresh,
            contentDescription = s.checkUpdate,
            dark = dark
        ) { onAction(UiAction.CheckUpdate) }
        Spacer(Modifier.width(10.dp))
        GlassIconButton(
            icon = if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
            contentDescription = if (dark) s.themeLight else s.themeDark,
            dark = dark
        ) { onAction(UiAction.ToggleTheme) }
    }
}

@Composable
private fun BottomBar(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    NavigationBar(
        containerColor = Color.Transparent,
        tonalElevation = 0.dp
    ) {
        val itemColors = NavigationBarItemDefaults.colors(
            selectedIconColor = AccentBlue,
            selectedTextColor = AccentBlue,
            unselectedIconColor = if (dark) TextSecondaryDark else TextSecondaryLight,
            unselectedTextColor = if (dark) TextSecondaryDark else TextSecondaryLight,
            indicatorColor = AccentBlue.copy(alpha = 0.16f)
        )

        NavigationBarItem(
            selected = state.tab == AppTab.UPDATE,
            onClick = { onAction(UiAction.SelectTab(AppTab.UPDATE)) },
            icon = { androidx.compose.material3.Icon(Icons.Filled.Download, contentDescription = null) },
            label = { Text(s.tabUpdate) },
            colors = itemColors
        )
        NavigationBarItem(
            selected = state.tab == AppTab.INJECT,
            onClick = { onAction(UiAction.SelectTab(AppTab.INJECT)) },
            icon = {
                androidx.compose.material3.Icon(
                    Icons.Filled.SystemUpdateAlt,
                    contentDescription = null
                )
            },
            label = { Text(s.tabInject) },
            colors = itemColors
        )
        NavigationBarItem(
            selected = state.tab == AppTab.CARD,
            onClick = { onAction(UiAction.SelectTab(AppTab.CARD)) },
            icon = { androidx.compose.material3.Icon(Icons.Filled.CreditCard, contentDescription = null) },
            label = { Text(s.tabCard) },
            colors = itemColors
        )
    }
}
