package com.tengcd.czr

import com.tengcd.czr.inject.InjectionMode

/** UI 往 ViewModel 发的动作,界面不需要直接持有 ViewModel */
sealed class UiAction {

    data class SelectTab(val tab: AppTab) : UiAction()
    object ToggleTheme : UiAction()
    object CheckUpdate : UiAction()
    object DownloadModule : UiAction()
    object Inject : UiAction()
    object LaunchTarget : UiAction()
    object RefreshRuntime : UiAction()
    object StartService : UiAction()
    data class SetMode(val mode: InjectionMode) : UiAction()
    data class SelectSoVariant(val variant: String) : UiAction()
    object PickLocalSo : UiAction()
    object UseBuiltinSo : UiAction()
    object ClearLocalSo : UiAction()
    data class CardKeyChanged(val text: String) : UiAction()
    object QueryCard : UiAction()
    object UnbindCard : UiAction()
    object ToggleLocalCardMode : UiAction()
    object GenerateShareCode : UiAction()
    object DismissDialog : UiAction()
}
