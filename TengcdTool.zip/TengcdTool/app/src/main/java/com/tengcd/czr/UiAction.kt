package com.tengcd.czr

import com.tengcd.czr.inject.InjectionMode

/** T3 设置页里四个输入框 */
/** UI 往 ViewModel 发的动作,界面不需要直接持有 ViewModel */
sealed class UiAction {

    data class SelectTab(val tab: AppTab) : UiAction()
    object ToggleTheme : UiAction()
    object Inject : UiAction()
    object LaunchTarget : UiAction()
    object RefreshRuntime : UiAction()
    object StartService : UiAction()
    data class SetMode(val mode: InjectionMode) : UiAction()
    data class SelectSoVariant(val variant: String) : UiAction()
    object PickLocalSo : UiAction()
    object UseBuiltinSo : UiAction()
    object UseLocalSo : UiAction()
    object ClearLocalSo : UiAction()
    data class CardKeyChanged(val text: String) : UiAction()
    object QueryCard : UiAction()
    object UnbindCard : UiAction()
    object ToggleLocalCardMode : UiAction()
    object GenerateShareCode : UiAction()
    object DismissDialog : UiAction()

    // 资源导入(左源 -> 右目标 覆盖)
    object PickImportSource : UiAction()
    object PickImportTarget : UiAction()
    data class SetImportPath(val forTarget: Boolean, val path: String) : UiAction()
    object ClearImportSource : UiAction()
    object ToggleImportReplaceAll : UiAction()
    object RunImport : UiAction()

    /** 申请 Shizuku 授权 */
    object GrantShizuku : UiAction()

    // ---------------- T3 网络验证 ----------------
    data class LoginCardChanged(val text: String) : UiAction()
    object Login : UiAction()
    object Logout : UiAction()

    /** 重新拉一次公告 */
    object RefreshNotice : UiAction()
}
