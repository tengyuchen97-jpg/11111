package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.T3Field
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.GlassBorderDark
import com.tengcd.czr.ui.theme.GlassBorderLight
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/**
 * 启动门:进 App 先要求输入卡密,走 T3 验证。
 * 验证通过才进主界面(首页/注入/导入/卡密四个 tab)。
 * 下面藏一个"T3 验证服务器"设置,域名 / appid / appkey / 通信密钥都在这填。
 */
@Composable
fun StartGate(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        Text(
            text = s.appTitle,
            style = MaterialTheme.typography.headlineLarge,
            fontFamily = TitleFontFamily,
            fontSize = 42.sp,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = s.loginSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )

        Spacer(Modifier.height(28.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Lock, s.loginTitle, dark)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.loginCard,
                onValueChange = { onAction(UiAction.LoginCardChanged(it)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(s.loginCardLabel) },
                placeholder = { Text(s.cardKeyHint) },
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onAction(UiAction.Login) }),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(dark)
            )

            state.loginError?.takeIf { it.isNotBlank() }?.let { err ->
                Spacer(Modifier.height(8.dp))
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }

            Spacer(Modifier.height(14.dp))
            PrimaryActionButton(
                text = if (state.loginBusy) s.loginBusy else s.loginButton,
                icon = Icons.Filled.VpnKey,
                enabled = !state.loginBusy,
                dark = dark
            ) { onAction(UiAction.Login) }

            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                TextButton(onClick = { onAction(UiAction.ToggleT3Settings) }) {
                    Text(
                        text = s.loginServerTitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = AccentBlue
                    )
                }
            }
        }

        if (state.showT3Settings) {
            Spacer(Modifier.height(12.dp))
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.Settings, s.loginServerTitle, dark)
                Spacer(Modifier.height(10.dp))
                ServerField(
                    value = state.t3BaseUrl,
                    label = s.loginServerTitle,
                    placeholder = s.loginServerHint,
                    dark = dark
                ) { onAction(UiAction.SetT3Field(T3Field.BASE_URL, it)) }
                Spacer(Modifier.height(8.dp))
                ServerField(
                    value = state.t3AppId,
                    label = s.loginAppId,
                    placeholder = s.loginAppId,
                    dark = dark
                ) { onAction(UiAction.SetT3Field(T3Field.APP_ID, it)) }
                Spacer(Modifier.height(8.dp))
                ServerField(
                    value = state.t3AppKey,
                    label = s.loginAppKey,
                    placeholder = s.loginAppKey,
                    dark = dark
                ) { onAction(UiAction.SetT3Field(T3Field.APP_KEY, it)) }
                Spacer(Modifier.height(8.dp))
                ServerField(
                    value = state.t3AesKey,
                    label = s.loginAesKey,
                    placeholder = s.loginAesKey,
                    dark = dark
                ) { onAction(UiAction.SetT3Field(T3Field.AES_KEY, it)) }
                Spacer(Modifier.height(12.dp))
                PrimaryActionButton(
                    text = s.loginSave,
                    icon = Icons.Filled.Settings,
                    enabled = true,
                    dark = dark
                ) { onAction(UiAction.SaveT3Config) }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ServerField(
    value: String,
    label: String,
    placeholder: String,
    dark: Boolean,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        },
        textStyle = MaterialTheme.typography.labelSmall.copy(
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        shape = RoundedCornerShape(12.dp),
        colors = fieldColors(dark)
    )
}

@Composable
private fun fieldColors(dark: Boolean) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AccentBlue,
    unfocusedBorderColor = if (dark) GlassBorderDark else GlassBorderLight,
    focusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
    unfocusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
    cursorColor = AccentBlue,
    focusedLabelColor = OkGreen,
    unfocusedLabelColor = if (dark) TextSecondaryDark else TextSecondaryLight
)
