package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.NoticeCard
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.GlassBorderDark
import com.tengcd.czr.ui.theme.GlassBorderLight
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/**
 * 启动门:进 App 先输卡密,走 T3 网络验证。
 * 服务器地址 / appkey / 编码集全部写死在 T3Panel 里,界面不提供任何修改入口,
 * 也不存在本地卡密放行 —— 服务端说通过才进主界面。
 */
@Composable
fun StartGate(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        Text(
            text = s.appTitle,
            style = MaterialTheme.typography.headlineLarge,
            fontFamily = TitleFontFamily,
            fontSize = 42.sp,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = s.loginSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )

        Spacer(Modifier.height(28.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Lock, s.loginTitle, dark)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.loginCard,
                onValueChange = { onAction(UiAction.LoginCardChanged(it)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(s.loginCardLabel) },
                placeholder = { Text(s.cardKeyHint) },
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onAction(UiAction.Login) }),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(dark)
            )

            state.loginError?.takeIf { it.isNotBlank() }?.let { err ->
                Spacer(Modifier.height(8.dp))
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }

            Spacer(Modifier.height(14.dp))
            PrimaryActionButton(
                text = if (state.loginBusy) s.loginBusy else s.loginButton,
                icon = Icons.Filled.VpnKey,
                enabled = !state.loginBusy,
                dark = dark
            ) { onAction(UiAction.Login) }

            Spacer(Modifier.height(8.dp))
            Text(
                text = s.loginServerFixed,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(12.dp))
        NoticeCard(state = state, s = s, dark = dark) { onAction(it) }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun fieldColors(dark: Boolean) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AccentBlue,
    unfocusedBorderColor = if (dark) GlassBorderDark else GlassBorderLight,
    focusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
    unfocusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
    cursorColor = AccentBlue,
    focusedLabelColor = OkGreen,
    unfocusedLabelColor = if (dark) TextSecondaryDark else TextSecondaryLight
)
