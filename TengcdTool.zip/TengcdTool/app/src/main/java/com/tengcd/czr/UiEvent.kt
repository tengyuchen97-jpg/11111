package com.tengcd.czr

sealed class UiEvent {

    data class Toast(val text: String) : UiEvent()

    /** 让界面拉起系统的文件选择器,挑本机的 so */
    object PickLocalSoFile : UiEvent()

    data class Dialog(
        val title: String,
        val message: String,
        val confirmText: String,
        val cancelText: String? = null,
        val confirm: (() -> Unit)? = null,
        val dismiss: (() -> Unit)? = null
    ) : UiEvent()
}
