package com.tengcd.czr

sealed class UiEvent {

    data class Toast(val text: String) : UiEvent()

    /** 让界面拉起系统的文件选择器,挑本机的 so */
    object PickLocalSoFile : UiEvent()

    /** 让界面拉起系统的文件夹选择器(SAF)。forTarget = true 是给目标文件夹用的 */
    data class PickFolderTree(val forTarget: Boolean) : UiEvent()

    data class Dialog(
        val title: String,
        val message: String,
        val confirmText: String,
        val cancelText: String? = null,
        val confirm: (() -> Unit)? = null,
        val dismiss: (() -> Unit)? = null
    ) : UiEvent()
}
