package com.tengcd.czr.i18n

/**
 * 界面文案接口。加语言就在 Strings.kt 里再实现一份,
 * 这里不动。字段名和 UI 代码一一对应。
 */
interface LocalizedStrings {
    val lang: String

    val appTitle: String
    val tabUpdate: String
    val tabInject: String
    val tabCard: String
    val tabImport: String

    // 资源导入
    val importTitle: String
    val importDesc: String
    val importTargetLabel: String
    val importSource: String
    val importPick: String
    val importPickNone: String
    val importSelected: String
    val importFileCount: String
    val importSourcePane: String
    val importTargetPane: String
    val importSourceHint: String
    val importTargetHint: String
    val importSourcePicked: String
    val importTargetPicked: String
    val importTargetSet: String
    val importTargetWillCreate: String
    val importTargetMissing: String
    val importFileUnit: String
    val importModeTitle: String
    val importModeMerge: String
    val importModeReplace: String
    val importModeMergeDesc: String
    val importModeReplaceDesc: String
    val importManualPath: String
    val importManualHint: String
    val importEmptyDir: String
    val importDirCount: String
    val importChannelSaf: String
    val importPathDialogTitle: String
    val importPathDialogOk: String
    val importSwapHint: String
    val importTotalSize: String
    val importStart: String
    val importRunning: String
    val importProgress: String
    val importCopied: String
    val importChannel: String
    val importChannelDirect: String
    val importChannelRoot: String
    val importRootAvailable: String
    val importRootMissing: String
    val importNeedRoot: String
    val importCoverHint: String
    val importConfirmTitle: String
    val importConfirmMessage: String
    val importDone: String
    val importFailedMsg: String
    val importClearedSelection: String
    val importNoAccess: String

    // 注入失败详情
    val abiMismatch: String
    val remoteSyscallFailed: String
    val loaderBusy: String
    val injectDetailLabel: String
    val themeLight: String
    val themeDark: String

    val announcement: String
    val announcementLoading: String
    val announcementEmpty: String
    val announcementFailed: String

    val moduleOverview: String
    val localModule: String
    val frameworkStatus: String
    val remoteModuleVersion: String
    val statusReady: String
    val statusNotReady: String
    val statusActivated: String
    val statusNotActivated: String
    val moduleNotDownloaded: String
    val moduleFileMissing: String

    val checkUpdate: String
    val launchGame: String
    val currentIsLatest: String
    val foundNewVersion: String
    val moduleHasUpdate: String
    val moduleUpdateSuccess: String
    val needUpdateModule: String
    val updateMissingUrl: String
    val verifyFailedKeepOriginal: String
    val moduleReplaceFailed: String
    val downloadFailed: String
    val downloadingModule: String
    val checking: String
    val fetchingVersion: String
    val pleaseDownloadFirst: String
    val pageDownloadModule: String
    val redownload: String
    val downloadNow: String
    val confirm: String
    val cancel: String
    val knowIt: String

    val injectTitle: String
    val frameworkInject: String
    val processInject: String
    val frameworkPrepare: String
    val processPrepare: String
    val frameworkPrepareDesc: String
    val processPrepareDesc: String
    val frameworkModuleInactive: String
    val frameworkModuleActive: String
    val moduleReady: String
    val moduleNotReady: String
    val oneKeyInject: String
    val injectMode: String
    val targetApp: String
    val targetProcess: String
    val targetDir: String
    val targetDirOk: String
    val targetDirNo: String
    val moduleVersionLabel: String
    val localPath: String
    val remoteVersionLabel: String
    val checkRuntimeCondition: String
    val notSameUid: String
    val targetNotRunning: String
    val attachDenied: String
    val linkerRejected: String
    val targetNotFound: String
    val injectFailed: String
    val injectDone: String
    val injectRunning: String
    val injectorUnavailable: String
    val moduleNotCopied: String
    val targetNotInstalled: String
    val installTargetFirst: String
    val needFrameworkFirst: String
    val frameworkScopeHint: String
    val serviceRunning: String
    val serviceStopped: String
    val moduleServiceRunning: String

    val soSelect: String
    val soSourceLabel: String
    val soBuiltin: String
    val soLocal: String
    val soRemote: String
    val soReady: String
    val soNotReady: String
    val soSwitchedTo: String
    val soSwitchedBuiltin: String
    val soSizeLabel: String
    val soPlaceholderHint: String
    val soInvalidHint: String
    val soSelectorHint: String

    // 写入通道 / Shizuku
    val refresh: String
    val androidVersionLabel: String
    val shizukuStatus: String
    val shizukuGrant: String
    val shizukuNotInstalled: String
    val shizukuNotRunning: String
    val shizukuGranted: String
    val shizukuDenied: String
    val importChannelShizuku: String
    val importChannelNone: String
    val importNotReady: String

    val localSoTitle: String
    val localSoDesc: String
    val localSoPick: String
    val localSoNone: String
    val localSoSourcePathLabel: String
    val localSoStagedPathLabel: String
    val localSoUseHint: String
    val localSoClear: String
    val localSoLoaded: String
    val localSoFailed: String
    val localSoCleared: String

    val cardTitle: String
    val cardQuery: String
    val cardHint: String
    val cardInvalid: String
    val cardQueryResult: String
    val expireTime: String
    val remainCount: String
    val bindDevice: String
    val unbindCount: String
    val unbindDevice: String
    val unbinding: String
    val unbindSuccess: String
    val noBinding: String
    val banned: String
    val expired: String
    val countExhausted: String
    val notUsed: String
    val inUse: String
    val querying: String
    val requestFailed: String
    val localVerify: String
    
    val linkTitle: String
    val linkOpen: String 
    val copy: String
    val copied: String

    val operationFailed: String
    val checkNetwork: String
    val networkFailed: String
    val unlimited: String
    val forever: String
    val yes: String
    val no: String

    // ---------------- v0.6:首页 / T3 验证 / SO 来源 ----------------
    val tabHome: String get() = "首页"
    val homeDesc: String get() = "先选 SO 再注入;要刷游戏资源就去导入。"
    val homeStatus: String get() = "运行状态"
    val homeQuick: String get() = "快捷入口"
    val homeGoInject: String get() = "去注入"
    val homeGoImport: String get() = "去导入"
    val homeSoNow: String get() = "当前 SO"
    val homeWriteChannel: String get() = "写入通道"
    val homeAccount: String get() = "卡密"
    val loginTitle: String get() = "卡密验证"
    val loginSubtitle: String get() = "输入卡密,验证通过后进入首页"
    val loginCardLabel: String get() = "卡密"
    val cardKeyHint: String get() = "输入你的卡密"
    val loginButton: String get() = "登录"
    val loginBusy: String get() = "正在验证…"
    val loginEmpty: String get() = "先输入卡密"
    val loginNeedServer: String get() = "还没填 T3 验证服务器地址"
    val loginFailed: String get() = "验证失败"
    val loginSuccess: String get() = "验证通过"
    val loginExpire: String get() = "到期时间"
    val loginServerTitle: String get() = "T3 验证服务器"
    val loginServerHint: String get() = "T3 后台给你的验证域名,例如 https://api.xxx.com"
    val loginAppId: String get() = "appid"
    val loginAppKey: String get() = "appkey"
    val loginAesKey: String get() = "通信密钥"
    val loginSave: String get() = "保存"
    val loginServerSaved: String get() = "服务器设置已保存"
    val loginLogout: String get() = "退出登录"
    val soSourceTitle: String get() = "SO 来源"
    val soSourceBuiltin: String get() = "内置"
    val localSoSwitched: String get() = "已切到本机 SO"
    val soSourceLocal: String get() = "本地"
    val importReadPath: String get() = "读取"
    val importPathHint: String get() = "点「读取」或者粘一个路径"
    val importTargetPathHint: String get() = "目标文件夹路径"
    val importPathInvalid: String get() = "这个路径不是文件夹"
}