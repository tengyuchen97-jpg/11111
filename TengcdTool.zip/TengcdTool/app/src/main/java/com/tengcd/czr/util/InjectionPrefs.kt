package com.tengcd.czr.util

import android.content.Context
import android.content.SharedPreferences

/**
 * 全局配置存取。所有状态都落在一个 SharedPreferences 里,
 * 跨进程(注入服务 / HookInit)读的话走 SoProvider.call()。
 */
object InjectionPrefs {

    private const val FILE = "honffx_inject"

    const val KEY_MODULE_PATH = "module_path"
    const val KEY_MODULE_VERSION = "module_version"
    const val KEY_MODULE_MD5 = "module_md5"
    const val KEY_REMOTE_VERSION = "remote_version"
    const val KEY_SO_URL = "so_url"
    const val KEY_ANNOUNCEMENT = "announcement"
    const val KEY_TARGET_PACKAGE = "target_package"
    const val KEY_CARD_KEY = "card_key"
    const val KEY_MODE = "injection_mode"
    const val KEY_DARK = "dark_theme"
    const val KEY_FRAMEWORK_ACTIVE = "framework_active"
    const val KEY_LAST_INJECT = "last_inject_time"
    const val KEY_BOOT_AUTOSTART = "boot_autostart"
    const val KEY_CONFIG_URL = "config_url"
    const val KEY_LOCAL_CARD_MODE = "local_card_mode"
    const val KEY_LOCAL_CARD = "local_card"
    const val KEY_BOUND_DEVICE = "bound_device"

    /** 当前选中的内置 SO 变体(模块概览下面那个选择器) */
    const val KEY_SO_VARIANT = "so_variant"

    /** 注入源:builtin = 用内置变体,local = 用本机读取进来的 so */
    const val KEY_SO_SOURCE = "so_source"

    /** 本机读取的 so 原始路径(只做展示,真正注入用的是私有目录那份) */
    const val KEY_LOCAL_SO_SOURCE_PATH = "local_so_source_path"

    /** 内置 so 的解包指纹(安装包版本 + 安装时间),换了包要重新解包 */
    const val KEY_SO_BUNDLE_STAMP = "so_bundle_stamp"

    /** 框架注入:目标进程里模块加载失败的原因(由目标进程回报) */
    const val KEY_FRAMEWORK_ERROR = "framework_error"

    /** 框架注入:目标进程里实际加载成功的 so 路径 */
    const val KEY_FRAMEWORK_PATH = "framework_path"

    /** 资源导入:上次选中的源文件夹(SAF tree uri) */
    const val KEY_IMPORT_FOLDER_URI = "import_folder_uri"

    /** 资源导入:源文件夹(SAF) */
    const val KEY_IMPORT_SOURCE_URI = "import_source_uri"

    /** 资源导入:目标文件夹(SAF) */
    const val KEY_IMPORT_TARGET_URI = "import_target_uri"

    /** 资源导入:目标文件夹(手输绝对路径) */
    const val KEY_IMPORT_TARGET_PATH = "import_target_path"

    /** 资源导入:true = 先清空目标再写 */
    const val KEY_IMPORT_REPLACE_ALL = "import_replace_all"

    const val DEFAULT_SO_VARIANT = "v0.24"
    const val SO_SOURCE_BUILTIN = "builtin"
    const val SO_SOURCE_LOCAL = "local"
    const val SO_SOURCE_REMOTE = "remote"

    const val DEFAULT_TARGET_PACKAGE = "com.pi.czrxdfirst"

    /** 远端配置地址:换成你自己的服务端就行 */
    const val DEFAULT_CONFIG_URL = "https://example.com/api/honffx/config.json"

    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences =
        sp ?: throw IllegalStateException("InjectionPrefs.init() 还没调用")

    private fun putString(key: String, value: String?) {
        p().edit().putString(key, value).apply()
    }

    var modulePath: String?
        get() = p().getString(KEY_MODULE_PATH, null)
        set(v) = putString(KEY_MODULE_PATH, v)

    var moduleVersion: String?
        get() = p().getString(KEY_MODULE_VERSION, null)
        set(v) = putString(KEY_MODULE_VERSION, v)

    var moduleMd5: String?
        get() = p().getString(KEY_MODULE_MD5, null)
        set(v) = putString(KEY_MODULE_MD5, v)

    var remoteVersion: String?
        get() = p().getString(KEY_REMOTE_VERSION, null)
        set(v) = putString(KEY_REMOTE_VERSION, v)

    var soUrl: String?
        get() = p().getString(KEY_SO_URL, null)
        set(v) = putString(KEY_SO_URL, v)

    var announcement: String?
        get() = p().getString(KEY_ANNOUNCEMENT, null)
        set(v) = putString(KEY_ANNOUNCEMENT, v)

    var targetPackage: String
        get() = p().getString(KEY_TARGET_PACKAGE, DEFAULT_TARGET_PACKAGE) ?: DEFAULT_TARGET_PACKAGE
        set(v) = putString(KEY_TARGET_PACKAGE, v)

    var cardKey: String
        get() = p().getString(KEY_CARD_KEY, "") ?: ""
        set(v) = putString(KEY_CARD_KEY, v)

    var injectionMode: Int
        get() = p().getInt(KEY_MODE, 0)
        set(v) = p().edit().putInt(KEY_MODE, v).apply()

    var darkTheme: Boolean
        get() = p().getBoolean(KEY_DARK, false)
        set(v) = p().edit().putBoolean(KEY_DARK, v).apply()

    var frameworkActive: Boolean
        get() = p().getBoolean(KEY_FRAMEWORK_ACTIVE, false)
        set(v) = p().edit().putBoolean(KEY_FRAMEWORK_ACTIVE, v).apply()

    var lastInjectTime: Long
        get() = p().getLong(KEY_LAST_INJECT, 0L)
        set(v) = p().edit().putLong(KEY_LAST_INJECT, v).apply()

    var bootAutoStart: Boolean
        get() = p().getBoolean(KEY_BOOT_AUTOSTART, false)
        set(v) = p().edit().putBoolean(KEY_BOOT_AUTOSTART, v).apply()

    var configUrl: String
        get() = p().getString(KEY_CONFIG_URL, DEFAULT_CONFIG_URL) ?: DEFAULT_CONFIG_URL
        set(v) = putString(KEY_CONFIG_URL, v)

    /** true = 卡密走本地校验(不联网),false = 走服务端查询 */
    var localCardMode: Boolean
        get() = p().getBoolean(KEY_LOCAL_CARD_MODE, false)
        set(v) = p().edit().putBoolean(KEY_LOCAL_CARD_MODE, v).apply()

    /** 本地卡密(本地校验模式下用,多个用英文逗号分隔) */
    var localCard: String
        get() = p().getString(KEY_LOCAL_CARD, "HONFFX-LOCAL-2024") ?: "HONFFX-LOCAL-2024"
        set(v) = putString(KEY_LOCAL_CARD, v)

    var boundDevice: String?
        get() = p().getString(KEY_BOUND_DEVICE, null)
        set(v) = putString(KEY_BOUND_DEVICE, v)

    /** 当前选中的内置 SO 变体名,例如 v0.19 / v0.20 / v0.23 / v0.24 */
    var soVariant: String
        get() = p().getString(KEY_SO_VARIANT, DEFAULT_SO_VARIANT) ?: DEFAULT_SO_VARIANT
        set(v) = putString(KEY_SO_VARIANT, v)

    /** builtin / local */
    var soSource: String
        get() = p().getString(KEY_SO_SOURCE, SO_SOURCE_BUILTIN) ?: SO_SOURCE_BUILTIN
        set(v) = putString(KEY_SO_SOURCE, v)

    /** 本机选中的 so 在手机上的原始路径(展示用) */
    var importFolderUri: String?
        get() = p().getString(KEY_IMPORT_FOLDER_URI, null)
        set(v) = putString(KEY_IMPORT_FOLDER_URI, v)

    /** 资源导入:源文件夹 SAF uri */
    var importSourceUri: String?
        get() = p().getString(KEY_IMPORT_SOURCE_URI, null)
        set(v) = putString(KEY_IMPORT_SOURCE_URI, v)

    /** 资源导入:目标文件夹 SAF uri */
    var importTargetUri: String?
        get() = p().getString(KEY_IMPORT_TARGET_URI, null)
        set(v) = putString(KEY_IMPORT_TARGET_URI, v)

    /** 资源导入:目标文件夹绝对路径(手输那条路) */
    var importTargetPath: String
        get() = p().getString(KEY_IMPORT_TARGET_PATH, FolderImporter.DEFAULT_TARGET_PATH)
            ?: FolderImporter.DEFAULT_TARGET_PATH
        set(v) = putString(KEY_IMPORT_TARGET_PATH, v)

    /** true = 整目录替换(先清空目标) */
    var importReplaceAll: Boolean
        get() = p().getBoolean(KEY_IMPORT_REPLACE_ALL, false)
        set(v) = p().edit().putBoolean(KEY_IMPORT_REPLACE_ALL, v).apply()

    var localSoSourcePath: String?
        get() = p().getString(KEY_LOCAL_SO_SOURCE_PATH, null)
        set(v) = putString(KEY_LOCAL_SO_SOURCE_PATH, v)

    /** 上次解包内置 so 时的安装包指纹 */
    var soBundleStamp: String?
        get() = p().getString(KEY_SO_BUNDLE_STAMP, null)
        set(v) = putString(KEY_SO_BUNDLE_STAMP, v)

    /** 目标进程回报的模块加载失败原因 */
    var frameworkError: String?
        get() = p().getString(KEY_FRAMEWORK_ERROR, null)
        set(v) = putString(KEY_FRAMEWORK_ERROR, v)

    /** 目标进程里真正加载成功的 so 路径 */
    var frameworkPath: String?
        get() = p().getString(KEY_FRAMEWORK_PATH, null)
        set(v) = putString(KEY_FRAMEWORK_PATH, v)
}
