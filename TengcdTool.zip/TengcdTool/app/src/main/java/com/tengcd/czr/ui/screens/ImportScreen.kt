package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.EmptyHint
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.WarnOrange
import com.tengcd.czr.util.FolderImporter

/**
 * 资源导入页。
 *
 * 选本机一个文件夹 -> 整个覆盖到目标应用私有目录(files)。
 * 导入前先清空目标目录,写入走"直写 / root"两条通道,页面上看得见每条通道的状态。
 */
@Composable
fun ImportScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // ---------------- 目标目录 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.FolderZip, s.importTitle, dark)
            Spacer(Modifier.height(8.dp))
            Text(
                text = s.importDesc,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = s.importTargetLabel,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(6.dp))
            PathBox(text = FolderImporter.TARGET_PATH, dark = dark, accent = ErrRed)

            Spacer(Modifier.height(10.dp))
            StatusRow(
                label = s.importChannelDirect,
                value = if (state.targetDirWritable) s.statusReady else s.statusNotReady,
                dark = dark,
                dot = true,
                ok = state.targetDirWritable
            )
            StatusRow(
                label = s.importChannelRoot,
                value = if (state.rootAvailable) s.importRootAvailable else s.importRootMissing,
                dark = dark,
                dot = true,
                ok = state.rootAvailable
            )
            if (!state.targetDirWritable && !state.rootAvailable) {
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp)
                ) {
                    Text(
                        text = s.importNeedRoot,
                        style = MaterialTheme.typography.bodySmall,
                        color = WarnOrange
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 源文件夹 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Folder, s.importSource, dark)
            Spacer(Modifier.height(8.dp))

            if (state.importFolderName.isBlank()) {
                EmptyHint(s.importPickNone, dark)
            } else {
                KeyValueRow(s.importSelected, state.importFolderName, dark, OkGreen)
                KeyValueRow(s.importFileCount, "${state.importFileCount}", dark)
                KeyValueRow(s.importTotalSize, FolderImporter.formatSize(state.importTotalBytes), dark)
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SecondaryActionButton(
                    text = if (state.importFolderName.isBlank()) s.importPick else s.importClearedSelection,
                    icon = if (state.importFolderName.isBlank()) Icons.Filled.Folder else Icons.Filled.RestartAlt,
                    dark = dark,
                    modifier = Modifier.weight(1f),
                    enabled = !state.importing
                ) { onAction(UiAction.PickImportFolder) }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 进度 ----------------
        if (state.importing || state.importFinished) {
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.CloudUpload, s.importProgress, dark)
                Spacer(Modifier.height(10.dp))
                val total = state.importFileCount.coerceAtLeast(1)
                val progress = (state.importProgressFiles.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { if (state.importFinished) 1f else progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = if (state.importFailed) ErrRed else OkGreen
                )
                Spacer(Modifier.height(10.dp))
                KeyValueRow(
                    label = s.importCopied,
                    value = "${state.importProgressFiles} / ${state.importFileCount}",
                    dark = dark,
                    valueColor = if (state.importFailed) ErrRed else OkGreen
                )
                KeyValueRow(
                    label = s.importTotalSize,
                    value = FolderImporter.formatSize(state.importProgressBytes),
                    dark = dark
                )
                state.importChannelLabel?.takeIf { it.isNotBlank() }?.let {
                    KeyValueRow(s.importChannel, it, dark)
                }
                state.importMessage?.takeIf { it.isNotBlank() }?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.importFailed) ErrRed else OkGreen
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        PrimaryActionButton(
            text = if (state.importing) s.importRunning else s.importStart,
            icon = Icons.Filled.CloudUpload,
            enabled = !state.importing && state.importFolderName.isNotBlank(),
            dark = dark
        ) { onAction(UiAction.RunImport) }

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Shield,
                contentDescription = null,
                tint = if (dark) TextSecondaryDark else TextSecondaryLight,
                modifier = Modifier.size(13.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = s.importCoverHint,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(28.dp))
    }
}
