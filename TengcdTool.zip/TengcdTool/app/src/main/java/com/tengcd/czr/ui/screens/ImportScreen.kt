package com.tengcd.czr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SegmentedControl
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.components.liquidGlass
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.GlassBorderDark
import com.tengcd.czr.ui.theme.GlassBorderLight
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.util.FolderImporter

/**
 * 资源导入页(MT 管理器那种左右双栏)。
 *
 * 左边选本机文件夹,右边选目标文件夹,把左边的整个覆盖到右边:
 *   - 两个文件夹都能"选文件夹"(系统选择器)或"手输绝对路径"
 *   - 覆盖方式:合并覆盖 / 清空后覆盖
 *   - 落盘通道:文件夹通道(SAF) / 直写 / root,页面上给状态
 */
@Composable
fun ImportScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme

    // 手输路径弹窗:null = 关着,true = 改目标,false = 改源
    var pathDialogFor by remember { mutableStateOf<Boolean?>(null) }
    var pathDialogText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // ---------------- 说明 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.SwapHoriz, s.importTitle, dark)
            Spacer(Modifier.height(8.dp))
            Text(
                text = s.importDesc,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 左右双栏 ----------------
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FolderPane(
                dark = dark,
                modifier = Modifier.weight(1f),
                title = s.importSourcePane,
                accent = AccentBlue,
                path = state.importSourcePath,
                hint = s.importSourceHint,
                files = state.importSourceFiles,
                dirs = state.importSourceDirs,
                bytes = state.importSourceBytes,
                emptyText = s.importEmptyDir,
                fileUnit = s.importFileUnit,
                dirLabel = s.importDirCount,
                pickText = s.importPick,
                manualText = s.importManualPath,
                onPick = { onAction(UiAction.PickImportSource) },
                onManual = {
                    pathDialogText = state.importSourcePath
                    pathDialogFor = false
                }
            )

            Icon(
                Icons.Filled.ArrowForward,
                contentDescription = null,
                tint = AccentBlue,
                modifier = Modifier
                    .padding(top = 34.dp)
                    .size(16.dp)
            )

            FolderPane(
                dark = dark,
                modifier = Modifier.weight(1f),
                title = s.importTargetPane,
                accent = OkGreen,
                path = state.importTargetPath,
                hint = s.importTargetHint,
                files = state.importTargetFiles,
                dirs = -1,
                bytes = state.importTargetBytes,
                emptyText = s.importEmptyDir,
                fileUnit = s.importFileUnit,
                dirLabel = s.importDirCount,
                pickText = s.importPick,
                manualText = s.importManualPath,
                onPick = { onAction(UiAction.PickImportTarget) },
                onManual = {
                    pathDialogText = state.importTargetPath
                    pathDialogFor = true
                }
            )
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = s.importSwapHint,
                style = MaterialTheme.typography.labelSmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 覆盖方式 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.FolderOpen, s.importModeTitle, dark)
            Spacer(Modifier.height(10.dp))
            SegmentedControl(
                options = listOf(s.importModeMerge, s.importModeReplace),
                selectedIndex = if (state.importReplaceAll) 1 else 0,
                dark = dark
            ) {
                if ((it == 1) != state.importReplaceAll) onAction(UiAction.ToggleImportReplaceAll)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (state.importReplaceAll) s.importModeReplaceDesc else s.importModeMergeDesc,
                style = MaterialTheme.typography.bodySmall,
                color = if (state.importReplaceAll) ErrRed else if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(10.dp))
            StatusRow(
                label = s.importChannel,
                value = if (state.targetDirWritable) s.statusReady else s.statusNotReady,
                dark = dark,
                dot = true,
                ok = state.targetDirWritable
            )
            StatusRow(
                label = s.importChannelRoot,
                value = if (state.rootAvailable) s.importRootAvailable else s.importRootMissing,
                dark = dark,
                dot = true,
                ok = state.rootAvailable
            )
        }

        // ---------------- 进度 ----------------
        if (state.importing || state.importFinished) {
            Spacer(Modifier.height(12.dp))
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.CloudUpload, s.importProgress, dark)
                Spacer(Modifier.height(10.dp))
                val total = state.importProgressTotal.coerceAtLeast(1)
                val progress = (state.importProgressFiles.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { if (state.importFinished) 1f else progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = if (state.importFailed) ErrRed else OkGreen
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = s.importCopied + " " + state.importProgressFiles + " / " +
                            state.importProgressTotal,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.importFailed) ErrRed else OkGreen
                    )
                    Text(
                        text = FolderImporter.formatSize(state.importProgressBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                state.importChannelLabel?.takeIf { it.isNotBlank() }?.let { channel ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = s.importChannel + ": " + channel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                state.importMessage?.takeIf { it.isNotBlank() }?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.importFailed) ErrRed else OkGreen
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        PrimaryActionButton(
            text = if (state.importing) s.importRunning else s.importStart,
            icon = Icons.Filled.CloudUpload,
            // 源有内容 + 目标有落点,才能开跑;选完文件夹立刻就能点
            enabled = !state.importing &&
                (state.importSourceUri != null || state.importSourcePath.isNotBlank()) &&
                (state.importTargetUri != null || state.importTargetPath.isNotBlank()),
            dark = dark
        ) { onAction(UiAction.RunImport) }

        Spacer(Modifier.height(24.dp))
    }

    // ---------------- 手输路径弹窗 ----------------
    val dialogTarget = pathDialogFor
    if (dialogTarget != null) {
        AlertDialog(
            onDismissRequest = { pathDialogFor = null },
            title = {
                Text(
                    text = if (dialogTarget) s.importTargetPane else s.importSourcePane,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
            },
            text = {
                Column {
                    OutlinedTextField(
                        value = pathDialogText,
                        onValueChange = { pathDialogText = it },
                        singleLine = false,
                        minLines = 2,
                        maxLines = 4,
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        placeholder = {
                            Text(
                                text = s.importManualHint,
                                style = MaterialTheme.typography.bodySmall
                            )
                        },
                        label = { Text(s.importPathDialogTitle) }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = s.importManualHint,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onAction(UiAction.SetImportPath(dialogTarget, pathDialogText.trim()))
                    pathDialogFor = null
                }) {
                    Text(s.importPathDialogOk)
                }
            },
            dismissButton = {
                TextButton(onClick = { pathDialogFor = null }) {
                    Text(s.cancel)
                }
            }
        )
    }
}

/**
 * 单栏:标题 + 路径 + 统计 + 两个小按钮(选文件夹 / 输路径)。
 * 左右两栏长得一样,靠 accent 区分源和目标。
 */
@Composable
private fun FolderPane(
    dark: Boolean,
    modifier: Modifier,
    title: String,
    accent: Color,
    path: String,
    hint: String,
    files: Int,
    dirs: Int,
    bytes: Long,
    emptyText: String,
    fileUnit: String,
    dirLabel: String,
    pickText: String,
    manualText: String,
    onPick: () -> Unit,
    onManual: () -> Unit
) {
    Column(
        modifier = modifier
            .liquidGlass(dark, 22)
            .padding(horizontal = 10.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(accent.copy(alpha = if (dark) 0.28f else 0.16f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Folder,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = if (dark) TextPrimaryDark else TextPrimaryLight,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(8.dp))

        // 路径:没选的时候显示提示,选了按等宽字体折两行
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .border(
                    1.dp,
                    accent.copy(alpha = 0.45f),
                    RoundedCornerShape(12.dp)
                )
                .background(
                    accent.copy(alpha = if (dark) 0.12f else 0.07f),
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 8.dp, vertical = 7.dp)
        ) {
            Text(
                text = path.ifBlank { hint },
                style = MaterialTheme.typography.labelSmall,
                fontFamily = if (path.isBlank()) FontFamily.Default else FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 14.sp,
                color = if (path.isBlank()) {
                    if (dark) TextSecondaryDark else TextSecondaryLight
                } else {
                    if (dark) TextPrimaryDark else TextPrimaryLight
                },
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(6.dp))

        Text(
            text = if (files <= 0) emptyText else "$files $fileUnit · " + FolderImporter.formatSize(bytes),
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = if (dark) TextSecondaryDark else TextSecondaryLight,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (dirs > 0) {
            Text(
                text = "$dirLabel $dirs",
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PaneChip(text = pickText, accent = accent, dark = dark, onClick = onPick)
            PaneChip(text = manualText, accent = accent, dark = dark, onClick = onManual)
        }
    }
}

@Composable
private fun PaneChip(text: String, accent: Color, dark: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .height(28.dp)
            .background(accent.copy(alpha = if (dark) 0.22f else 0.14f), shape)
            .border(1.dp, accent.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 11.sp,
            color = accent,
            maxLines = 1
        )
    }
}
