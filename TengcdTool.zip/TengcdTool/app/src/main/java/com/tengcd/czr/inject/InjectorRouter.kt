package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 */
object InjectorRouter {

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        if (!ModuleStore.isDownloaded(context) && !ModuleStore.ensureBundled(context)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY)
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry)
        }
    }

    /**
     * 框架注入:我们不需要自己动手,只要把路径告诉 HookInit,
     * 目标进程起来时它自己 System.load。所以这里做的是"把一切准备好"。
     */
    private fun frameworkInject(context: Context, targetPkg: String): PtraceInjectResult {
        if (!XposedDetector.isFrameworkInstalled(context)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED)
        }
        val soPath = ModuleStore.moduleFile(context).absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        val pids = PackageUtil.findPids(targetPkg)
        if (pids.isEmpty()) {
            // 目标还没跑:这不叫失败,下次它启动时模块会自己载入
            InjectionPrefs.frameworkActive = true
            return PtraceInjectResult.Success(
                pid = -1,
                soPath = soPath,
                detail = "waiting_target"
            )
        }
        if (!InjectionPrefs.frameworkActive) {
            // 主进程在跑但没报告模块激活 —— 大概率是作用域没勾/没重启目标
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.FRAMEWORK_NOT_ACTIVE, "scope_or_restart"
            )
        }
        return PtraceInjectResult.Success(pids.first(), soPath, "active")
    }

    /**
     * 进程注入:目标在跑 -> 把 so 挪到目标数据目录 -> ptrace 附加 -> 远程 dlopen。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?
    ): PtraceInjectResult {
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.SAME_UID_REQUIRED)
        }
        val pids = PackageUtil.findPids(targetPkg)
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_FOUND, "not_running")
        }
        val staged = ModuleStore.stageForTarget(context, targetPkg)
            ?: return PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE)

        var last: PtraceInjectResult? = null
        for (pid in pids) {
            val result = PtraceInjector.inject(pid, staged.absolutePath, entry)
            if (result.isSuccess) return result
            last = result
        }
        return last ?: PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN)
    }
}
