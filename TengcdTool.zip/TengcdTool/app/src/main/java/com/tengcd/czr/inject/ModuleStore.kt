package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import java.io.File
import java.io.InputStream

/**
 * 模块 so 的存放 / 校验 / 分发。
 *
 * 现在一共有三种来源,注入时用哪一个看 InjectionPrefs.soSource:
 *  - builtin : 包里内置的变体。assets/so/v0.19.so ~ v0.24.so,
 *              首次启动全部铺到 files/module/libhonffx_<变体>.so,选择器切哪个就用哪个
 *  - local   : 用户从本机读进来的 so,落到 files/module/libhonffx_local.so
 *  - remote  : 从服务端下载的 so,落到 files/module/libhonffx.so
 *
 * 进程注入时还会再往目标应用自己的数据目录里放一份 —— 不给它放,
 * 目标进程的 linker 会因为路径权限拒绝加载。
 */
object ModuleStore {

    /** 远端下载件的老文件名 */
    const val MODULE_FILE_NAME = "libhonffx.so"

    /** 包里内置 so 的目录(assets/so/) */
    private const val ASSET_SO_DIR = "so"

    /** 老资产兼容:以前是 assets/injlib 单文件 */
    private const val LEGACY_ASSET = "injlib"

    /** 内置的四个变体,按这个顺序显示在模块概览下面的选择器里 */
    val BUILTIN_VARIANTS = listOf("v0.19", "v0.20", "v0.23", "v0.24")

    fun moduleDir(context: Context): File = File(context.filesDir, "module")

    /** 远端下载件落位 */
    fun remoteFile(context: Context): File = File(moduleDir(context), MODULE_FILE_NAME)

    /** 内置变体落位 */
    fun variantFile(context: Context, variant: String): File =
        File(moduleDir(context), "libhonffx_$variant.so")

    /** 本机读取进来的 so 落位 */
    fun localFile(context: Context): File = File(moduleDir(context), "libhonffx_local.so")

    /** 当前注入会用的那个文件(不一定存在) */
    fun effectiveFile(context: Context): File = when (InjectionPrefs.soSource) {
        InjectionPrefs.SO_SOURCE_LOCAL -> localFile(context)
        InjectionPrefs.SO_SOURCE_REMOTE -> remoteFile(context)
        else -> variantFile(context, InjectionPrefs.soVariant)
    }

    /** 当前生效的 so 路径,没就绪返回 null */
    fun effectivePath(context: Context): String? =
        effectiveFile(context).takeIf { it.isFile && it.length() > 0 }?.absolutePath

    /** 当前生效的 so(兼容老调用点) */
    fun moduleFile(context: Context): File = effectiveFile(context)

    /** 当前生效的 so 是否就绪 */
    fun isDownloaded(context: Context): Boolean = effectivePath(context) != null

    fun size(context: Context): Long = effectiveFile(context).length()

    /** 给界面用的一句话来源标签 */
    fun sourceLabel(): String = when (InjectionPrefs.soSource) {
        InjectionPrefs.SO_SOURCE_LOCAL -> "local"
        InjectionPrefs.SO_SOURCE_REMOTE -> "remote"
        else -> InjectionPrefs.soVariant
    }

    /**
     * 首次进来把四个内置变体都铺到私有目录,之后切哪个用哪个,不用再解包。
     * 包里如果没有 assets/so/ 这一批,退回老的 injlib 单文件。
     */
    fun ensureBundled(context: Context): Boolean {
        var any = false
        for (variant in BUILTIN_VARIANTS) {
            if (unpackVariant(context, variant)) any = true
        }
        if (!any) any = unpackLegacy(context)
        refreshPrefs(context)
        return any
    }

    fun hasVariant(context: Context, variant: String): Boolean {
        val f = variantFile(context, variant)
        return f.isFile && f.length() > 0
    }

    private fun unpackVariant(context: Context, variant: String): Boolean {
        val dst = variantFile(context, variant)
        if (dst.isFile && dst.length() > 0) return true
        return try {
            dst.parentFile?.mkdirs()
            context.assets.open("$ASSET_SO_DIR/$variant.so").use { input ->
                dst.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            dst.length() > 0
        } catch (t: Throwable) {
            false
        }
    }

    private fun unpackLegacy(context: Context): Boolean {
        val dst = remoteFile(context)
        if (dst.isFile && dst.length() > 0) return true
        return try {
            dst.parentFile?.mkdirs()
            context.assets.open(LEGACY_ASSET).use { input ->
                dst.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            dst.length() > 0
        } catch (t: Throwable) {
            false
        }
    }

    /**
     * 把本机读进来的 so 落到私有目录。
     * 外部路径(比如 /sdcard/Download/xxx.so)目标进程未必打得开,所以统一先收进私有目录,
     * 再按进程注入的老路子往目标数据目录里搬。
     */
    fun importLocalSo(context: Context, input: InputStream, sourcePath: String?): File? {
        val dst = localFile(context)
        return try {
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            if (tmp.length() <= 0L) {
                tmp.delete()
                return null
            }
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) {
                tmp.delete()
                return null
            }
            InjectionPrefs.localSoSourcePath = sourcePath ?: dst.absolutePath
            InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_LOCAL
            refreshPrefs(context)
            dst
        } catch (t: Throwable) {
            null
        }
    }

    /** 切到内置变体 */
    fun useBuiltin(context: Context, variant: String) {
        InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
        InjectionPrefs.soVariant = variant
        refreshPrefs(context)
    }

    /** 切到本机读进来的 so */
    fun useLocal(context: Context) {
        InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_LOCAL
        refreshPrefs(context)
    }

    fun clearLocal(context: Context) {
        try {
            localFile(context).delete()
        } catch (t: Throwable) {
        }
        InjectionPrefs.localSoSourcePath = null
        if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL) {
            InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
        }
        refreshPrefs(context)
    }

    /** 把"当前生效文件"的路径 / md5 / 版本名同步进偏好(注入链路都读这几个键) */
    fun refreshPrefs(context: Context) {
        val f = effectiveFile(context)
        InjectionPrefs.modulePath = f.absolutePath
        InjectionPrefs.moduleMd5 = if (f.isFile) Md5Util.md5(f) else null
        InjectionPrefs.moduleVersion = sourceLabel()
    }

    /** 把当前生效的 so 复制到目标自己的数据目录,进程注入靠它才能 dlopen 成功 */
    fun stageForTarget(context: Context, targetPkg: String): File? {
        val src = effectiveFile(context)
        if (!src.isFile || src.length() <= 0L) return null
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        val targetDir = File(dataDir, "files")
        if (!PermissionUtil.canWriteDir(targetDir)) return null
        val dst = File(targetDir, src.name)
        if (dst.isFile && Md5Util.md5(dst) == Md5Util.md5(src)) return dst
        return if (Md5Util.copyWithVerify(src, dst, Md5Util.md5(src))) dst else null
    }

    /** 框架注入时,HookInit 从这里读 so 路径 */
    fun handoffFile(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "module_path.txt")

    fun writeHandoff(context: Context, soPath: String, targetPkg: String) {
        try {
            val f = handoffFile(context)
            f.parentFile?.mkdirs()
            f.writeText("$soPath\n$targetPkg\n")
        } catch (t: Throwable) {
            // 外部目录不可写就退到私有目录,由 SoProvider 兜底
            try {
                File(context.filesDir, "module_path.txt").writeText("$soPath\n$targetPkg\n")
            } catch (ignored: Throwable) {
            }
        }
    }

    fun readHandoff(context: Context): Pair<String, String>? {
        val candidates = listOf(
            handoffFile(context),
            File(context.filesDir, "module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val lines = f.readLines().filter { it.isNotBlank() }
                if (lines.isEmpty()) continue
                val pkg = lines.getOrNull(1) ?: InjectionPrefs.targetPackage
                return lines[0].trim() to pkg.trim()
            } catch (t: Throwable) {
            }
        }
        return null
    }
}
