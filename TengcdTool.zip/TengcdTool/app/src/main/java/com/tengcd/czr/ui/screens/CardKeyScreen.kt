package com.tengcd.czr.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/** 内置链接:统一在 util/Links 里改一处就够了 */
private val BUILTIN_LINK = com.tengcd.czr.util.Links.QQ_GROUP

/**
 * 次数显示:null = 服务端这次没给这一项,写「未返回」;
 * -1 = 服务端明确说不限;>=0 = 具体数。
 * 以前不管拿到没拿到都写「不限」,看着像查到了,其实是没查到。
 */
private fun countText(value: Int?, s: LocalizedStrings): String = when {
    value == null -> s.notReturned
    value < 0 -> s.unlimited
    else -> value.toString()
}

@Composable
fun CardKeyScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme
    val uriHandler = LocalUriHandler.current
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 卡密页不再放公告卡,直接在下面查卡
        Spacer(Modifier.height(16.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Key, s.cardQuery, dark)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = state.cardKey,
                onValueChange = { onAction(UiAction.CardKeyChanged(it)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(s.cardHint) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                    unfocusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                    focusedBorderColor = AccentBlue,
                    unfocusedBorderColor = if (dark) Color(0x55FFFFFF) else Color(0x66FFFFFF),
                    focusedLabelColor = AccentBlue,
                    unfocusedLabelColor = if (dark) TextSecondaryDark else TextSecondaryLight,
                    cursorColor = AccentBlue,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                )
            )

            Spacer(Modifier.height(14.dp))

            // 删除了“本地校验”的 Text 和 Switch 开关

            // 只留查询:解绑那套不做了(查询是只读的,不该顺手把设备解绑)
            PrimaryActionButton(
                text = if (state.cardQuerying) s.querying else s.cardQuery,
                icon = null,
                enabled = !state.cardQuerying,
                dark = dark
            ) { onAction(UiAction.QueryCard) }
        }

        Spacer(Modifier.height(12.dp))

        // 机器码不再单独占一张卡(和下面「绑定设备」那行重复):
        // 串还是那一串,复制按钮搬到了「绑定设备」行右边。
        // 只显示「这一张卡」的结果。换卡后还没重查时,别把上一张卡的数据摆在下面装成本卡。
        val cardInput = state.cardKey.trim()
        val shownInfo = state.cardInfo?.takeIf { it.card.equals(cardInput, ignoreCase = true) }
        if (state.cardInfo != null && shownInfo == null && !state.cardQuerying && cardInput.isNotEmpty()) {
            Text(
                text = s.cardResultStale,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        shownInfo?.let { info ->
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.Info, s.cardQueryResult, dark)
                Spacer(Modifier.height(8.dp))

                val stateText = when {
                    info.banned -> s.banned
                    !info.valid && info.message == "expired" -> s.expired
                    !info.valid && info.message == "count_exhausted" -> s.countExhausted
                    info.valid -> s.inUse
                    else -> s.cardInvalid
                }
                StatusRow(
                    label = s.cardQuery,
                    value = stateText,
                    dark = dark,
                    dot = false,
                    ok = info.valid,
                    warn = !info.valid && !info.banned
                )
                if (info.valid) {
                    // 计次卡后台不给到期时间:这里写「按次计费」,不要写成「不限」,
                    // 不然用户以为永久有效,次数用完还来问为什么不能用了。
                    val isCount = info.isCountCard || info.cardType.contains("次") ||
                        (info.expireTime.isBlank() && info.remainCount != null)
                    StatusRow(
                        label = s.expireTime,
                        value = when {
                            info.expireTime.isNotBlank() -> info.expireTime
                            isCount || info.isCountCard -> s.expireByCount
                            // 后台没给到期时间、又不是次数卡:老实写「未返回」,
                            // 别拿「不限」糊过去(那会被当成永久有效)
                            else -> s.notReturned
                        },
                        dark = dark
                    )
                    if (info.cardType.isNotBlank()) {
                        StatusRow(
                            label = s.cardTypeLabel,
                            value = info.cardType,
                            dark = dark
                        )
                    }
                    // 次数只在登录回包里出现(状态接口给的 available 是剩余秒数),
                    // 查询时拿不到就退回登录时读到的那一份,别写「不限」骗人。
                    val showCount = info.remainCount?.takeIf { it > 0 }
                    StatusRow(
                        label = s.remainCount,
                        value = when {
                            showCount != null -> showCount.toString()
                            isCount -> s.notReturned
                            else -> s.unlimited
                        },
                        dark = dark,
                        dot = isCount,
                        ok = isCount
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = s.bindDevice,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (dark) TextPrimaryDark else TextPrimaryLight
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            text = info.boundDevice.ifBlank { s.noBinding },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (dark) TextSecondaryDark else TextSecondaryLight
                        )
                        val copyText = info.boundDevice.ifBlank { state.machineCode }
                        if (copyText.isNotBlank()) {
                            Spacer(Modifier.width(8.dp))
                            SecondaryActionButton(
                                text = s.machineCodeCopy,
                                icon = null,
                                dark = dark,
                                modifier = Modifier.width(64.dp)
                            ) {
                                clipboard.setText(AnnotatedString(copyText))
                                Toast.makeText(context, s.machineCodeCopied, Toast.LENGTH_SHORT)
                                    .show()
                            }
                        }
                    }
                } else {
                    // 查不到就把真实原因写出来,别拿一排「不限」占位糊弄
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = info.message.ifBlank { s.cardInvalid },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }

                // 在线人数:从「获取在线卡密数量」接口拿的,跟这张卡有没有效无关,
                // 所以放在有效性判断外面,查卡时每次都能看到。
                if (info.onlineCount != null) {
                    StatusRow(
                        label = s.onlineCount,
                        value = info.onlineCount.toString(),
                        dark = dark
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Link, s.linkTitle, dark)
            Spacer(Modifier.height(6.dp))
            Text(
                text = s.qqGroupHint,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = BUILTIN_LINK,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(12.dp))
            // 整行大按钮:点一下直接拉起 QQ 进群
            PrimaryActionButton(
                text = s.qqGroupJoin,
                icon = Icons.Filled.Group,
                enabled = true,
                dark = dark
            ) {
                try {
                    uriHandler.openUri(BUILTIN_LINK)
                } catch (t: Throwable) {
                    Toast.makeText(context, s.operationFailed, Toast.LENGTH_SHORT).show()
                }
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}