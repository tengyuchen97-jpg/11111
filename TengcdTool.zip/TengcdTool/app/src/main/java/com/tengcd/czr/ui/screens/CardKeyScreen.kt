package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/** 内置链接:把下面地址换成你的实际链接 */
private const val BUILTIN_LINK = "https://qm.qq.com/q/RJvQktX6gg"

@Composable
fun CardKeyScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme
    val uriHandler = LocalUriHandler.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 卡密页不再放公告卡,直接在下面查卡
        Spacer(Modifier.height(16.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Key, s.cardQuery, dark)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = state.cardKey,
                onValueChange = { onAction(UiAction.CardKeyChanged(it)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(s.cardHint) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                    unfocusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                    focusedBorderColor = AccentBlue,
                    unfocusedBorderColor = if (dark) Color(0x55FFFFFF) else Color(0x66FFFFFF),
                    focusedLabelColor = AccentBlue,
                    unfocusedLabelColor = if (dark) TextSecondaryDark else TextSecondaryLight,
                    cursorColor = AccentBlue,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                )
            )

            Spacer(Modifier.height(14.dp))

            // 删除了“本地校验”的 Text 和 Switch 开关

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PrimaryActionButton(
                    text = if (state.cardQuerying) s.querying else s.cardQuery,
                    icon = null,
                    enabled = !state.cardQuerying,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.QueryCard) }

                SecondaryActionButton(
                    text = if (state.cardQuerying) s.unbinding else s.unbindDevice,
                    icon = null,
                    dark = dark,
                    modifier = Modifier.weight(1f),
                    enabled = !state.cardQuerying
                ) { onAction(UiAction.UnbindCard) }
            }
        }

        Spacer(Modifier.height(12.dp))

        state.cardInfo?.let { info ->
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.Info, s.cardQueryResult, dark)
                Spacer(Modifier.height(8.dp))

                val stateText = when {
                    info.banned -> s.banned
                    !info.valid && info.message == "expired" -> s.expired
                    !info.valid && info.message == "count_exhausted" -> s.countExhausted
                    info.valid -> s.inUse
                    else -> s.cardInvalid
                }
                StatusRow(
                    label = s.cardQuery,
                    value = stateText,
                    dark = dark,
                    dot = false,
                    ok = info.valid,
                    warn = !info.valid && !info.banned
                )
                StatusRow(
                    label = s.expireTime,
                    value = info.expireTime.ifBlank { s.unlimited },
                    dark = dark
                )
                StatusRow(
                    label = s.remainCount,
                    value = if (info.remainCount < 0) s.unlimited else info.remainCount.toString(),
                    dark = dark
                )
                StatusRow(
                    label = s.bindDevice,
                    value = info.boundDevice.ifBlank { s.noBinding },
                    dark = dark,
                    dot = info.boundDevice.isBlank(),
                    ok = info.boundDevice.isBlank()
                )
                StatusRow(
                    label = s.unbindCount,
                    value = if (info.unbindCount < 0) s.unlimited else info.unbindCount.toString(),
                    dark = dark
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        GlassCard(dark = dark) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(Icons.Filled.Link, s.linkTitle, dark)
                Spacer(Modifier.weight(1f))
                SecondaryActionButton(
                    text = s.linkOpen,
                    icon = null,
                    dark = dark,
                    modifier = Modifier.width(110.dp)
                ) {
                    uriHandler.openUri(BUILTIN_LINK)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = BUILTIN_LINK,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(28.dp))
    }
}