package com.tengcd.czr.network

/**
 * 卡密查询结果。本地校验模式下由 LocalCardGate 直接构造同名对象。
 */
data class CardQueryInfo(
    val card: String = "",
    val expireTime: String = "",
    val remainCount: Int = -1,
    val unbindCount: Int = -1,
    val boundDevice: String = "",
    val banned: Boolean = false,
    val valid: Boolean = true,
    val message: String = ""
)
