package com.tengcd.czr.inject

import com.tengcd.czr.util.PackageUtil
import java.io.File

/**
 * 进程注入器(uid 注入)。
 *
 * 流程:找 pid -> ptrace 附加 -> 在目标里解析 mmap/dlopen(优先 __loader_dlopen)
 * -> 远程 mmap 一块内存写 so 路径 -> 调 dlopen -> 还原寄存器 -> detach。
 * 全在 native 侧做,这边只负责找目标 + 把结果翻译成人话。
 */
object PtraceInjector {

    data class TargetProcess(val pid: Int, val name: String, val uid: Int)

    private const val LIB_NAME = "ptrace_injector"

    private val loadError: String? = try {
        System.loadLibrary(LIB_NAME)
        null
    } catch (t: Throwable) {
        t.message ?: t.javaClass.simpleName
    }

    val isAvailable: Boolean get() = loadError == null

    val unavailableReason: String? get() = loadError

    private external fun nativeInject(pid: Int, soPath: String, entry: String?): Int

    /**
     * 一次会话注入多个 so。
     * 只冻目标一次、只放行一次(原生侧原生支持,留着给多库场景用)。
     */
    private external fun nativeInjectMany(pid: Int, soPaths: Array<String>, entry: String?): Int

    /** 最近一次注入,原生侧给出的详细原因(注入到哪一步停的) */
    private external fun nativeLastDetail(): String

    /**
     * 给 [RootShimMain] 用的直通口:在那个 root 身份的 app_process 里,
     * 库是 System.load(绝对路径) 加载的,loadLibrary 的结论不适用,
     * 所以跳开 [inject] 的可用性检查直接打原生方法。
     */
    internal fun nativeInjectRaw(pid: Int, soPath: String, entry: String?): Int =
        nativeInject(pid, soPath, entry)

    internal fun nativeDetailRaw(): String = nativeLastDetail()

    @Volatile
    var lastDetail: String? = null
        private set

    /** 目标包在跑的所有进程(主进程 + :xxx 子进程) */
    fun listProcesses(pkg: String): List<TargetProcess> =
        PackageUtil.findPids(pkg).map { pid ->
            TargetProcess(pid, PackageUtil.processNameOfPid(pid), PackageUtil.readUidOfPid(pid))
        }

    /**
     * 一次 ptrace 会话把多个 so 按顺序 dlopen 进目标。
     *
     * 顺序就是列表顺序:调用方一般把补丁库放前面(先把更新检测按住),
     * 游戏模块放后面。前面的失败不影响后面的,只要有一个成功就算成功。
     */
    fun injectMany(pid: Int, soPaths: List<String>, entry: String? = null): PtraceInjectResult {
        if (!isAvailable) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.NATIVE_NOT_LOADED, loadError
            )
        }
        if (soPaths.isEmpty()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN, "没有要注入的 so")
        }
        if (soPaths.any { it.length >= 256 }) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.PATH_TOO_LONG)
        }
        // 第一份是用户真正要注入的模块:它必须存在
        val missing = soPaths.firstOrNull { !File(it).exists() }
        if (missing != null) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.DLOPEN_FAILED, "so 不存在:" + File(missing).name
            )
        }
        val code = try {
            nativeInjectMany(pid, soPaths.toTypedArray(), entry)
        } catch (t: Throwable) {
            PtraceInjectFailure.UNKNOWN.code
        }
        val detail = try {
            nativeLastDetail()
        } catch (t: Throwable) {
            null
        }
        lastDetail = detail
        return PtraceInjectResult.fromCode(code, pid, soPaths.last(), detail)
    }

    /**
     * @param pid     目标进程
     * @param soPath  模块 so 的可访问绝对路径(最好放目标自己数据目录里)
     * @param entry   可选:so 里要主动调一下的导出符号名(不带项目)
     */
    fun inject(pid: Int, soPath: String, entry: String? = null): PtraceInjectResult {
        if (!isAvailable) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.NATIVE_NOT_LOADED, loadError
            )
        }
        if (soPath.length >= 256) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.PATH_TOO_LONG)
        }
        if (!File(soPath).exists()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.DLOPEN_FAILED, "so 不存在")
        }
        val code = try {
            nativeInject(pid, soPath, entry)
        } catch (t: Throwable) {
            PtraceInjectFailure.UNKNOWN.code
        }
        val detail = try {
            nativeLastDetail()
        } catch (t: Throwable) {
            null
        }
        lastDetail = detail
        return PtraceInjectResult.fromCode(code, pid, soPath, detail)
    }
}
