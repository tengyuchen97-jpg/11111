package com.tengcd.czr.network

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import java.util.Locale

/**
 * 本地卡密版:整个 App 完全不联网校验。
 *
 * 对外暴露的接口和联网版一模一样(login / query / unbind / heartbeat / notice ...),
 * 所以界面层一行都不用改,只把校验从「T3 服务器」换成「本机卡密表」。
 *
 * 卡密表在哪:
 *   1. LocalCardGate.kt 顶部的 BUILT_IN_CARDS(改一行重新编译就换卡)
 *   2. /sdcard/Download/honffx_card.txt(不重新打包也能换卡/加卡/改到期时间)
 *      格式:卡密|到期时间|剩余次数(-1=不限)|解绑次数
 *      例:  ABC-1234-5678|2027-12-31|-1|3
 *
 * 这张卡不联网,自然也没有服务器能封它 —— 只在本机按上面的表和日期判断。
 */
data class T3Config(
    val baseUrl: String = "local://card",
    val appId: String = "",
    val appKey: String = "",
    val aesKey: String = "",
    val charset: String = "",
    /** 请求体格式:官方只有 form,保留字段兼容老配置 */
    val format: String = "form"
) {
    val ready: Boolean
        get() = true

    companion object {
        fun official(): T3Config = T3Config()

        fun fromPrefs(): T3Config = T3Config()
    }
}

data class T3Result(
    val ok: Boolean,
    val message: String,
    val token: String = "",
    val expireAt: Long = 0L,
    val expireText: String = "",
    val remainCount: Int = -1,
    val unbindCount: Int = -1,
    val boundDevice: String = "",
    val banned: Boolean = false,
    val expired: Boolean = false,
    val exhausted: Boolean = false,
    /** 卡不能用(过期/次数用完/卡不在表里),调用方应该退登 */
    val invalid: Boolean = false,
    val notice: String = "",
    val reached: Boolean = true,
    val raw: String = ""
)

object T3Client {

    /** 本地公告:想改就改这一行,或者往 /sdcard/Download/honffx_notice.txt 里写 */
    private const val LOCAL_NOTICE = "本地卡密版:不联网校验,进入即用。"
    private const val LOCAL_NOTICE_FILE = "/sdcard/Download/honffx_notice.txt"

    /** 卡密登录:只查本机卡密表 */
    suspend fun login(
        context: Context,
        config: T3Config,
        card: String,
        deviceId: String
    ): T3Result {
        attach(context)
        val c = card.trim()
        if (c.isEmpty()) return T3Result(false, "请输入卡密", reached = true)

        val info = LocalCardGate.query(context, c)
        if (!info.valid) return failOf(info)

        LocalCardGate.bind(context, c)
        val bound = InjectionPrefs.boundDevice ?: deviceId
        return T3Result(
            ok = true,
            message = "ok",
            token = tokenOf(c, deviceId),
            expireAt = 0L,
            expireText = info.expireTime,
            remainCount = info.remainCount,
            unbindCount = info.unbindCount,
            boundDevice = bound,
            reached = true
        )
    }

    /** 卡密查询:返回本机记录的到期时间/次数/绑定设备 */
    suspend fun query(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result {
        val c = card.trim()
        if (c.isEmpty()) return T3Result(false, "请输入卡密", reached = true)
        val info = LocalCardGate.query(androidContext ?: return T3Result(false, "初始化未完成"), c)
        if (!info.valid) return failOf(info)
        return T3Result(
            ok = true,
            message = "ok",
            token = tokenOf(c, deviceId),
            expireText = info.expireTime,
            remainCount = info.remainCount,
            unbindCount = info.unbindCount,
            boundDevice = info.boundDevice,
            reached = true
        )
    }

    /** 解绑:本地版就是把记录的绑定设备清掉 */
    suspend fun unbind(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result {
        val c = card.trim()
        val ctx = androidContext ?: return T3Result(false, "初始化未完成")
        val info = LocalCardGate.query(ctx, c)
        if (!info.valid) return failOf(info)
        LocalCardGate.unbind(ctx, c)
        return T3Result(ok = true, message = "解绑成功", boundDevice = "", reached = true)
    }

    /** 心跳:本地版只是复核一下卡还在不在表里(比如你把 txt 删了) */
    suspend fun heartbeat(
        config: T3Config,
        token: String,
        deviceId: String,
        card: String = ""
    ): T3Result {
        val ctx = androidContext ?: return T3Result(ok = true, message = "ok")
        val c = card.trim().ifBlank { InjectionPrefs.cardKey }
        if (c.isBlank()) return T3Result(ok = true, message = "ok")
        val info = LocalCardGate.query(ctx, c)
        if (!info.valid) return failOf(info)
        return T3Result(
            ok = true,
            message = "ok",
            token = token,
            expireText = info.expireTime,
            remainCount = info.remainCount,
            unbindCount = info.unbindCount,
            boundDevice = info.boundDevice,
            reached = true
        )
    }

    /** 公告:读本地文本 */
    suspend fun notice(config: T3Config, card: String = "", token: String = ""): T3Result {
        val text = readNotice()
        return T3Result(ok = true, message = "ok", notice = text, reached = true)
    }

    suspend fun latestVersion(config: T3Config): T3Result =
        T3Result(ok = true, message = "1.0", reached = true)

    suspend fun checkVersion(config: T3Config, ver: String): T3Result =
        T3Result(ok = true, message = "已是最新版本", reached = true)

    /** 设备指纹:本地版也用它记「这张卡第一次绑在哪台机」 */
    fun deviceId(context: Context): String = try {
        LocalCardGate.deviceId(context)
    } catch (t: Throwable) {
        "LOCALDEVICE0000"
    }

    /** 展示用:本地版没有服务器地址 */
    fun prettyHost(url: String): String = "本地校验"

    // ---------------- 内部 ----------------

    /** 随便一个稳定的字符串当"登录态",本地版不需要服务端认它 */
    private fun tokenOf(card: String, deviceId: String): String =
        "LOCAL-" + Md5Util.md5(card + "|" + deviceId).take(16).uppercase(Locale.US)

    private fun failOf(info: CardQueryInfo): T3Result {
        val expired = info.message == "expired"
        val exhausted = info.message == "count_exhausted"
        val msg = when {
            expired -> "卡密已过期"
            exhausted -> "卡密次数已用完"
            info.banned -> "卡密已被停用"
            else -> "卡密无效"
        }
        return T3Result(
            ok = false,
            message = msg,
            banned = info.banned,
            expired = expired,
            exhausted = exhausted,
            invalid = true,
            reached = true
        )
    }

    private fun readNotice(): String {
        try {
            val f = java.io.File(LOCAL_NOTICE_FILE)
            if (f.isFile) {
                val text = f.readText().trim()
                if (text.isNotEmpty()) return text
            }
        } catch (t: Throwable) {
            // 读不到就用内置那句
        }
        return LOCAL_NOTICE
    }

    /** query/unbind/heartbeat 这些签名里没有 Context,登录时记一份 */
    @Volatile
    private var androidContext: Context? = null

    /** 必须在 Application / 登录入口调一次(界面层不用管,MainViewModel 的 login 会带 ctx) */
    fun attach(context: Context) {
        androidContext = context.applicationContext
    }
}

fun T3Result.toCardInfo(card: String): CardQueryInfo = CardQueryInfo(
    card = card,
    expireTime = expireText,
    remainCount = remainCount,
    unbindCount = unbindCount,
    boundDevice = boundDevice,
    banned = banned,
    valid = ok,
    message = when {
        ok -> message
        banned -> "banned"
        expired -> "expired"
        exhausted -> "count_exhausted"
        else -> message
    }
)
