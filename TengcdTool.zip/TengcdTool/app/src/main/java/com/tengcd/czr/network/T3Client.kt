package com.tengcd.czr.network

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Base64
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * T3 网络验证的接入参数。
 */
data class T3Config(
    val baseUrl: String,
    val appId: String,
    val appKey: String,
    val aesKey: String
) {
    /** 地址和 appid 都填了才算配置好 */
    val ready: Boolean
        get() = baseUrl.isNotBlank() && appId.isNotBlank()

    companion object {
        fun fromPrefs(): T3Config = T3Config(
            baseUrl = InjectionPrefs.t3BaseUrl,
            appId = InjectionPrefs.t3AppId,
            appKey = InjectionPrefs.t3AppKey,
            aesKey = InjectionPrefs.t3AesKey
        )
    }
}

/** 一次验证请求的结果 */
data class T3Result(
    val ok: Boolean,
    val message: String,
    val token: String = "",
    val expireAt: Long = 0L,
    val expireText: String = "",
    val raw: String = ""
)

/**
 * T3 网络验证客户端(登录 / 心跳 / 解绑)。
 *
 * 请求体和字段名都集中在这个文件里,后台如果和你给的文档对不上,
 * 只需要改下面这几个常量就行,界面不用动。
 */
object T3Client {

    /** 接口路径 —— 按 T3 后台的文档改这里 */
    private const val LOGIN_PATH = "/api/v2/login"
    private const val HEARTBEAT_PATH = "/api/v2/heartbeat"
    private const val UNBIND_PATH = "/api/v2/unbind"

    private const val UA = "TengcdTool/0.6 (Android)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    // ---------------- 对外接口 ----------------

    /** 卡密登录 */
    suspend fun login(
        context: Context,
        config: T3Config,
        card: String,
        deviceId: String
    ): T3Result = withContext(Dispatchers.IO) {
        val time = System.currentTimeMillis() / 1000L
        val body = JSONObject()
        body.put("appid", config.appId)
        body.put("app_id", config.appId)
        body.put("appkey", config.appKey)
        body.put("app_key", config.appKey)
        body.put("card", card)
        body.put("kami", card)
        body.put("device", deviceId)
        body.put("machine_code", deviceId)
        body.put("time", time)
        body.put("timestamp", time)
        body.put("sign", sign(config.appId, card, deviceId, time, config.appKey))
        // 有的版本要求把参数整体加密成 data,这里一并带上,服务端不认就忽略
        encrypted(config, card, deviceId, time)?.let { body.put("data", it) }

        val result = post(config.baseUrl + LOGIN_PATH, body)
        parseLogin(result)
    }

    /** 心跳:带上 token 保活 */
    suspend fun heartbeat(config: T3Config, token: String, deviceId: String): T3Result =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
            body.put("appid", config.appId)
            body.put("appkey", config.appKey)
            body.put("token", token)
            body.put("device", deviceId)
            body.put("time", System.currentTimeMillis() / 1000L)
            parseLogin(post(config.baseUrl + HEARTBEAT_PATH, body))
        }

    /** 解绑当前设备 */
    suspend fun unbind(config: T3Config, card: String, deviceId: String): T3Result =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
            body.put("appid", config.appId)
            body.put("appkey", config.appKey)
            body.put("card", card)
            body.put("device", deviceId)
            body.put("time", System.currentTimeMillis() / 1000L)
            parseLogin(post(config.baseUrl + UNBIND_PATH, body))
        }

    // ---------------- 内部实现 ----------------

    private fun post(url: String, body: JSONObject): String {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "application/json")
                .post(body.toString().toRequestBody(jsonMedia))
                .build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (text.isBlank() && !response.isSuccessful) {
                    "{\"code\":${response.code},\"msg\":\"HTTP ${response.code}\"}"
                } else {
                    text
                }
            }
        } catch (t: Throwable) {
            "{\"code\":-1,\"msg\":\"" + (t.message ?: "网络异常").replace("\"", "'") + "\"}"
        }
    }

    /** 签名:md5(appid + card + device + time + appkey),跟 T3 后台的约定 */
    private fun sign(appId: String, card: String, device: String, time: Long, appKey: String): String =
        Md5Util.md5(appId + card + device + time + appKey).uppercase(Locale.US)

    /** 参数整体 AES 加密,key 用后台给的 base64 密钥 */
    private fun encrypted(config: T3Config, card: String, device: String, time: Long): String? {
        return try {
            val key = Base64.decode(config.aesKey, Base64.DEFAULT)
            if (key.size < 16) return null
            val aesKey = when {
                key.size >= 32 -> key.copyOf(32)
                key.size >= 24 -> key.copyOf(24)
                else -> key.copyOf(16)
            }
            val iv = aesKey.copyOf(16)
            val payload = JSONObject()
            payload.put("card", card)
            payload.put("device", device)
            payload.put("time", time)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(
                Cipher.ENCRYPT_MODE,
                SecretKeySpec(aesKey, "AES"),
                IvParameterSpec(iv)
            )
            Base64.encodeToString(cipher.doFinal(payload.toString().toByteArray()), Base64.NO_WRAP)
        } catch (t: Throwable) {
            null
        }
    }

    /** 服务端返回的格式五花八门,这里尽量都认 */
    private fun parseLogin(text: String): T3Result {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || trimmed[0] != '{') {
            return T3Result(false, trimmed.take(180).ifBlank { "服务器没有返回内容" }, raw = text)
        }
        return try {
            val json = JSONObject(trimmed)
            val code = when {
                json.has("code") -> json.optInt("code", -1)
                json.has("status") -> json.optInt("status", -1)
                else -> -1
            }
            val msg = json.optString("msg").ifBlank { json.optString("message") }
                .ifBlank { json.optString("info") }
            val data = json.optJSONObject("data") ?: JSONObject()
            val token = data.optString("token")
                .ifBlank { data.optString("access_token") }
                .ifBlank { json.optString("token") }
            val expireRaw = data.optString("expire_time")
                .ifBlank { data.optString("expire") }
                .ifBlank { data.optString("expireTime") }
                .ifBlank { data.optString("vip_time") }
            val expireAt = parseExpire(expireRaw)
            val okFlag = when {
                token.isNotBlank() -> true
                code == 0 || code == 1 || code == 200 -> true
                json.optBoolean("success", false) -> true
                else -> false
            }
            T3Result(
                ok = okFlag,
                message = msg.ifBlank {
                    if (okFlag) "ok" else "验证失败(返回码 $code)"
                },
                token = token,
                expireAt = expireAt,
                expireText = formatExpire(expireAt, expireRaw),
                raw = text
            )
        } catch (t: Throwable) {
            T3Result(false, "服务器返回解析不了", raw = text)
        }
    }

    private fun parseExpire(raw: String): Long {
        val value = raw.trim()
        if (value.isEmpty() || value == "0" || value.equals("null", true)) return 0L
        value.toLongOrNull()?.let { num ->
            return if (num > 10_000_000_000L) num else num * 1000L
        }
        val patterns = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd HH:mm:ss")
        for (pattern in patterns) {
            try {
                val format = SimpleDateFormat(pattern, Locale.CHINA)
                format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
                val date = format.parse(value) ?: continue
                return date.time
            } catch (t: Throwable) {
                // 换下一个格式
            }
        }
        return 0L
    }

    private fun formatExpire(expireAt: Long, raw: String): String {
        if (expireAt <= 0L) return raw.trim()
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
            format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
            format.format(expireAt)
        } catch (t: Throwable) {
            raw.trim()
        }
    }

    /** 设备指纹:优先用系统给的 ANDROID_ID 派生的那个 */
    fun deviceId(context: Context): String = try {
        LocalCardGate.deviceId(context)
    } catch (t: Throwable) {
        val fallback = (Build.MODEL.orEmpty() + Build.BRAND.orEmpty() + Build.ID.orEmpty())
        Md5Util.md5(fallback).take(16).uppercase(Locale.US)
    }

    /** 展示用:把域名裁一裁,别在界面上撑爆一行 */
    fun prettyHost(url: String): String {
        if (url.isBlank()) return "-"
        return try {
            Uri.parse(url).host ?: url
        } catch (t: Throwable) {
            url
        }
    }
}
