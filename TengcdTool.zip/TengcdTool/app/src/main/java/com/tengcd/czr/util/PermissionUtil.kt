package com.tengcd.czr.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

object PermissionUtil {

    /** Android 11+ 需要"所有文件访问"权限才能碰 /sdcard 下的模块目录 */
    fun hasAllFilesAccess(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        true
    }

    fun hasLegacyStorage(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return true
        val read = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        val write = ContextCompat.checkSelfPermission(
            context, Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        return read && write
    }

    fun hasNotification(context: Context): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    /** 能不能读目标应用的数据目录(同 uid 才行) */
    fun canReadDir(dir: File?): Boolean {
        if (dir == null) return false
        return try {
            dir.exists() && dir.canRead() && (dir.list()?.isNotEmpty() == true || dir.isDirectory)
        } catch (t: Throwable) {
            false
        }
    }

    fun canWriteDir(dir: File?): Boolean {
        if (dir == null) return false
        if (!dir.exists()) return dir.mkdirs() || dir.canWrite()
        return dir.canWrite()
    }
}
