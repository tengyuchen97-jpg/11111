package com.tengcd.czr.inject

/**
 * 两种注入方式。
 *
 * FRAMEWORK - 框架注入:Xposed/LSPosed 里勾选本应用为模块 + 勾选目标作用域,
 *             目标进程启动时由 HookInit 把模块 so 载进去。
 * PROCESS   - 进程注入:目标已经在跑,用 App 自己的身份 ptrace 附加,远程调 __loader_dlopen 加载 so。
 *             要求两个应用共用同一个 sharedUserId,目标数据目录可访问。
 *
 * value 是老版本就存在存储里的整数,别改(FRAMEWORK 0 / PROCESS 1 保持不变)。
 * 老版本还有一档 ROOT(2),已经整档删掉;读配置时碰到 2 一律按 FRAMEWORK 处理,
 * 并把存储里的值改回 0,不会再把界面切回一个不存在的档位。
 */
enum class InjectionMode(val value: Int) {
    FRAMEWORK(0),
    PROCESS(1);

    companion object {
        /** 老版本 root 注入存的整数,只用来识别旧配置,不再对应任何模式 */
        const val LEGACY_ROOT_VALUE = 2

        fun from(value: Int): InjectionMode = when (value) {
            PROCESS.value -> PROCESS
            else -> FRAMEWORK
        }
    }
}
