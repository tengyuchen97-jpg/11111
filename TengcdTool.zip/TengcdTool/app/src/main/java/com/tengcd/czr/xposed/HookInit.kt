package com.tengcd.czr.xposed

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.io.File

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 干的事很简单:目标包启动 -> 拿到模块 so 路径 -> System.load 进去 -> 回报激活状态。
 *
 * 路径来源按顺序找:
 *   1. XSharedPreferences(honffx_inject.module_path)
 *   2. 本应用的 ContentProvider(content://com.tengcd.czr.so, get_handoff)
 *   3. 外部交接文件 Android/data/com.tengcd.czr/files/module_path.txt
 *   4. 兜底:我们自己的私有目录 /data/data/com.tengcd.czr/files/module/libhonffx.so
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var moduleEntrancePath: String? = null

    @Volatile
    private var loaded = false

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleEntrancePath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return
        if (pkg == OUR_PACKAGE || pkg == "android" || pkg == "com.android.systemui") return

        val prefs = readPrefs()
        val target = prefs?.second ?: readHandoffTarget() ?: DEFAULT_TARGET
        if (pkg != target) return

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        // 稍微等一下,让目标自己的初始化先跑完,再塞模块进去
                        Handler(Looper.getMainLooper()).postDelayed({
                            loadModule(context, pkg, prefs)
                        }, LOAD_DELAY_MS)
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked target: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook attach failed: ${t.message}")
        }
    }

    private fun loadModule(context: Context, pkg: String, prefs: Pair<String, String>?) {
        if (loaded) return
        val path = resolveSoPath(context, prefs) ?: run {
            XposedBridge.log("[Tengcd] module so not found")
            return
        }
        try {
            System.load(path)
            loaded = true
            XposedBridge.log("[Tengcd] module loaded: $path")
            reportActive(context, pkg)
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] System.load failed: ${t.message}")
        }
    }

    /** 先读 XSharedPreferences,再由 Provider / 外部文件兜底 */
    private fun resolveSoPath(context: Context, prefs: Pair<String, String>?): String? {
        prefs?.first?.takeIf { it.isNotBlank() && File(it).exists() }?.let { return it }
        try {
            val bundle: Bundle? = context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", null, null
            )
            val fromProvider = bundle?.getString("path")
            if (!fromProvider.isNullOrBlank() && File(fromProvider).exists()) return fromProvider
        } catch (t: Throwable) {
        }
        for (candidate in handoffCandidates()) {
            try {
                val f = File(candidate)
                if (f.isFile) {
                    val first = f.readLines().firstOrNull()?.trim()
                    if (!first.isNullOrBlank() && File(first).exists()) return first
                }
            } catch (t: Throwable) {
            }
        }
        // 最后一道:直接扫我们的 module 目录,拿最后落位的那个 so(变体文件名带后缀,不能写死)
        for (dir in moduleDirCandidates()) {
            try {
                val d = File(dir)
                if (!d.isDirectory) continue
                val so = d.listFiles { f -> f.isFile && f.name.endsWith(".so") }
                    ?.sortedByDescending { it.lastModified() }
                    ?.firstOrNull()
                if (so != null) return so.absolutePath
            } catch (t: Throwable) {
            }
        }
        return null
    }

    private fun moduleDirCandidates(): List<String> = listOf(
        "/data/data/$OUR_PACKAGE/files/module",
        "/data/user/0/$OUR_PACKAGE/files/module"
    )

    private fun handoffCandidates(): List<String> = buildList {
        add("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt")
        add("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt")
        add("/data/data/$OUR_PACKAGE/files/module_path.txt")
        add("/data/data/$OUR_PACKAGE/files/module/libhonffx.so")
        add("/data/user/0/$OUR_PACKAGE/files/module/libhonffx.so")
    }

    private fun reportActive(context: Context, pkg: String) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_active",
                pkg,
                Bundle().apply { putString("package", pkg) }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report active failed: ${t.message}")
        }
    }

    private fun readPrefs(): Pair<String, String>? {
        return try {
            val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
            @Suppress("DEPRECATION")
            try {
                xsp.makeWorldReadable()
            } catch (t: Throwable) {
            }
            xsp.reload()
            val path = xsp.getString("module_path", null)
            val target = xsp.getString("target_package", null)
            if (path.isNullOrBlank() && target.isNullOrBlank()) null
            else (path ?: "") to (target ?: DEFAULT_TARGET)
        } catch (t: Throwable) {
            null
        }
    }

    private fun readHandoffTarget(): String? = try {
        val f = File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt")
        if (f.isFile) f.readLines().getOrNull(1)?.trim() else null
    } catch (t: Throwable) {
        null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"
        private const val LOAD_DELAY_MS = 150L
    }
}
