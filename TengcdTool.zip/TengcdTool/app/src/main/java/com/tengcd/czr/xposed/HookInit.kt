package com.tengcd.czr.xposed

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process as AndroidProcess
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 目标包启动 -> 找到用户选的那份 so -> System.load -> 回报结果。
 *
 * ⚠️ 关键点(以前"内置 so 用不了"的根因):
 *   模块的 so 放在我们自己的私有目录里,目标进程的 uid 根本读不到,
 *   直接拿那个路径去 System.load 必然失败。
 *   现在改成:目标进程从**模块安装包**(任何进程都读得到)里把选中的变体抽出来,
 *   写进目标进程自己的私有目录再加载 —— 这条路和目标本身的数据目录一致,加载器不会拒。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    @Volatile
    private var loaded = false

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return
        if (pkg == OUR_PACKAGE || pkg == "android" || pkg == "com.android.systemui") return

        // 便宜的先判断一下:偏好里读得到目标包、又不是它,直接跳过,不去问 Provider
        val cachedTarget = readTargetPackage()
        if (!cachedTarget.isNullOrBlank() && pkg != cachedTarget) return

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        // 稍等一下,让目标自己的初始化先跑完,再塞模块进去
                        Handler(Looper.getMainLooper()).postDelayed({
                            try {
                                loadModule(context, pkg)
                            } catch (t: Throwable) {
                                report(context, false, null, t.message ?: t.javaClass.simpleName)
                            }
                        }, LOAD_DELAY_MS)
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked target: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook attach failed: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- 加载

    private fun loadModule(context: Context, pkg: String) {
        if (loaded) return

        // 目标包名以 Provider 给的为准,读不到再退回偏好里存的
        val handoff = queryHandoff(context)
        val target = handoff?.target?.takeIf { it.isNotBlank() }
            ?: readTargetPackage()
            ?: DEFAULT_TARGET
        if (context.packageName != target) return

        val variant = handoff?.variant?.takeIf { it.isNotBlank() }
            ?: readVariantFromPrefs()
            ?: DEFAULT_VARIANT

        val reasons = ArrayList<String>()

        // 1) 先用现成的路径试试(共用 uid / 有 root 的时候这条路能直接过)
        val candidates = listOfNotNull(
            handoff?.path,
            readPathFromPrefs(),
            readHandoffPathFile(context)
        ).distinct()
        for (path in candidates) {
            if (path.isBlank()) continue
            val f = File(path)
            if (!f.isFile) {
                reasons.add("文件不存在")
                continue
            }
            if (!f.canRead()) {
                reasons.add("目标进程读不到应用私有目录")
                continue
            }
            val why = validateSo(f)
            if (why != null) {
                reasons.add(why)
                continue
            }
            if (attemptLoad(context, f.absolutePath)) {
                report(context, true, f.absolutePath, null)
                return
            }
            reasons.add("System.load 被拒")
        }

        // 2) 从模块安装包里把选中的变体抽到目标进程自己的目录(哪个目录能加载就用哪个)
        val extracted = extractVariant(context, variant, reasons) { file ->
            attemptLoad(context, file.absolutePath)
        }
        if (extracted != null) {
            report(context, true, extracted.absolutePath, null)
            return
        }

        // 3) 上面都挂了,把原因回报给界面
        val detail = if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().joinToString(" / ")
        XposedBridge.log("[Tengcd] load failed: $detail")
        report(context, false, null, detail)
    }

    private fun attemptLoad(context: Context, path: String): Boolean = try {
        System.load(path)
        loaded = true
        XposedBridge.log("[Tengcd] module loaded: $path")
        true
    } catch (t: Throwable) {
        XposedBridge.log("[Tengcd] System.load($path) failed: ${t.message}")
        false
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "内置 SO 还是占位文件,把真 so 放进 assets/so 重新打包"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF 文件"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "这个 so 是 64 位,目标进程是 32 位" else "这个 so 是 32 位,目标进程是 64 位"
        }
        return null
    }

    // ---------------------------------------------------------------- 抽取

    /**
     * 从模块安装包里抽 assets/so/<variant>.so,写到目标进程自己的目录。
     * 写不进去就换下一个目录,全失败返回 null。
     */
    private fun extractVariant(
        context: Context,
        variant: String,
        reasons: MutableList<String>,
        attempt: (File) -> Boolean
    ): File? {
        val apk = resolveModuleApk(context)
        if (apk == null) {
            reasons.add("找不到模块安装包")
            return null
        }

        val entryName = "assets/so/$variant.so"
        val targets = buildList {
            add(File(context.codeCacheDir, "honffx"))
            add(File(context.filesDir, "honffx"))
            try {
                add(File(context.createDeviceProtectedStorageContext().filesDir, "honffx"))
            } catch (t: Throwable) {
            }
        }

        for (dir in targets) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                val dst = File(dir, "libhonffx_$variant.so")
                if (!unzipEntry(apk, entryName, dst, reasons)) continue
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add(why)
                    continue
                }
                dst.setReadable(true, false)
                if (attempt(dst)) return dst
                reasons.add("解出来的 so 在 ${dir.name} 目录加载失败，换下一个目录")
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    private fun unzipEntry(apk: File, entryName: String, dst: File, reasons: MutableList<String>): Boolean {
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(entryName)
                if (entry == null) {
                    // 变体名对不上就挑包里最大的那个 so(占位文件只有 320 字节,不会误选)
                    entry = zip.entries().toList()
                        .filter { it.name.startsWith("assets/so/") && it.name.endsWith(".so") }
                        .maxByOrNull { it.size }
                }
                if (entry == null) {
                    reasons.add("安装包里没有 assets/so/$entryName")
                    return false
                }
                val tmp = File(dst.parentFile, dst.name + ".tmp")
                zip.getInputStream(entry).use { input ->
                    tmp.outputStream().use { output -> input.copyTo(output, 128 * 1024) }
                }
                if (tmp.length() <= 0L) {
                    tmp.delete()
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    reasons.add("落盘失败")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:${t.message}")
            return false
        }
    }

    /** 模块安装包路径:优先 initZygote 给的,拿不到就去问 PackageManager */
    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- 取配置

    private data class Handoff(val path: String, val variant: String, val target: String)

    /** 问我们自己的 ContentProvider 要交接信息(最可靠的一条路) */
    private fun queryHandoff(context: Context): Handoff? = try {
        val bundle: Bundle? = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", context.packageName, null
        )
        if (bundle == null) {
            null
        } else {
            Handoff(
                path = bundle.getString("path").orEmpty(),
                variant = bundle.getString("variant").orEmpty(),
                target = bundle.getString("target").orEmpty()
            )
        }
    } catch (t: Throwable) {
        null
    }

    private fun report(context: Context, ok: Boolean, path: String?, detail: String?) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_state",
                if (ok) "ok" else "error",
                Bundle().apply {
                    putString("package", context.packageName)
                    putString("path", path)
                    putString("detail", detail)
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report failed: ${t.message}")
        }
    }

    private fun readPrefs(): XSharedPreferences? = try {
        val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
        @Suppress("DEPRECATION")
        try {
            xsp.makeWorldReadable()
        } catch (t: Throwable) {
        }
        xsp.reload()
        xsp
    } catch (t: Throwable) {
        null
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)
    } catch (t: Throwable) {
        null
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = listOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"
        private const val DEFAULT_VARIANT = "v0.24"
        private const val LOAD_DELAY_MS = 250L
    }
}
