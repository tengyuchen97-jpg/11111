package com.tengcd.czr.util

import java.io.BufferedReader
import java.io.InputStreamReader

object ShellUtil {

    data class Result(val code: Int, val output: String) {
        val ok: Boolean get() = code == 0
    }

    fun exec(command: String, timeoutMs: Long = 8000L): Result {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val sb = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val deadline = System.currentTimeMillis() + timeoutMs
            reader.use {
                while (System.currentTimeMillis() < deadline) {
                    if (reader.ready()) {
                        val line = reader.readLine() ?: break
                        sb.append(line).append('\n')
                    } else if (!process.isAlive) {
                        break
                    } else {
                        Thread.sleep(20)
                    }
                }
            }
            val code = try {
                process.waitFor()
            } catch (t: Throwable) {
                process.destroy()
                -1
            }
            Result(code, sb.toString())
        } catch (t: Throwable) {
            Result(-1, t.message ?: "exec failed")
        }
    }

    @Volatile
    private var rootCached: Boolean = false

    @Volatile
    private var rootCheckedAt: Long = 0L

    /**
     * 有没有 root。进程注入在没有 root 的情况下,
     * 需要目标允许调试/转储 + 同 uid 才附加得上。
     *
     * 结果缓存 5 秒:一次导入流程要问好几次,别每次都去拉 su(遇到授权框还会卡死)。
     */
    fun hasRoot(): Boolean {
        val now = System.currentTimeMillis()
        if (rootCheckedAt != 0L && now - rootCheckedAt < 5000L) return rootCached
        var result = false
        val probe = Thread {
            try {
                val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
                val out = process.inputStream.bufferedReader().readText()
                process.waitFor()
                result = out.contains("uid=0")
            } catch (t: Throwable) {
                result = false
            }
        }
        probe.isDaemon = true
        probe.start()
        try {
            probe.join(2500L)
        } catch (t: Throwable) {
        }
        rootCached = result
        rootCheckedAt = now
        return result
    }

    /**
     * 主动申请 root:会拉起授权框(Magisk / KernelSU / APatch 都认这条路),
     * 用户点「允许」才返回 true。
     *
     * 和 [hasRoot] 的区别:hasRoot 只探一次、2.5 秒就放弃,遇到需要用户点确认的授权框必然判「没 root」;
     * 这里给足时间等用户点,并且跑完立刻刷新缓存。
     */
    fun requestRoot(timeoutMs: Long = 20000L): Boolean {
        val flag = java.util.concurrent.atomic.AtomicBoolean(false)
        val probe = Thread {
            try {
                val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
                val out = process.inputStream.bufferedReader().readText()
                process.waitFor()
                flag.set(out.contains("uid=0"))
            } catch (t: Throwable) {
                flag.set(false)
            }
        }
        probe.isDaemon = true
        probe.start()
        try {
            probe.join(timeoutMs)
        } catch (t: Throwable) {
        }
        if (probe.isAlive) {
            try {
                probe.interrupt()
            } catch (t: Throwable) {
            }
        }
        val ok = flag.get()
        rootCached = ok
        rootCheckedAt = System.currentTimeMillis()
        return ok
    }

    /** 用 root 把文件 chmod 到目标可读(有 root 的时候走这条路最省事) */
    fun grantRead(path: String): Boolean {
        if (!hasRoot()) return false
        val r = exec("su -c 'chmod 644 \"$path\" && chcon u:object_r:apk_data_file:s0 \"$path\"'")
        return r.ok
    }

    /** 以 root 身份跑一条命令;没有 root(或 su 被拒)返回 null */
    fun execAsRoot(command: String, timeoutMs: Long = 15000L): Result? {
        if (!hasRoot()) return null
        val quoted = "'" + command.replace("'", "'\\''") + "'"
        val r = exec("su -c $quoted", timeoutMs)
        return if (r.ok) r else null
    }

    /** 探到一次「这台机器没有 root / su 被拒」就记下来,别再反复拉 su 弹授权框 */
    @Volatile
    private var rootDenied: Boolean = false

    /**
     * 直接用 root 跑命令,不吃 [hasRoot] 的 5 秒缓存。
     *
     * 为什么需要它:hasRoot 只等 2.5 秒,Magisk / KernelSU 的授权框还没点就判了「没 root」,
     * 于是导入参数这种「明明有 root 却一直说没权限」的场景永远走不到 root 通道。
     * 这里直接 su 一次:成功就把 root 标成可用,失败(机器本来没 su)才记成 denied。
     *
     * @return 命令跑起来但自身报错时也会返回(ok=false),方便上层如实报错;
     *         完全没有 root 通道才返回 null
     */
    fun execRoot(command: String, timeoutMs: Long = 20000L): Result? {
        if (rootDenied) return null
        val quoted = "'" + command.replace("'", "'\\''") + "'"
        val r = exec("su -c $quoted", timeoutMs)
        if (r.code == 0) {
            rootCached = true
            rootCheckedAt = System.currentTimeMillis()
            return r
        }
        // 命令自己失败了:再确认一次 su 到底能不能用(区分「没 root」和「命令报错」)
        val probe = exec("su -c id", 6000L)
        val usable = probe.code == 0 && probe.output.contains("uid=0")
        rootCached = usable
        rootCheckedAt = System.currentTimeMillis()
        if (usable) return r
        rootDenied = true
        return null
    }

    /** 用户手动点了「授权 root」之后,把之前的否定缓存清掉重新探 */
    fun resetRootProbe() {
        rootDenied = false
        rootCached = false
        rootCheckedAt = 0L
    }

    /**
     * 特权执行:先 root,再 Shizuku。两个都不可用返回 null。
     * 安卓 12 以上写别的应用的 /Android/data 目录全靠这个。
     */
    fun execPrivileged(context: android.content.Context?, command: String, timeoutMs: Long = 15000L): Result? {
        val root = execRoot(command, timeoutMs)
        if (root != null && root.ok) return root
        if (context != null) {
            val shizuku = ShizukuShell.exec(command, timeoutMs)
            if (shizuku != null && shizuku.ok) return shizuku
            // root 跑得动但命令报错:把 root 的真实输出交给上层,别吞掉原因
            if (root != null) return root
            return shizuku
        }
        return root
    }

    /** 当前设备实际可用的最高权限通道 */
    fun privilegeChannel(context: android.content.Context?): String = when {
        hasRoot() -> CHANNEL_ROOT
        context != null && ShizukuShell.granted() -> CHANNEL_SHIZUKU
        else -> CHANNEL_NONE
    }

    const val CHANNEL_ROOT = "root"
    const val CHANNEL_SHIZUKU = "shizuku"
    const val CHANNEL_NONE = "none"
}
