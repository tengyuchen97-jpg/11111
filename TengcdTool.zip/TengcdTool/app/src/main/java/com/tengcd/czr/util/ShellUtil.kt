package com.tengcd.czr.util

import java.io.BufferedReader
import java.io.InputStreamReader

object ShellUtil {

    data class Result(val code: Int, val output: String) {
        val ok: Boolean get() = code == 0
    }

    fun exec(command: String, timeoutMs: Long = 8000L): Result {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val sb = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val deadline = System.currentTimeMillis() + timeoutMs
            reader.use {
                while (System.currentTimeMillis() < deadline) {
                    if (reader.ready()) {
                        val line = reader.readLine() ?: break
                        sb.append(line).append('\n')
                    } else if (!process.isAlive) {
                        break
                    } else {
                        Thread.sleep(20)
                    }
                }
            }
            val code = try {
                process.waitFor()
            } catch (t: Throwable) {
                process.destroy()
                -1
            }
            Result(code, sb.toString())
        } catch (t: Throwable) {
            Result(-1, t.message ?: "exec failed")
        }
    }

    /**
     * 有没有 root。进程注入在没有 root 的情况下,
     * 需要目标允许调试/转储 + 同 uid 才附加得上。
     */
    fun hasRoot(): Boolean = try {
        val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
        val out = process.inputStream.bufferedReader().readText()
        process.waitFor()
        out.contains("uid=0")
    } catch (t: Throwable) {
        false
    }

    /** 用 root 把文件 chmod 到目标可读(有 root 的时候走这条路最省事) */
    fun grantRead(path: String): Boolean {
        if (!hasRoot()) return false
        val r = exec("su -c 'chmod 644 \"$path\" && chcon u:object_r:apk_data_file:s0 \"$path\"'")
        return r.ok
    }
}
