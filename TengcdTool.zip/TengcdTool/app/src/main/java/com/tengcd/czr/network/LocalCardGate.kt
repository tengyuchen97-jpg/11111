package com.tengcd.czr.network

import android.content.Context
import android.provider.Settings
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 本地卡密校验。
 *
 * 卡密不想联网校验的时候用这个:把卡密写死在本地(或写进手机的
 * /sdcard/Download/honffx_card.txt),输入对得上就直接放行,
 * 到期时间/剩余次数也由本地给。
 *
 * 格式:/sdcard/Download/card_list.txt
 *   HONFFX-AAAA-BBBB|2026-12-31|-1|3
 *   └ 卡密 | 到期时间 | 剩余次数(-1=不限) | 解绑次数
 */
object LocalCardGate {

    private const val EXTERNAL_CARD_FILE = "/sdcard/Download/card_list.txt"

    fun deviceId(context: Context): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        } catch (t: Throwable) {
            ""
        }
        val raw = androidId + "|" + InjectionPrefs.targetPackage
        return Md5Util.md5(raw).take(16).uppercase(Locale.US)
    }

    fun query(context: Context, card: String): CardQueryInfo {
        val trimmed = card.trim()
        if (trimmed.isEmpty()) {
            return CardQueryInfo(card = trimmed, valid = false, message = "empty")
        }
        val entry = loadEntries().firstOrNull { it.card.equals(trimmed, ignoreCase = true) }
            ?: return CardQueryInfo(card = trimmed, valid = false, message = "invalid")

        val expired = isExpired(entry.expireTime)
        val exhausted = entry.remainCount == 0
        return CardQueryInfo(
            card = entry.card,
            expireTime = entry.expireTime,
            remainCount = entry.remainCount,
            unbindCount = entry.unbindCount,
            boundDevice = InjectionPrefs.boundDevice ?: deviceId(context),
            banned = false,
            valid = !(expired || exhausted),
            message = when {
                expired -> "expired"
                exhausted -> "count_exhausted"
                else -> "ok"
            }
        )
    }

    /** 本地模式下"绑定设备"就是记一下首次使用的设备号 */
    fun bind(context: Context, card: String): Boolean {
        val info = query(context, card)
        if (!info.valid) return false
        if (InjectionPrefs.boundDevice == null) {
            InjectionPrefs.boundDevice = deviceId(context)
        }
        InjectionPrefs.cardKey = card.trim()
        return true
    }

    fun unbind(context: Context, card: String): Boolean {
        val info = query(context, card)
        if (!info.valid) return false
        InjectionPrefs.boundDevice = null
        return true
    }

    private fun isExpired(expireTime: String): Boolean {
        if (expireTime.isBlank() || expireTime == "-1" || expireTime.contains("永久")) return false
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = fmt.parse(expireTime.trim()) ?: return false
            date.before(Date())
        } catch (t: Throwable) {
            false
        }
    }

    private data class Entry(
        val card: String,
        val expireTime: String,
        val remainCount: Int,
        val unbindCount: Int
    )

    /**
     * 内置卡密。改卡密直接改这里(或者往 /sdcard/Download/card_list.txt 里加,
     * 那样不用重新打包)。
     */
    private val BUILT_IN = listOf(
        Entry("W1ACDB170ECFDC8337ED7242B5FDB559", "永久", -1, 3),
        Entry("LOCAL-TEST-0001", "永久", -1, 3)
    )

    private fun loadEntries(): List<Entry> {
        val list = ArrayList<Entry>(BUILT_IN)
        // 1. 偏好里内置的几张
        InjectionPrefs.localCard.split(',').forEach { item ->
            val c = item.trim()
            if (c.isNotEmpty()) list.add(Entry(c, "永久", -1, 3))
        }
        // 2. 外部文件(方便不重新打包就换卡)
        try {
            val f = java.io.File(EXTERNAL_CARD_FILE)
            if (f.isFile) {
                f.readLines().forEach { line ->
                    val text = line.trim()
                    if (text.isEmpty() || text.startsWith("#")) return@forEach
                    val parts = text.split('|')
                    val card = parts.getOrNull(0)?.trim().orEmpty()
                    if (card.isEmpty()) return@forEach
                    list.add(
                        Entry(
                            card = card,
                            expireTime = parts.getOrNull(1)?.trim().orEmpty().ifEmpty { "永久" },
                            remainCount = parts.getOrNull(2)?.trim()?.toIntOrNull() ?: -1,
                            unbindCount = parts.getOrNull(3)?.trim()?.toIntOrNull() ?: 3
                        )
                    )
                }
            }
        } catch (t: Throwable) {
        }
        return list
    }
}
