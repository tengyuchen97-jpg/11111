package com.tengcd.czr.util

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * 跨组件共享的运行态:注入服务在跑没有、框架模块在目标里激活没有。
 * Provider(被目标进程调用)、Service、ViewModel 都读写这里。
 *
 * ⚠️ 两个状态必须分清楚,别再混:
 *  - selfLoaded      :框架把模块注入到了「模块自己」的进程。只说明框架认得这个模块。
 *  - frameworkActive :**目标游戏进程**里真的把 so 加载起来了。界面上那个「已激活」只能看它。
 */
object ServiceState {

    val serviceRunning = MutableStateFlow(false)

    /** 目标游戏进程回报的注入状态(唯一可以显示成「已激活」的依据) */
    val frameworkActive = MutableStateFlow(false)

    /** 框架识别到模块(模块自己被注入),不等于游戏里注入成功 */
    val frameworkSelfLoaded = MutableStateFlow(false)

    val lastInjectOk = MutableStateFlow<Boolean?>(null)
    val lastInjectDetail = MutableStateFlow<String?>(null)

    /** 只有目标进程报上来的才算「已注入游戏」 */
    fun onReportedActive() {
        frameworkActive.value = true
        InjectionPrefs.frameworkActive = true
        InjectionPrefs.frameworkActiveAt = System.currentTimeMillis()
    }

    /** 模块自己被框架注入(框架认得模块了) */
    fun onSelfLoaded() {
        frameworkSelfLoaded.value = true
        InjectionPrefs.frameworkSelfLoaded = true
    }

    /** 目标进程报了失败:把「已激活」撤掉,别再挂着骗人 */
    fun onReportedFailure(detail: String?) {
        frameworkActive.value = false
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkActiveAt = 0L
        lastInjectOk.value = false
        lastInjectDetail.value = detail
    }

    fun syncFromPrefs() {
        frameworkActive.value = InjectionPrefs.frameworkActive
        frameworkSelfLoaded.value = InjectionPrefs.frameworkSelfLoaded
        lastInjectDetail.value = InjectionPrefs.frameworkError
    }
}
