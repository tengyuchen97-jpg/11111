package com.tengcd.czr.util

import android.content.Context
import java.io.File

/**
 * 参数配置文件(honffx.config)的读写。
 *
 * 就一个 plain text 文件:读出来原样丢进输入框,保存时整份覆盖回去。
 *
 * 通道顺序:直接读/写 -> root -> Shizuku。
 * ⚠️ 以前只认 Shizuku:有 root、没装 Shizuku 的机器一律报「文件不存在或目录没权限」,
 *    明明 root 能改也不让改。现在 root 和 Shizuku 平级,谁先能用走谁,
 *    并且把最终用了哪条通道返回给界面显示(用户能一眼看出是走了 root 还是没权限)。
 */
object ConfigFile {

    /** 参数文件固定路径 */
    const val TARGET_PATH =
        "/storage/emulated/0/Android/data/com.pi.czrxdfirst/files/honffx.config"

    /** 按目标包名算参数文件路径(czr 组指到 czr 的目录) */
    fun targetPath(pkg: String = "com.pi.czrxdfirst"): String {
        val p = pkg.ifBlank { "com.pi.czrxdfirst" }
        return "/storage/emulated/0/Android/data/$p/files/honffx.config"
    }

    /** 读写通道 */
    const val CH_DIRECT = "direct"
    const val CH_ROOT = "root"
    const val CH_SHIZUKU = "shizuku"
    const val CH_NONE = "none"

    /**
     * 读写结果。
     * @param ok 成功与否
     * @param text 读到的内容(读操作) / 写回后核对用的内容(写操作)
     * @param channel 实际生效的通道:dicrect / root / shizuku / none
     * @param error 失败原因(给界面拼提示用,可能为 null)
     */
    data class Result(
        val ok: Boolean,
        val text: String? = null,
        val channel: String = CH_NONE,
        val error: String? = null
    )

    /**
     * 读文件内容:直接读 -> root -> Shizuku。
     * 三条都不通时 channel = none,error 带上最后一条通道的原因。
     */
    fun read(
        context: Context,
        path: String = targetPath(InjectionPrefs.targetPackage)
    ): Result {
        // 1 本进程直接读(授权过 MANAGE_EXTERNAL_STORAGE / 或本来就是本应用目录)
        val direct = runCatching {
            val f = File(path)
            if (f.exists() && f.canRead()) f.readText() else null
        }
        // 读得到就用;内容为空也算读到(空文件是合法状态)
        direct.getOrNull()?.let { return Result(true, it, CH_DIRECT) }

        // 2 root:这台机上有 root 就直接走,别管 Shizuku 装没装
        if (ShellUtil.hasRoot()) {
            val r = runCatching { ShellUtil.execRoot("cat " + q(path) + " 2>/dev/null", 20000L) }
                .getOrNull()
            if (r != null && r.ok) return Result(true, r.output, CH_ROOT)
        }

        // 3 Shizuku
        val s = runCatching { ShizukuShell.exec("cat " + q(path) + " 2>/dev/null", 20000L) }
            .getOrNull()
        if (s != null && s.ok) return Result(true, s.output, CH_SHIZUKU)

        val why = when {
            s != null -> s.output.trim().take(200).ifBlank { null }
            else -> null
        }
        return Result(false, null, CH_NONE, why)
    }

    /**
     * 整份覆盖写入。写完一定读回来核对一遍再报成功。
     * 通道顺序同 [read]:直接写 -> root -> Shizuku。
     */
    fun write(
        context: Context,
        text: String,
        path: String = targetPath(InjectionPrefs.targetPackage)
    ): Result {
        // 1 先按本进程权限直接写
        val direct = runCatching {
            val f = File(path)
            f.parentFile?.mkdirs()
            f.writeText(text)
            f.exists() && f.readText() == text
        }.getOrDefault(false)
        if (direct) return Result(true, text, CH_DIRECT)

        // 2 写不进去:先落一份到本应用目录,再让特权通道 cp 过去
        val tmpDir = context.getExternalFilesDir(null) ?: context.cacheDir
        val tmp = File(tmpDir, "honffx.config.tmp")
        if (!runCatching { tmp.writeText(text) }.isSuccess) {
            return Result(false, null, CH_NONE, "临时文件写不进去")
        }
        val script = buildString {
            append("mkdir -p ").append(q(parentOf(path))).append("; ")
            append("cp ").append(q(tmp.absolutePath)).append(" ").append(q(path)).append("; ")
            val uid = runCatching { PackageUtil.uidOf(context, packageOf(path)) }.getOrDefault(0)
            if (uid > 0) {
                append("chown ").append(uid).append(":").append(uid).append(" ")
                    .append(q(path)).append("; ")
            }
            append("chmod 660 ").append(q(path)).append("; ")
            append("cat ").append(q(path))
        }

        // 2a root
        if (ShellUtil.hasRoot()) {
            val r = runCatching { ShellUtil.execRoot(script, 30000L) }.getOrNull()
            runCatching { tmp.delete() }
            if (r != null && r.ok && r.output.trimEnd('\n') == text.trimEnd('\n')) {
                return Result(true, text, CH_ROOT)
            }
        }

        // 2b Shizuku
        val s = runCatching { ShizukuShell.exec(script, 30000L) }.getOrNull()
        runCatching { tmp.delete() }
        if (s != null && s.ok && s.output.trimEnd('\n') == text.trimEnd('\n')) {
            return Result(true, text, CH_SHIZUKU)
        }

        val why = when {
            s != null -> s.output.trim().take(200).ifBlank { null }
            else -> null
        }
        return Result(false, null, CH_NONE, why)
    }

    /** 路径里带的目标包名,取不到就用已知的 */
    fun packageOf(path: String): String {
        val marker = "/Android/data/"
        val i = path.indexOf(marker)
        if (i >= 0) {
            val rest = path.substring(i + marker.length)
            val pkg = rest.substringBefore('/')
            if (pkg.isNotBlank()) return pkg
        }
        return try {
            InjectionPrefs.targetPackage.ifBlank { "com.pi.czrxdfirst" }
        } catch (t: Throwable) {
            "com.pi.czrxdfirst"
        }
    }

    private fun parentOf(path: String): String =
        path.substringBeforeLast('/', "/storage/emulated/0")

    private fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"
}
