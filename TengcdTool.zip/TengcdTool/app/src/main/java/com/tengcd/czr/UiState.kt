package com.tengcd.czr

import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.network.CardQueryInfo

enum class AppTab { UPDATE, INJECT, IMPORT, CARD }

data class UiState(
    val tab: AppTab = AppTab.UPDATE,
    val darkTheme: Boolean = false,

    // 公告
    val announcement: String? = null,
    val announcementLoading: Boolean = false,
    val announcementFailed: Boolean = false,

    // 模块
    val localModuleReady: Boolean = false,
    val localModulePath: String? = null,
    val moduleVersion: String? = null,
    val remoteVersion: String? = null,
    val moduleMd5: String? = null,

    // SO 选择(模块概览下面那个)
    val soVariants: List<String> = emptyList(),
    val selectedSo: String = "v0.24",
    val soSource: String = "builtin",
    val activeSoPath: String? = null,
    val localSoSourcePath: String? = null,
    val localSoReady: Boolean = false,

    // 框架
    val frameworkInstalled: Boolean = false,
    val frameworkActive: Boolean = false,
    val serviceRunning: Boolean = false,

    // 目标
    val targetPackage: String = "",
    val targetLabel: String = "",
    val targetInstalled: Boolean = false,
    val targetRunning: Boolean = false,
    val targetPid: Int = -1,
    val targetDirAccessible: Boolean = false,
    val sameUid: Boolean = false,

    // 注入
    val mode: InjectionMode = InjectionMode.FRAMEWORK,
    val injecting: Boolean = false,
    val lastInjectDetail: String? = null,

    // 更新
    val checking: Boolean = false,
    val downloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,

    // 资源导入(把左边源文件夹整个覆盖到右边目标文件夹)
    val importSourceUri: String? = null,
    val importSourcePath: String = "",
    val importSourceName: String = "",
    val importSourceFiles: Int = 0,
    val importSourceDirs: Int = 0,
    val importSourceBytes: Long = 0L,

    val importTargetUri: String? = null,
    val importTargetPath: String = "",
    val importTargetName: String = "",
    val importTargetFiles: Int = 0,
    val importTargetBytes: Long = 0L,

    /** false = 合并覆盖(同名替换),true = 先清空目标再写 */
    val importReplaceAll: Boolean = false,

    val importing: Boolean = false,
    val importProgressFiles: Int = 0,
    val importProgressTotal: Int = 0,
    val importProgressBytes: Long = 0L,
    val importFinished: Boolean = false,
    val importFailed: Boolean = false,
    val importChannelLabel: String? = null,
    val importMessage: String? = null,
    val rootAvailable: Boolean = false,
    val targetDirWritable: Boolean = false,

    // 注入失败时 native 侧的详细原因(界面上直接显示)
    val injectDetail: String? = null,

    // 卡密
    val cardKey: String = "",
    val localCardMode: Boolean = false,
    val cardQuerying: Boolean = false,
    val cardInfo: CardQueryInfo? = null,
    val shareCode: String? = null
)
