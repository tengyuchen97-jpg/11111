package com.tengcd.czr

import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.network.CardQueryInfo

enum class AppTab { UPDATE, INJECT, CARD }

data class UiState(
    val tab: AppTab = AppTab.UPDATE,
    val darkTheme: Boolean = false,

    // 公告
    val announcement: String? = null,
    val announcementLoading: Boolean = false,
    val announcementFailed: Boolean = false,

    // 模块
    val localModuleReady: Boolean = false,
    val localModulePath: String? = null,
    val moduleVersion: String? = null,
    val remoteVersion: String? = null,
    val moduleMd5: String? = null,

    // SO 选择(模块概览下面那个)
    val soVariants: List<String> = emptyList(),
    val selectedSo: String = "v0.24",
    val soSource: String = "builtin",
    val activeSoPath: String? = null,
    val localSoSourcePath: String? = null,
    val localSoReady: Boolean = false,

    // 框架
    val frameworkInstalled: Boolean = false,
    val frameworkActive: Boolean = false,
    val serviceRunning: Boolean = false,

    // 目标
    val targetPackage: String = "",
    val targetLabel: String = "",
    val targetInstalled: Boolean = false,
    val targetRunning: Boolean = false,
    val targetPid: Int = -1,
    val targetDirAccessible: Boolean = false,
    val sameUid: Boolean = false,

    // 注入
    val mode: InjectionMode = InjectionMode.FRAMEWORK,
    val injecting: Boolean = false,
    val lastInjectDetail: String? = null,

    // 更新
    val checking: Boolean = false,
    val downloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,

    // 卡密
    val cardKey: String = "",
    val localCardMode: Boolean = false,
    val cardQuerying: Boolean = false,
    val cardInfo: CardQueryInfo? = null,
    val shareCode: String? = null
)
