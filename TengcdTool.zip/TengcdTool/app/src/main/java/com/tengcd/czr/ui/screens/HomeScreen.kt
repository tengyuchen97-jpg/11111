package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.AppTab
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.NoticeCard
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.WarnOrange
import com.tengcd.czr.util.AndroidVersion

/**
 * 首页。左边一个总览:框架在不在、服务跑没跑、目标装没装、SO 是哪份、
 * 写目录走哪条通道。下面两个快捷入口直接跳去注入 / 导入。
 */
@Composable
fun HomeScreen(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        GlassCard(dark = dark) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = s.appTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = TitleFontFamily,
                    fontSize = 30.sp,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
                Spacer(Modifier.weight(1f))
                Icon(
                    imageVector = Icons.Filled.Home,
                    contentDescription = null,
                    tint = AccentBlue
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = s.homeDesc,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }

        Spacer(Modifier.height(12.dp))

        // 公告放首页最上面,进 App 一眼就能看到
        NoticeCard(state = state, s = s, dark = dark) { onAction(it) }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Info, s.homeStatus, dark)
            Spacer(Modifier.height(8.dp))
            StatusRow(
                label = s.frameworkStatus,
                value = if (state.frameworkInstalled) s.statusActivated else s.statusNotActivated,
                dark = dark,
                dot = true,
                ok = state.frameworkInstalled,
                warn = !state.frameworkInstalled
            )
            StatusRow(
                label = s.moduleServiceRunning,
                value = if (state.serviceRunning) s.serviceRunning else s.serviceStopped,
                dark = dark,
                dot = true,
                ok = state.serviceRunning,
                warn = !state.serviceRunning
            )
            StatusRow(
                label = s.targetApp,
                value = if (state.targetInstalled) {
                    state.targetLabel.ifBlank { state.targetPackage }
                } else {
                    s.targetNotInstalled
                },
                dark = dark,
                dot = true,
                ok = state.targetInstalled,
                warn = !state.targetInstalled
            )
            Spacer(Modifier.height(6.dp))
            KeyValueRow(
                label = s.homeSoNow,
                value = when (state.soSource) {
                    "local" -> s.soLocal
                    "remote" -> s.soRemote
                    else -> s.soBuiltin + " " + state.selectedSo
                },
                dark = dark,
                valueColor = if (state.soValid) OkGreen else ErrRed
            )
            KeyValueRow(
                label = s.homeWriteChannel,
                value = channelText(state, s),
                dark = dark,
                valueColor = if (state.writeChannelReady) OkGreen else WarnOrange
            )
            KeyValueRow(
                label = s.shizukuStatus,
                value = AndroidVersion.label(state.sdkInt),
                dark = dark
            )
            if (state.loggedIn && state.loginExpire.isNotBlank()) {
                KeyValueRow(
                    label = s.homeAccount,
                    value = state.loginExpire,
                    dark = dark,
                    valueColor = OkGreen
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Bolt, s.homeQuick, dark)
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SecondaryActionButton(
                    text = s.homeGoInject,
                    icon = Icons.Filled.Bolt,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.SelectTab(AppTab.INJECT)) }
                SecondaryActionButton(
                    text = s.homeGoImport,
                    icon = Icons.Filled.FolderZip,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.SelectTab(AppTab.IMPORT)) }
            }
        }

        Spacer(Modifier.height(18.dp))
    }
}

/** 通道名:跟导入页那个保持一致 */
private fun channelText(state: UiState, s: LocalizedStrings): String = when (state.writeChannel) {
    "root" -> s.importChannelRoot
    "shizuku" -> s.importChannelShizuku
    "direct" -> s.importChannelDirect
    else -> s.importChannelNone
}
