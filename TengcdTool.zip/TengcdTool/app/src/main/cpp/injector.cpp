//
// ptrace 进程注入器(arm64)
//
// 和被注入进程"同 uid"场景下的免 root 注入。流程:
//   1. 挑一个"闲着的"线程(优先睡眠态、非主线程),避免它在 linker/libc 的临界区里
//      —— 这是老版本闪退的主要原因之一:选到正在持锁的线程,远程 dlopen 直接死锁。
//   2. PTRACE_ATTACH 附加(失败再试 PTRACE_SEIZE + INTERRUPT)
//   3. 用目标进程 libc 里现成的 `svc #0` 指令做"远程 syscall",调 mmap 拿到一块内存
//      —— 老版本这里是拿 LR=0 去调 mmap,函数一返回就跳到地址 0,目标进程当场 SIGSEGV。
//   4. 在拿到的那块内存里写 so 路径 + `brk #0` 断点,然后把 PC 指到 dlopen,LR 指到断点
//   5. 路径加载失败(mkdir/权限/路径被 linker 拒)时,自动改用 memfd:
//      在目标进程里 memfd_create + pwrite64 把 so 写进去,再 dlopen /proc/self/fd/<fd>
//   6. **无论成败都先把寄存器原样还原,再 detach** —— 老版本失败路径直接 detach,
//      PC 还停在蹦了的地址上,等于亲手把目标进程送走。
//
// 返回值 = 0 成功,负数失败(和 Kotlin 侧 PtraceInjectFailure 一一对应)
//
#include "injector.h"

#include <cerrno>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <algorithm>
#include <string>
#include <vector>

#include <dirent.h>
#include <dlfcn.h>
#include <elf.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>

#include <android/log.h>

#define LOG_TAG "zaka-injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef __WALL
#define __WALL 0x40000000
#endif

// 和 Kotlin 的 PtraceInjectFailure 对齐,改一边记得改另一边
enum {
    ERR_NONE = 0,
    ERR_NATIVE_NOT_LOADED = -1,
    ERR_TARGET_NOT_FOUND = -2,
    ERR_ATTACH_DENIED = -3,
    ERR_MMAP_FAILED = -4,
    ERR_DLOPEN_SYMBOL_NOT_FOUND = -5,
    ERR_DLOPEN_FAILED = -6,
    ERR_PATH_TOO_LONG = -7,
    ERR_TARGET_DIR_NOT_ACCESSIBLE = -8,
    ERR_WRITE_REMOTE_FAILED = -9,
    ERR_REMOTE_SYSCALL_FAILED = -15,
    ERR_ABI_MISMATCH = -16,
    ERR_LOADER_BUSY = -17,
    ERR_UNKNOWN = -99,
};

#if defined(__aarch64__)

namespace {

// ---------------------------------------------------------------- 失败详情
//
// Kotlin 层通过 nativeLastDetail() 取走,直接显示到界面上,
// 省得用户只知道"失败了"却不知道卡在哪一步。
std::string g_detail;

void set_detail(const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    g_detail = buf;
    LOGE("%s", buf);
}

void clear_detail() { g_detail.clear(); }

// ---------------------------------------------------------------- 寄存器

struct Regs {
    uint64_t x[31];   // x0..x30
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
};

static_assert(sizeof(Regs) == 34 * sizeof(uint64_t), "unexpected arm64 regs layout");

bool get_regs(pid_t tid, Regs* out) {
    struct iovec io{};
    io.iov_base = out;
    io.iov_len = sizeof(Regs);
    return ptrace(PTRACE_GETREGSET, tid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

bool set_regs(pid_t tid, const Regs* in) {
    struct iovec io{};
    io.iov_base = const_cast<Regs*>(in);
    io.iov_len = sizeof(Regs);
    return ptrace(PTRACE_SETREGSET, tid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

// ---------------------------------------------------------------- 内存读写

bool read_mem(pid_t tid, uint64_t addr, void* buf, size_t len) {
    struct iovec local{};
    struct iovec remote{};
    local.iov_base = buf;
    local.iov_len = len;
    remote.iov_base = reinterpret_cast<void*>(static_cast<uintptr_t>(addr));
    remote.iov_len = len;
    ssize_t n = process_vm_readv(tid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(len)) return true;

    uint8_t* p = static_cast<uint8_t*>(buf);
    size_t done = 0;
    while (done < len) {
        errno = 0;
        long word = ptrace(PTRACE_PEEKDATA, tid,
                           reinterpret_cast<void*>(static_cast<uintptr_t>(addr + done)), nullptr);
        if (word == -1 && errno != 0) return false;
        size_t chunk = sizeof(long);
        if (chunk > len - done) chunk = len - done;
        memcpy(p + done, &word, chunk);
        done += chunk;
    }
    return true;
}

bool write_mem(pid_t tid, uint64_t addr, const void* buf, size_t len) {
    struct iovec local{};
    struct iovec remote{};
    local.iov_base = const_cast<void*>(buf);
    local.iov_len = len;
    remote.iov_base = reinterpret_cast<void*>(static_cast<uintptr_t>(addr));
    remote.iov_len = len;
    ssize_t n = process_vm_writev(tid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(len)) return true;

    const uint8_t* p = static_cast<const uint8_t*>(buf);
    size_t done = 0;
    while (done < len) {
        size_t chunk = sizeof(long);
        if (chunk > len - done) chunk = len - done;
        long word = 0;
        if (chunk < sizeof(long)) {
            // 尾巴不足一个字:先读回来再拼,免得把后面那几个字节抹了
            errno = 0;
            word = ptrace(PTRACE_PEEKDATA, tid,
                          reinterpret_cast<void*>(static_cast<uintptr_t>(addr + done)), nullptr);
            if (word == -1 && errno != 0) return false;
        }
        memcpy(&word, p + done, chunk);
        if (ptrace(PTRACE_POKEDATA, tid,
                   reinterpret_cast<void*>(static_cast<uintptr_t>(addr + done)),
                   reinterpret_cast<void*>(word)) < 0) {
            return false;
        }
        done += chunk;
    }
    return true;
}

// ---------------------------------------------------------------- 等待停止

bool wait_stopped(pid_t tid, int* out_sig) {
    int st = 0;
    for (int i = 0; i < 400; i++) {
        pid_t w = waitpid(tid, &st, __WALL);
        if (w < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (WIFEXITED(st) || WIFSIGNALED(st)) return false;
        if (WIFSTOPPED(st)) {
            if (out_sig != nullptr) *out_sig = WSTOPSIG(st);
            return true;
        }
    }
    return false;
}

// ---------------------------------------------------------------- maps

struct MapEntry {
    uint64_t start = 0;
    uint64_t end = 0;
    uint64_t offset = 0;
    bool readable = false;
    bool executable = false;
    std::string path;
};

std::vector<MapEntry> parse_maps(pid_t pid) {
    std::vector<MapEntry> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (fp == nullptr) return out;

    char line[1024];
    while (fgets(line, sizeof(line), fp) != nullptr) {
        unsigned long long start = 0, end = 0, offset = 0;
        char perms[8] = {0};
        char file[768] = {0};
        int n = sscanf(line, "%llx-%llx %7s %llx %*s %*s %767[^\n]",
                       &start, &end, perms, &offset, file);
        if (n < 4) continue;
        MapEntry e{};
        e.start = start;
        e.end = end;
        e.offset = offset;
        e.readable = perms[0] == 'r';
        e.executable = perms[2] == 'x';
        if (n >= 5) {
            std::string p(file);
            while (!p.empty() && (p.front() == ' ' || p.front() == '\t')) p.erase(p.begin());
            while (!p.empty() && (p.back() == ' ' || p.back() == '\n' || p.back() == '\r')) p.pop_back();
            e.path = p;
        }
        out.push_back(e);
    }
    fclose(fp);
    return out;
}

// ---------------------------------------------------------------- ELF 符号

bool symbol_offset_in_file(const char* path, const char* symbol, uint64_t* out_offset) {
    FILE* fp = fopen(path, "rb");
    if (fp == nullptr) return false;

    uint8_t ident[EI_NIDENT];
    if (fread(ident, 1, sizeof(ident), fp) != sizeof(ident) ||
        memcmp(ident, ELFMAG, SELFMAG) != 0 ||
        ident[EI_CLASS] != ELFCLASS64) {
        fclose(fp);
        return false;
    }

    Elf64_Ehdr eh{};
    fseek(fp, 0, SEEK_SET);
    if (fread(&eh, 1, sizeof(eh), fp) != sizeof(eh) || eh.e_shoff == 0 || eh.e_shnum == 0) {
        fclose(fp);
        return false;
    }

    Elf64_Shdr shdr{};
    for (int i = 0; i < eh.e_shnum; i++) {
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(i) * eh.e_shentsize), SEEK_SET);
        if (fread(&shdr, 1, sizeof(shdr), fp) != sizeof(shdr)) break;
        if (shdr.sh_type != SHT_DYNSYM) continue;

        Elf64_Shdr str_sh{};
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(shdr.sh_link) * eh.e_shentsize), SEEK_SET);
        if (fread(&str_sh, 1, sizeof(str_sh), fp) != sizeof(str_sh)) break;

        int count = static_cast<int>(shdr.sh_size / sizeof(Elf64_Sym));
        for (int j = 0; j < count; j++) {
            Elf64_Sym sym{};
            fseek(fp, static_cast<long>(shdr.sh_offset + static_cast<uint64_t>(j) * sizeof(Elf64_Sym)), SEEK_SET);
            if (fread(&sym, 1, sizeof(sym), fp) != sizeof(sym)) break;
            if (sym.st_shndx == SHN_UNDEF || sym.st_name == 0) continue;
            char name[256] = {0};
            fseek(fp, static_cast<long>(str_sh.sh_offset + sym.st_name), SEEK_SET);
            if (fread(name, 1, sizeof(name) - 1, fp) == 0) continue;
            if (strcmp(name, symbol) == 0) {
                *out_offset = sym.st_value;
                fclose(fp);
                return true;
            }
        }
    }
    fclose(fp);
    return false;
}

/** 在目标的某个库里找符号,返回目标进程里的绝对地址 */
uint64_t resolve_in_libs(const std::vector<MapEntry>& maps, const std::vector<std::string>& libs,
                         const char* symbol) {
    for (const auto& lib : libs) {
        for (const auto& m : maps) {
            if (m.path.empty() || !m.executable) continue;
            if (m.path.find(lib) == std::string::npos) continue;
            uint64_t offset = 0;
            if (!symbol_offset_in_file(m.path.c_str(), symbol, &offset)) continue;
            uint64_t base = m.start - m.offset;
            uint64_t addr = base + offset;
            LOGI("symbol %s from %s -> 0x%llx", symbol, m.path.c_str(),
                 static_cast<unsigned long long>(addr));
            return addr;
        }
    }
    return 0;
}

/** dlopen:优先 linker 里的 __loader_dlopen,退到 libdl 的 dlopen */
uint64_t resolve_dlopen(const std::vector<MapEntry>& maps, bool* is_loader) {
    std::vector<std::string> linkers = {"linker64", "linker"};
    uint64_t addr = resolve_in_libs(maps, linkers, "__loader_dlopen");
    if (addr != 0) {
        *is_loader = true;
        return addr;
    }
    std::vector<std::string> dl = {"libdl.so", "libdl_android.so", "libc.so"};
    addr = resolve_in_libs(maps, dl, "dlopen");
    *is_loader = false;
    return addr;
}

/**
 * 找一条目标进程里现成的 `svc #0` 指令。
 * 远程 syscall 全靠它 —— 不需要往目标里写任何代码,也不挑 W^X。
 */
uint64_t find_svc_gadget(pid_t tid, const std::vector<MapEntry>& maps) {
    std::vector<std::string> libs = {"libc.so", "libm.so", "linker64", "libutils.so"};
    for (const auto& lib : libs) {
        for (const auto& m : maps) {
            if (m.path.empty() || !m.executable || !m.readable) continue;
            if (m.path.find(lib) == std::string::npos) continue;

            const size_t kChunk = 64 * 1024;
            std::vector<uint8_t> buf(kChunk);
            for (uint64_t addr = m.start; addr < m.end; addr += kChunk) {
                size_t len = static_cast<size_t>(std::min<uint64_t>(kChunk, m.end - addr));
                if (!read_mem(tid, addr, buf.data(), len)) break;
                for (size_t i = 0; i + 4 <= len; i += 4) {
                    if (buf[i] == 0xD4 && buf[i + 1] == 0x00 && buf[i + 2] == 0x00 && buf[i + 3] == 0x01) {
                        uint64_t found = addr + i;
                        LOGI("svc gadget 0x%llx in %s", static_cast<unsigned long long>(found),
                             m.path.c_str());
                        return found;
                    }
                }
            }
        }
    }
    return 0;
}

// ---------------------------------------------------------------- 远程调用

/** 用目标里现成的 svc 指令跑一次系统调用(单步,不写任何代码到目标里) */
bool remote_syscall(pid_t tid, uint64_t svc, uint64_t nr, const uint64_t* args, int nargs,
                    uint64_t* out) {
    Regs saved{};
    if (!get_regs(tid, &saved)) return false;

    Regs r = saved;
    for (int i = 0; i < 8; i++) r.x[i] = (i < nargs) ? args[i] : 0;
    r.x[8] = nr;
    r.pc = svc;

    if (!set_regs(tid, &r)) {
        set_regs(tid, &saved);
        return false;
    }
    if (ptrace(PTRACE_SINGLESTEP, tid, nullptr, nullptr) < 0) {
        set_regs(tid, &saved);
        return false;
    }

    int sig = 0;
    bool stopped = wait_stopped(tid, &sig);
    bool ok = stopped && sig == SIGTRAP;

    if (ok && out != nullptr) {
        Regs after{};
        if (get_regs(tid, &after)) *out = after.x[0];
    }
    // 无论如何还原:失败时目标必须干干净净地接着跑
    set_regs(tid, &saved);
    return ok;
}

/** 远程调一个函数,返回靠 LR 指到写好的 brk 断点上取 */
bool remote_call(pid_t tid, uint64_t fn, const uint64_t* args, int nargs,
                 uint64_t* out, uint64_t stub) {
    Regs saved{};
    if (!get_regs(tid, &saved)) return false;

    Regs r = saved;
    for (int i = 0; i < 8; i++) r.x[i] = (i < nargs) ? args[i] : 0;
    r.x[30] = stub;   // LR -> 断点
    r.pc = fn;

    if (!set_regs(tid, &r)) {
        set_regs(tid, &saved);
        return false;
    }
    if (ptrace(PTRACE_CONT, tid, nullptr, nullptr) < 0) {
        set_regs(tid, &saved);
        return false;
    }

    int sig = 0;
    bool stopped = wait_stopped(tid, &sig);
    bool ok = stopped && sig == SIGTRAP;
    if (!ok && stopped) {
        LOGE("remote call stopped by signal %d", sig);
    }

    if (ok && out != nullptr) {
        Regs after{};
        if (get_regs(tid, &after)) *out = after.x[0];
    }
    // 这里最关键:哪怕函数炸了,也要把现场还原,不然目标进程直接报废
    set_regs(tid, &saved);
    return ok;
}

// ---------------------------------------------------------------- 线程挑选

struct ThreadPick {
    pid_t tid;
    char state;
};

std::vector<ThreadPick> list_threads(pid_t pid) {
    std::vector<ThreadPick> out;
    char dir[64];
    snprintf(dir, sizeof(dir), "/proc/%d/task", pid);
    DIR* d = opendir(dir);
    if (d == nullptr) return out;

    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        pid_t tid = static_cast<pid_t>(atoi(e->d_name));
        if (tid <= 0) continue;
        char st = '?';
        char p[96];
        snprintf(p, sizeof(p), "/proc/%d/task/%d/stat", pid, tid);
        FILE* f = fopen(p, "r");
        if (f != nullptr) {
            char buf[512];
            size_t n = fread(buf, 1, sizeof(buf) - 1, f);
            fclose(f);
            buf[n] = '\0';
            char* rp = strrchr(buf, ')');
            if (rp != nullptr && rp[1] == ' ' && rp[2] != '\0') st = rp[2];
        }
        out.push_back({tid, st});
    }
    closedir(d);

    // 睡着的线程优先(不在 linker 临界区、不持锁),主线程排最后
    std::sort(out.begin(), out.end(), [](const ThreadPick& a, const ThreadPick& b) {
        int sa = (a.state == 'S' || a.state == 'D') ? 0 : 1;
        int sb = (b.state == 'S' || b.state == 'D') ? 0 : 1;
        if (sa != sb) return sa < sb;
        return a.tid > b.tid;
    });
    return out;
}

bool attach_thread(pid_t tid, std::string* why) {
    g_detail.clear();
    if (ptrace(PTRACE_ATTACH, tid, nullptr, nullptr) == 0) {
        int sig = 0;
        if (wait_stopped(tid, &sig)) return true;
        ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
        *why = "attach 后等不到停止";
        return false;
    }

    int attach_errno = errno;
    // 老内核/被限制的 SELinux 有时 PTRACE_ATTACH 挂了但 SEIZE 还能用
    if (ptrace(PTRACE_SEIZE, tid, nullptr, nullptr) == 0) {
        if (ptrace(PTRACE_INTERRUPT, tid, nullptr, nullptr) == 0) {
            int sig = 0;
            if (wait_stopped(tid, &sig)) return true;
        }
        ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
    }
    char buf[96];
    snprintf(buf, sizeof(buf), "attach 被拒(errno=%d %s)", attach_errno, strerror(attach_errno));
    *why = buf;
    return false;
}

void detach_thread(pid_t tid, const Regs& saved, bool restore) {
    if (restore) set_regs(tid, &saved);
    ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
}

// ---------------------------------------------------------------- 本地 so 信息

bool read_file_size(const char* path, uint64_t* size, bool* is64) {
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    struct stat st{};
    if (fstat(fd, &st) != 0 || st.st_size <= 0) {
        close(fd);
        return false;
    }
    uint8_t ident[EI_NIDENT] = {0};
    ssize_t n = pread(fd, ident, sizeof(ident), 0);
    close(fd);
    if (n < static_cast<ssize_t>(sizeof(ident))) return false;
    if (memcmp(ident, ELFMAG, SELFMAG) != 0) return false;
    *size = static_cast<uint64_t>(st.st_size);
    *is64 = ident[EI_CLASS] == ELFCLASS64;
    return true;
}

bool target_is64(const std::vector<MapEntry>& maps) {
    for (const auto& m : maps) {
        if (m.path.empty()) continue;
        if (m.path.size() >= 8 && m.path.compare(m.path.size() - 8, 8, "linker64") == 0) return true;
        if (m.path.size() >= 6 && m.path.compare(m.path.size() - 6, 6, "linker") == 0) return false;
    }
    return true;
}

// ---------------------------------------------------------------- 单线程注入

struct RemoteCtx {
    pid_t pid = -1;
    pid_t tid = -1;
    Regs saved{};
    uint64_t svc = 0;
    uint64_t page = 0;
    uint64_t page_size = 0;
    uint64_t stub = 0;
    uint64_t dlopen_addr = 0;
    bool is_loader = false;
};

/** 在目标里调一次 syscall,返回 errno 语义的 0 或负数 */
int64_t remote_syscall_ret(RemoteCtx& c, uint64_t nr, const uint64_t* args, int nargs, bool* called) {
    uint64_t ret = 0;
    *called = remote_syscall(c.tid, c.svc, nr, args, nargs, &ret);
    if (!*called) return -1;
    return static_cast<int64_t>(ret);
}

int inject_into_thread(pid_t pid, pid_t tid, const std::vector<MapEntry>& maps,
                       const char* so_path, const char* entry_symbol) {
    RemoteCtx c;
    c.pid = pid;
    c.tid = tid;

    std::string why;
    if (!attach_thread(tid, &why)) {
        set_detail("附加线程 %d 失败:%s", tid, why.c_str());
        return ERR_ATTACH_DENIED;
    }

    if (!get_regs(tid, &c.saved)) {
        set_detail("读不到线程 %d 的寄存器", tid);
        ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
        return ERR_ATTACH_DENIED;
    }

    int result = ERR_UNKNOWN;
    bool restore = true;

    do {
        c.svc = find_svc_gadget(tid, maps);
        if (c.svc == 0) {
            set_detail("目标里找不到 svc 指令,无法做远程调用");
            result = ERR_REMOTE_SYSCALL_FAILED;
            break;
        }

        c.dlopen_addr = resolve_dlopen(maps, &c.is_loader);
        if (c.dlopen_addr == 0) {
            set_detail("解析不到 dlopen 地址(linker/libdl 不匹配)");
            result = ERR_DLOPEN_SYMBOL_NOT_FOUND;
            break;
        }

        // 1) 远程 mmap:放路径 + 断点 + (可能要用的)so 数据缓冲
        uint64_t local_size = 0;
        bool is64 = false;
        bool valid_so = read_file_size(so_path, &local_size, &is64);
        uint64_t want = 0x4000;
        if (valid_so && local_size <= (64ull << 20)) {
            want = 0x4000 + local_size + (local_size / 16) + 0x1000;
        }
        want = (want + 0xFFF) & ~0xFFFull;

        uint64_t mmap_args[6];
        mmap_args[0] = 0;
        mmap_args[1] = want;
        mmap_args[2] = PROT_READ | PROT_WRITE | PROT_EXEC;
        mmap_args[3] = MAP_PRIVATE | MAP_ANONYMOUS;
        mmap_args[4] = static_cast<uint64_t>(-1);
        mmap_args[5] = 0;

        bool called = false;
        int64_t ret = remote_syscall_ret(c, 222 /* mmap */, mmap_args, 6, &called);
        if (!called) {
            set_detail("远程 mmap 调用没停下来(线程状态异常)");
            result = ERR_MMAP_FAILED;
            break;
        }
        if (ret < 0 && ret > -4096) {
            set_detail("远程 mmap 失败(errno=%lld)", static_cast<long long>(-ret));
            result = ERR_MMAP_FAILED;
            break;
        }
        c.page = static_cast<uint64_t>(ret);
        c.page_size = want;
        if (c.page == 0) {
            set_detail("远程 mmap 返回 0");
            result = ERR_MMAP_FAILED;
            break;
        }
        LOGI("remote page 0x%llx size 0x%llx", static_cast<unsigned long long>(c.page),
             static_cast<unsigned long long>(want));

        // 2) 写路径和断点
        c.stub = c.page + 0x2000;
        const uint32_t trap = 0xD4200000u;  // brk #0
        if (!write_mem(tid, c.page, so_path, strlen(so_path) + 1) ||
            !write_mem(tid, c.stub, &trap, sizeof(trap))) {
            set_detail("往目标进程写数据失败");
            result = ERR_WRITE_REMOTE_FAILED;
            break;
        }

        // 3) 路径加载
        uint64_t dl_args[2];
        dl_args[0] = c.page;
        dl_args[1] = RTLD_NOW | RTLD_GLOBAL;
        uint64_t handle = 0;
        int64_t memfd_fd = -1;
        bool ok = remote_call(tid, c.dlopen_addr, dl_args, 2, &handle, c.stub);
        if (!ok) {
            set_detail("远程 dlopen 调用崩了(目标线程状态异常)");
            result = ERR_DLOPEN_FAILED;
            break;
        }

        // 4) 路径失败 -> memfd 兜底(不依赖目标数据目录能不能写)
        if (handle == 0) {
            LOGI("dlopen(path) returned NULL, trying memfd");
            if (!valid_so) {
                set_detail("dlopen(%s) 返回空,且本机文件读不到", so_path);
                result = ERR_DLOPEN_FAILED;
                break;
            }
            if (!is64) {
                set_detail("这个 so 是 32 位的,目标进程是 64 位,加载不了");
                result = ERR_ABI_MISMATCH;
                break;
            }
            if (local_size > (64ull << 20)) {
                set_detail("so 太大(>64MB),memfd 通道跳过");
                result = ERR_DLOPEN_FAILED;
                break;
            }

            // memfd_create("z", 0)
            uint64_t name_addr = c.page + 0x100;
            if (!write_mem(tid, name_addr, "z", 2)) {
                set_detail("写 memfd 名字失败");
                result = ERR_WRITE_REMOTE_FAILED;
                break;
            }
            uint64_t memfd_args[2] = {name_addr, 0};
            int64_t fd = remote_syscall_ret(c, 279 /* memfd_create */, memfd_args, 2, &called);
            memfd_fd = fd;
            if (!called || fd < 0) {
                set_detail("memfd_create 失败(%lld)", static_cast<long long>(fd));
                result = ERR_DLOPEN_FAILED;
                break;
            }

            // 把 so 分块写进去:pwrite64(fd, buf, len, off)
            uint64_t buf_addr = c.page + 0x3000;
            uint64_t capacity = (c.page_size > 0x3000) ? (c.page_size - 0x3000) : 0;
            uint64_t chunk = std::min<uint64_t>(capacity, 1ull << 20);  // 一次最多 1MB
            if (chunk == 0) {
                set_detail("memfd 缓冲区算出来是 0");
                result = ERR_WRITE_REMOTE_FAILED;
                break;
            }

            int src = open(so_path, O_RDONLY | O_CLOEXEC);
            if (src < 0) {
                set_detail("打开本机 so 失败(errno=%d)", errno);
                result = ERR_DLOPEN_FAILED;
                break;
            }
            std::vector<uint8_t> local(static_cast<size_t>(chunk));
            uint64_t offset = 0;
            bool copy_ok = true;
            while (offset < local_size) {
                size_t want_read = static_cast<size_t>(std::min<uint64_t>(chunk, local_size - offset));
                ssize_t got = pread(src, local.data(), want_read, static_cast<off_t>(offset));
                if (got <= 0) { copy_ok = false; break; }
                if (!write_mem(tid, buf_addr, local.data(), static_cast<size_t>(got))) {
                    copy_ok = false;
                    break;
                }
                uint64_t pw_args[4] = {static_cast<uint64_t>(fd), buf_addr,
                                       static_cast<uint64_t>(got), offset};
                int64_t wrote = remote_syscall_ret(c, 67 /* pwrite64 */, pw_args, 4, &called);
                if (!called || wrote != static_cast<int64_t>(got)) {
                    copy_ok = false;
                    break;
                }
                offset += static_cast<uint64_t>(got);
            }
            close(src);
            if (!copy_ok) {
                set_detail("写 memfd 失败(写到第 %llu 字节)", static_cast<unsigned long long>(offset));
                result = ERR_WRITE_REMOTE_FAILED;
                break;
            }

            // dlopen("/proc/self/fd/<fd>")
            char fd_path[64];
            snprintf(fd_path, sizeof(fd_path), "/proc/self/fd/%lld", static_cast<long long>(fd));
            if (!write_mem(tid, c.page, fd_path, strlen(fd_path) + 1)) {
                set_detail("写 memfd 路径失败");
                result = ERR_WRITE_REMOTE_FAILED;
                break;
            }
            ok = remote_call(tid, c.dlopen_addr, dl_args, 2, &handle, c.stub);
            if (!ok || handle == 0) {
                set_detail("memfd 方式 dlopen 也返回空(so 依赖不全或 ABI 不符)");
                result = ERR_DLOPEN_FAILED;
                break;
            }
            LOGI("loaded from memfd fd=%lld", static_cast<long long>(fd));
        }

        LOGI("module loaded, handle=0x%llx%s", static_cast<unsigned long long>(handle),
             c.is_loader ? " via __loader_dlopen" : "");

        // 5) 需要主动调 entry 的话,顺手 dlsym 出来调一下
        if (entry_symbol != nullptr && entry_symbol[0] != '\0') {
            uint64_t dlsym_addr = resolve_in_libs(maps, {"libdl.so", "libdl_android.so", "libc.so"}, "dlsym");
            if (dlsym_addr != 0) {
                uint64_t sym_name = c.page + 0x400;
                if (write_mem(tid, sym_name, entry_symbol, strlen(entry_symbol) + 1)) {
                    uint64_t sym_args[2] = {handle, sym_name};
                    uint64_t fn = 0;
                    if (remote_call(tid, dlsym_addr, sym_args, 2, &fn, c.stub) && fn != 0) {
                        uint64_t ignored = 0;
                        remote_call(tid, fn, nullptr, 0, &ignored, c.stub);
                        LOGI("entry %s called", entry_symbol);
                    }
                }
            }
        }

        // 6) 收拾现场:把临时内存还回去、fd 关掉。
        //    dlopen 已经把 ELF 映射好,这块 RWX 临时页留着只会被反作弊当成"外挂内存",没必要。
        if (c.page != 0) {
            uint64_t un_args[2] = {c.page, c.page_size};
            bool un_called = false;
            remote_syscall_ret(c, 215 /* munmap */, un_args, 2, &un_called);
            c.page = 0;
        }
        if (memfd_fd >= 0) {
            uint64_t close_arg[1] = {static_cast<uint64_t>(memfd_fd)};
            bool close_called = false;
            remote_syscall_ret(c, 57 /* close */, close_arg, 1, &close_called);
        }

        result = ERR_NONE;
    } while (false);

    // 收尾:还原现场再放走。失败也绝不把目标留在"PC 悬空"的状态
    detach_thread(tid, c.saved, restore);
    return result;
}

}  // namespace

const char* inject_last_detail() { return g_detail.c_str(); }

int inject_module(pid_t pid, const char* so_path, const char* entry_symbol) {
    clear_detail();

    if (pid <= 0 || so_path == nullptr || so_path[0] == '\0') {
        set_detail("目标进程不存在");
        return ERR_TARGET_NOT_FOUND;
    }
    if (strlen(so_path) >= 200) {
        set_detail("so 路径太长(%zu 字节)", strlen(so_path));
        return ERR_PATH_TOO_LONG;
    }

    std::vector<MapEntry> maps = parse_maps(pid);
    if (maps.empty()) {
        set_detail("读不到 /proc/%d/maps", pid);
        return ERR_TARGET_DIR_NOT_ACCESSIBLE;
    }

    if (!target_is64(maps)) {
        set_detail("目标进程是 32 位,这个注入器只带 64 位通道");
        return ERR_ABI_MISMATCH;
    }

    std::vector<ThreadPick> threads = list_threads(pid);
    if (threads.empty()) {
        threads.push_back({pid, 'S'});
    }

    int last = ERR_UNKNOWN;
    int tried = 0;
    for (const auto& t : threads) {
        if (tried >= 6) break;   // 最多试 6 个线程,别在一棵树上吊死
        tried++;
        LOGI("try inject into tid=%d state=%c", t.tid, t.state);
        int rc = inject_into_thread(pid, t.tid, maps, so_path, entry_symbol);
        if (rc == ERR_NONE) return ERR_NONE;
        last = rc;
        // 附加被拒是进程级权限问题,换线程也没用,直接收,别浪费时间
        if (rc == ERR_ATTACH_DENIED) break;
    }
    return last;
}

#else  // 非 arm64 构建

const char* inject_last_detail() { return "这个构建只带 arm64 注入通道"; }

int inject_module(pid_t pid, const char* so_path, const char* entry_symbol) {
    (void) pid;
    (void) so_path;
    (void) entry_symbol;
    return ERR_ABI_MISMATCH;
}

#endif
