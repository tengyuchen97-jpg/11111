//
// ptrace 进程注入器(arm64 / arm32)
//
// 流程:
//   1. PTRACE_ATTACH 附加目标进程
//   2. 读 /proc/<pid>/maps,算出 mmap / dlopen / dlsym 在目标里的地址
//   3. 远程调 mmap 拿一页可读写可执行内存,把 so 路径和一条断点指令写进去
//   4. 远程调 __loader_dlopen(优先)/ dlopen 加载模块
//   5. 需要的话再 dlsym 出 entry 符号调一下
//   6. 还原寄存器(含原 pc/返回值寄存器),PTRACE_DETACH 放走
//
// 返回值 = 0 成功,负数失败(和 Kotlin 侧 PtraceInjectFailure 一一对应)
//
#include "injector.h"

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <dlfcn.h>
#include <elf.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>

#include <android/log.h>

#define LOG_TAG "honffx-injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ---------------------------------------------------------------- 架构相关

#if defined(__aarch64__) || defined(HONFFX_FORCE_ARCH_64)
#define HONFFX_ARCH_ARM64 1
#elif defined(__arm__) || defined(HONFFX_FORCE_ARCH_32)
#define HONFFX_ARCH_ARM32 1
#endif

#if defined(HONFFX_ARCH_ARM64)
struct regs_t {
    uint64_t regs[31];   // x0..x30
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
};
#define ARG_REG(r, i) ((r).regs[i])
#define RET_REG(r) ((r).regs[0])
#define LR_REG(r) ((r).regs[30])
#define SET_LR(r, v) ((r).regs[30] = (uint64_t)(v))
#define GET_PC(r) ((r).pc)
#define SET_PC(r, v) ((r).pc = (uint64_t)(v))
// brk #0
static const uint32_t TRAP_INSN = 0xD4200000u;
#elif defined(HONFFX_ARCH_ARM32)
struct regs_t {
    uint32_t uregs[18];  // r0..r15, cpsr, orig_r0
};
#define ARG_REG(r, i) ((r).uregs[i])
#define RET_REG(r) ((r).uregs[0])
#define LR_REG(r) ((r).uregs[14])
#define SET_LR(r, v) ((r).uregs[14] = (uint32_t)(v))
#define GET_PC(r) ((r).uregs[15])
#define SET_PC(r, v) ((r).uregs[15] = (uint32_t)(v))
// bkpt #0
static const uint32_t TRAP_INSN = 0xE1200070u;
#else
struct regs_t { uint64_t dummy[32]; };
#endif

// 和 Kotlin 的 PtraceInjectFailure 对齐
enum {
    ERR_NONE = 0,
    ERR_NATIVE_NOT_LOADED = -1,
    ERR_TARGET_NOT_FOUND = -2,
    ERR_ATTACH_DENIED = -3,
    ERR_MMAP_FAILED = -4,
    ERR_DLOPEN_SYMBOL_NOT_FOUND = -5,
    ERR_DLOPEN_FAILED = -6,
    ERR_PATH_TOO_LONG = -7,
    ERR_TARGET_DIR_NOT_ACCESSIBLE = -8,
    ERR_WRITE_REMOTE_FAILED = -9,
    ERR_UNKNOWN = -99,
};

namespace {

struct MapEntry {
    uint64_t start;
    uint64_t end;
    uint64_t offset;
    bool executable;
    std::string path;
};

// ------------------------------------------------------------ 读 / 写 内存

bool read_mem(pid_t pid, uint64_t addr, void* buf, size_t len) {
    struct iovec local{};
    struct iovec remote{};
    local.iov_base = buf;
    local.iov_len = len;
    remote.iov_base = reinterpret_cast<void*>(addr);
    remote.iov_len = len;
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(len)) return true;

    // 退路:一次一个机器字地用 ptrace 拷
    uint8_t* p = static_cast<uint8_t*>(buf);
    size_t copied = 0;
    while (copied < len) {
        errno = 0;
        long word = ptrace(PTRACE_PEEKDATA, pid, reinterpret_cast<void*>(addr + copied), nullptr);
        if (word == -1 && errno != 0) return false;
        size_t chunk = sizeof(long);
        if (chunk > len - copied) chunk = len - copied;
        memcpy(p + copied, &word, chunk);
        copied += chunk;
    }
    return true;
}

bool write_mem(pid_t pid, uint64_t addr, const void* buf, size_t len) {
    struct iovec local{};
    struct iovec remote{};
    local.iov_base = const_cast<void*>(buf);
    local.iov_len = len;
    remote.iov_base = reinterpret_cast<void*>(addr);
    remote.iov_len = len;
    ssize_t n = process_vm_writev(pid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(len)) return true;

    const uint8_t* p = static_cast<const uint8_t*>(buf);
    size_t written = 0;
    while (written < len) {
        long word = 0;
        size_t chunk = sizeof(long);
        if (chunk > len - written) {
            // 尾巴不足一个字:先读回来再拼,免得把后面的字节抹了
            word = ptrace(PTRACE_PEEKDATA, pid, reinterpret_cast<void*>(addr + written), nullptr);
            chunk = len - written;
        }
        memcpy(&word, p + written, chunk);
        if (ptrace(PTRACE_POKEDATA, pid, reinterpret_cast<void*>(addr + written),
                   reinterpret_cast<void*>(word)) < 0) {
            return false;
        }
        written += chunk;
    }
    return true;
}

// ---------------------------------------------------------------- 寄存器

bool get_regs(pid_t pid, regs_t* out) {
    struct iovec io{};
    io.iov_base = out;
    io.iov_len = sizeof(regs_t);
    return ptrace(PTRACE_GETREGSET, pid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

bool set_regs(pid_t pid, const regs_t* in) {
    struct iovec io{};
    io.iov_base = const_cast<regs_t*>(in);
    io.iov_len = sizeof(regs_t);
    return ptrace(PTRACE_SETREGSET, pid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

bool wait_for_trap(pid_t pid) {
    int status = 0;
    for (int i = 0; i < 64; i++) {
        if (waitpid(pid, &status, 0) < 0) return false;
        if (!WIFSTOPPED(status)) return false;
        int sig = WSTOPSIG(status);
        if (sig == SIGTRAP) return true;
        if (sig == SIGSEGV || sig == SIGBUS || sig == SIGILL) {
            // 目标自己崩了,别硬撑
            LOGE("target stopped by signal %d", sig);
            return false;
        }
        // 其它信号原样丢回去继续跑
        ptrace(PTRACE_CONT, pid, nullptr, reinterpret_cast<void*>(static_cast<long>(sig)));
    }
    return false;
}

/** 在目标进程里调一次函数,拿返回值。stub_addr 里放着断点指令 */
bool remote_call(pid_t pid, uint64_t func, const uint64_t* args, int nargs,
                 uint64_t* ret, uint64_t stub_addr) {
    regs_t saved{};
    regs_t regs{};
    if (!get_regs(pid, &saved)) return false;
    regs = saved;

    for (int i = 0; i < nargs && i < 8; i++) {
        ARG_REG(regs, i) = args[i];
    }
    SET_PC(regs, func);
    SET_LR(regs, stub_addr);

    if (!set_regs(pid, &regs)) return false;
    if (ptrace(PTRACE_CONT, pid, nullptr, nullptr) < 0) return false;
    if (!wait_for_trap(pid)) return false;

    regs_t after{};
    if (!get_regs(pid, &after)) return false;
    if (ret != nullptr) *ret = RET_REG(after);

    // 还原:调用者的 pc / 寄存器 / 返回值全都要回到原样
    if (!set_regs(pid, &saved)) return false;
    return true;
}

// ---------------------------------------------------------------- maps

std::vector<MapEntry> parse_maps(pid_t pid) {
    std::vector<MapEntry> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (fp == nullptr) return out;

    char line[1024];
    while (fgets(line, sizeof(line), fp) != nullptr) {
        unsigned long long start = 0, end = 0, offset = 0;
        char perms[8] = {0};
        char file[768] = {0};
        int n = sscanf(line, "%llx-%llx %7s %llx %*s %*s %767[^\n]",
                       &start, &end, perms, &offset, file);
        if (n < 4) continue;
        MapEntry e{};
        e.start = start;
        e.end = end;
        e.offset = offset;
        e.executable = perms[2] == 'x';
        if (n >= 5) {
            std::string p(file);
            while (!p.empty() && (p.front() == ' ' || p.front() == '\t')) p.erase(p.begin());
            while (!p.empty() && (p.back() == ' ' || p.back() == '\n' || p.back() == '\r')) p.pop_back();
            e.path = p;
        }
        out.push_back(e);
    }
    fclose(fp);
    return out;
}

// ---------------------------------------------------------------- ELF 符号

bool symbol_offset_in_file(const char* path, const char* symbol, uint64_t* out_offset) {
    FILE* fp = fopen(path, "rb");
    if (fp == nullptr) return false;

    uint8_t ident[EI_NIDENT];
    if (fread(ident, 1, sizeof(ident), fp) != sizeof(ident)) {
        fclose(fp);
        return false;
    }
    if (memcmp(ident, ELFMAG, SELFMAG) != 0) {
        fclose(fp);
        return false;
    }
    bool is64 = ident[EI_CLASS] == ELFCLASS64;

    if (is64) {
        Elf64_Ehdr eh{};
        fseek(fp, 0, SEEK_SET);
        if (fread(&eh, 1, sizeof(eh), fp) != sizeof(eh)) {
            fclose(fp);
            return false;
        }
        if (eh.e_shoff == 0 || eh.e_shnum == 0) {
            fclose(fp);
            return false;
        }
        Elf64_Shdr shdr{};
        for (int i = 0; i < eh.e_shnum; i++) {
            fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(i) * eh.e_shentsize), SEEK_SET);
            if (fread(&shdr, 1, sizeof(shdr), fp) != sizeof(shdr)) break;
            if (shdr.sh_type != SHT_DYNSYM) continue;
            Elf64_Shdr str_sh{};
            fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(shdr.sh_link) * eh.e_shentsize), SEEK_SET);
            if (fread(&str_sh, 1, sizeof(str_sh), fp) != sizeof(str_sh)) break;

            int count = static_cast<int>(shdr.sh_size / sizeof(Elf64_Sym));
            for (int j = 0; j < count; j++) {
                Elf64_Sym sym{};
                fseek(fp, static_cast<long>(shdr.sh_offset + static_cast<uint64_t>(j) * sizeof(Elf64_Sym)), SEEK_SET);
                if (fread(&sym, 1, sizeof(sym), fp) != sizeof(sym)) break;
                if (sym.st_shndx == SHN_UNDEF || sym.st_name == 0) continue;
                char name[256] = {0};
                fseek(fp, static_cast<long>(str_sh.sh_offset + sym.st_name), SEEK_SET);
                size_t r = fread(name, 1, sizeof(name) - 1, fp);
                if (r == 0) continue;
                if (strcmp(name, symbol) == 0) {
                    *out_offset = sym.st_value;
                    fclose(fp);
                    return true;
                }
            }
        }
        fclose(fp);
        return false;
    }

    Elf32_Ehdr eh{};
    fseek(fp, 0, SEEK_SET);
    if (fread(&eh, 1, sizeof(eh), fp) != sizeof(eh)) {
        fclose(fp);
        return false;
    }
    if (eh.e_shoff == 0 || eh.e_shnum == 0) {
        fclose(fp);
        return false;
    }
    Elf32_Shdr shdr{};
    for (int i = 0; i < eh.e_shnum; i++) {
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint32_t>(i) * eh.e_shentsize), SEEK_SET);
        if (fread(&shdr, 1, sizeof(shdr), fp) != sizeof(shdr)) break;
        if (shdr.sh_type != SHT_DYNSYM) continue;
        Elf32_Shdr str_sh{};
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint32_t>(shdr.sh_link) * eh.e_shentsize), SEEK_SET);
        if (fread(&str_sh, 1, sizeof(str_sh), fp) != sizeof(str_sh)) break;

        int count = static_cast<int>(shdr.sh_size / sizeof(Elf32_Sym));
        for (int j = 0; j < count; j++) {
            Elf32_Sym sym{};
            fseek(fp, static_cast<long>(shdr.sh_offset + static_cast<uint32_t>(j) * sizeof(Elf32_Sym)), SEEK_SET);
            if (fread(&sym, 1, sizeof(sym), fp) != sizeof(sym)) break;
            if (sym.st_shndx == SHN_UNDEF || sym.st_name == 0) continue;
            char name[256] = {0};
            fseek(fp, static_cast<long>(str_sh.sh_offset + sym.st_name), SEEK_SET);
            size_t r = fread(name, 1, sizeof(name) - 1, fp);
            if (r == 0) continue;
            if (strcmp(name, symbol) == 0) {
                *out_offset = sym.st_value;
                fclose(fp);
                return true;
            }
        }
    }
    fclose(fp);
    return false;
}

/** 在目标的某几个库里找符号,返回目标进程里的绝对地址 */
uint64_t resolve_in_libs(pid_t pid, const std::vector<MapEntry>& maps,
                         const std::vector<std::string>& libs, const char* symbol) {
    for (const auto& lib : libs) {
        for (const auto& m : maps) {
            if (m.path.empty()) continue;
            if (m.path.find(lib) == std::string::npos) continue;
            uint64_t offset = 0;
            if (!symbol_offset_in_file(m.path.c_str(), symbol, &offset)) continue;
            uint64_t base = m.start - m.offset;
            uint64_t addr = base + offset;
            LOGI("symbol %s from %s -> 0x%llx", symbol, m.path.c_str(),
                 static_cast<unsigned long long>(addr));
            return addr;
        }
    }
    return 0;
}

/** 找"能不能加载 so"的那个入口:优先 linker 里的 __loader_dlopen */
uint64_t resolve_dlopen(pid_t pid, const std::vector<MapEntry>& maps, bool* is_loader) {
    std::vector<std::string> linkers = {"linker64", "linker", "libdl.so", "libdl_android.so"};
    uint64_t addr = resolve_in_libs(pid, maps, linkers, "__loader_dlopen");
    if (addr != 0) {
        *is_loader = true;
        return addr;
    }
    std::vector<std::string> dl = {"libdl.so", "libdl_android.so", "libc.so"};
    addr = resolve_in_libs(pid, maps, dl, "dlopen");
    *is_loader = false;
    return addr;
}

}  // namespace

int inject_module(pid_t pid, const char* so_path, const char* entry_symbol) {
#if !defined(HONFFX_ARCH_ARM64) && !defined(HONFFX_ARCH_ARM32)
    (void) pid; (void) so_path; (void) entry_symbol;
    LOGE("unsupported abi");
    return ERR_UNKNOWN;
#else
    if (pid <= 0 || so_path == nullptr) return ERR_TARGET_NOT_FOUND;
    if (strlen(so_path) >= 256) return ERR_PATH_TOO_LONG;

    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) < 0) {
        LOGE("ptrace attach failed: %s", strerror(errno));
        return ERR_ATTACH_DENIED;
    }
    int status = 0;
    if (waitpid(pid, &status, 0) < 0 || !WIFSTOPPED(status)) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_ATTACH_DENIED;
    }

    int result = ERR_UNKNOWN;
    std::vector<MapEntry> maps = parse_maps(pid);
    if (maps.empty()) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_TARGET_DIR_NOT_ACCESSIBLE;
    }

    uint64_t mmap_addr = resolve_in_libs(pid, maps, {"libc.so"}, "mmap");
    bool is_loader = false;
    uint64_t dlopen_addr = resolve_dlopen(pid, maps, &is_loader);

    if (mmap_addr == 0 || dlopen_addr == 0) {
        LOGE("resolve failed: mmap=0x%llx dlopen=0x%llx",
             static_cast<unsigned long long>(mmap_addr),
             static_cast<unsigned long long>(dlopen_addr));
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_DLOPEN_SYMBOL_NOT_FOUND;
    }

    // 1) 远程 mmap 一页:可读可写可执行
    uint64_t args[6];
    args[0] = 0;                       // addr
    args[1] = 0x1000;                  // length
    args[2] = PROT_READ | PROT_WRITE | PROT_EXEC;
    args[3] = MAP_PRIVATE | MAP_ANONYMOUS;
    args[4] = static_cast<uint64_t>(-1);  // fd
    args[5] = 0;                       // offset
    uint64_t page = 0;
    if (!remote_call(pid, mmap_addr, args, 6, &page, 0)) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_MMAP_FAILED;
    }
    if (page == 0 || page == static_cast<uint64_t>(-1)) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_MMAP_FAILED;
    }
    LOGI("remote page = 0x%llx", static_cast<unsigned long long>(page));

    // 2) 把 so 路径和断点指令写进去
    uint64_t str_addr = page;
    uint64_t stub_addr = page + 0x100;
    if (!write_mem(pid, str_addr, so_path, strlen(so_path) + 1)) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_WRITE_REMOTE_FAILED;
    }
    if (!write_mem(pid, stub_addr, &TRAP_INSN, sizeof(TRAP_INSN))) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_WRITE_REMOTE_FAILED;
    }

    // 3) 调 dlopen(路径, RTLD_NOW|RTLD_GLOBAL)
    uint64_t dl_args[2];
    dl_args[0] = str_addr;
    dl_args[1] = RTLD_NOW | RTLD_GLOBAL;
    uint64_t handle = 0;
    bool called = remote_call(pid, dlopen_addr, dl_args, 2, &handle, stub_addr);
    if (!called) {
        LOGE("remote dlopen call failed");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_DLOPEN_FAILED;
    }
    if (handle == 0) {
        LOGE("dlopen returned NULL (%s)", is_loader ? "__loader_dlopen" : "dlopen");
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return ERR_DLOPEN_FAILED;
    }
    LOGI("module loaded, handle=0x%llx", static_cast<unsigned long long>(handle));

    // 4) 需要主动调 entry 的话,顺手 dlsym 出来调一下
    if (entry_symbol != nullptr && entry_symbol[0] != '\0') {
        uint64_t dlsym_addr = resolve_in_libs(
                pid, maps, {"libdl.so", "libdl_android.so", "libc.so"}, "dlsym");
        if (dlsym_addr != 0) {
            uint64_t sym_args[2];
            sym_args[0] = handle;
            sym_args[1] = str_addr + 0x400;  // 符号名写到页面后半段
            if (write_mem(pid, sym_args[1], entry_symbol, strlen(entry_symbol) + 1)) {
                uint64_t fn = 0;
                if (remote_call(pid, dlsym_addr, sym_args, 2, &fn, stub_addr) && fn != 0) {
                    uint64_t no_args[1] = {0};
                    uint64_t ignored = 0;
                    remote_call(pid, fn, no_args, 0, &ignored, stub_addr);
                    LOGI("entry %s called", entry_symbol);
                }
            }
        }
    }

    result = ERR_NONE;
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
    return result;
#endif
}
