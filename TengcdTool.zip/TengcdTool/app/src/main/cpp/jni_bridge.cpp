//
// JNI 桥。符号名必须和 Kotlin 侧对上:
//   com.tengcd.czr.inject.PtraceInjector.nativeInject(int, String, String)
//
#include <jni.h>
#include <string>
#include <vector>

#include <android/log.h>

#include "injector.h"

#define LOG_TAG "honffx-injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jint JNICALL
Java_com_tengcd_czr_inject_PtraceInjector_nativeInject(JNIEnv* env, jobject /*thiz*/,
                                                        jint pid, jstring so_path,
                                                        jstring entry) {
    if (so_path == nullptr) return -2;

    const char* c_path = env->GetStringUTFChars(so_path, nullptr);
    if (c_path == nullptr) return -2;

    const char* c_entry = nullptr;
    if (entry != nullptr) {
        c_entry = env->GetStringUTFChars(entry, nullptr);
    }

    int ret = inject_module(static_cast<pid_t>(pid), c_path, c_entry);
    LOGI("inject pid=%d path=%s ret=%d", pid, c_path, ret);

    env->ReleaseStringUTFChars(so_path, c_path);
    if (c_entry != nullptr) {
        env->ReleaseStringUTFChars(entry, c_entry);
    }
    return ret;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_tengcd_czr_inject_PtraceInjector_nativeInjectMany(JNIEnv* env, jobject /*thiz*/,
                                                           jint pid, jobjectArray paths,
                                                           jstring entry) {
    if (paths == nullptr) return -2;

    jsize n = env->GetArrayLength(paths);
    if (n <= 0) return -2;

    std::vector<std::string> holder;
    std::vector<const char*> raw;
    holder.reserve(static_cast<size_t>(n));
    for (jsize i = 0; i < n; i++) {
        auto s = static_cast<jstring>(env->GetObjectArrayElement(paths, i));
        if (s == nullptr) {
            raw.push_back(nullptr);
            continue;
        }
        const char* c = env->GetStringUTFChars(s, nullptr);
        holder.emplace_back(c == nullptr ? "" : c);
        if (c != nullptr) env->ReleaseStringUTFChars(s, c);
        env->DeleteLocalRef(s);
    }
    for (auto& s : holder) raw.push_back(s.c_str());

    const char* c_entry = nullptr;
    if (entry != nullptr) c_entry = env->GetStringUTFChars(entry, nullptr);

    int ret = inject_module_multi(static_cast<pid_t>(pid), raw.data(),
                                  static_cast<int>(raw.size()), c_entry);
    LOGI("injectMany pid=%d libs=%d ret=%d", pid, static_cast<int>(raw.size()), ret);

    if (c_entry != nullptr) env->ReleaseStringUTFChars(entry, c_entry);
    return ret;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_tengcd_czr_inject_PtraceInjector_nativeLastDetail(JNIEnv* env, jobject /*thiz*/) {
    const char* d = inject_last_detail();
    if (d == nullptr) d = "";
    return env->NewStringUTF(d);
}
