pluginManagement {
    repositories {
        maven("https://dl.google.com/dl/android/maven2")
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven("https://dl.google.com/dl/android/maven2")
        maven("https://api.xposed.info/")
        google()
        mavenCentral()
    }
}

rootProject.name = "TengcdTool"
include(":app")
