/* root 注入器独立编译用的 android/log.h 替身:日志直接进 stderr(root 下就是 shell 输出) */
#ifndef ZAKA_STUB_ANDROID_LOG_H
#define ZAKA_STUB_ANDROID_LOG_H
#include <cstdio>
#include <cstdarg>
#define ANDROID_LOG_INFO 4
#define ANDROID_LOG_ERROR 6
static inline int __android_log_print(int prio, const char* tag, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "[%s] ", tag ? tag : "log");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    return 0;
}
#endif
