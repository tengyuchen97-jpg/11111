// root 注入器的命令行外壳。
//
// 注入核心逻辑跟 App 里那份 JNI 库完全同一份 injector.cpp,
// 这里只是给它配一个 main(),让它能在 root 下独立跑:
//     ptrace_inject <pid> <so 绝对路径> [入口符号]
// 输出固定两行,App 那边按前缀解析:
//     RESULT=0
//     DETAIL=xxx
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "injector.h"

int main(int argc, char** argv) {
    if (argc < 3) {
        printf("RESULT=-2\n");
        printf("DETAIL=用法: %s <pid> <so路径> [入口符号]\n", argv[0]);
        return 2;
    }
    pid_t pid = static_cast<pid_t>(atoi(argv[1]));
    const char* so_path = argv[2];
    const char* entry = (argc > 3 && argv[3][0] != '\0' && strcmp(argv[3], "-") != 0) ? argv[3] : nullptr;
    if (pid <= 1) {
        printf("RESULT=-2\n");
        printf("DETAIL=pid 不对: %s\n", argv[1]);
        return 2;
    }
    int code = inject_module(pid, so_path, entry);
    const char* detail = inject_last_detail();
    printf("RESULT=%d\n", code);
    printf("DETAIL=%s\n", detail ? detail : "");
    fflush(stdout);
    return code == 0 ? 0 : 1;
}
