# 遄懂（TengcdTool）—— 完整源码

Kotlin + Jetpack Compose 全套工程，两条注入通道（框架注入 / 进程注入）+ ptrace native 注入器源码 + Xposed 模块入口 + 卡密页 + 更新分发。

> 这是**源码工程**，用 Android Studio 打开直接能编。

---

## 一、这一版改了什么

| # | 改动 | 在哪 |
|---|---|---|
| 1 | **模块概览下面加了 SO 选择器**：`v0.19 / v0.20 / v0.23 / v0.24` 四个变体，点哪个就用哪个注入（包里先放的是空白占位 so） | `ModuleStore.BUILTIN_VARIANTS` + `ui/screens/UpdateScreen.kt` |
| 2 | **注入时不再弹任何阻止性对话框**（不再拦「请先更新模块 / 请先在框架里启用」），直接按当前选中的 SO 往里打 | `MainViewModel.inject()` |
| 3 | 标题 `Honffx Tool` → **遄懂**（字体不变，仍是手写体标题档） | `i18n/Strings.kt` `appTitle`、`res/values/strings.xml` |
| 4 | **配色**：未激活 / 未就绪 → 黄色；已激活 / 可访问 / 已就绪 → 绿色 | `ui/components/LiquidGlass.kt` `StatusRow`、两个屏幕 |
| 5 | **目标应用名标红**，下面一个框单独放它的包名 | `ui/components/LiquidGlass.kt` `TargetAppBadge` |
| 6 | 包名 → **`com.tengcd.czr`**（含 Kotlin 目录、JNI 符号名、provider authority、action 全量同步） | 全局 |
| 7 | **公告下面加了「本机 SO」卡**：从本机读一个 so 文件，读完注入就用它 | `ModuleStore.importLocalSo` + `UpdateScreen` |

---

## 二、怎么编

1. Android Studio（Koala 或更新）→ Open → 选本目录
2. 首次打开会自动拉 Gradle 8.9 / AGP 8.7.3 / Compose 依赖
3. **native 部分需要 NDK**：默认写的是 `ndkVersion = "26.1.10909125"`（`app/build.gradle.kts` 里）。
   本机没这个版本就改成你已装的版本号（Android Studio 也会自动下）。
4. Run ▶ 装到真机（arm64 / armv7 都编了）

命令行编：

```bash
./gradlew :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

工程里带了 gradle wrapper 配置；缺 `gradlew` 脚本和 `gradle-wrapper.jar` 的话，
在项目根目录跑一次 `gradle wrapper --gradle-version 8.9` 生成即可。

---

## 三、把你的真 SO 塞进去（重要）

`app/src/main/assets/so/` 下面那四个 `v0.19.so ~ v0.24.so` 现在是**空白占位件**
（最小可 dlopen 的 arm64 空壳，注入进去不会崩、但也不做任何事）。

换成真的：**直接用你的真 so 覆盖同名文件即可**，文件名不要改。

```
app/src/main/assets/so/v0.19.so   ← 覆盖成真的 v0.19
app/src/main/assets/so/v0.20.so
app/src/main/assets/so/v0.23.so
app/src/main/assets/so/v0.24.so
```

换完之后：
- 首次启动会把四个变体解到私有目录 `files/module/libhonffx_<变体>.so`
- 界面上点哪个变体，注入用的就是那个文件
- 想加/减变体：改 `ModuleStore.BUILTIN_VARIANTS`（顺序就是界面上显示的顺序），
  然后往 `assets/so/` 放同名文件

> 已经装过旧版的话，装新版前先清一下数据（老的四份落位件还在私有目录里，同名会被复用）。

「本机 SO」那条路不走内置资产：用户在界面上挑一个手机里的 so，
文件会被收进私有目录 `files/module/libhonffx_local.so`，之后注入就用它；
点「清除」自动退回内置变体。

---

## 四、目录结构

```
app/src/main/
├─ AndroidManifest.xml                 清单（sharedUserId / Xposed 声明 / Provider / 服务 / 广播）
├─ assets/
│   ├─ xposed_init                     框架模块入口：com.tengcd.czr.xposed.HookInit
│   └─ so/v0.19.so … v0.24.so          ← 内置 SO 变体（现在是占位件，换成你的真 so）
├─ res/                                图标 / 主题 / xposed 作用域 / 文案
├─ cpp/
│   ├─ CMakeLists.txt
│   ├─ injector.h
│   ├─ injector.cpp                    ptrace 注入器（arm64 + arm32）
│   └─ jni_bridge.cpp                  JNI 桥：PtraceInjector.nativeInject
└─ java/com/tengcd/czr/
    ├─ HonffxApplication.kt            启动：配置初始化 + 内置 SO 落位 + 本地 socket 常驻
    ├─ MainActivity.kt                 界面外壳：标题栏 / 底部三页签 / 系统文件选择器 / 弹窗调度
    ├─ MainViewModel.kt                全部业务逻辑（更新 / 下载 / 注入 / SO 切换 / 本机 SO / 卡密）
    ├─ UiState.kt  UiAction.kt  UiEvent.kt  ErrorKind.kt
    ├─ i18n/                           中英文案（LocalizedStrings + Strings）
    ├─ inject/
    │   ├─ InjectionMode.kt            FRAMEWORK / PROCESS
    │   ├─ InjectorRouter.kt           按模式选通道，统一出入口
    │   ├─ PtraceInjector.kt           进程注入（加载 native 库 + 找 pid）
    │   ├─ PtraceInjectFailure.kt      失败码（和 native 一一对应）
    │   ├─ PtraceInjectResult.kt
    │   └─ ModuleStore.kt              so 的多来源落位（内置变体 / 本机 / 远端）+ 交接文件
    ├─ ipc/SoSocketServer.kt           本地 socket：目标进程来问模块路径
    ├─ network/                        配置拉取 / 模块下载校验 / 卡密接口 / 本地卡密
    ├─ provider/SoProvider.kt          content:// 把 so 供出去 + 回报激活状态
    ├─ service/                        InjectService / 交接唤醒 / 开机自启
    ├─ ui/                             主题、玻璃组件、三个页面
    ├─ util/                           偏好、md5、包工具、权限、分享码、shell
    └─ xposed/
        ├─ HookInit.kt                 框架注入入口
        └─ XposedDetector.kt           检测设备上有没有 Xposed 系框架
```

---

## 五、两条注入通道怎么走

### 1. 框架注入（`InjectionMode.FRAMEWORK`）
1. 装 LSPosed → 模块里勾上本应用 → 作用域勾目标游戏
2. 「一键注入」把当前选中的 so 路径写进交接文件 / 偏好（`ModuleStore.writeHandoff`）
3. 目标游戏启动 → `HookInit` 拿到路径 → `System.load()` → 回 `content://com.tengcd.czr.so` 报激活
4. 路径来源顺序：XSharedPreferences → ContentProvider → 外部交接文件 → 私有 module 目录里的 so

### 2. 进程注入（`InjectionMode.PROCESS`）
1. 目标应用先跑起来（「启动游戏」按钮，起来后自动触发一次交接广播）
2. 校验两件事：**两个应用同一个 sharedUserId**（清单里写的是 `ts.al.al`）、目标数据目录可写
3. 把当前选中的 so 复制到 `/data/data/<目标包>/files/`（`ModuleStore.stageForTarget`）
4. native 侧 `injector.cpp`：`PTRACE_ATTACH` → 读 maps 解析 `mmap` / `__loader_dlopen`（退 `dlopen`）→ 远程 mmap 一页 → 写路径 + 断点指令 → 远程调 `dlopen` → 还原寄存器 → `PTRACE_DETACH`

失败原因全都有对应人话提示（`ui/InjectFailureMessage.kt`）：
未装目标 / 没跑起来 / uid 不一致 / 附加被拒 / 链接器拒绝该路径 / so 不存在 ……

---

## 六、上线前要改的地方

| 改什么 | 在哪 |
|---|---|
| 目标游戏包名 | `InjectionPrefs.DEFAULT_TARGET_PACKAGE` + `res/xml/xposed_scope.xml` + 清单里的 `<queries>` |
| sharedUserId | `AndroidManifest.xml` 的 `android:sharedUserId`（必须和目标应用一致才能进程注入） |
| 服务端地址 | `InjectionPrefs.DEFAULT_CONFIG_URL`（配置 JSON 字段见 `network/ConfigParser.kt`） |
| 内置 SO | `app/src/main/assets/so/v*.so` 覆盖同名文件 + `ModuleStore.BUILTIN_VARIANTS` |
| 卡密本地校验 | 卡密页开关，或 `/sdcard/Download/honffx_card.txt`，格式：`卡密\|到期时间\|剩余次数\|解绑次数` |
| 加语言 | `i18n/Strings.kt` 再补一份 `LocalizedStrings` 实例 |

服务端配置 JSON 长这样：

```json
{
  "version": "0.24",
  "so_url": "https://你的域名/module/libhonffx.so",
  "md5": "模块文件的md5",
  "announcement": "公告文字",
  "target_package": "com.pi.czrxdfirst",
  "force_update": false,
  "update_log": "更新说明"
}
```

---

## 七、真机上的几个实话

- **进程注入在无 root 的设备上限制很大**：Android 7+ 的 SELinux 默认不允许跨进程 ptrace。
  能走通的前提是「同 sharedUserId + 目标允许调试/转储」，走不通就换框架注入那条路。
- 模块 so 得是**目标进程能 dlopen 的纯 native 库**（不要依赖 JNI 环境，除非你自己调 `JNI_OnLoad`）。
- 目标 so 的路径权限很关键，所以默认优先放目标私有目录，再退到外部目录。
- 「本机 SO」挑进来的文件会先收进本应用私有目录再注入 —— 外部路径（比如 Downloads 里）
  目标进程多半没权限打开。

---

## 八、免责

代码只做技术演示，注入的目标应用请确保是你自己有权调试的。
