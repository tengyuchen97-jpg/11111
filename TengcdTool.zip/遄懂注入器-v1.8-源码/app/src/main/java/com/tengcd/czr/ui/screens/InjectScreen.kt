package com.tengcd.czr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.ui.components.EmptyHint
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.SoSourceChips
import com.tengcd.czr.ui.components.SoGroupChips
import com.tengcd.czr.ui.components.SegmentedControl
import com.tengcd.czr.ui.components.TargetAppBadge
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.WarnOrange

@Composable
fun InjectScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme

    // 这两组状态全部来自运行时真实读取,没有任何写死的图/文字:
    //  frameworkOn      = 框架管理器里真的把这个模块认下来了(so 被 Provider / 钩子回报)
    //  frameworkActive  = 目标游戏进程里真的把 so 加载起来了
    val frameworkOn = state.frameworkSelfLoaded
    val injectStateText = when {
        state.frameworkActive -> s.injectIntoGameOk
        !state.targetRunning -> s.targetNotStarted
        else -> s.injectIntoGameNo
    }
    val injectStateColor = when {
        state.frameworkActive -> OkGreen
        !state.targetRunning -> ErrRed
        else -> WarnOrange
    }

    // 每次进到这一页都重新核一遍:本地 so 还在不在、目标进程活没活
    // (不然删掉本地 so 之后,「本地」那个按钮会挂在那儿不走)
    LaunchedEffect(Unit) { onAction(UiAction.RefreshRuntime) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 删除了原本的大标题 Text 和它上面的 Spacer
        // 直接留出一点点顶部间距即可
        Spacer(Modifier.height(16.dp)) 

        // 两个模式:框架注入 / 进程注入(root 注入那一档整档删掉了)
        SegmentedControl(
            options = listOf(s.frameworkInject, s.processInject),
            selectedIndex = when (state.mode) {
                InjectionMode.FRAMEWORK -> 0
                InjectionMode.PROCESS -> 1
            },
            dark = dark
        ) { index ->
            onAction(
                UiAction.SetMode(
                    when (index) {
                        0 -> InjectionMode.FRAMEWORK
                        else -> InjectionMode.PROCESS
                    }
                )
            )
        }

        Spacer(Modifier.height(14.dp))

        if (state.mode == InjectionMode.FRAMEWORK) {
            GlassCard(dark = dark) {
                // 标题:圆形拼图图标 + 手写体「框架准备」,按设计稿排
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AccentBlue.copy(alpha = if (dark) 0.30f else 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Extension,
                            contentDescription = null,
                            tint = AccentBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = s.frameworkPrepare,
                        fontFamily = TitleFontFamily,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (dark) TextPrimaryDark else TextPrimaryLight
                    )
                }

                Spacer(Modifier.height(14.dp))

                // 一行大字:只认框架真实回报的 frameworkSelfLoaded,
                // 框架管理器里没勾选 / 没生效,这里就是「未激活」,不是贴上去的假图
                Text(
                    text = if (frameworkOn) s.frameworkModuleActive else s.frameworkModuleInactive,
                    fontFamily = TitleFontFamily,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (frameworkOn) OkGreen else WarnOrange
                )

                Spacer(Modifier.height(10.dp))

                Text(
                    text = s.frameworkPrepareDesc,
                    fontFamily = TitleFontFamily,
                    fontSize = 14.sp,
                    lineHeight = 23.sp,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = s.frameworkStatus,
                        fontFamily = TitleFontFamily,
                        fontSize = 15.sp,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                    Spacer(Modifier.width(18.dp))
                    Text(
                        text = if (frameworkOn) s.statusActivated else s.statusNotActivated,
                        fontFamily = TitleFontFamily,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (frameworkOn) OkGreen else WarnOrange
                    )
                }

                // 以下是真实读数里的补充信息,有才显示,不占版面
                state.frameworkProcess?.takeIf { it.isNotBlank() }?.let { proc ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = proc,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                if (!frameworkOn) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = s.frameworkSelfHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                if (state.frameworkActive) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = s.overlayPermissionHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                state.frameworkError?.takeIf { it.isNotBlank() }?.let { err ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = s.injectDetailLabel + ": " + err,
                        style = MaterialTheme.typography.bodySmall,
                        color = ErrRed
                    )
                }
            }
        } else {
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.Storage, s.processPrepare, dark)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = s.checkRuntimeCondition,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = AccentBlue
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.processPrepareDesc,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(10.dp))
                KeyValueRow(
                    label = s.targetDir,
                    value = if (state.targetDirAccessible) s.targetDirOk else s.targetDirNo,
                    dark = dark,
                    valueColor = if (state.targetDirAccessible) OkGreen else WarnOrange
                )
                KeyValueRow(
                    label = s.injectMode,
                    value = s.processInject,
                    dark = dark
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            // 标题右边不再挂那个绿色对勾:勾不勾 / 就绪没就绪看下面那行文字就够了,
            // 标题旁边多个勾反而让人以为是个可以点的勾选项
            SectionHeader(Icons.Filled.Storage, s.localModule, dark)
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (state.soValid) s.moduleReady else s.moduleNotReady,
                style = MaterialTheme.typography.bodyMedium,
                color = if (state.soValid) OkGreen else WarnOrange
            )
            Spacer(Modifier.height(4.dp))
            KeyValueRow(
                label = s.soSelect,
                value = when (state.soSource) {
                    "local" -> s.soLocal
                    "remote" -> s.soRemote
                    else -> if (ModuleStore.BUILTIN_VARIANTS.isEmpty()) {
                        // 这个包没有内置 so,别显示「内置SO · v0.24」误导人
                        s.localSoNone
                    } else buildString {
                        append(s.soBuiltin)
                        append("SO · ")
                        ModuleStore.groupOf(state.selectedSo)?.let {
                            append(it.title)
                            append(' ')
                        }
                        append(state.selectedSo)
                    }
                },
                dark = dark,
                valueColor = if (state.soSource == "local") OkGreen else null
            )
            KeyValueRow(
                label = s.soSizeLabel,
                value = formatSoSize(state.soSize),
                dark = dark,
                valueColor = if (state.soValid) OkGreen else WarnOrange
            )
            if (state.soPlaceholder) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.soPlaceholderHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            } else if (state.soSize <= 0L && ModuleStore.BUILTIN_VARIANTS.isNotEmpty()) {
                // 这份变体一个字节都没有(有空变体但没真 so);内置整组为空时不重复提示,
                // 下面那条 soNoBuiltin 已经说清楚了
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.soBlankHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarnOrange
                )
            } else if (!state.soValid) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.soInvalidHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
            Spacer(Modifier.height(10.dp))
            if (ModuleStore.BUILTIN_VARIANTS.isEmpty()) {
                // 安装包里本来就没有内置 so:不再摆一排永远点不亮的按钮,直接说清楚走本地导入
                Text(
                    text = s.soNoBuiltin,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarnOrange
                )
                Spacer(Modifier.height(10.dp))
            } else {
                ModuleStore.VARIANT_GROUPS.forEach { group ->
                    if (group.variants.isEmpty()) return@forEach
                    SoGroupChips(
                        groupLabel = group.title,
                        groupHint = group.hint,
                        options = group.variants,
                        selected = state.selectedSo,
                        active = state.soSource == "builtin",
                        dark = dark,
                        ready = state.soVariantReady
                    ) { onAction(UiAction.SelectSoVariant(it)) }
                    Spacer(Modifier.height(10.dp))
                }
            }
            KeyValueRow(
                label = s.soTypeLabel,
                value = when {
                    state.soSource == "local" -> s.soLocal + "SO"
                    state.soSource == "remote" -> s.soRemote + "SO"
                    ModuleStore.BUILTIN_VARIANTS.isEmpty() -> s.localSoNone
                    else -> s.soBuiltin + "SO"
                },
                dark = dark
            )
            Spacer(Modifier.height(10.dp))
            KeyValueRow(
                label = s.localSoTitle,
                value = if (state.localSoReady) s.soReady else s.localSoNone,
                dark = dark,
                valueColor = if (state.localSoReady) OkGreen else null
            )
            state.localSoSourcePath?.let { path ->
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.localSoSourcePathLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(4.dp))
                // 整条路径单独占一行(等宽字体,长路径自动折行,不再挤成半截)
                PathBox(text = path, dark = dark)
            }
            Spacer(Modifier.height(8.dp))
            // 包里没有内置 so 时没有「内置/本地」可切:只留下面「选择本机 SO」按钮
            if (ModuleStore.BUILTIN_VARIANTS.isNotEmpty()) {
                Text(
                    text = s.soSourceTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(6.dp))
                SoSourceChips(
                    dark = dark,
                    builtinActive = state.soSource != "local",
                    localReady = state.localSoReady,
                    onBuiltin = { onAction(UiAction.UseBuiltinSo) },
                    onLocal = {
                        if (state.localSoReady) {
                            onAction(UiAction.UseLocalSo)
                        } else {
                            onAction(UiAction.PickLocalSo)
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryActionButton(
                    text = s.localSoPick,
                    icon = Icons.Filled.Storage,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.PickLocalSo) }
                if (state.localSoReady) {
                    SecondaryActionButton(
                        text = s.localSoClear,
                        icon = Icons.Filled.Extension,
                        dark = dark,
                        modifier = Modifier.weight(1f)
                    ) { onAction(UiAction.ClearLocalSo) }
                }
            }
            state.frameworkError?.takeIf { it.isNotBlank() }?.let { err ->
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.injectDetailLabel + ": " + err,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            if (!state.targetInstalled) {
                EmptyHint(s.targetNotInstalled, dark)
            } else {
                TargetAppBadge(
                    label = state.targetLabel.ifBlank { state.targetPackage },
                    pkg = state.targetPackage,
                    dark = dark,
                    running = state.targetRunning
                )
                Spacer(Modifier.height(6.dp))
                KeyValueRow(
                    label = s.injectIntoGame,
                    value = injectStateText,
                    dark = dark,
                    valueColor = injectStateColor
                )
                KeyValueRow(
                    label = s.frameworkSelfLabel,
                    value = if (state.frameworkSelfLoaded) s.frameworkSelfYes else s.frameworkSelfNo,
                    dark = dark,
                    valueColor = if (state.frameworkSelfLoaded) OkGreen else WarnOrange
                )
                KeyValueRow(
                    label = s.injectMode,
                    value = when (state.mode) {
                        InjectionMode.FRAMEWORK -> s.frameworkInject
                        InjectionMode.PROCESS -> s.processInject
                    },
                    dark = dark
                )
                // 「游戏状态 已运行/未运行」这一行删了:状态统一挪到首页「框架准备」卡片里的
                // 「进程状态」,同一件事摆两处只会让人以为哪边没刷出来。
                KeyValueRow(
                    label = s.targetDir,
                    // 框架注入根本不需要碰目标目录(so 走模块的 ContentProvider 送进去),
                    // 这里再写「不可访问」只会误导人以为没配置好。
                    value = when {
                        state.mode == InjectionMode.FRAMEWORK -> s.frameworkNoDirNeeded
                        state.targetDirAccessible -> s.targetDirOk
                        else -> s.targetDirNo
                    },
                    dark = dark,
                    valueColor = if (state.mode == InjectionMode.FRAMEWORK || state.targetDirAccessible) OkGreen else WarnOrange
                )
                if (!state.sameUid && state.mode == InjectionMode.PROCESS) {
                    Spacer(Modifier.height(4.dp))
                    EmptyHint(s.notSameUid, dark)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        PrimaryActionButton(
            text = if (state.injecting) s.injectRunning else s.oneKeyInject,
            icon = Icons.Filled.Bolt,
            enabled = !state.injecting,
            dark = dark
        ) { onAction(UiAction.Inject) }

        state.injectDetail?.takeIf { it.isNotBlank() }?.let { detail ->
            Spacer(Modifier.height(12.dp))
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.BugReport, s.injectDetailLabel, dark)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(horizontalArrangement = Arrangement.Center) {
                Text(
                    text = if (state.serviceRunning) s.serviceRunning else s.serviceStopped,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.serviceRunning) OkGreen else WarnOrange
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = (if (state.targetRunning) s.gameRunning else s.gameStopped),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.targetRunning) OkGreen else WarnOrange
                )
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

/** so 大小:没文件就显示 "-" */
private fun formatSoSize(bytes: Long): String {
    if (bytes <= 0L) return "-"
    return when {
        bytes >= 1024L * 1024L -> String.format("%.2f MB", bytes / 1024.0 / 1024.0)
        bytes >= 1024L -> String.format("%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}
