package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 */
object InjectorRouter {

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        // 换过安装包也要先把内置 so 重新解包一遍,别拿旧的占位文件去加载
        ModuleStore.ensureBundled(context)

        if (!ModuleStore.isDownloaded(context)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY)
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry)
        }
    }

    /**
     * 框架注入:我们不需要自己动手,只要把"用哪个 so"写进交接文件,
     * 目标进程起来时由 HookInit 自己从安装包里抽出来加载。
     */
    private suspend fun frameworkInject(context: Context, targetPkg: String): PtraceInjectResult {
        if (!XposedDetector.isFrameworkInstalled(context)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED)
        }
        val info = ModuleStore.currentInfo(context)
        if (!info.ready) {
            val why = when {
                !info.exists -> "还没解包出内置 SO"
                info.placeholder -> "内置 SO 还是占位文件,把真 so 放进 assets/so 重新打包"
                !info.isElf -> "内置 SO 不是有效的 ELF 文件"
                else -> "内置 SO 不完整"
            }
            return PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }

        // 每次重新注入都先把上次的状态抹掉,免得界面一直显示"已激活"
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null

        val soPath = info.file.absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            // 目标还没跑:这不叫失败,下次它启动时模块会自己载入
            return PtraceInjectResult.Success(
                pid = -1,
                soPath = soPath,
                detail = "已准备好(" + ModuleStore.sourceLabel() + "),启动目标后自动加载"
            )
        }

        // 目标在跑:等目标进程回报(它下次启动才会重新加载)
        delay(1200)
        if (InjectionPrefs.frameworkActive) {
            return PtraceInjectResult.Success(pids.first(), soPath, "已生效")
        }
        val error = InjectionPrefs.frameworkError
        return PtraceInjectResult.Success(
            pid = pids.first(),
            soPath = soPath,
            detail = if (error.isNullOrBlank()) {
                "已准备好(" + ModuleStore.sourceLabel() + "),重启目标后生效"
            } else {
                "已准备好,但目标加载失败:" + error
            }
        )
    }

    /**
     * 进程注入:目标在跑 -> 把 so 挪到目标数据目录 -> ptrace 附加 -> 远程 dlopen。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?
    ): PtraceInjectResult {
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.SAME_UID_REQUIRED,
                "本应用与目标应用的 uid 不一致(需要 sharedUserId 相同)"
            )
        }
        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_FOUND, "目标没在跑")
        }
        val staged = ModuleStore.stageForTarget(context, targetPkg)
            ?: ModuleStore.stageForTargetPrivileged(context, targetPkg)
            ?: return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE,
                "复制不进目标数据目录(权限不足)"
            )

        var last: PtraceInjectResult? = null
        for (pid in pids) {
            val result = PtraceInjector.inject(pid, staged.absolutePath, entry)
            if (result.isSuccess) return result
            last = result
        }
        // 把原生侧的具体原因带出去,界面上直接看得到卡在哪一步
        PtraceInjector.lastDetail?.let { detail ->
            val all = last
            if (all is PtraceInjectResult.Failure) {
                return PtraceInjectResult.Failure(all.kind, detail)
            }
        }
        return last ?: PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN)
    }
}
