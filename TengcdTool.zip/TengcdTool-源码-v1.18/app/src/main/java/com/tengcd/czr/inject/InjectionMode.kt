package com.tengcd.czr.inject

/**
 * 两种注入方式。
 *
 * FRAMEWORK - 框架注入:Xposed/LSPosed 里勾选本应用为模块 + 勾选目标作用域,
 *             目标进程启动时由 HookInit 把模块 so 载进去。
 * PROCESS   - 进程注入:目标已经在跑,用 ptrace 附加进去,远程调 __loader_dlopen 加载 so。
 *             要求两个应用共用同一个 sharedUserId,目标数据目录可访问。
 */
enum class InjectionMode(val value: Int) {
    FRAMEWORK(0),
    PROCESS(1);

    companion object {
        fun from(value: Int): InjectionMode = if (value == PROCESS.value) PROCESS else FRAMEWORK
    }
}
