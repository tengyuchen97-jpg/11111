package com.tengcd.czr.util

import java.io.BufferedReader
import java.io.InputStreamReader

object ShellUtil {

    data class Result(val code: Int, val output: String) {
        val ok: Boolean get() = code == 0
    }

    fun exec(command: String, timeoutMs: Long = 8000L): Result {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val sb = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val deadline = System.currentTimeMillis() + timeoutMs
            reader.use {
                while (System.currentTimeMillis() < deadline) {
                    if (reader.ready()) {
                        val line = reader.readLine() ?: break
                        sb.append(line).append('\n')
                    } else if (!process.isAlive) {
                        break
                    } else {
                        Thread.sleep(20)
                    }
                }
            }
            val code = try {
                process.waitFor()
            } catch (t: Throwable) {
                process.destroy()
                -1
            }
            Result(code, sb.toString())
        } catch (t: Throwable) {
            Result(-1, t.message ?: "exec failed")
        }
    }

    @Volatile
    private var rootCached: Boolean = false

    @Volatile
    private var rootCheckedAt: Long = 0L

    /**
     * 有没有 root。进程注入在没有 root 的情况下,
     * 需要目标允许调试/转储 + 同 uid 才附加得上。
     *
     * 结果缓存 5 秒:一次导入流程要问好几次,别每次都去拉 su(遇到授权框还会卡死)。
     */
    fun hasRoot(): Boolean {
        val now = System.currentTimeMillis()
        if (rootCheckedAt != 0L && now - rootCheckedAt < 5000L) return rootCached
        var result = false
        val probe = Thread {
            try {
                val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
                val out = process.inputStream.bufferedReader().readText()
                process.waitFor()
                result = out.contains("uid=0")
            } catch (t: Throwable) {
                result = false
            }
        }
        probe.isDaemon = true
        probe.start()
        try {
            probe.join(2500L)
        } catch (t: Throwable) {
        }
        rootCached = result
        rootCheckedAt = now
        return result
    }

    /** 用 root 把文件 chmod 到目标可读(有 root 的时候走这条路最省事) */
    fun grantRead(path: String): Boolean {
        if (!hasRoot()) return false
        val r = exec("su -c 'chmod 644 \"$path\" && chcon u:object_r:apk_data_file:s0 \"$path\"'")
        return r.ok
    }

    /** 以 root 身份跑一条命令;没有 root(或 su 被拒)返回 null */
    fun execAsRoot(command: String, timeoutMs: Long = 15000L): Result? {
        if (!hasRoot()) return null
        val quoted = "'" + command.replace("'", "'\\''") + "'"
        val r = exec("su -c $quoted", timeoutMs)
        return if (r.ok) r else null
    }

    /**
     * 特权执行:先 root,再 Shizuku。两个都不可用返回 null。
     * 安卓 12 以上写别的应用的 /Android/data 目录全靠这个。
     */
    fun execPrivileged(context: android.content.Context?, command: String, timeoutMs: Long = 15000L): Result? {
        execAsRoot(command, timeoutMs)?.let { return it }
        if (context != null) {
            ShizukuShell.exec(command, timeoutMs)?.let { return it }
        }
        return null
    }

    /** 当前设备实际可用的最高权限通道 */
    fun privilegeChannel(context: android.content.Context?): String = when {
        hasRoot() -> CHANNEL_ROOT
        context != null && ShizukuShell.granted() -> CHANNEL_SHIZUKU
        else -> CHANNEL_NONE
    }

    const val CHANNEL_ROOT = "root"
    const val CHANNEL_SHIZUKU = "shizuku"
    const val CHANNEL_NONE = "none"
}
