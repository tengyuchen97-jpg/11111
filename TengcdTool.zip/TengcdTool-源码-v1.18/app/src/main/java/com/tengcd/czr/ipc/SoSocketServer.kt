package com.tengcd.czr.ipc

import android.net.LocalServerSocket
import android.net.LocalSocket
import com.tengcd.czr.util.InjectionPrefs
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.concurrent.thread

/**
 * 本地 socket 服务:框架注入时,被 hook 的目标进程起来后会来这儿问
 * "模块 so 在哪、要不要现在载",我们就把路径给它。
 *
 * 指令(一行一条,回一行):
 *   PING            -> OK
 *   GET_SO_PATH     -> /data/.../libhonffx.so
 *   GET_TARGET      -> com.pi.czrxdfirst
 *   REPORT_ACTIVE   -> OK   (目标进程报告模块已加载成功)
 */
object SoSocketServer {

    private const val SOCKET_NAME = "com.tengcd.czr.so.sock"

    @Volatile
    private var running = false
    private var serverSocket: LocalServerSocket? = null

    fun start() {
        if (running) return
        running = true
        thread(name = "honffx-so-server", isDaemon = true) {
            try {
                val server = LocalServerSocket(SOCKET_NAME)
                serverSocket = server
                while (running) {
                    val client = try {
                        server.accept()
                    } catch (t: Throwable) {
                        break
                    }
                    handle(client)
                }
            } catch (t: Throwable) {
                // 名字被占用 / 权限问题:静默退出,不影响主流程
            } finally {
                running = false
                try {
                    serverSocket?.close()
                } catch (t: Throwable) {
                }
                serverSocket = null
            }
        }
    }

    fun stop() {
        running = false
        try {
            serverSocket?.close()
        } catch (t: Throwable) {
        }
    }

    private fun handle(client: LocalSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(client.inputStream))
            val writer = OutputStreamWriter(client.outputStream)
            val line = reader.readLine()?.trim().orEmpty()
            val reply = when (line) {
                "PING" -> "OK"
                "GET_SO_PATH" -> InjectionPrefs.modulePath ?: ""
                "GET_TARGET" -> InjectionPrefs.targetPackage
                "REPORT_ACTIVE" -> {
                    InjectionPrefs.frameworkActive = true
                    "OK"
                }
                else -> "ERR unknown"
            }
            writer.write(reply + "\n")
            writer.flush()
        } catch (t: Throwable) {
        } finally {
            try {
                client.close()
            } catch (t: Throwable) {
            }
        }
    }

    fun request(command: String): String? = try {
        val socket = LocalSocket()
        socket.connect(android.net.LocalSocketAddress(SOCKET_NAME))
        val writer = OutputStreamWriter(socket.outputStream)
        writer.write(command + "\n")
        writer.flush()
        val reader = BufferedReader(InputStreamReader(socket.inputStream))
        val reply = reader.readLine()
        socket.close()
        reply
    } catch (t: Throwable) {
        null
    }
}
