package com.tengcd.czr

enum class ErrorKind {
    NETWORK,
    MODULE,
    INJECT,
    TARGET,
    CARD,
    PERMISSION,
    UNKNOWN
}
