package com.tengcd.czr.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight

/**
 * 公告卡:内容来自 T3 后台的公告接口,断网时显示上次缓存的那份。
 */
@Composable
fun NoticeCard(
    state: UiState,
    s: LocalizedStrings,
    dark: Boolean,
    onAction: (UiAction) -> Unit
) {
    val notice = state.announcement?.trim().orEmpty()
    GlassCard(dark = dark) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader(Icons.Filled.Info, s.announcement, dark)
            Spacer(Modifier.weight(1f))
            if (state.announcementUpdated.isNotBlank()) {
                Text(
                    text = "${s.noticeUpdated} ${state.announcementUpdated}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.width(6.dp))
            }
            TextButton(onClick = { onAction(UiAction.RefreshNotice) }) {
                Text(
                    text = if (state.announcementLoading) s.announcementLoading else s.noticeRefresh,
                    style = MaterialTheme.typography.labelMedium,
                    color = AccentBlue
                )
            }
        }

        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            when {
                notice.isNotBlank() -> Text(
                    text = notice,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )

                state.announcementLoading -> Text(
                    text = s.announcementLoading,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )

                state.announcementFailed -> Text(
                    text = s.announcementFailed,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )

                else -> Text(
                    text = s.announcementEmpty,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
            }
        }
    }
}
