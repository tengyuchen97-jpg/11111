package com.tengcd.czr.xposed

import android.content.Context
import com.tengcd.czr.util.ShellUtil

/**
 * 判断设备上有没有 Xposed 系框架(原版 / EdXposed / LSPosed 都算)。
 * 只有装了框架,框架注入那条路才谈得上。
 */
object XposedDetector {

    private val FRAMEWORK_PACKAGES = listOf(
        "de.robv.android.xposed.installer",
        "org.lsposed.manager",
        "org.meowcat.edxposed.manager",
        "com.solohsu.android.edxp.manager",
        "io.github.lsposed.manager"
    )

    fun isFrameworkInstalled(context: Context): Boolean {
        val pm = context.packageManager
        for (pkg in FRAMEWORK_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return true
            } catch (t: Throwable) {
            }
        }
        // 有些设备管理器被隐藏或改名了,再从进程/目录上兜一次
        if (ShellUtil.exec("ls /data/adb/lspd 2>/dev/null").output.isNotBlank()) return true
        if (ShellUtil.exec("ls /data/adb/modules 2>/dev/null | grep -i -E 'xposed|riru|lsposed'").output.isNotBlank()) return true
        return false
    }

    fun frameworkName(context: Context): String? {
        val pm = context.packageManager
        for (pkg in FRAMEWORK_PACKAGES) {
            try {
                val info = pm.getPackageInfo(pkg, 0)
                return info.applicationInfo?.loadLabel(pm)?.toString() ?: pkg
            } catch (t: Throwable) {
            }
        }
        return null
    }
}
