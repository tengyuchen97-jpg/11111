package com.tengcd.czr.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight

/** 玻璃弹窗:标题 + 正文 + 1~2 个按钮 */
@Composable
fun LiquidGlassDialog(
    dark: Boolean,
    title: String,
    message: String,
    confirmText: String,
    cancelText: String? = null,
    /** true = 强制框(公告式更新框):点外面 / 按返回都关不掉,只能点按钮 */
    forced: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = { if (!forced) onDismiss() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = !forced,
            dismissOnClickOutside = !forced
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .liquidGlass(dark, 26)
                .padding(20.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = if (dark) TextPrimaryDark else TextPrimaryLight
            )
            if (message.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                // 正文可能很长(更新日志一大段),限个高度让它自己滚,别把按钮顶出屏幕
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                PrimaryActionButton(
                    text = confirmText,
                    icon = null,
                    enabled = true,
                    dark = dark,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onConfirm
                )
                // 取消按钮:比主按钮小一号,单独放主按钮下面,居中
                if (cancelText != null) {
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text(
                                text = cancelText,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (dark) TextSecondaryDark else TextSecondaryLight
                            )
                        }
                    }
                }
            }
        }
    }
}

/** 圆形加载指示 */
@Composable
fun LoadingSpinner(size: Int = 18, stroke: Int = 2) {
    CircularProgressIndicator(
        modifier = Modifier.size(size.dp),
        color = AccentBlue,
        strokeWidth = stroke.dp
    )
}

/** 下载进度弹窗 */
@Composable
fun DownloadProgressDialog(
    dark: Boolean,
    title: String,
    message: String,
    progress: Float,
    indeterminate: Boolean = false
) {
    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .liquidGlass(dark, 24)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LoadingSpinner(size = 16, stroke = 2)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
            }
            Spacer(Modifier.height(12.dp))
            if (indeterminate) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    LoadingSpinner(size = 22, stroke = 3)
                }
            } else {
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }
    }
}
