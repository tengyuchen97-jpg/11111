package com.tengcd.czr

import android.app.Application
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.ipc.SoSocketServer
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.ServiceState

class HonffxApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        InjectionPrefs.init(this)
        ServiceState.syncFromPrefs()
        // 有内置模块就先落位一份,免得第一次进来啥都点不动
        ModuleStore.ensureBundled(this)
        // 本地 socket 服务常驻:目标进程随时能来问模块路径
        SoSocketServer.start()
    }

    companion object {
        lateinit var instance: HonffxApplication
            private set
    }
}
