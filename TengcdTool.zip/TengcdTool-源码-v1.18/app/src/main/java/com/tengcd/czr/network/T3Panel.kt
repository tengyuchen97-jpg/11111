package com.tengcd.czr.network

import java.util.Base64

/**
 * T3 网络验证的后台参数 + 编解码。
 *
 * 官方协议(与 T3 官方 SDK 一致):
 *   1. 接口地址 = 验证服务器 + "/" + 该接口的 VIP 调用码,例如
 *      https://w.t3yanzheng.com/47D4910970418F2E
 *   2. 每个参数的**值**先做自定义 Base64 编码,再转成 HEX 十六进制字符串;
 *   3. 签名 s = HEX(自定义Base64(md5("k=已编码值&k=已编码值&" + appkey)));
 *   4. 表单 POST 提交,返回内容用自定义 Base64 解码后就是 JSON。
 */
object T3Panel {

    /**
     * 主力验证服务器(客户端写死,界面上不提供修改入口)。
     *
     * ⚠️ 2026-10-19 改:后台「api 接口开放平台」页面上,这个账号的接口地址是
     *   http://w.13yanyheng.com/调用码
     * 而不是官方的 https://w.t3yanzheng.com/调用码。
     * 官方域名对部分网络(尤其挂 VPN 的手机)会返回一个网页/空响应,表现就是
     * 「HTTP200 但读不到版本号」——请求确实到了,回来的不是业务 JSON。
     * 所以这里以后台给的这个域名为准,官方那几个域名降为备用(T3Client 里会一起试)。
     */
    const val SERVER = "http://w.13yanyheng.com"

    /** 接口加密验证 APPKEY */
    const val APPKEY = "f736fd5efeb7a9ab1b6bdfcc7b364a78"

    /** Base64 自定义编码集(后台「Base64算法编码集」,必须是 64 位) */
    const val B64_CHARSET =
        "kXcZ3OBKtPVsR5w1Fdmjl2GLg4SYfNhrUWopiI6+z/TnvbauQeCy9Aq8HMJ70DEx"

    /** 标准 Base64 字符表,后台如果没自定义编码集就是这个 */
    const val STANDARD_B64 =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    /** RC4 加解密密钥 */
    const val RC4_KEY = "7lo18aX1QialEA5"

    /** 登录状态码有效期(秒) */
    const val TTL = 3600L

    // 各接口的 VIP 调用码
    /**
     * 客户端版本号(更新检测用)。
     *
     * ⚠️ 这是"本机版本"的唯一来源,和 build.gradle.kts 里的 versionName 保持一致。
     * 以前检测更新读 BuildConfig.VERSION_NAME,AIDE 有时不重新生成 BuildConfig,
     * 改了版本号还是读旧值 -> 后台改了号也不弹 / 改完的包又一直弹。
     * 现在统一读这里:发新版只改这一行 + gradle 里的 versionName 两处。
     *
     * 现在刻意填 1.0:后台挂的是 1.1,客户端号比后台低才会走「有新版本」。
     * 以前填 1.13.0(比后台高),检查更新会认定「后台比本机老」直接压掉,所以怎么点都不弹。
     */
    const val APP_VERSION = "1.1"

    /**
     * 后台版本号兜底(平时留空)。
     *
     * 「检测版本」「获取最新版序号」两个接口都读不到号的时候(接口被关、后台没填、
     * 网络被墙),就用这里填的号顶上,免得界面上永远只有一句「没读到后台版本号」。
     * 想强制全员更新又一时改不了后台,就把这里填成目标版本号。
     */
    const val FALLBACK_REMOTE_VERSION = "1.1"

    /**
     * 下载地址兜底(平时留空 = 用官方群)。
     *
     * 后台「检测版本」接口的 upurl 字段常常是空的,一空界面上就会出现
     * 「后台还没配下载地址」+ 一个点了没反应的按钮。填上这里(或者后台填上),
     * 弹窗的「立即更新」就能直接下包;两处都没填就自动退回官方群拿新版。
     */
    const val FALLBACK_DOWNLOAD_URL = ""

    const val CODE_LOGIN = "47D4910970418F2E"      // 单码卡密登录
    const val CODE_HEARTBEAT = "9542275815E7B7CE"  // 单码卡密心跳
    const val CODE_NOTICE = "3C223920FC8D1028"     // 获取程序公告
    const val CODE_LATEST = "32BAF86A30D5CC25"     // 获取最新版序号
    const val CODE_CHECK_VER = "FAE896FF9D204BEE"  // 检测版本是否最新版
    const val CODE_UNBIND = "0CAD0675444DC587"     // 解绑或换绑机器码(后台接口详情给的)

    /**
     * 「获取卡密状态信息」接口的 VIP 调用码(后台 → 接口管理 → 获取卡密状态信息)。
     * 入参只有 kami(单码卡密),返回该卡的可用量(available)/卡类型(amount)/到期时间。
     * 登录接口对计次卡不认的时候,以这个接口的结果为准。
     */
    const val CODE_QUERY_CARD = "D5067AFE7BE1F019"

    /**
     * 「获取在线卡密数量」接口的 VIP 调用码(后台 → 接口管理 → 获取在线卡密数量)。
     * 无入参,返回 {"code":200,"msg":"当前在线数"},数字在 msg 里。
     */
    const val CODE_ONLINE = "1BA9FB48989357C7"

    /** 接口参数名(后台接口详情里定义的) */
    const val P_CARD = "kami"
    const val P_DEVICE = "imei"
    const val P_STATE = "statecode"
    const val P_VER = "ver"

    fun codeOf(action: String): String = when (action) {
        "login" -> CODE_LOGIN
        "heartbeat" -> CODE_HEARTBEAT
        "notice" -> CODE_NOTICE
        "latest" -> CODE_LATEST
        "checkver" -> CODE_CHECK_VER
        "unbind" -> CODE_UNBIND
        "query" -> CODE_LOGIN
        "querycard" -> CODE_QUERY_CARD.ifBlank { CODE_LOGIN }
        "online" -> CODE_ONLINE
        else -> CODE_LOGIN
    }

    /** 编码集必须 64 个互不相同的字符,否则映射一定是错的 */
    fun usableCharset(charset: String): Boolean {
        val cs = charset.trim()
        return cs.length == 64 && cs.toSet().size == 64
    }

    // ---------------- 自定义 Base64 ----------------

    /** 标准 Base64 -> 自定义编码集 */
    fun encodeText(text: String, charset: String): String {
        val cs = if (usableCharset(charset)) charset.trim() else STANDARD_B64
        val std = Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(std.length)
        for (c in std) {
            val idx = STANDARD_B64.indexOf(c)
            sb.append(if (idx >= 0) cs[idx] else c)
        }
        return sb.toString()
    }

    /** 自定义编码集 -> 标准 Base64 -> 原文 */
    fun decodeText(text: String, charset: String): String? {
        val cs = if (usableCharset(charset)) charset.trim() else STANDARD_B64
        val clean = text.trim().trim('"').replace("\r", "").replace("\n", "").replace(" ", "")
        if (clean.isEmpty()) return null
        val sb = StringBuilder(clean.length)
        for (c in clean) {
            val idx = cs.indexOf(c)
            sb.append(if (idx >= 0) STANDARD_B64[idx] else c)
        }
        return try {
            String(Base64.getMimeDecoder().decode(sb.toString()), Charsets.UTF_8)
        } catch (t: Throwable) {
            null
        }
    }

    /** 参数值编码:自定义 Base64 之后再转 HEX(官方 SDK 的 base64 模式) */
    fun encodeValue(value: String, charset: String): String =
        encodeText(value, charset).toByteArray(Charsets.UTF_8).joinToString("") {
            "%02x".format(it.toInt() and 0xFF)
        }

    // ---------------- RC4 ----------------

    fun rc4(data: ByteArray): ByteArray = rc4(RC4_KEY.toByteArray(Charsets.UTF_8), data)

    fun rc4(key: ByteArray, data: ByteArray): ByteArray {
        val s = IntArray(256) { it }
        var j = 0
        for (i in 0 until 256) {
            j = (j + s[i] + (key[i % key.size].toInt() and 0xFF)) and 0xFF
            val tmp = s[i]; s[i] = s[j]; s[j] = tmp
        }
        val out = ByteArray(data.size)
        var i = 0; j = 0
        for (k in data.indices) {
            i = (i + 1) and 0xFF
            j = (j + s[i]) and 0xFF
            val tmp = s[i]; s[i] = s[j]; s[j] = tmp
            out[k] = (data[k].toInt() xor s[(s[i] + s[j]) and 0xFF]).toByte()
        }
        return out
    }

    /**
     * 解析服务端返回:依次尝试
     *   自定义 Base64 -> 直接明文 -> 自定义 Base64 后 RC4 -> 标准 Base64 -> 标准 Base64 后 RC4
     */
    fun decodePayload(raw: String, charset: String): String? {
        val text = raw.trim().trim('"')
        if (text.isEmpty()) return null
        if (text.startsWith("{") || text.startsWith("[")) return text

        val plain = decodeText(text, charset)
        if (plain != null) {
            val p = plain.trim()
            if (p.startsWith("{") || p.contains("=")) return p
            val un = String(rc4(plain.toByteArray(Charsets.UTF_8)), Charsets.UTF_8).trim()
            if (un.startsWith("{") || un.contains("=")) return un
        }
        val stdPlain = decodeText(text, STANDARD_B64)
        if (stdPlain != null) {
            val p = stdPlain.trim()
            if (p.startsWith("{") || p.contains("=")) return p
            val un = String(rc4(stdPlain.toByteArray(Charsets.UTF_8)), Charsets.UTF_8).trim()
            if (un.startsWith("{") || un.contains("=")) return un
        }
        return null
    }
}
