package com.tengcd.czr.network

/**
 * 卡密查询结果。本地校验模式下由 LocalCardGate 直接构造同名对象。
 *
 * 次数用可空表示:null = 服务端这次没返回这一项(界面上显示「未返回」),
 * -1 = 服务端明确说这张卡不限次数,>=0 = 具体剩多少次。
 */
data class CardQueryInfo(
    val card: String = "",
    val expireTime: String = "",
    val remainCount: Int? = null,
    val unbindCount: Int? = null,
    /** 在线人数:后台没配在线统计接口就是 null,界面上不显示这一行 */
    val onlineCount: Int? = null,
    /** 卡类型:1年 / 30天 / 100次 */
    val cardType: String = "",
    /** 计次卡:没有到期时间,只有剩余次数 */
    val isCountCard: Boolean = false,
    val boundDevice: String = "",
    val banned: Boolean = false,
    val valid: Boolean = true,
    val message: String = ""
)
