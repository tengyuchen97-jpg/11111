package com.tengcd.czr.network

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 本地卡密校验。
 *
 * 卡密不想联网校验的时候用这个:把卡密写死在本地(或写进手机的
 * /sdcard/Download/honffx_card.txt),输入对得上就直接放行,
 * 到期时间/剩余次数也由本地给。
 *
 * 格式:/sdcard/Download/card_list.txt
 *   HONFFX-AAAA-BBBB|2026-12-31|-1|3
 *   └ 卡密 | 到期时间 | 剩余次数(-1=不限) | 解绑次数
 */
object LocalCardGate {

    private const val EXTERNAL_CARD_FILE = "/sdcard/Download/card_list.txt"

    /**
     * 机器码(后台口子里的 imei)。
     *
     * ⚠️ 只跟「这台设备」绑定,绝对不能拼目标包名:
     * 以前是 md5(ANDROID_ID + "|" + 目标包名),用户在注入页选完目标应用 / 换一个目标应用,
     * 算出来的机器码就变了,后台一看"设备换了"直接回「请在原设备登录」——
     * 表现就是"卡密一开始能用,选完目标就用不了了 / 怎么输都进不去"。
     *
     * 现在只取 ANDROID_ID(取不到就用 Build 指纹兜底),装哪个版本、选哪个目标、换 SO 都不会变。
     * 同一台手机永远是同一串,后台绑一次就够。
     */
    /** 稳定算法:只跟设备绑定,选目标 / 换版本都不变 */
    private fun stableDeviceId(context: Context): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        } catch (t: Throwable) {
            ""
        }
        val good = androidId.isNotBlank() && !androidId.equals("9774d56d682e549c", true)
        val raw = if (good) {
            "tengcd|" + androidId.trim()
        } else {
            // 极少数系统 ANDROID_ID 拿不到 / 是个固定假值时,用 Build 指纹顶上
            "tengcd|" + Build.MODEL + "|" + Build.BRAND + "|" + Build.DEVICE + "|" + Build.ID
        }
        return Md5Util.md5(raw).take(16).uppercase(Locale.US)
    }

    /** 实际发给后台的机器码:验证通过过的那串优先,没有就用稳定算法 */
    fun deviceId(context: Context): String {
        val stored = InjectionPrefs.t3MachineCode
        if (stored.isNotBlank()) return stored
        return stableDeviceId(context)
    }

    /** 老版本算法(固定形式,给已绑定的老卡兜底):md5(ANDROID_ID + "|" + 包名) */
    private fun legacyId(context: Context, pkg: String): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        } catch (t: Throwable) {
            ""
        }
        return Md5Util.md5(androidId + "|" + pkg).take(16).uppercase(Locale.US)
    }

    /** 机器码的备用算法:老版本拼过目标包名,这串只在对账/查老卡时用得上 */
    fun legacyDeviceId(context: Context): String = legacyId(context, InjectionPrefs.targetPackage)

    /**
     * 登录时要挨个试的机器码。
     *
     * 老版本机器码里拼了「目标包名」,后台那边已经把卡绑在了老算法算出来的那串上;
     * 升级后如果只拿新算法去登录,后台统一判「请在原设备登录」,卡密看着就是坏的。
     * 所以这里全列出来,谁通就记谁,记下来之后所有请求都用同一串,不会再漂。
     */
    fun deviceCandidates(context: Context): List<String> {
        val out = ArrayList<String>()
        val stored = InjectionPrefs.t3MachineCode
        if (stored.isNotBlank()) out.add(stored)
        // 老卡最可能绑的是「还没选目标应用」时算的那串
        out.add(legacyId(context, ""))
        val cur = InjectionPrefs.targetPackage
        if (cur.isNotBlank()) out.add(legacyId(context, cur))
        out.add(stableDeviceId(context))
        return out.distinct()
    }

    fun query(context: Context, card: String): CardQueryInfo {
        val trimmed = card.trim()
        if (trimmed.isEmpty()) {
            return CardQueryInfo(card = trimmed, valid = false, message = "empty")
        }
        val entry = loadEntries().firstOrNull { it.card.equals(trimmed, ignoreCase = true) }
            ?: return CardQueryInfo(card = trimmed, valid = false, message = "invalid")

        val expired = isExpired(entry.expireTime)
        val exhausted = entry.remainCount == 0
        return CardQueryInfo(
            card = entry.card,
            expireTime = entry.expireTime,
            remainCount = entry.remainCount,
            unbindCount = entry.unbindCount,
            boundDevice = InjectionPrefs.boundDevice ?: deviceId(context),
            banned = false,
            valid = !(expired || exhausted),
            message = when {
                expired -> "expired"
                exhausted -> "count_exhausted"
                else -> "ok"
            }
        )
    }

    /** 本地模式下"绑定设备"就是记一下首次使用的设备号 */
    fun bind(context: Context, card: String): Boolean {
        val info = query(context, card)
        if (!info.valid) return false
        if (InjectionPrefs.boundDevice == null) {
            InjectionPrefs.boundDevice = deviceId(context)
        }
        InjectionPrefs.cardKey = card.trim()
        return true
    }

    fun unbind(context: Context, card: String): Boolean {
        val info = query(context, card)
        if (!info.valid) return false
        InjectionPrefs.boundDevice = null
        return true
    }

    private fun isExpired(expireTime: String): Boolean {
        if (expireTime.isBlank() || expireTime == "-1" || expireTime.contains("永久")) return false
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = fmt.parse(expireTime.trim()) ?: return false
            date.before(Date())
        } catch (t: Throwable) {
            false
        }
    }

    private data class Entry(
        val card: String,
        val expireTime: String,
        val remainCount: Int,
        val unbindCount: Int
    )

    /**
     * 内置卡密。改卡密直接改这里(或者往 /sdcard/Download/card_list.txt 里加,
     * 那样不用重新打包)。
     */
    private val BUILT_IN = listOf(
        Entry("遄懂666", "永久", -1, 3),
        Entry("W1ACDB170ECFDC8337ED7242B5FDB559", "永久", -1, 3)
    )

    private fun loadEntries(): List<Entry> {
        val list = ArrayList<Entry>(BUILT_IN)
        // 1. 偏好里内置的几张
        InjectionPrefs.localCard.split(',').forEach { item ->
            val c = item.trim()
            if (c.isNotEmpty()) list.add(Entry(c, "永久", -1, 3))
        }
        // 2. 外部文件(方便不重新打包就换卡)
        try {
            val f = java.io.File(EXTERNAL_CARD_FILE)
            if (f.isFile) {
                f.readLines().forEach { line ->
                    val text = line.trim()
                    if (text.isEmpty() || text.startsWith("#")) return@forEach
                    val parts = text.split('|')
                    val card = parts.getOrNull(0)?.trim().orEmpty()
                    if (card.isEmpty()) return@forEach
                    list.add(
                        Entry(
                            card = card,
                            expireTime = parts.getOrNull(1)?.trim().orEmpty().ifEmpty { "永久" },
                            remainCount = parts.getOrNull(2)?.trim()?.toIntOrNull() ?: -1,
                            unbindCount = parts.getOrNull(3)?.trim()?.toIntOrNull() ?: 3
                        )
                    )
                }
            }
        } catch (t: Throwable) {
        }
        return list
    }
}
