package com.tengcd.czr.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.util.InjectionPrefs

/**
 * 交接唤醒:目标应用起来之后,由框架模块 / 外部调用发一条广播过来,
 * 我们立刻把注入服务拉起来干活。
 */
class HandoffWakeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        InjectionPrefs.init(context)
        val mode = InjectionMode.from(intent?.getIntExtra(InjectService.EXTRA_MODE, 0) ?: 0)
        val target = intent?.getStringExtra(InjectService.EXTRA_TARGET) ?: InjectionPrefs.targetPackage
        InjectService.inject(context, mode, target)
    }

    companion object {
        const val ACTION_START_HANDOFF = "com.tengcd.czr.action.START_HANDOFF"

        fun send(context: Context, mode: InjectionMode, target: String) {
            val intent = Intent(ACTION_START_HANDOFF).apply {
                setPackage(context.packageName)
                putExtra(InjectService.EXTRA_MODE, mode.value)
                putExtra(InjectService.EXTRA_TARGET, target)
            }
            context.sendBroadcast(intent)
        }
    }
}
