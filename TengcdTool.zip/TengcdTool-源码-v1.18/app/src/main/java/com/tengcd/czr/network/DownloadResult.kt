package com.tengcd.czr.network

import java.io.File

data class DownloadResult(
    val ok: Boolean,
    val file: File? = null,
    val md5: String? = null,
    val message: String = ""
)
