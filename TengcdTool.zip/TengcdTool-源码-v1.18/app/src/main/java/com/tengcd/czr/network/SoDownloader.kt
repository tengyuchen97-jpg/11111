package com.tengcd.czr.network

import android.content.Context
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 模块下载 + 校验 + 落位。下载先写 .download 临时文件,
 * md5 对得上才替换正式文件;对不上就保留原文件(和界面提示一致)。
 */
object SoDownloader {

    suspend fun download(
        context: Context,
        config: RemoteConfig,
        onProgress: (Long, Long) -> Unit = { _, _ -> }
    ): DownloadResult = withContext(Dispatchers.IO) {
        if (config.soUrl.isBlank()) {
            return@withContext DownloadResult(false, message = "missing_url")
        }
        val tmpFile = File(context.cacheDir, "module_download.so")
        val result = NetworkClient.download(config.soUrl, tmpFile, onProgress)
        if (!result.ok || result.file == null) {
            return@withContext DownloadResult(false, message = result.message)
        }
        if (config.soMd5.isNotBlank()) {
            val actual = Md5Util.md5(tmpFile)
            if (!actual.equals(config.soMd5, ignoreCase = true)) {
                tmpFile.delete()
                return@withContext DownloadResult(false, message = "md5_mismatch")
            }
        }
        val dest = ModuleStore.remoteFile(context)
        val ok = Md5Util.copyWithVerify(tmpFile, dest, Md5Util.md5(tmpFile))
        tmpFile.delete()
        if (!ok) return@withContext DownloadResult(false, message = "write_failed")

        InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_REMOTE
        InjectionPrefs.modulePath = dest.absolutePath
        InjectionPrefs.moduleVersion = config.version
        InjectionPrefs.moduleMd5 = Md5Util.md5(dest)
        ModuleStore.writeHandoff(context, dest.absolutePath, InjectionPrefs.targetPackage)
        DownloadResult(true, dest, InjectionPrefs.moduleMd5, "ok")
    }
}
