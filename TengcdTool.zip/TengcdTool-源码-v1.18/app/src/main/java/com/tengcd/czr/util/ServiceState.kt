package com.tengcd.czr.util

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * 跨组件共享的运行态:注入服务在跑没有、框架模块在目标里激活没有。
 * Provider(被目标进程调用)、Service、ViewModel 都读写这里。
 */
object ServiceState {

    val serviceRunning = MutableStateFlow(false)
    val frameworkActive = MutableStateFlow(false)
    val lastInjectOk = MutableStateFlow<Boolean?>(null)
    val lastInjectDetail = MutableStateFlow<String?>(null)

    fun onReportedActive() {
        frameworkActive.value = true
        InjectionPrefs.frameworkActive = true
    }

    fun syncFromPrefs() {
        frameworkActive.value = InjectionPrefs.frameworkActive
    }
}
