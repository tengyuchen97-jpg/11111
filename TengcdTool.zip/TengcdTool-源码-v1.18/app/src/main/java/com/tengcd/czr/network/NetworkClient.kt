package com.tengcd.czr.network

import com.tengcd.czr.util.InjectionPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object NetworkClient {

    private const val UA = "HonffxTool/0.1 (Android)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /** 拉配置。configUrl 可以在偏好设置里改,也支持本地文件覆盖 */
    suspend fun fetchConfig(url: String): PublicApiResult = withContext(Dispatchers.IO) {
        // 先看本地有没有放配置文件(调试用)
        val local = File("/sdcard/Download/honffx_config.json")
        if (local.isFile) {
            return@withContext PublicApiResult(true, "local", local.readText())
        }
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                PublicApiResult(response.isSuccessful, response.code.toString(), body)
            }
        } catch (t: Throwable) {
            PublicApiResult(false, t.message ?: "network_error")
        }
    }

    suspend fun download(
        url: String,
        dest: File,
        onProgress: (downloaded: Long, total: Long) -> Unit = { _, _ -> }
    ): DownloadResult = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext DownloadResult(false, message = "http ${response.code}")
                }
                val body = response.body ?: return@withContext DownloadResult(false, message = "empty")
                val total = body.contentLength()
                dest.parentFile?.mkdirs()
                val tmp = File(dest.parentFile, dest.name + ".download")
                body.byteStream().use { input ->
                    tmp.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n <= 0) break
                            output.write(buf, 0, n)
                            done += n
                            onProgress(done, total)
                        }
                    }
                }
                if (total > 0 && tmp.length() != total) {
                    tmp.delete()
                    return@withContext DownloadResult(false, message = "length_mismatch")
                }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) {
                    tmp.delete()
                    return@withContext DownloadResult(false, message = "rename_failed")
                }
                DownloadResult(true, dest, message = "ok")
            }
        } catch (t: Throwable) {
            DownloadResult(false, message = t.message ?: "download_error")
        }
    }

    /** 卡密查询(远端模式用) */
    suspend fun queryCard(baseUrl: String, card: String, deviceId: String): PublicApiResult =
        post("$baseUrl/card/query", card, deviceId)

    /** 卡密解绑设备 */
    suspend fun unbindCard(baseUrl: String, card: String, deviceId: String): PublicApiResult =
        post("$baseUrl/card/unbind", card, deviceId)

    private suspend fun post(url: String, card: String, deviceId: String): PublicApiResult =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject()
                    .put("card", card)
                    .put("device", deviceId)
                    .put("package", InjectionPrefs.targetPackage)
                    .toString()
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", UA)
                    .post(payload.toRequestBody(jsonMedia))
                    .build()
                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    PublicApiResult(response.isSuccessful, response.code.toString(), body)
                }
            } catch (t: Throwable) {
                PublicApiResult(false, t.message ?: "network_error")
            }
        }
}
