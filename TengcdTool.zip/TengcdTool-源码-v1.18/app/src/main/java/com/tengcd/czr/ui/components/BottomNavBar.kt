package com.tengcd.czr.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.NavPillDark
import com.tengcd.czr.ui.theme.NavPillLight
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily

/** 一个导航项:图标 + 手写体文字 */
data class NavEntry(
    val label: String,
    val icon: ImageVector,
    val selected: Boolean,
    val onClick: () -> Unit
)

/**
 * 底部悬浮导航(和参考图一致的那种胶囊)。
 *
 * 整条是一个浮在上面的玻璃胶囊:两头全圆、半透明白色、细描边,
 * 里面每一项都撑满高度,选中的那一项自己再垫一块浅色胶囊(图标和文字一起包住),
 * 图标 + 文字变蓝;没选中的图标和文字接近黑色,不垫底。
 */
@Composable
fun BottomNavBar(
    dark: Boolean,
    entries: List<NavEntry>,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(62.dp)
            .liquidGlass(dark, 31)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        entries.forEach { entry ->
            NavItem(entry = entry, dark = dark)
        }
    }
}

@Composable
private fun RowScope.NavItem(entry: NavEntry, dark: Boolean) {
    val activeColor = AccentBlue
    // 未选中:浅色主题下几乎是黑字(跟参考图一致),深色主题下用亮白
    val idleColor = if (dark) TextPrimaryDark else Color(0xFF16151C)
    val pillColor = if (dark) NavPillDark else NavPillLight

    Column(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clip(RoundedCornerShape(24.dp))
            .background(if (entry.selected) pillColor else Color.Transparent)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { entry.onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = entry.icon,
            contentDescription = entry.label,
            tint = if (entry.selected) activeColor else idleColor,
            modifier = Modifier.size(20.dp)
        )

        Spacer(Modifier.height(3.dp))

        Text(
            text = entry.label,
            style = TextStyle(
                fontFamily = TitleFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                lineHeight = 13.sp
            ),
            color = if (entry.selected) activeColor else idleColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
