package com.tengcd.czr.inject

sealed class PtraceInjectResult {

    data class Success(
        val pid: Int,
        val soPath: String,
        val detail: String? = null
    ) : PtraceInjectResult()

    data class Failure(
        val kind: PtraceInjectFailure,
        val detail: String? = null
    ) : PtraceInjectResult()

    val isSuccess: Boolean get() = this is Success

    companion object {
        fun fromCode(code: Int, pid: Int, soPath: String, detail: String? = null): PtraceInjectResult =
            if (code == PtraceInjectFailure.NONE.code) {
                Success(pid, soPath, detail)
            } else {
                Failure(PtraceInjectFailure.fromCode(code), detail)
            }
    }
}
