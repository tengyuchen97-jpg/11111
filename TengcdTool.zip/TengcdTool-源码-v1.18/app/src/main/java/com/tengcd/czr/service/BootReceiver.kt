package com.tengcd.czr.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tengcd.czr.util.InjectionPrefs

/**
 * 开机自启:开了"保持模块加载服务运行"才会拉起服务。
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON" &&
            action != "com.htc.intent.action.QUICKBOOT_POWERON" &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }
        InjectionPrefs.init(context)
        if (!InjectionPrefs.bootAutoStart) return
        try {
            InjectService.start(context)
        } catch (t: Throwable) {
        }
    }
}
