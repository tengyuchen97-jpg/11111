package com.tengcd.czr.network

import org.json.JSONObject

/**
 * 配置解析。兼容两种返回:
 *  - 直接就是配置对象 {...}
 *  - 外面包了一层 {code:0, data:{...}}
 */
object ConfigParser {

    fun parse(body: String): RemoteConfig? {
        return try {
            var json = JSONObject(body.trim())
            if (json.has("data") && json.optJSONObject("data") != null) {
                json = json.optJSONObject("data")!!
            }
            RemoteConfig(
                version = json.optString("version", json.optString("remote_version", "")),
                soUrl = json.optString("so_url", json.optString("url", "")),
                soMd5 = json.optString("md5", json.optString("so_md5", "")),
                announcement = json.optString("announcement", json.optString("notice", "")),
                targetPackage = json.optString("target_package", json.optString("package", "")),
                forceUpdate = json.optBoolean("force_update", false),
                updateLog = json.optString("update_log", "")
            )
        } catch (t: Throwable) {
            null
        }
    }
}
