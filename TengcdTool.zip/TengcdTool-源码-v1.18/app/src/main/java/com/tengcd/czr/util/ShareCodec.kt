package com.tengcd.czr.util

import android.util.Base64

/**
 * 分享码:把 so 路径 + 目标包名 + 卡密码成一段字符串,
 * 方便在两个设备/两个应用之间传配置。
 */
object ShareCodec {

    private val KEY = byteArrayOf(0x48, 0x6F, 0x6E, 0x66, 0x78, 0x54, 0x6F, 0x6F, 0x6C, 0x23, 0x32, 0x30, 0x32, 0x34)

    fun encode(plain: String): String {
        val raw = plain.toByteArray(Charsets.UTF_8)
        val out = ByteArray(raw.size)
        for (i in raw.indices) {
            out[i] = (raw[i].toInt() xor KEY[i % KEY.size].toInt()).toByte()
        }
        return Base64.encodeToString(out, Base64.URL_SAFE or Base64.NO_WRAP)
    }

    fun decode(code: String): String? = try {
        val raw = Base64.decode(code.trim(), Base64.URL_SAFE or Base64.NO_WRAP)
        val out = ByteArray(raw.size)
        for (i in raw.indices) {
            out[i] = (raw[i].toInt() xor KEY[i % KEY.size].toInt()).toByte()
        }
        String(out, Charsets.UTF_8)
    } catch (t: Throwable) {
        null
    }
}
