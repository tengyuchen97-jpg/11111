package com.tengcd.czr.network

/**
 * 服务端下发的配置。字段名跟服务端 JSON 对齐,
 * 你改服务端就在 ConfigParser 里跟着改。
 */
data class RemoteConfig(
    val version: String = "",
    val soUrl: String = "",
    val soMd5: String = "",
    val announcement: String = "",
    val targetPackage: String = "",
    val forceUpdate: Boolean = false,
    val updateLog: String = ""
)
