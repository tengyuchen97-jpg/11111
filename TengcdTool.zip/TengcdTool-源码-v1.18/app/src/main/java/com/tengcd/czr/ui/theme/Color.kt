package com.tengcd.czr.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** 背景渐变:浅色是粉紫奶黄,深色是暗夜紫 */
val LightGradientTop = Color(0xFFFFE7F1)
val LightGradientMid = Color(0xFFE8E3FF)
val LightGradientBottom = Color(0xFFFFF7DE)

val DarkGradientTop = Color(0xFF171426)
val DarkGradientMid = Color(0xFF1B1730)
val DarkGradientBottom = Color(0xFF120F1C)

val AccentBlue = Color(0xFF2E7BFF)
val AccentViolet = Color(0xFF7C4DFF)
val AccentPink = Color(0xFFFF6FA5)

val TextPrimaryLight = Color(0xFF1C1B22)
val TextSecondaryLight = Color(0xFF6B6880)
val TextPrimaryDark = Color(0xFFF3F1FA)
val TextSecondaryDark = Color(0xFFA8A3C0)

val GlassBorderLight = Color(0x99FFFFFF)
val GlassBorderDark = Color(0x33FFFFFF)
val GlassFillLight = Color(0x8CFFFFFF)
val GlassFillDark = Color(0x1AFFFFFF)

/** 底部导航选中项那块浅色垫底:浅色主题是带一点绿调的灰白,深色主题用低透明度蓝 */
val NavPillLight = Color(0xFFDDE3D6)
val NavPillDark = Color(0x332E7BFF)

val OkGreen = Color(0xFF2FBF71)
val WarnOrange = Color(0xFFFF9F43)
val ErrRed = Color(0xFFFF5A5F)

fun appBackgroundBrush(dark: Boolean): Brush = Brush.verticalGradient(
    colors = if (dark) {
        listOf(DarkGradientTop, DarkGradientMid, DarkGradientBottom)
    } else {
        listOf(LightGradientTop, LightGradientMid, LightGradientBottom)
    }
)
