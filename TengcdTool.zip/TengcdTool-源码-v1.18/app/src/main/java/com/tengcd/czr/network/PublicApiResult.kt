package com.tengcd.czr.network

data class PublicApiResult(
    val ok: Boolean,
    val message: String = "",
    val body: String = ""
)
