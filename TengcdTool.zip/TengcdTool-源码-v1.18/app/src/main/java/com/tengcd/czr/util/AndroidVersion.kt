package com.tengcd.czr.util

import android.os.Build

/**
 * 系统版本显示。
 *
 * 以前界面直接把 Build.VERSION.SDK_INT 当"安卓版本"显示了,
 * 于是安卓 15 会被写成 "Android 35" —— 那是 API 等级,不是版本号。
 * 这里把 API 等级翻译成真正的版本名。
 */
object AndroidVersion {

    /** API 等级 -> 版本名(例如 35 -> 15) */
    fun name(sdk: Int): String = when (sdk) {
        1 -> "1.0"
        2 -> "1.1"
        3 -> "1.5"
        4 -> "1.6"
        5 -> "2.0"
        6 -> "2.0.1"
        7 -> "2.1"
        8 -> "2.2"
        9 -> "2.3"
        10 -> "2.3.3"
        11 -> "3.0"
        12 -> "3.1"
        13 -> "3.2"
        14 -> "4.0"
        15 -> "4.0.3"
        16 -> "4.1"
        17 -> "4.2"
        18 -> "4.3"
        19 -> "4.4"
        20 -> "4.4W"
        21 -> "5.0"
        22 -> "5.1"
        23 -> "6.0"
        24 -> "7.0"
        25 -> "7.1"
        26 -> "8.0"
        27 -> "8.1"
        28 -> "9"
        29 -> "10"
        30 -> "11"
        31 -> "12"
        32 -> "12L"
        33 -> "13"
        34 -> "14"
        35 -> "15"
        36 -> "16"
        else -> ""
    }

    /** 界面上那行"系统版本"的值:Android 15 (API 35) */
    fun label(sdk: Int): String {
        val api = if (sdk > 0) sdk else Build.VERSION.SDK_INT
        val mapped = name(api)
        val release = try {
            Build.VERSION.RELEASE.orEmpty()
        } catch (t: Throwable) {
            ""
        }
        val version = mapped.ifBlank { release.ifBlank { "?" } }
        return "Android $version (API $api)"
    }

    /** 安卓 12 及以上要 Shizuku / root 才能写别的应用目录 */
    fun needsPrivilegedChannel(sdk: Int = Build.VERSION.SDK_INT): Boolean = sdk >= 31
}
