package com.tengcd.czr.util

import java.io.File
import java.security.MessageDigest

object Md5Util {

    fun md5(text: String): String = md5(text.toByteArray(Charsets.UTF_8))

    fun md5(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("MD5")
        val out = digest.digest(bytes)
        val sb = StringBuilder(out.size * 2)
        for (b in out) {
            val v = b.toInt() and 0xFF
            if (v < 0x10) sb.append('0')
            sb.append(Integer.toHexString(v))
        }
        return sb.toString()
    }

    fun md5(file: File): String? {
        if (!file.isFile) return null
        return try {
            val digest = MessageDigest.getInstance("MD5")
            file.inputStream().use { input ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    digest.update(buf, 0, n)
                }
            }
            val out = digest.digest()
            val sb = StringBuilder(out.size * 2)
            for (b in out) {
                val v = b.toInt() and 0xFF
                if (v < 0x10) sb.append('0')
                sb.append(Integer.toHexString(v))
            }
            sb.toString()
        } catch (t: Throwable) {
            null
        }
    }

    /** 复制并校验:校验失败保留原文件,返回 false */
    fun copyWithVerify(src: File, dst: File, expectMd5: String?): Boolean {
        if (!src.isFile) return false
        return try {
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            src.inputStream().use { input ->
                tmp.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            if (expectMd5.isNullOrEmpty() || md5(tmp).equals(expectMd5, ignoreCase = true)) {
                if (dst.exists()) dst.delete()
                tmp.renameTo(dst)
            } else {
                tmp.delete()
                false
            }
        } catch (t: Throwable) {
            false
        }
    }
}
