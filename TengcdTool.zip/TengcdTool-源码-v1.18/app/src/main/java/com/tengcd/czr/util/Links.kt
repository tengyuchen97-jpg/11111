package com.tengcd.czr.util

/**
 * 内置跳转链接集中放一处,页面里不再散写字面量。
 * 换群换地址只改这里。
 */
object Links {
    /** 官方 QQ 群(卡密验证页 / 卡密页都用这一个) */
    const val QQ_GROUP = "https://qm.qq.com/q/RJvQktX6gg"
}
