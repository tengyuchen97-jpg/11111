package com.tengcd.czr.util

import android.content.Context
import java.io.File

/**
 * 参数配置文件(honffx.config)的读写。
 *
 * 就一个 plain text 文件:读出来原样丢进输入框,保存时整份覆盖回去。
 * 自己写不进去(安卓 12+ 别的应用的 /Android/data)就走 root / Shizuku,
 * 先把内容写到本应用目录,再 cp 过去并修好属主,保证目标应用读得到。
 */
object ConfigFile {

    /** 参数文件固定路径 */
    const val TARGET_PATH =
        "/storage/emulated/0/Android/data/com.pi.czrxdfirst/files/honffx.config"

    /** 读文件内容:直接读不到就走特权通道 cat。读不到返回 null */
    fun read(context: Context, path: String = TARGET_PATH): String? {
        runCatching {
            val f = File(path)
            if (f.exists() && f.canRead()) {
                return f.readText()
            }
        }
        val r = runCatching {
            ShellUtil.execPrivileged(context, "cat " + q(path) + " 2>/dev/null", 15000L)
        }.getOrNull() ?: return null
        return if (r.ok) r.output else null
    }

    /** 整份覆盖写入。成功返回 true(写完会读回来核对一遍) */
    fun write(context: Context, text: String, path: String = TARGET_PATH): Boolean {
        // 1 先按本进程权限直接写
        runCatching {
            val f = File(path)
            f.parentFile?.mkdirs()
            f.writeText(text)
            if (f.exists() && f.readText() == text) return true
        }
        // 2 写不进去:走特权通道
        val tmpDir = context.getExternalFilesDir(null) ?: context.cacheDir
        val tmp = File(tmpDir, "honffx.config.tmp")
        if (!runCatching { tmp.writeText(text) }.isSuccess) return false
        val pkg = packageOf(path)
        val uid = runCatching { PackageUtil.uidOf(context, pkg) }.getOrDefault(0)
        val script = buildString {
            append("mkdir -p ").append(q(parentOf(path))).append("; ")
            append("cp ").append(q(tmp.absolutePath)).append(" ").append(q(path)).append("; ")
            if (uid > 0) {
                append("chown ").append(uid).append(":").append(uid).append(" ")
                    .append(q(path)).append("; ")
            }
            append("chmod 660 ").append(q(path)).append("; ")
            append("cat ").append(q(path))
        }
        val r = runCatching { ShellUtil.execPrivileged(context, script, 25000L) }.getOrNull()
        runCatching { tmp.delete() }
        if (r == null || !r.ok) return false
        return r.output.trimEnd('\n') == text.trimEnd('\n')
    }

    /** 路径里带的目标包名,取不到就用已知的 */
    fun packageOf(path: String): String {
        val marker = "/Android/data/"
        val i = path.indexOf(marker)
        if (i >= 0) {
            val rest = path.substring(i + marker.length)
            val pkg = rest.substringBefore('/')
            if (pkg.isNotBlank()) return pkg
        }
        return "com.pi.czrxdfirst"
    }

    private fun parentOf(path: String): String =
        path.substringBeforeLast('/', "/storage/emulated/0")

    private fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"
}
