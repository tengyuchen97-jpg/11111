//
// JNI 桥。符号名必须和 Kotlin 侧对上:
//   com.tengcd.czr.inject.PtraceInjector.nativeInject(int, String, String)
//
#include <jni.h>
#include <string>

#include <android/log.h>

#include "injector.h"

#define LOG_TAG "honffx-injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jint JNICALL
Java_com_tengcd_czr_inject_PtraceInjector_nativeInject(JNIEnv* env, jobject /*thiz*/,
                                                        jint pid, jstring so_path,
                                                        jstring entry) {
    if (so_path == nullptr) return -2;

    const char* c_path = env->GetStringUTFChars(so_path, nullptr);
    if (c_path == nullptr) return -2;

    const char* c_entry = nullptr;
    if (entry != nullptr) {
        c_entry = env->GetStringUTFChars(entry, nullptr);
    }

    int ret = inject_module(static_cast<pid_t>(pid), c_path, c_entry);
    LOGI("inject pid=%d path=%s ret=%d", pid, c_path, ret);

    env->ReleaseStringUTFChars(so_path, c_path);
    if (c_entry != nullptr) {
        env->ReleaseStringUTFChars(entry, c_entry);
    }
    return ret;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_tengcd_czr_inject_PtraceInjector_nativeLastDetail(JNIEnv* env, jobject /*thiz*/) {
    const char* d = inject_last_detail();
    if (d == nullptr) d = "";
    return env->NewStringUTF(d);
}
