//
// ptrace 进程注入器(arm64)
//
// 和被注入进程"同 uid"场景下的免 root 注入。流程:
//   1. 挑一个"闲着的"线程(优先睡眠态、非主线程),避免它在 linker/libc 的临界区里
//      —— 这是老版本闪退的主要原因之一:选到正在持锁的线程,远程 dlopen 直接死锁。
//   2. PTRACE_ATTACH 附加(失败再试 PTRACE_SEIZE + INTERRUPT)
//   3. 用目标进程 libc 里现成的 `svc #0` 指令做"远程 syscall",调 mmap 拿到一块内存
//      —— 老版本这里是拿 LR=0 去调 mmap,函数一返回就跳到地址 0,目标进程当场 SIGSEGV。
//   4. 在拿到的那块内存里写 so 路径 + `brk #0` 断点,然后把 PC 指到 dlopen,LR 指到断点
//   5. 路径加载失败(mkdir/权限/路径被 linker 拒)时,自动改用 memfd:
//      在目标进程里 memfd_create + pwrite64 把 so 写进去,再 dlopen /proc/self/fd/<fd>
//   6. **无论成败都先把寄存器原样还原,再 detach** —— 老版本失败路径直接 detach,
//      PC 还停在蹦了的地址上,等于亲手把目标进程送走。
//
// 返回值 = 0 成功,负数失败(和 Kotlin 侧 PtraceInjectFailure 一一对应)
//
#include "injector.h"

#include <cerrno>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#include <algorithm>
#include <string>
#include <vector>

#include <dirent.h>
#include <dlfcn.h>
#include <elf.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>

#include <android/log.h>

#define LOG_TAG "zaka-injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef __WALL
#define __WALL 0x40000000
#endif

// 和 Kotlin 的 PtraceInjectFailure 对齐,改一边记得改另一边
enum {
    ERR_NONE = 0,
    ERR_NATIVE_NOT_LOADED = -1,
    ERR_TARGET_NOT_FOUND = -2,
    ERR_ATTACH_DENIED = -3,
    ERR_MMAP_FAILED = -4,
    ERR_DLOPEN_SYMBOL_NOT_FOUND = -5,
    ERR_DLOPEN_FAILED = -6,
    ERR_PATH_TOO_LONG = -7,
    ERR_TARGET_DIR_NOT_ACCESSIBLE = -8,
    ERR_WRITE_REMOTE_FAILED = -9,
    ERR_REMOTE_SYSCALL_FAILED = -15,
    ERR_ABI_MISMATCH = -16,
    ERR_LOADER_BUSY = -17,
    ERR_ATTACH_GONE = -18,      // 内部用:挑中的线程已经退出,换一个继续,不往上抛
    ERR_SO_INVALID = -19,       // 选中的 so 有问题(空文件 / 不是 ELF / 32 位 / 太小)
    ERR_UNKNOWN = -99,
};

#if defined(__aarch64__)

namespace {

// ---------------------------------------------------------------- 失败详情
//
// Kotlin 层通过 nativeLastDetail() 取走,直接显示到界面上,
// 省得用户只知道"失败了"却不知道卡在哪一步。
std::string g_detail;

void set_detail(const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    g_detail = buf;
    LOGE("%s", buf);
}

void clear_detail() { g_detail.clear(); }

/** 单调时钟毫秒:远程调用要设总超时,别用 waitpid 的轮询次数凑数 */
static int64_t now_ms() {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}

/** 最近一次远程调用撞到的致命信号(0 = 没有) */
static int g_last_call_signal = 0;

// ---------------------------------------------------------------- 寄存器

struct Regs {
    uint64_t x[31];   // x0..x30
    uint64_t sp;
    uint64_t pc;
    uint64_t pstate;
};

static_assert(sizeof(Regs) == 34 * sizeof(uint64_t), "unexpected arm64 regs layout");

bool get_regs(pid_t tid, Regs* out) {
    struct iovec io{};
    io.iov_base = out;
    io.iov_len = sizeof(Regs);
    return ptrace(PTRACE_GETREGSET, tid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

bool set_regs(pid_t tid, const Regs* in) {
    struct iovec io{};
    io.iov_base = const_cast<Regs*>(in);
    io.iov_len = sizeof(Regs);
    return ptrace(PTRACE_SETREGSET, tid, reinterpret_cast<void*>(NT_PRSTATUS), &io) == 0;
}

// ---------------------------------------------------------------- 内存读写

bool read_mem(pid_t tid, uint64_t addr, void* buf, size_t len) {
    struct iovec local{};
    struct iovec remote{};
    local.iov_base = buf;
    local.iov_len = len;
    remote.iov_base = reinterpret_cast<void*>(static_cast<uintptr_t>(addr));
    remote.iov_len = len;
    ssize_t n = process_vm_readv(tid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(len)) return true;

    uint8_t* p = static_cast<uint8_t*>(buf);
    size_t done = 0;
    while (done < len) {
        errno = 0;
        long word = ptrace(PTRACE_PEEKDATA, tid,
                           reinterpret_cast<void*>(static_cast<uintptr_t>(addr + done)), nullptr);
        if (word == -1 && errno != 0) return false;
        size_t chunk = sizeof(long);
        if (chunk > len - done) chunk = len - done;
        memcpy(p + done, &word, chunk);
        done += chunk;
    }
    return true;
}

bool write_mem(pid_t tid, uint64_t addr, const void* buf, size_t len) {
    // 按 4KB 页切成小段:process_vm_writev 在跨页/部分失败时只会返回"写进去了多少",
    // 老写法直接拿整段长度比对,一旦部分成功就判失败 -> Android 10 上搬到一半就断。
    // 现在每段先试 process_vm_writev,返回不够再对这一段剩下的用 PTRACE_POKEDATA 补齐。
    const uint8_t* p = static_cast<const uint8_t*>(buf);
    size_t done = 0;
    while (done < len) {
        size_t chunk = 4096;
        if (chunk > len - done) chunk = len - done;

        struct iovec local{};
        struct iovec remote{};
        local.iov_base = const_cast<void*>(static_cast<const void*>(p + done));
        local.iov_len = chunk;
        remote.iov_base = reinterpret_cast<void*>(static_cast<uintptr_t>(addr + done));
        remote.iov_len = chunk;
        errno = 0;
        ssize_t n = process_vm_writev(tid, &local, 1, &remote, 1, 0);
        if (n == static_cast<ssize_t>(chunk)) {
            done += chunk;
            continue;
        }
        size_t got = (n > 0) ? static_cast<size_t>(n) : 0;

        // 剩下的按字长 PTRACE_POKEDATA 补
        while (got < chunk) {
            size_t word_len = sizeof(long);
            if (word_len > chunk - got) word_len = chunk - got;
            size_t at = done + got;
            long word = 0;
            if (word_len < sizeof(long)) {
                // 尾巴不足一个字:先读回来再拼,免得把后面那几个字节抹了
                errno = 0;
                word = ptrace(PTRACE_PEEKDATA, tid,
                              reinterpret_cast<void*>(static_cast<uintptr_t>(addr + at)), nullptr);
                if (word == -1 && errno != 0) return false;
            }
            memcpy(&word, p + at, word_len);
            if (ptrace(PTRACE_POKEDATA, tid,
                       reinterpret_cast<void*>(static_cast<uintptr_t>(addr + at)),
                       reinterpret_cast<void*>(word)) < 0) {
                return false;
            }
            got += word_len;
        }
        done += got;
    }
    return true;
}

// ---------------------------------------------------------------- 等待停止

/**
 * 等目标线程停下。
 * 老写法是阻塞 waitpid:万一目标卡在 linker 锁里出不来,整个注入线程(连着 App)就永远挂着。
 * 现在改成 WNOHANG 轮询 + 超时,超时当"这一次没成",还能接着换线程/换通道。
 */
bool wait_stopped(pid_t tid, int* out_sig, int timeout_ms = 3000) {
    int st = 0;
    int waited_us = 0;
    const int step_us = 500;
    while (waited_us <= timeout_ms * 1000) {
        pid_t w = waitpid(tid, &st, __WALL | WNOHANG);
        if (w < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (w == tid) {
            if (WIFEXITED(st) || WIFSIGNALED(st)) return false;
            if (WIFSTOPPED(st)) {
                if (out_sig != nullptr) *out_sig = WSTOPSIG(st);
                return true;
            }
        }
        usleep(step_us);
        waited_us += step_us;
    }
    errno = ETIMEDOUT;
    return false;
}

// ---------------------------------------------------------------- maps

struct MapEntry {
    uint64_t start = 0;
    uint64_t end = 0;
    uint64_t offset = 0;
    bool readable = false;
    bool executable = false;
    std::string path;
};

std::vector<MapEntry> parse_maps(pid_t pid) {
    std::vector<MapEntry> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (fp == nullptr) return out;

    char line[1024];
    while (fgets(line, sizeof(line), fp) != nullptr) {
        unsigned long long start = 0, end = 0, offset = 0;
        char perms[8] = {0};
        char file[768] = {0};
        int n = sscanf(line, "%llx-%llx %7s %llx %*s %*s %767[^\n]",
                       &start, &end, perms, &offset, file);
        if (n < 4) continue;
        MapEntry e{};
        e.start = start;
        e.end = end;
        e.offset = offset;
        e.readable = perms[0] == 'r';
        e.executable = perms[2] == 'x';
        if (n >= 5) {
            std::string p(file);
            while (!p.empty() && (p.front() == ' ' || p.front() == '\t')) p.erase(p.begin());
            while (!p.empty() && (p.back() == ' ' || p.back() == '\n' || p.back() == '\r')) p.pop_back();
            e.path = p;
        }
        out.push_back(e);
    }
    fclose(fp);
    return out;
}

// ---------------------------------------------------------------- ELF 符号

bool symbol_offset_in_file(const char* path, const char* symbol, uint64_t* out_offset) {
    FILE* fp = fopen(path, "rb");
    if (fp == nullptr) return false;

    uint8_t ident[EI_NIDENT];
    if (fread(ident, 1, sizeof(ident), fp) != sizeof(ident) ||
        memcmp(ident, ELFMAG, SELFMAG) != 0 ||
        ident[EI_CLASS] != ELFCLASS64) {
        fclose(fp);
        return false;
    }

    Elf64_Ehdr eh{};
    fseek(fp, 0, SEEK_SET);
    if (fread(&eh, 1, sizeof(eh), fp) != sizeof(eh) || eh.e_shoff == 0 || eh.e_shnum == 0) {
        fclose(fp);
        return false;
    }

    Elf64_Shdr shdr{};
    for (int i = 0; i < eh.e_shnum; i++) {
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(i) * eh.e_shentsize), SEEK_SET);
        if (fread(&shdr, 1, sizeof(shdr), fp) != sizeof(shdr)) break;
        if (shdr.sh_type != SHT_DYNSYM) continue;

        Elf64_Shdr str_sh{};
        fseek(fp, static_cast<long>(eh.e_shoff + static_cast<uint64_t>(shdr.sh_link) * eh.e_shentsize), SEEK_SET);
        if (fread(&str_sh, 1, sizeof(str_sh), fp) != sizeof(str_sh)) break;

        int count = static_cast<int>(shdr.sh_size / sizeof(Elf64_Sym));
        for (int j = 0; j < count; j++) {
            Elf64_Sym sym{};
            fseek(fp, static_cast<long>(shdr.sh_offset + static_cast<uint64_t>(j) * sizeof(Elf64_Sym)), SEEK_SET);
            if (fread(&sym, 1, sizeof(sym), fp) != sizeof(sym)) break;
            if (sym.st_shndx == SHN_UNDEF || sym.st_name == 0) continue;
            char name[256] = {0};
            fseek(fp, static_cast<long>(str_sh.sh_offset + sym.st_name), SEEK_SET);
            if (fread(name, 1, sizeof(name) - 1, fp) == 0) continue;
            if (strcmp(name, symbol) == 0) {
                *out_offset = sym.st_value;
                fclose(fp);
                return true;
            }
        }
    }
    fclose(fp);
    return false;
}

/** 在目标的某个库里找符号,返回目标进程里的绝对地址 */
uint64_t resolve_in_libs(const std::vector<MapEntry>& maps, const std::vector<std::string>& libs,
                         const char* symbol) {
    for (const auto& lib : libs) {
        for (const auto& m : maps) {
            if (m.path.empty() || !m.executable) continue;
            if (m.path.find(lib) == std::string::npos) continue;
            uint64_t offset = 0;
            if (!symbol_offset_in_file(m.path.c_str(), symbol, &offset)) continue;
            uint64_t base = m.start - m.offset;
            uint64_t addr = base + offset;
            LOGI("symbol %s from %s -> 0x%llx", symbol, m.path.c_str(),
                 static_cast<unsigned long long>(addr));
            return addr;
        }
    }
    return 0;
}

/** dlopen:优先 linker 里的 __loader_dlopen,退到 libdl 的 dlopen */
uint64_t resolve_dlopen(const std::vector<MapEntry>& maps, bool* is_loader) {
    std::vector<std::string> linkers = {"linker64", "linker"};
    uint64_t addr = resolve_in_libs(maps, linkers, "__loader_dlopen");
    if (addr != 0) {
        *is_loader = true;
        return addr;
    }
    std::vector<std::string> dl = {"libdl.so", "libdl_android.so", "libc.so"};
    addr = resolve_in_libs(maps, dl, "dlopen");
    *is_loader = false;
    return addr;
}

/**
 * 找一条目标进程里现成的 `svc #0` 指令。
 * 远程 syscall 全靠它 —— 不需要往目标里写任何代码,也不挑 W^X。
 */
/**
 * 在一段可执行映射里按 4 字节步长找指令。
 * 读失败(某些 ROM 对 process_vm_readv 有限制)只跳过这一块,不放弃整个映射。
 */
uint64_t scan_map_for(pid_t tid, const MapEntry& m, uint32_t want) {
    const size_t kChunk = 64 * 1024;
    std::vector<uint8_t> buf(kChunk);
    for (uint64_t addr = m.start; addr < m.end; addr += kChunk) {
        size_t len = static_cast<size_t>(std::min<uint64_t>(kChunk, m.end - addr));
        if (len < 4) break;
        if (!read_mem(tid, addr, buf.data(), len)) continue;   // 这一块读不到就换下一块
        for (size_t i = 0; i + 4 <= len; i += 4) {
            uint32_t insn = 0;
            memcpy(&insn, buf.data() + i, sizeof(insn));
            if (insn == want) return addr + i;
        }
    }
    return 0;
}

uint64_t find_gadget(pid_t tid, const std::vector<MapEntry>& maps, uint32_t want,
                     const std::vector<std::string>& preferred, bool scan_all) {
    for (const auto& lib : preferred) {
        for (const auto& m : maps) {
            if (m.path.empty() || !m.executable || !m.readable) continue;
            if (m.path.find(lib) == std::string::npos) continue;
            uint64_t found = scan_map_for(tid, m, want);
            if (found != 0) {
                LOGI("gadget 0x%08x at 0x%llx in %s", want,
                     static_cast<unsigned long long>(found), m.path.c_str());
                return found;
            }
        }
    }
    if (!scan_all) return 0;

    // 兜底:把目标里所有可执行段都扫一遍(限制总量,免得在最坏情况下卡太久)
    const uint64_t kScanBudget = 96ull << 20;
    uint64_t scanned = 0;
    for (const auto& m : maps) {
        if (m.path.empty() || !m.executable || !m.readable) continue;
        if (m.path.find("/data/dalvik-cache") != std::string::npos) continue;
        if (m.path.find(".oat") != std::string::npos) continue;
        if (scanned > kScanBudget) break;
        scanned += (m.end - m.start);
        uint64_t found = scan_map_for(tid, m, want);
        if (found != 0) {
            LOGI("gadget 0x%08x at 0x%llx in %s (fallback)", want,
                 static_cast<unsigned long long>(found), m.path.c_str());
            return found;
        }
    }
    return 0;
}

/** `svc #0`:用它做远程系统调用 */
uint64_t find_svc_gadget(pid_t tid, const std::vector<MapEntry>& maps) {
    std::vector<std::string> libs = {"libc.so", "libm.so", "linker64", "linker",
                                     "libc++.so", "libutils.so", "libbase.so"};
    return find_gadget(tid, maps, 0xD4000001u /* svc #0 */, libs, true);
}

/** `brk #0`:把它当"函数调用返回点",函数一回来就停下来 */
uint64_t find_trap_gadget(pid_t tid, const std::vector<MapEntry>& maps) {
    std::vector<std::string> libs = {"libc.so", "libm.so", "linker64", "linker", "libc++.so"};
    return find_gadget(tid, maps, 0xD4200000u /* brk #0 */, libs, true);
}

// ---------------------------------------------------------------- 远程调用

/** 用目标里现成的 svc 指令跑一次系统调用(单步,不写任何代码到目标里) */
/** 读 /proc/<tid>/status 里的 Tgid(给 tgkill 补发信号用) */
static pid_t tgid_of(pid_t tid) {
    char p[64];
    snprintf(p, sizeof(p), "/proc/%d/status", tid);
    FILE* f = fopen(p, "r");
    if (f == nullptr) return 0;
    char line[160];
    pid_t tgid = 0;
    while (fgets(line, sizeof(line), f) != nullptr) {
        if (strncmp(line, "Tgid:", 5) == 0) {
            tgid = static_cast<pid_t>(atoi(line + 5));
            break;
        }
    }
    fclose(f);
    return tgid;
}

/** 被我们截住的异步信号(ART 的 SIGURG 之类)原样补发回去,否则目标进程 GC 会卡住 */
static void redeliver_signal(pid_t tid, int sig) {
    if (sig <= 0) return;
    pid_t tgid = tgid_of(tid);
    if (tgid <= 0) tgid = tid;
#ifdef __NR_tgkill
    syscall(__NR_tgkill, tgid, tid, sig);
#else
    syscall(270 /* tgkill(arm64) */, tgid, tid, sig);
#endif
}

bool remote_syscall(pid_t tid, uint64_t svc, uint64_t nr, const uint64_t* args, int nargs,
                    uint64_t* out) {
    Regs saved{};
    if (!get_regs(tid, &saved)) return false;

    bool ok = false;
    int swallowed = 0;
    for (int attempt = 0; attempt < 4 && !ok; attempt++) {
        Regs r = saved;
        for (int i = 0; i < 8; i++) r.x[i] = (i < nargs) ? args[i] : 0;
        r.x[8] = nr;
        r.pc = svc;

        if (!set_regs(tid, &r)) {
            set_regs(tid, &saved);
            if (swallowed != 0) redeliver_signal(tid, swallowed);
            return false;
        }
        if (ptrace(PTRACE_SINGLESTEP, tid, nullptr, nullptr) < 0) {
            set_regs(tid, &saved);
            if (swallowed != 0) redeliver_signal(tid, swallowed);
            return false;
        }

        int sig = 0;
        if (!wait_stopped(tid, &sig)) break;

        Regs after{};
        bool have = get_regs(tid, &after);
        // 关键:PC 已经不是那条 svc 了 => 这一条指令确实执行完。
        // 这时停下来的信号可能压根不是 SIGTRAP(ART 挂起线程用的 SIGURG 就会插进来),
        // 老版本把它当"没跑起来",于是 Android 10 上动不动报"线程状态异常"。
        bool bad = (sig == SIGSEGV || sig == SIGILL || sig == SIGBUS || sig == SIGFPE);
        if (have && after.pc != svc && !bad) {
            ok = true;
            if (out != nullptr) *out = after.x[0];
        }
        if (sig != 0 && sig != SIGTRAP) {
            swallowed = sig;
            if (!ok) LOGI("syscall attempt %d interrupted by sig %d, retry", attempt + 1, sig);
        }
    }
    // 无论如何还原现场:目标必须干干净净接着跑
    set_regs(tid, &saved);
    if (swallowed != 0) redeliver_signal(tid, swallowed);
    return ok;
}

/** 远程调一个函数,返回靠 LR 指到写好的 brk 断点上取 */
bool remote_call(pid_t tid, uint64_t fn, const uint64_t* args, int nargs,
                 uint64_t* out, uint64_t stub) {
    Regs saved{};
    if (!get_regs(tid, &saved)) return false;

    Regs r = saved;
    for (int i = 0; i < 8; i++) r.x[i] = (i < nargs) ? args[i] : 0;
    r.x[30] = stub;   // LR -> 断点
    r.pc = fn;

    if (!set_regs(tid, &r)) {
        set_regs(tid, &saved);
        return false;
    }
    if (ptrace(PTRACE_CONT, tid, nullptr, nullptr) < 0) {
        set_regs(tid, &saved);
        return false;
    }

    bool ok = false;
    const int64_t deadline = now_ms() + 12000;
    while (!ok && now_ms() < deadline) {
        int64_t left = deadline - now_ms();
        int slice = static_cast<int>(left > 6000 ? 6000 : left);
        int sig = 0;
        // dlopen 可能真的要跑几秒(重定位 + 依赖加载),给足时间,但整体设上限
        if (!wait_stopped(tid, &sig, slice)) break;
        Regs after{};
        bool have = get_regs(tid, &after);
        if (have && after.pc == stub) {
            ok = true;
            if (out != nullptr) *out = after.x[0];
            break;
        }
        // 致命信号(段错/非法指令):是我们自己调崩了,绝不能原样回灌给目标,
        // 否则目标进程当场去世 —— 老版本就是这么把游戏杀掉的。
        if (sig == SIGSEGV || sig == SIGILL || sig == SIGBUS || sig == SIGFPE) {
            LOGE("remote call at 0x%llx raised fatal signal %d",
                 static_cast<unsigned long long>(fn), sig);
            g_last_call_signal = sig;
            break;
        }
        if (sig != SIGTRAP) {
            // 不是我们埋的 brk:多半是 ART 的 SIGURG 这类异步信号。
            // 原样发回目标继续跑,别一句话判死。
            LOGI("remote call interrupted by sig %d, keep waiting", sig);
            if (ptrace(PTRACE_CONT, tid, nullptr,
                       reinterpret_cast<void*>(static_cast<intptr_t>(sig))) < 0) {
                break;
            }
            continue;
        }
        // SIGTRAP 但 PC 不在断点上(别处打断),接着跑
        if (ptrace(PTRACE_CONT, tid, nullptr, nullptr) < 0) break;
    }
    if (!ok) LOGE("remote call did not reach stub");
    // 这里最关键:哪怕函数炸了,也要把现场还原,不然目标进程直接报废
    set_regs(tid, &saved);
    return ok;
}

// ---------------------------------------------------------------- 线程挑选

struct ThreadPick {
    pid_t tid;
    char state;
};

std::vector<ThreadPick> list_threads(pid_t pid) {
    std::vector<ThreadPick> out;
    char dir[64];
    snprintf(dir, sizeof(dir), "/proc/%d/task", pid);
    DIR* d = opendir(dir);
    if (d == nullptr) return out;

    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        pid_t tid = static_cast<pid_t>(atoi(e->d_name));
        if (tid <= 0) continue;
        char st = '?';
        char p[96];
        snprintf(p, sizeof(p), "/proc/%d/task/%d/stat", pid, tid);
        FILE* f = fopen(p, "r");
        if (f != nullptr) {
            char buf[512];
            size_t n = fread(buf, 1, sizeof(buf) - 1, f);
            fclose(f);
            buf[n] = '\0';
            char* rp = strrchr(buf, ')');
            if (rp != nullptr && rp[1] == ' ' && rp[2] != '\0') st = rp[2];
        }
        out.push_back({tid, st});
    }
    closedir(d);

    // 睡着的线程优先(不在 linker 临界区、不持锁),主线程排最后
    std::sort(out.begin(), out.end(), [](const ThreadPick& a, const ThreadPick& b) {
        int sa = (a.state == 'S' || a.state == 'D') ? 0 : 1;
        int sb = (b.state == 'S' || b.state == 'D') ? 0 : 1;
        if (sa != sb) return sa < sb;
        return a.tid > b.tid;
    });
    return out;
}

/**
 * 附加结果。
 * 关键区分:ESRCH(线程已经没了)是可恢复的 —— 换下一个线程就好;
 * EPERM/EACCES 才是真的"系统不给附加",换线程没用。
 * 老版本把两者混成一个 ERR_ATTACH_DENIED,于是一个刚要退出的线程就把整条注入废掉了
 * (截图里那条 "附加线程 19135 失败:attach 被拒(errno=3 No such process)")。
 */
enum AttachStatus {
    ATTACH_OK = 0,
    ATTACH_GONE = 1,      // 线程已退出 / tid 无效:换下一个
    ATTACH_DENIED_ = 2,   // EPERM / EACCES:权限问题
    ATTACH_FAILED = 3,    // 其它
};

int attach_thread(pid_t tid, int* out_errno, std::string* why) {
    g_detail.clear();
    errno = 0;
    if (ptrace(PTRACE_ATTACH, tid, nullptr, nullptr) == 0) {
        int sig = 0;
        if (wait_stopped(tid, &sig)) {
            if (out_errno != nullptr) *out_errno = 0;
            return ATTACH_OK;
        }
        ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
        if (out_errno != nullptr) *out_errno = ETIMEDOUT;
        *why = "附加后等不到它停下(可能正在被反调试/被别的工具占用)";
        return ATTACH_FAILED;
    }

    int attach_errno = errno != 0 ? errno : EPERM;
    // 老内核/被限制的 SELinux 有时 PTRACE_ATTACH 挂了但 SEIZE 还能用
    if (attach_errno != EPERM) {   // EPERM 时 SEIZE 只会再被拒一次,白费时间
        if (ptrace(PTRACE_SEIZE, tid, nullptr, nullptr) == 0) {
            if (ptrace(PTRACE_INTERRUPT, tid, nullptr, nullptr) == 0) {
                int sig = 0;
                if (wait_stopped(tid, &sig)) {
                    if (out_errno != nullptr) *out_errno = 0;
                    return ATTACH_OK;
                }
            }
            ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
        }
    }

    if (out_errno != nullptr) *out_errno = attach_errno;
    char buf[128];
    if (attach_errno == ESRCH || attach_errno == EINVAL) {
        snprintf(buf, sizeof(buf), "线程已经不在了(errno=%d)", attach_errno);
        *why = buf;
        return ATTACH_GONE;
    }
    if (attach_errno == EPERM || attach_errno == EACCES) {
        snprintf(buf, sizeof(buf), "系统拒绝附加(errno=%d %s)", attach_errno, strerror(attach_errno));
        *why = buf;
        return ATTACH_DENIED_;
    }
    snprintf(buf, sizeof(buf), "attach 被拒(errno=%d %s)", attach_errno, strerror(attach_errno));
    *why = buf;
    return ATTACH_FAILED;
}

/**
 * 冻住目标里除了我们正在用的那个线程之外的所有线程。
 * 这是那个免 root 注入工具做得比我们好的地方(它日志里的 Frozen/Thawed N threads):
 * 注入过程中目标其它线程继续跑,可能正在 libc/linker 里搬数据、抢锁,
 * 我们改寄存器、远程调 dlopen 的时候它正好踩进来,就会出各种莫名其妙的失败。
 * 冻住它们,注入完再逐个放行。
 */
int freeze_others(pid_t pid, pid_t keep, std::vector<pid_t>* frozen) {
    frozen->clear();
    std::vector<ThreadPick> threads = list_threads(pid);
    int denied = 0;
    int skipped_busy = 0;
    for (const auto& t : threads) {
        if (t.tid == keep || t.tid <= 0) continue;
        if (frozen->size() >= 128) break;
        // 只冻"睡着"的线程(S/D)。
        // 正在跑(R)的线程有可能正卡在 malloc / linker 这种临界区里,
        // 把它冻在半路,我们自己的 dlopen 就会等一把永远不释放的锁 —— 死锁比不冻更糟。
        if (t.state != 'S' && t.state != 'D') {
            skipped_busy++;
            continue;
        }
        int err = 0;
        std::string why;
        int st = attach_thread(t.tid, &err, &why);
        if (st == ATTACH_OK) {
            frozen->push_back(t.tid);
        } else if (st == ATTACH_DENIED_) {
            denied++;
        }
        // ATTACH_GONE:线程已经退了,跳过;其它失败也跳过,冻不住不影响主线程干活
    }
    LOGI("frozen %zu threads (keep %d), denied %d, skipped busy %d", frozen->size(), keep,
         denied, skipped_busy);
    return static_cast<int>(frozen->size());
}

void thaw_all(std::vector<pid_t>* frozen) {
    for (pid_t tid : *frozen) {
        ptrace(PTRACE_DETACH, tid, nullptr, reinterpret_cast<void*>(0));
    }
    if (!frozen->empty()) LOGI("thawed %zu threads", frozen->size());
    frozen->clear();
}

void detach_thread(pid_t tid, const Regs& saved, bool restore) {
    if (restore) set_regs(tid, &saved);
    ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
}

// ---------------------------------------------------------------- 本地 so 信息

struct SoInfo {
    uint64_t size = 0;
    bool is64 = false;
    uint16_t machine = 0;
    bool valid = false;
    std::string why;   // 不合格的原因(人话,直接显示到界面)
};

/**
 * 动手前先把 so 验一遍。
 * 老版本一路跑到 memfd 才因为空文件/坏文件失败,报出来的是一句看不懂的 "-1";
 * 实际最常见的就是「选了个 0 字节的占位 so」或者「拖进来的是个 32 位的 so」。
 */
SoInfo inspect_so(const char* path) {
    SoInfo info;
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) {
        info.why = std::string("打不开这个 so(errno=") + std::to_string(errno) + " " +
                   strerror(errno) + ")";
        return info;
    }
    struct stat st{};
    if (fstat(fd, &st) != 0) {
        info.why = "读不到 so 文件大小";
        close(fd);
        return info;
    }
    info.size = static_cast<uint64_t>(st.st_size);
    if (st.st_size <= 0) {
        info.why = "这个 so 是空文件(0 字节),占位用的空文件注入不了,换成真的 so";
        close(fd);
        return info;
    }
    if (info.size < 1024) {
        info.why = "这个 so 只有 " + std::to_string(info.size) + " 字节,不可能是完整的 so";
        close(fd);
        return info;
    }
    Elf64_Ehdr eh{};
    ssize_t n = pread(fd, &eh, sizeof(eh), 0);
    close(fd);
    if (n < static_cast<ssize_t>(sizeof(eh))) {
        info.why = "so 文件不完整(头都没读全)";
        return info;
    }
    if (memcmp(eh.e_ident, ELFMAG, SELFMAG) != 0) {
        info.why = "这个文件不是 ELF 格式(前 4 字节不是 \\x7fELF)";
        return info;
    }
    info.is64 = eh.e_ident[EI_CLASS] == ELFCLASS64;
    info.machine = eh.e_machine;
    if (!info.is64) {
        info.why = "这个 so 是 32 位的,目标进程是 64 位,加载不了";
        return info;
    }
    if (info.machine != EM_AARCH64) {
        info.why = "这个 so 不是 arm64 的(不是给手机 CPU 用的)";
        return info;
    }
    if (eh.e_type != ET_DYN) {
        info.why = "这个文件不是共享库(ELF type 不是 ET_DYN)";
        return info;
    }
    info.valid = true;
    return info;
}

bool target_is64(const std::vector<MapEntry>& maps) {
    for (const auto& m : maps) {
        if (m.path.empty()) continue;
        if (m.path.size() >= 8 && m.path.compare(m.path.size() - 8, 8, "linker64") == 0) return true;
        if (m.path.size() >= 6 && m.path.compare(m.path.size() - 6, 6, "linker") == 0) return false;
    }
    return true;
}

// ---------------------------------------------------------------- 单线程注入

struct RemoteCtx {
    pid_t pid = -1;
    pid_t tid = -1;
    Regs saved{};
    const std::vector<MapEntry>* maps = nullptr;
    uint64_t svc = 0;
    uint64_t trap = 0;      // libc 里的 brk #0,没有 svc 时用它当函数返回断点
    uint64_t page = 0;
    uint64_t page_size = 0;
    uint64_t stub = 0;
    uint64_t dlopen_addr = 0;
    uint64_t tramp = 0;         // 我们自己写进目标内存的 svc #0; ret 桩
    uint64_t libc_syscall = 0;  // libc 的 syscall(),最后一层兜底
    bool svc_broken = false;    // 单步 svc 被打断过 => 这台机器上别再指望它
    bool tramp_unusable = false;// 桩自检没过 => 别再反复装
    bool is_loader = false;
};

/** 一次系统调用的结果。ok=false 表示"根本没执行"(通道不通),ok=true 时 val 是原始返回值 */
struct SysRes {
    bool ok = false;
    int64_t val = 0;
    std::string why;
};

/**
 * 往我们自己 mmap 出来的 RWX 页里写一根"系统调用函数"。
 *
 * 为什么要这个:老方案是拿目标 libc 里现成的 svc 指令 + 单步执行,
 * 安卓 10 上 ART 会往线程里塞 SIGURG(挂起信号),单步过程中一被打断就判失败,
 * 于是动不动报"远程调用没停下来(线程状态异常)"。
 * 走这根桩就是一次连续执行,中途插信号也不影响,返回时落在我们自己的 brk 上。
 *
 * 调用约定(和 raw_syscall 对齐):x0 = 系统调用号,x1..x6 = 系统调用参数 x0..x5。
 * ⚠️ 桩里必须先把参数整体左移一格(x0=x1, x1=x2 …)再 svc,
 *    因为内核要的是 x8 = 号、x0..x5 = 参数。
 *    老版本只做了 `mov x8, x0` 就进内核,于是内核把"号"当成了第一个参数:
 *      mmap(len=0) -> EINVAL
 *      memfd_create(name=279, flags=<指针>) -> EINVAL(22)
 *    界面上那句「memfd_create 失败(errno=22)」就是这一格错位造成的。
 */
bool write_syscall_stub(RemoteCtx& c) {
    uint64_t at = c.page + 0x3000;
    const size_t bytes = 10 * sizeof(uint32_t);
    if (at + bytes + 16 > c.page + c.page_size) return false;
    const uint32_t code[10] = {
        0xAA0003E8u,  // mov x8, x0   ; x8 = 系统调用号
        0xAA0103E0u,  // mov x0, x1
        0xAA0203E1u,  // mov x1, x2
        0xAA0303E2u,  // mov x2, x3
        0xAA0403E3u,  // mov x3, x4
        0xAA0503E4u,  // mov x4, x5
        0xAA0603E5u,  // mov x5, x6
        0xD4000001u,  // svc #0
        0xD65F03C0u,  // ret          -- 回到 remote_call 埋的 brk
        0xD4200000u,  // brk #0(占位,别让后面的野指令跟上来)
    };
    if (!write_mem(c.tid, at, code, sizeof(code))) return false;
    c.tramp = at;
    return true;
}

/** 桩装好先拿 getpid 试一发:返回不是个正常 pid 就说明这条路在这台机器上不可用 */
bool selftest_syscall_stub(RemoteCtx& c) {
    uint64_t args[1] = {172 /* getpid */};
    uint64_t v = 0;
    if (!remote_call(c.tid, c.tramp, args, 1, &v, c.stub)) return false;
    int64_t got = static_cast<int64_t>(v);
    if (got <= 0 || got == 172) return false;
    LOGI("syscall stub self-test ok: getpid=%lld", static_cast<long long>(got));
    return true;
}

bool install_syscall_trampoline(RemoteCtx& c) {
    if (c.tramp != 0) return true;
    if (c.tramp_unusable) return false;
    if (c.page == 0 || c.stub == 0) return false;
    if (!write_syscall_stub(c)) {
        c.tramp = 0;
        return false;
    }
    if (!selftest_syscall_stub(c)) {
        LOGE("syscall stub self-test failed, fallback to inline svc / libc syscall");
        c.tramp = 0;
        c.tramp_unusable = true;
        return false;
    }
    LOGI("syscall trampoline ready at 0x%llx", static_cast<unsigned long long>(c.tramp));
    return true;
}

/**
 * 发一次系统调用。三条通道按可靠程度排:
 *   1) 自建 svc 桩(连续执行,最稳)
 *   2) 目标里现成的 svc 指令 + 单步(老方案,安卓 10 上常被打断)
 *   3) libc 的 syscall()(前两条都不行时兜底;它失败只返回 -1,拿不到具体 errno)
 * 返回 true 表示真的执行了,*out 是原始返回值(负数一般是 -errno)。
 */
bool raw_syscall(RemoteCtx& c, uint64_t nr, const uint64_t* args, int nargs, int64_t* out,
                 std::string* why) {
    uint64_t a[7] = {nr, 0, 0, 0, 0, 0, 0};
    for (int i = 0; i < nargs && i < 6; i++) a[i + 1] = args[i];

    if (c.tramp != 0) {
        uint64_t v = 0;
        if (remote_call(c.tid, c.tramp, a, nargs + 1, &v, c.stub)) {
            *out = static_cast<int64_t>(v);
            return true;
        }
        if (why != nullptr) *why = "系统调用桩没返回(目标线程卡住)";
    }

    if (c.svc != 0 && !c.svc_broken) {
        uint64_t v = 0;
        if (remote_syscall(c.tid, c.svc, nr, args, nargs, &v)) {
            *out = static_cast<int64_t>(v);
            return true;
        }
        c.svc_broken = true;   // 记住:这台机器单步 svc 不可靠,后面别再浪费轮次
        LOGI("inline svc failed, switching to trampoline/libc channel");
        if (why != nullptr) *why = "单步 svc 被打断";
    }

    if (c.libc_syscall != 0 && c.trap != 0) {
        uint64_t v = 0;
        if (remote_call(c.tid, c.libc_syscall, a, nargs + 1, &v, c.trap)) {
            *out = (v == static_cast<uint64_t>(-1)) ? -1 : static_cast<int64_t>(v);
            return true;
        }
        if (why != nullptr) *why = "libc syscall() 没返回";
    }
    return false;
}

SysRes do_syscall(RemoteCtx& c, uint64_t nr, const uint64_t* args, int nargs) {
    SysRes r;
    int64_t v = 0;
    std::string why;
    if (!raw_syscall(c, nr, args, nargs, &v, &why)) {
        r.why = why.empty() ? "系统调用通道不通" : why;
        return r;
    }
    r.ok = true;
    r.val = v;
    return r;
}

/**
 * 在目标进程里申请一块内存。
 * 老版本这里只有 svc 一条路(第一块页面才有 libc 兜底),所以 svc 一坏,
 * 后面申请 so 数据缓冲区就直接吐 "-1"(截图里那句"给 SO 数据申请目标内存失败")。
 * 现在统一走这个函数:桩 / svc / libc mmap 三条道都试,ENOMEM 还会自动把尺寸减半重来。
 */
bool remote_alloc(RemoteCtx& c, uint64_t size, int prot, uint64_t* out, std::string* why) {
    int64_t last_err = 0;
    bool have_errno = false;
    uint64_t want = size;
    for (int round = 0; round < 3 && want >= 4096; round++) {
        uint64_t args[6] = {0, want, static_cast<uint64_t>(prot),
                            static_cast<uint64_t>(MAP_PRIVATE | MAP_ANONYMOUS),
                            static_cast<uint64_t>(-1), 0};

        SysRes r = do_syscall(c, 222 /* mmap(arm64) */, args, 6);
        if (r.ok && r.val > 0) {
            *out = static_cast<uint64_t>(r.val);
            return true;
        }
        if (r.ok) {
            last_err = r.val;
            have_errno = true;
            LOGI("mmap size %llu -> %lld", static_cast<unsigned long long>(want),
                 static_cast<long long>(r.val));
        }

        if (c.maps != nullptr && c.trap != 0) {
            uint64_t fn = resolve_in_libs(*c.maps, {"libc.so", "libc++.so", "libm.so"}, "mmap");
            if (fn != 0) {
                uint64_t got = 0;
                if (remote_call(c.tid, fn, args, 6, &got, c.trap)) {
                    if (got != 0 && static_cast<int64_t>(got) > 0) {
                        *out = got;
                        LOGI("mmap via libc -> 0x%llx", static_cast<unsigned long long>(got));
                        return true;
                    }
                    if (!have_errno) {
                        have_errno = true;
                        last_err = -1;
                    }
                }
            }
        }

        // 只有"目标内存不够"才值得把尺寸减半再试一次;别的错误缩尺寸也没用
        if (!(r.ok && r.val == -12 /* ENOMEM */)) break;
        want /= 2;
    }
    if (why != nullptr) {
        if (have_errno && last_err != -1) {
            *why = "申请内存失败(errno=" + std::to_string(-last_err) + " " + strerror(-last_err) + ")";
        } else {
            *why = "申请内存失败(系统调用通道和 libc mmap 都没成)";
        }
    }
    return false;
}

// ---------------------------------------------------------------- memfd 搬运
// 老版本一次往目标进程里甩 1MB 再 pwrite64 进 memfd,Android 10 上经常搬到一半就断
// (报"写到第 1048626 / 4131 字节")。这里换成两条互不相干的路:
//   路线 1:本机读 -> 64KB 小步写进目标内存 -> 目标进程用 write() 顺序写进 memfd,每步校验
//   路线 2:数据全程留在目标进程内部 —— 目标自己 open(so) / read / write 进 memfd
// 任一条通,后面 dlopen 就能接着走。

/** 把一块数据搬进目标内存,再调一次 write() 顺序写进 memfd;短写自动补齐 */
static bool remote_write_via_buf(RemoteCtx& c, int64_t fd, uint64_t buf, const uint8_t* data,
                                 size_t len, size_t* progress, int64_t* last_err) {
    size_t done = 0;
    int fails = 0;
    *progress = 0;
    *last_err = 0;
    while (done < len) {
        size_t left = len - done;
        if (!write_mem(c.tid, buf, data + done, left)) {
            if (++fails >= 5) { *last_err = -1000; *progress = done; return false; }
            continue;
        }
        uint64_t args[3] = {static_cast<uint64_t>(fd), buf, static_cast<uint64_t>(left)};
        SysRes w = do_syscall(c, 64 /* write(arm64) */, args, 3);
        if (!w.ok) { *last_err = -1001; *progress = done; return false; }
        int64_t n = w.val;
        if (n > 0) { done += static_cast<size_t>(n); fails = 0; continue; }
        *last_err = n;
        if (n == -4 /* EINTR */) continue;
        if (++fails >= 5) { *progress = done; return false; }
    }
    *progress = done;
    return true;
}

/** 路线 1 */
static bool copy_so_by_ptrace(RemoteCtx& c, int src, int64_t fd, uint64_t buf, uint64_t total,
                              uint64_t* written, std::string* why) {
    // 块大小自适应:64KB 走不动就退到 16KB / 4KB / 1KB / 256B,
    // 而且是从"已经写到的那个字节"接着走,不从头再来。
    static const size_t kSizes[] = {64 * 1024, 16 * 1024, 4096, 1024, 256};
    size_t step = 0;
    std::vector<uint8_t> chunk(kSizes[0]);
    uint64_t done = 0;
    int soft_fails = 0;
    *written = 0;
    while (done < total) {
        size_t want = kSizes[step];
        if (want > total - done) want = static_cast<size_t>(total - done);
        ssize_t got = pread(src, chunk.data(), want, static_cast<off_t>(done));
        if (got <= 0) { *why = "读本机 so 失败"; *written = done; return false; }
        size_t wrote = 0;
        int64_t err = 0;
        bool ok = remote_write_via_buf(c, fd, buf, chunk.data(), static_cast<size_t>(got), &wrote,
                                      &err);
        done += wrote;
        if (ok) { soft_fails = 0; continue; }
        // 这个块没搬完:换成更小的块,从断点继续
        if (step + 1 < (int)(sizeof(kSizes) / sizeof(kSizes[0])) && ++soft_fails <= 8) {
            step++;
            continue;
        }
        char tmp[128];
        if (err == -1000) {
            snprintf(tmp, sizeof(tmp), "往目标进程内存写数据失败(已写 %llu 字节)",
                     static_cast<unsigned long long>(done));
        } else if (err == -1001) {
            snprintf(tmp, sizeof(tmp), "目标进程执行 write 后没停下(已写 %llu 字节)",
                     static_cast<unsigned long long>(done));
        } else {
            snprintf(tmp, sizeof(tmp), "目标进程 write 返回 %lld(已写 %llu 字节)",
                     static_cast<long long>(err), static_cast<unsigned long long>(done));
        }
        *why = tmp;
        *written = done;
        return false;
    }
    *written = done;
    return true;
}

/** 路线 2:数据不经过 ptrace,目标进程自己 open/read/write */
static bool copy_so_inside_target(RemoteCtx& c, uint64_t path_addr, int64_t fd, uint64_t buf,
                                  uint64_t total, uint64_t* written, std::string* why) {
    uint64_t open_args[4] = {static_cast<uint64_t>(-100) /* AT_FDCWD */, path_addr, 0 /* O_RDONLY */, 0};
    SysRes o = do_syscall(c, 56 /* openat(arm64) */, open_args, 3);
    int64_t sfd = o.ok ? o.val : -999;
    *written = 0;
    if (!o.ok || sfd < 0) {
        char tmp[128];
        if (!o.ok) {
            snprintf(tmp, sizeof(tmp), "目标进程调 openat 没成功(%s)", o.why.c_str());
        } else {
            snprintf(tmp, sizeof(tmp), "目标进程打不开 so 文件(openat=%lld)",
                     static_cast<long long>(sfd));
        }
        *why = tmp;
        return false;
    }
    uint64_t done = 0;
    while (done < total) {
        uint64_t rd_args[3] = {static_cast<uint64_t>(sfd), buf, 64 * 1024};
        SysRes rd = do_syscall(c, 63 /* read(arm64) */, rd_args, 3);
        int64_t n = rd.ok ? rd.val : -1;
        if (!rd.ok || n <= 0) { *why = "目标进程读 so 内容失败"; break; }
        int64_t off = 0;
        while (off < n) {
            uint64_t wr_args[3] = {static_cast<uint64_t>(fd),
                                   buf + static_cast<uint64_t>(off),
                                   static_cast<uint64_t>(n - off)};
            SysRes wr = do_syscall(c, 64 /* write(arm64) */, wr_args, 3);
            int64_t w = wr.ok ? wr.val : -1;
            if (!wr.ok || w <= 0) break;
            off += w;
        }
        if (off != n) { *why = "目标进程写 memfd 失败"; break; }
        done += static_cast<uint64_t>(n);
    }
    uint64_t close_args[1] = {static_cast<uint64_t>(sfd)};
    do_syscall(c, 57 /* close(arm64) */, close_args, 1);
    *written = done;
    return done == total;
}

// ---------------------------------------------------------------- fd 装载 / JNI 初始化

/**
 * 找一个"属于目标 App 自己"的地址,当 __loader_dlopen / android_dlopen_ext 的 caller。
 * linker 是靠 caller 地址反查它落在哪个 so 里,再决定用哪个 namespace 的 ——
 * 给错了(比如给 libc 里的地址)就会被塞进系统的 default namespace,
 * 于是 memfd 里的库连带依赖都找不到,返回空 handle。
 */
uint64_t app_namespace_caller(const std::vector<MapEntry>& maps) {
    for (const auto& m : maps) {
        if (m.path.empty() || !m.executable) continue;
        const bool in_app = m.path.rfind("/data/app/", 0) == 0 ||
                            m.path.rfind("/data/data/", 0) == 0 ||
                            m.path.rfind("/data/user/", 0) == 0 ||
                            m.path.rfind("/mnt/expand/", 0) == 0;
        if (in_app) return m.start;
    }
    return 0;
}

/**
 * 把已经写满 so 的 memfd 装进目标。
 * 先用 android_dlopen_ext + ANDROID_DLEXT_USE_LIBRARY_FD —— 这是系统专门留的
 * "从 fd 装库"通道,不做路径/命名空间字符串检查,memfd 这种没有真路径的库靠它才稳;
 * 不行再退到 /proc/self/fd/<fd> 当路径喂给 dlopen(9/10 上常见配方)。
 */
uint64_t load_from_memfd(RemoteCtx& c, const std::vector<MapEntry>& maps, int64_t fd,
                         const char* display_name) {
    if (fd < 0 || c.page == 0) return 0;
    uint64_t caller = app_namespace_caller(maps);
    if (caller == 0) caller = c.svc;

    // 给 linker 一个像样的文件名:某些 ROM 会按后缀判断是不是 so
    char name[128];
    snprintf(name, sizeof(name), "%s", (display_name != nullptr && display_name[0] != '\0')
                                          ? display_name : "libinject_target.so");
    uint64_t name_addr = c.page + 0x100;
    if (!write_mem(c.tid, name_addr, name, strlen(name) + 1)) return 0;

    // ---- 1) android_dlopen_ext(name, RTLD_NOW|RTLD_GLOBAL, &dlextinfo)
    std::vector<std::string> dl_libs = {"libdl.so", "libdl_android.so", "linker64", "linker"};
    uint64_t ext_fn = resolve_in_libs(maps, dl_libs, "android_dlopen_ext");
    if (ext_fn == 0) ext_fn = resolve_in_libs(maps, dl_libs, "__loader_android_dlopen_ext");
    if (ext_fn != 0) {
        uint64_t info[6] = {0};
        info[0] = 0x10;  // ANDROID_DLEXT_USE_LIBRARY_FD
        info[3] = static_cast<uint64_t>(static_cast<uint32_t>(fd)) << 32;  // library_fd
        uint64_t ext_addr = c.page + 0x400;
        if (write_mem(c.tid, ext_addr, info, sizeof(info))) {
            uint64_t args[3] = {name_addr, RTLD_NOW | RTLD_GLOBAL, ext_addr};
            uint64_t h = 0;
            if (remote_call(c.tid, ext_fn, args, 3, &h, c.stub) && h != 0) {
                LOGI("android_dlopen_ext(USE_LIBRARY_FD) ok, handle=0x%llx",
                     static_cast<unsigned long long>(h));
                return h;
            }
            LOGI("android_dlopen_ext(USE_LIBRARY_FD) failed, trying /proc/self/fd path");
        }
    }

    // ---- 2) dlopen("/proc/self/fd/<fd>")
    char fd_path[64];
    snprintf(fd_path, sizeof(fd_path), "/proc/self/fd/%lld", static_cast<long long>(fd));
    uint64_t path_addr = c.page + 0x0;
    if (!write_mem(c.tid, path_addr, fd_path, strlen(fd_path) + 1)) return 0;
    uint64_t h = 0;
    if (c.is_loader) {
        uint64_t args[3] = {path_addr, RTLD_NOW | RTLD_GLOBAL, caller};
        if (remote_call(c.tid, c.dlopen_addr, args, 3, &h, c.stub) && h != 0) {
            LOGI("dlopen(%s) via __loader_dlopen ok", fd_path);
            return h;
        }
    }
    uint64_t args2[2] = {path_addr, RTLD_NOW | RTLD_GLOBAL};
    if (remote_call(c.tid, c.dlopen_addr, args2, 2, &h, c.stub) && h != 0) {
        LOGI("dlopen(%s) ok", fd_path);
        return h;
    }
    return 0;
}

/** so 里存不存在这个导出符号(存在才值得去 dlsym,省得白调) */
bool so_exports_symbol(const char* path, const char* symbol) {
    uint64_t off = 0;
    return symbol_offset_in_file(path, symbol, &off);
}

/**
 * 尽力把 JNI_OnLoad 补调一遍。
 *
 * 走 System.loadLibrary 的时候是 ART 替 so 调的 JNI_OnLoad;我们这条 memfd + dlopen
 * 的路 ART 根本不参与,而绝大多数 ImGui 菜单 so 的初始化(找 JavaVM、起绘制线程、
 * hook eglSwapBuffers)全写在 JNI_OnLoad 里 —— 不补这一下,表面"注入成功"但不出菜单。
 * 全程 best-effort:任何一步失败就当没这回事,不影响注入结果。
 */
void try_call_jni_onload(RemoteCtx& c, const std::vector<MapEntry>& maps, uint64_t handle,
                         const char* so_path) {
    if (c.page == 0 || c.stub == 0 || handle == 0 || so_path == nullptr) return;
    if (!so_exports_symbol(so_path, "JNI_OnLoad")) {
        LOGI("so 没导出 JNI_OnLoad,跳过");
        return;
    }

    uint64_t dlsym_addr = resolve_in_libs(maps, {"libdl.so", "libdl_android.so", "libc.so"}, "dlsym");
    uint64_t get_vms = resolve_in_libs(maps, {"libart.so", "libnativehelper.so", "libnativeloader.so"},
                                      "JNI_GetCreatedJavaVMs");
    if (dlsym_addr == 0 || get_vms == 0) {
        LOGI("JNI_OnLoad 跳过: dlsym=0x%llx getJavaVMs=0x%llx",
             static_cast<unsigned long long>(dlsym_addr),
             static_cast<unsigned long long>(get_vms));
        return;
    }

    uint64_t sym_name = c.page + 0x1800;
    uint64_t vm_slot = c.page + 0x1900;
    uint64_t env_slot = c.page + 0x1980;
    uint64_t cnt_slot = c.page + 0x1a00;
    if (cnt_slot + 8 > c.stub) return;
    if (!write_mem(c.tid, sym_name, "JNI_OnLoad", 11)) return;

    uint64_t ds_args[2] = {handle, sym_name};
    uint64_t fn = 0;
    if (!remote_call(c.tid, dlsym_addr, ds_args, 2, &fn, c.stub) || fn == 0) {
        LOGI("dlsym(JNI_OnLoad) 拿不到地址");
        return;
    }

    // JNI_GetCreatedJavaVMs(&vm, 1, &count)
    uint64_t zero = 0, one = 1;
    if (!write_mem(c.tid, vm_slot, &zero, sizeof(zero)) ||
        !write_mem(c.tid, cnt_slot, &one, sizeof(one))) {
        return;
    }
    uint64_t gv_args[3] = {vm_slot, 1, cnt_slot};
    uint64_t rc = 0;
    if (!remote_call(c.tid, get_vms, gv_args, 3, &rc, c.stub) || static_cast<int32_t>(rc) != 0) {
        LOGI("JNI_GetCreatedJavaVMs 失败 rc=%d", static_cast<int>(rc));
        return;
    }
    uint64_t vm = 0;
    if (!read_mem(c.tid, vm_slot, &vm, sizeof(vm)) || vm == 0) return;

    // JavaVM* -> JNIInvokeInterface**:AttachCurrentThread 是第 4 号槽
    // (reserved0..2 / DestroyJavaVM / AttachCurrentThread / Detach / GetEnv / AttachAsDaemon)
    uint64_t vtbl = 0;
    if (!read_mem(c.tid, vm, &vtbl, sizeof(vtbl)) || vtbl == 0) return;
    uint64_t attach = 0;
    if (!read_mem(c.tid, vtbl + 4 * sizeof(uint64_t), &attach, sizeof(attach)) || attach == 0) return;

    if (!write_mem(c.tid, env_slot, &zero, sizeof(zero))) return;
    uint64_t at_args[3] = {vm, env_slot, 0};
    uint64_t at_rc = 0;
    if (!remote_call(c.tid, attach, at_args, 3, &at_rc, c.stub)) return;
    uint64_t env = 0;
    if (!read_mem(c.tid, env_slot, &env, sizeof(env)) || env == 0) {
        LOGI("AttachCurrentThread 没给出 JNIEnv,跳过 JNI_OnLoad");
        return;
    }

    uint64_t jn_args[2] = {env, vm};
    uint64_t version = 0;
    if (remote_call(c.tid, fn, jn_args, 2, &version, c.stub)) {
        LOGI("JNI_OnLoad 调用完成,返回 0x%x", static_cast<unsigned>(version & 0xffffffffu));
    } else {
        LOGI("JNI_OnLoad 调用没返回");
    }
}

int inject_into_thread(pid_t pid, pid_t tid, const std::vector<MapEntry>& maps,
                       const char* so_path, const char* entry_symbol, bool allow_freeze) {
    RemoteCtx c;
    c.pid = pid;
    c.tid = tid;
    c.maps = &maps;

    std::string why;
    int attach_errno = 0;
    int attach_state = attach_thread(tid, &attach_errno, &why);
    if (attach_state != ATTACH_OK) {
        set_detail("附加线程 %d 失败:%s", tid, why.c_str());
        if (attach_state == ATTACH_DENIED_) return ERR_ATTACH_DENIED;
        // 线程已经退出(errno=3 ESRCH)或等不到它停下:换一个线程接着来,
        // 不能因为一个刚好退出的线程把整条注入判死
        return ERR_ATTACH_GONE;
    }

    if (!get_regs(tid, &c.saved)) {
        set_detail("读不到线程 %d 的寄存器", tid);
        ptrace(PTRACE_DETACH, tid, nullptr, nullptr);
        return ERR_ATTACH_GONE;
    }

    int result = ERR_UNKNOWN;
    bool restore = true;
    std::vector<pid_t> frozen;

    do {
        // 0) 先把目标其它线程冻住。
        //    注入期间它们继续跑,可能正好在 linker 里持锁、在 libc 里搬数据,
        //    我们远程改寄存器/调 dlopen 时撞上去就是"偶发失败"。
        //    参考工具那套 Frozen/Thawed N threads 就是这个意思。
        if (allow_freeze) {
            int n = freeze_others(pid, tid, &frozen);
            LOGI("freeze on: %d threads frozen", n);
        }

        c.svc = find_svc_gadget(tid, maps);
        c.trap = find_trap_gadget(tid, maps);
        c.libc_syscall = resolve_in_libs(maps, {"libc.so"}, "syscall");
        if (c.svc == 0 && c.trap == 0) {
            set_detail("目标里既找不到 svc 指令也找不到 brk 断点,无法做远程调用");
            result = ERR_REMOTE_SYSCALL_FAILED;
            break;
        }
        LOGI("svc=0x%llx trap=0x%llx",
             static_cast<unsigned long long>(c.svc), static_cast<unsigned long long>(c.trap));

        c.dlopen_addr = resolve_dlopen(maps, &c.is_loader);
        if (c.dlopen_addr == 0) {
            set_detail("解析不到 dlopen 地址(linker/libdl 不匹配)");
            result = ERR_DLOPEN_SYMBOL_NOT_FOUND;
            break;
        }

        // 1) 远程 mmap 一块临时页:路径 / 名字 / dlextinfo / 断点 / svc 桩 都放这儿
        SoInfo so = inspect_so(so_path);
        if (!so.valid) {
            set_detail("%s", so.why.c_str());
            result = ERR_SO_INVALID;
            break;
        }
        uint64_t local_size = so.size;
        LOGI("so ok: %llu bytes", static_cast<unsigned long long>(local_size));

        // 固定 32KB:路径(0x0)/ 名字(0x100)/ dlextinfo(0x400)/ 备用路径(0x800)/
        // 断点(0x2000)/ svc 桩(0x3000)。so 数据另开一块 64KB 缓冲,不跟这儿挤。
        uint64_t want = 0x8000;

        std::string alloc_why;
        uint64_t page = 0;
        if (!remote_alloc(c, want, PROT_READ | PROT_WRITE | PROT_EXEC, &page, &alloc_why)) {
            set_detail("远程申请临时内存失败:%s", alloc_why.c_str());
            result = ERR_MMAP_FAILED;
            break;
        }
        c.page = page;
        c.page_size = want;
        LOGI("remote page 0x%llx size 0x%llx", static_cast<unsigned long long>(c.page),
             static_cast<unsigned long long>(want));

        // 2) 写路径和断点,再把 svc 桩装上
        c.stub = c.page + 0x2000;
        const uint32_t trap = 0xD4200000u;  // brk #0
        if (!write_mem(tid, c.page, so_path, strlen(so_path) + 1) ||
            !write_mem(tid, c.stub, &trap, sizeof(trap))) {
            set_detail("往目标进程写数据失败");
            result = ERR_WRITE_REMOTE_FAILED;
            break;
        }
        // 这一步是关键:之后所有系统调用都走我们自己的 svc 桩,
        // 不再依赖"单步目标里的 svc 指令"(安卓 10 上那条最容易被信号打断)
        if (!install_syscall_trampoline(c)) {
            LOGI("trampoline install failed, fallback to inline svc/libc");
        }

        // 3) 路径加载
        uint64_t dl_args[2];
        dl_args[0] = c.page;
        dl_args[1] = RTLD_NOW | RTLD_GLOBAL;
        uint64_t handle = 0;
        int64_t memfd_fd = -1;
        bool ok = remote_call(tid, c.dlopen_addr, dl_args, 2, &handle, c.stub);
        if (!ok) {
            set_detail("远程 dlopen 调用崩了(目标线程状态异常)");
            result = ERR_DLOPEN_FAILED;
            break;
        }

        // 4) 路径失败 -> memfd 兜底(不依赖目标数据目录能不能写)
        if (handle == 0) {
            LOGI("dlopen(path) returned NULL, trying memfd");
            if (local_size > (64ull << 20)) {
                set_detail("so 太大(>64MB),memfd 通道跳过");
                result = ERR_DLOPEN_FAILED;
                break;
            }

            // memfd_create("z", 0)
            uint64_t name_addr = c.page + 0x100;
            if (!write_mem(tid, name_addr, "z", 2)) {
                set_detail("写 memfd 名字失败");
                result = ERR_WRITE_REMOTE_FAILED;
                break;
            }
            uint64_t memfd_args[2] = {name_addr, 0};
            SysRes fdr = do_syscall(c, 279 /* memfd_create */, memfd_args, 2);
            int64_t fd = fdr.ok ? fdr.val : -999;
            memfd_fd = fd;
            if (!fdr.ok || fd < 0) {
                if (!fdr.ok) {
                    set_detail("memfd_create 没执行成功:%s", fdr.why.c_str());
                } else if (fd == -22) {
                    set_detail("memfd_create 被内核拒绝(errno=22),这台机器可能禁用了匿名内存文件");
                } else if (fd == -1 || fd == -38) {
                    set_detail("memfd_create 不可用(errno=%lld),系统调用被拦",
                               static_cast<long long>(-fd));
                } else {
                    set_detail("memfd_create 失败(errno=%lld)", static_cast<long long>(-fd));
                }
                result = ERR_DLOPEN_FAILED;
                break;
            }

            // 数据缓冲单独开一块 64KB,不跟路径页挤在一起(同样三条通道都试)
            uint64_t buf_size = 64 * 1024;
            std::string buf_why;
            uint64_t buf_addr = 0;
            if (!remote_alloc(c, buf_size, PROT_READ | PROT_WRITE, &buf_addr, &buf_why)) {
                set_detail("给 so 数据申请目标内存失败:%s", buf_why.c_str());
                result = ERR_MMAP_FAILED;
                break;
            }

            // 路线 1:本机读 + 64KB 小步搬 + 顺序 write 进 memfd
            uint64_t written = 0;
            std::string why;
            bool copy_ok = false;
            int src = open(so_path, O_RDONLY | O_CLOEXEC);
            if (src >= 0) {
                copy_ok = copy_so_by_ptrace(c, src, fd, buf_addr, local_size, &written, &why);
                close(src);
            } else {
                why = "打开本机 so 失败";
            }
            // 路线 2:目标进程自读自写,数据全程不过我们的手
            if (!copy_ok) {
                std::string why2;
                uint64_t written2 = 0;
                LOGI("ptrace 搬运失败(%s,已写 %llu 字节),改走目标进程自读自写", why.c_str(),
                     static_cast<unsigned long long>(written));
                // 路线 1 可能已经写进去半截,把文件位置拨回 0 重写,不然拼出来是个坏 so
                uint64_t reset_args[3] = {static_cast<uint64_t>(fd), 0, 0 /* SEEK_SET */};
                do_syscall(c, 62 /* lseek(arm64) */, reset_args, 3);
                if (!write_mem(tid, c.page + 0x800, so_path, strlen(so_path) + 1)) {
                    why2 = "写 so 路径失败";
                } else if (copy_so_inside_target(c, c.page + 0x800, fd, buf_addr, local_size,
                                                 &written2, &why2)) {
                    copy_ok = true;
                    written = written2;
                }
                if (!copy_ok) {
                    set_detail("写 memfd 失败(写到第 %llu 字节,%s;目标自读自写:%s)",
                               static_cast<unsigned long long>(written), why.c_str(), why2.c_str());
                    result = ERR_WRITE_REMOTE_FAILED;
                    break;
                }
            }
            // 写完把文件位置拨回 0,不然 linker 从当前位置读,读出来是空壳
            uint64_t seek_args[3] = {static_cast<uint64_t>(fd), 0, 0 /* SEEK_SET */};
            do_syscall(c, 62 /* lseek(arm64) */, seek_args, 3);

            // 装载:android_dlopen_ext(USE_LIBRARY_FD) 优先,/proc/self/fd/<fd> 兜底
            LOGI("memfd 就绪 %llu/%llu 字节", static_cast<unsigned long long>(written),
                 static_cast<unsigned long long>(local_size));
            handle = load_from_memfd(c, maps, fd, "libinject_target.so");
            if (handle == 0) {
                set_detail("memfd 已写好 %llu 字节,但两种装载方式都没成功(so 依赖不全或 ABI 不符)",
                           static_cast<unsigned long long>(written));
                result = ERR_DLOPEN_FAILED;
                break;
            }
            LOGI("loaded from memfd fd=%lld", static_cast<long long>(fd));
        }

        LOGI("module loaded, handle=0x%llx%s", static_cast<unsigned long long>(handle),
             c.is_loader ? " via __loader_dlopen" : "");

        // 5) ART 没参与这条路,so 的 JNI_OnLoad 得我们自己补(菜单/线程通常都在这儿起)
        try_call_jni_onload(c, maps, handle, so_path);

        // 6) 需要主动调 entry 的话,顺手 dlsym 出来调一下
        if (entry_symbol != nullptr && entry_symbol[0] != '\0') {
            uint64_t dlsym_addr = resolve_in_libs(maps, {"libdl.so", "libdl_android.so", "libc.so"}, "dlsym");
            if (dlsym_addr != 0) {
                uint64_t sym_name = c.page + 0x400;
                if (write_mem(tid, sym_name, entry_symbol, strlen(entry_symbol) + 1)) {
                    uint64_t sym_args[2] = {handle, sym_name};
                    uint64_t fn = 0;
                    if (remote_call(tid, dlsym_addr, sym_args, 2, &fn, c.stub) && fn != 0) {
                        uint64_t ignored = 0;
                        remote_call(tid, fn, nullptr, 0, &ignored, c.stub);
                        LOGI("entry %s called", entry_symbol);
                    }
                }
            }
        }

        // 6) 收拾现场:把临时内存还回去、fd 关掉。
        //    dlopen 已经把 ELF 映射好,这块 RWX 临时页留着只会被反作弊当成"外挂内存",没必要。
        if (c.page != 0) {
            uint64_t un_args[2] = {c.page, c.page_size};
            SysRes un = do_syscall(c, 215 /* munmap */, un_args, 2);
            if (!un.ok) {
                uint64_t munmap_fn = resolve_in_libs(maps, {"libc.so", "libm.so"}, "munmap");
                if (munmap_fn != 0 && c.trap != 0) {
                    uint64_t ignored = 0;
                    remote_call(tid, munmap_fn, un_args, 2, &ignored, c.trap);
                }
            }
            c.page = 0;
        }
        // memfd 不关:USE_LIBRARY_FD 这条路是 linker 接管这个 fd 的(它自己会关),
        // 我们再去 close 一次有可能关到被复用的号上,索性留着(进程死了自然回收)。
        (void)memfd_fd;

        result = ERR_NONE;
    } while (false);

    // 收尾:先把冻住的线程全部放行,再还原现场让目标继续跑。
    // 失败也绝不把目标留在"PC 悬空 + 一堆线程冻着"的状态
    thaw_all(&frozen);
    detach_thread(tid, c.saved, restore);
    return result;
}

}  // namespace

const char* inject_last_detail() { return g_detail.c_str(); }

int inject_module(pid_t pid, const char* so_path, const char* entry_symbol) {
    clear_detail();

    if (pid <= 0 || so_path == nullptr || so_path[0] == '\0') {
        set_detail("目标进程不存在");
        return ERR_TARGET_NOT_FOUND;
    }
    if (strlen(so_path) >= 200) {
        set_detail("so 路径太长(%zu 字节)", strlen(so_path));
        return ERR_PATH_TOO_LONG;
    }

    std::vector<MapEntry> maps = parse_maps(pid);
    if (maps.empty()) {
        set_detail("读不到 /proc/%d/maps", pid);
        return ERR_TARGET_DIR_NOT_ACCESSIBLE;
    }

    if (!target_is64(maps)) {
        set_detail("目标进程是 32 位,这个注入器只带 64 位通道");
        return ERR_ABI_MISMATCH;
    }

    // 动手前先验 so:空文件(比如占位的 v0.26)/ 32 位 / 不是 ELF,在这儿就说清楚,
    // 别等调到一半再吐一句看不懂的 -1
    SoInfo so = inspect_so(so_path);
    if (!so.valid) {
        set_detail("%s", so.why.c_str());
        return ERR_SO_INVALID;
    }
    LOGI("so %s => %llu bytes, arm64 ok", so_path, static_cast<unsigned long long>(so.size));

    int last = ERR_UNKNOWN;
    // 两轮:
    //   第 1 轮 冻结其它线程(最稳,参考工具就是这么干的)
    //   第 2 轮 不冻结(万一冻住了正持有 linker 锁的线程,导致 dlopen 死锁,还能捞回来)
    for (int pass = 0; pass < 2; pass++) {
        const bool freeze = (pass == 0);
        std::vector<ThreadPick> threads = list_threads(pid);
        if (threads.empty()) {
            threads.push_back({pid, 'S'});
        }
        // 先挑睡着的线程(S/D)下手:它们停在 epoll/futex 里,
        // 停下时不在 malloc / linker / ART 的临界区中间,踩雷几率最低。
        std::stable_sort(threads.begin(), threads.end(), [](const ThreadPick& a, const ThreadPick& b) {
            auto nice = [](char st) { return (st == 'S' || st == 'D') ? 0 : 1; };
            return nice(a.state) < nice(b.state);
        });
        int tried = 0;
        int gone = 0;
        for (const auto& t : threads) {
            if (tried >= 8) break;   // 最多试 8 个线程
            tried++;
            LOGI("pass %d try tid=%d state=%c freeze=%d", pass, t.tid, t.state, freeze ? 1 : 0);
            int rc = inject_into_thread(pid, t.tid, maps, so_path, entry_symbol, freeze);
            if (rc == ERR_NONE) return ERR_NONE;
            last = rc;
            if (rc == ERR_ATTACH_GONE) { gone++; continue; }   // 线程没了,换下一个接着来
            // 下面这些是进程级/文件级问题,换线程换轮次都没用
            if (rc == ERR_ATTACH_DENIED || rc == ERR_SO_INVALID || rc == ERR_ABI_MISMATCH ||
                rc == ERR_PATH_TOO_LONG || rc == ERR_TARGET_DIR_NOT_ACCESSIBLE) {
                return rc;
            }
        }
        LOGI("pass %d done: tried %d thread(s), %d already gone", pass, tried, gone);
        if (last == ERR_ATTACH_DENIED) break;
    }
    return last;
}

#else  // 非 arm64 构建

const char* inject_last_detail() { return "这个构建只带 arm64 注入通道"; }

int inject_module(pid_t pid, const char* so_path, const char* entry_symbol) {
    (void) pid;
    (void) so_path;
    (void) entry_symbol;
    return ERR_ABI_MISMATCH;
}

#endif
