#ifndef HONFFX_INJECTOR_H
#define HONFFX_INJECTOR_H

#include <sys/types.h>

/**
 * 把 so 注入到 pid 里。
 *
 * @param pid           目标进程
 * @param so_path       目标进程能访问到的 so 绝对路径
 * @param entry_symbol  可选:加载成功后要调的导出符号(NULL / 空串 = 不调)
 * @return 0 成功,负数为失败码(见 injector.cpp 顶部枚举 / Kotlin 的 PtraceInjectFailure)
 */
int inject_module(pid_t pid, const char* so_path, const char* entry_symbol);

/** 最近一次注入的失败详情(给界面显示用),永远是有效字符串 */
const char* inject_last_detail();

#endif  // HONFFX_INJECTOR_H
