# Xposed 入口不能被混淆 / 删掉
-keep class com.tengcd.czr.xposed.** { *; }
-keep class com.tengcd.czr.inject.PtraceInjector { *; }

# native 方法对应的类要保持名字,否则 JNI 符号对不上
-keepclasseswithmembernames class * {
    native <methods>;
}

-keep class org.json.** { *; }
-dontwarn org.jetbrains.annotations.**
-dontwarn de.robv.android.xposed.**
