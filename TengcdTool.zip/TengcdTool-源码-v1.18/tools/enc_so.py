#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
内置 so 加密工具(电脑上用,需要 python3 + cryptography)。

用途:把你准备好的一份 so 加密成工程里 assets/so 需要的 .so.enc。
App 里解密靠的是代码里内置的密钥,所以**密钥不用你填,脚本里已经写死了**,
和 app/src/main/java/com/tengcd/czr/util/SoVault.kt 里的四段密钥 + 掩码完全对应。

用法:
    python3 tools/enc_so.py assets/so/v0.26.so
    -> 生成 assets/so/v0.26.so.enc (原名 + .enc),原明文建议删掉

批量:
    python3 tools/enc_so.py assets/so/*.so

自检(解密回去比对):
    python3 tools/enc_so.py --verify assets/so/v0.26.so.enc
"""
import hashlib
import hmac
import os
import secrets
import struct
import sys

# ---- 和 SoVault.kt 一一对应,别单方面改 ----
K1 = "6044c62328c79f79"
K2 = "d7a0c6228ef309d4"
K3 = "ff9eab9352589e8e"
K4 = "ba18db2d308aca80"
MASK = "337d501fc4e9085bc02931bbedec9218fbc6eb0e251b983c61641dfa3557a103"

MAGIC = b"TCD2"
VERSION = 1
# 和 SoVault.kt 的 APP_ID 一致:包名混进密钥派生,换包名的工程解不开
PKG = "com.tengcd.czr"


def master_key() -> bytes:
    mixed = bytes.fromhex(K1 + K2 + K3 + K4)
    mask = bytes.fromhex(MASK)
    secret = bytes(m ^ mask[i % len(mask)] for i, m in enumerate(mixed))
    return hashlib.sha256(secret + b"|TCD-SO-V2").digest()


MASTER = master_key()


def file_key(entry: str) -> bytes:
    return hmac.new(MASTER, ("k|" + PKG + "|" + entry).encode(), hashlib.sha256).digest()


def mac_key(entry: str) -> bytes:
    return hmac.new(MASTER, ("m|" + PKG + "|" + entry).encode(), hashlib.sha256).digest()


def encrypt_file(src: str, dst: str, entry_name: str = None) -> int:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    entry = entry_name or os.path.basename(dst)
    plain = open(src, "rb").read()
    if not plain.startswith(b"\x7fELF"):
        raise SystemExit(f"  [跳过] {src} 不是 ELF 文件")
    iv = secrets.token_bytes(16)
    enc = Cipher(algorithms.AES(file_key(entry)), modes.CTR(iv)).encryptor()
    ct = enc.update(plain) + enc.finalize()
    header = MAGIC + bytes([VERSION]) + iv + struct.pack(">I", len(ct))
    tag = hmac.new(mac_key(entry), header + ct, hashlib.sha256).digest()
    with open(dst, "wb") as f:
        f.write(header + ct + tag)
    return len(plain)


def decrypt_bytes(raw: bytes, entry: str) -> bytes:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    if raw[:4] != MAGIC or raw[4] != VERSION:
        raise SystemExit("  文件头不对,不是本工程的加密件")
    iv = raw[5:21]
    (n,) = struct.unpack(">I", raw[21:25])
    ct = raw[25:25 + n]
    tag = raw[25 + n:25 + n + 32]
    expect = hmac.new(mac_key(entry), raw[:25 + n], hashlib.sha256).digest()
    if not hmac.compare_digest(expect, tag):
        raise SystemExit("  HMAC 校验失败(密文被改过)")
    dec = Cipher(algorithms.AES(file_key(entry)), modes.CTR(iv)).decryptor()
    return dec.update(ct) + dec.finalize()


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1
    if argv[1] == "--verify":
        for path in argv[2:]:
            entry = os.path.basename(path)
            plain = decrypt_bytes(open(path, "rb").read(), entry)
            print(f"[OK] {path} -> {len(plain)} 字节,ELF 头 {plain[:4]!r}")
        return 0
    for src in argv[1:]:
        if src.endswith(".enc"):
            continue
        dst = src + ".enc"
        n = encrypt_file(src, dst)
        print(f"[加密] {src} -> {os.path.basename(dst)}  ({n} 字节明文)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
