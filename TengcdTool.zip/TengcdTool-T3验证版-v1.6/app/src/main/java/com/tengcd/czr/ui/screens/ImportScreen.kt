package com.tengcd.czr.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.SegmentedControl
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.components.liquidGlass
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.AccentPink
import com.tengcd.czr.ui.theme.AccentViolet
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.GlassBorderDark
import com.tengcd.czr.ui.theme.GlassBorderLight
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.WarnOrange
import com.tengcd.czr.util.AndroidVersion
import com.tengcd.czr.util.FolderImporter

/**
 * 资源导入页。
 *
 * 版式跟参考图一致:从上往下一列卡片——
 *   ① 顶部一段提示(粉紫渐变的小条)
 *   ② 原文件夹:点一下弹系统文件夹选择器,选完这里直接显示真实路径
 *   ③ 目标文件夹:同上,支持手输绝对路径
 *   ④ 覆盖方式:合并覆盖 / 清空后覆盖,下面挂通道与系统状态
 *   ⑤ 开始导入(覆盖)
 * 两栏并排的旧版式已经去掉,手机上竖着看更顺、路径也不会被挤成两行乱码。
 */
@Composable
fun ImportScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme

    // 手输路径弹窗:null = 关着,true = 改目标,false = 改源
    var pathDialogFor by remember { mutableStateOf<Boolean?>(null) }
    var pathDialogText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        // ---------------- 顶部提示条 ----------------
        ImportHint(text = s.importDesc, dark = dark)

        Spacer(Modifier.height(12.dp))

        // ---------------- 原文件夹 ----------------
        FolderPickCard(
            dark = dark,
            title = s.importSourcePane,
            accent = AccentBlue,
            icon = Icons.Filled.FolderOpen,
            path = state.importSourcePath,
            placeholder = s.importPickNone,
            selected = state.importSourceUri != null || state.importSourcePath.isNotBlank(),
            stats = sourceStats(state, s, dark),
            actionText = s.importManualPath,
            onCommit = { onAction(UiAction.SetImportPath(false, it)) }
        )

        Spacer(Modifier.height(10.dp))

        // ---------------- 目标文件夹 ----------------
        FolderPickCard(
            dark = dark,
            title = s.importTargetPane,
            accent = OkGreen,
            icon = Icons.Filled.Folder,
            path = state.importTargetPath,
            placeholder = s.importTargetHint,
            selected = state.importTargetUri != null || state.importTargetPath.isNotBlank(),
            stats = targetStats(state, s),
            actionText = s.importManualPath,
            onCommit = { onAction(UiAction.SetImportPath(true, it)) }
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text = s.importSwapHint,
            modifier = Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.labelSmall,
            fontSize = 11.sp,
            color = if (dark) TextSecondaryDark else TextSecondaryLight,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(Modifier.height(12.dp))

        // ---------------- 覆盖方式 ----------------
        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.FolderOpen, s.importModeTitle, dark)
            Spacer(Modifier.height(10.dp))
            SegmentedControl(
                options = listOf(s.importModeMerge, s.importModeReplace),
                selectedIndex = if (state.importReplaceAll) 1 else 0,
                dark = dark
            ) {
                if ((it == 1) != state.importReplaceAll) onAction(UiAction.ToggleImportReplaceAll)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (state.importReplaceAll) s.importModeReplaceDesc else s.importModeMergeDesc,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.5.sp,
                color = if (state.importReplaceAll) {
                    ErrRed
                } else {
                    if (dark) TextSecondaryDark else TextSecondaryLight
                }
            )

            if (state.importTargetPath.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                PathBox(
                    text = state.importTargetPath,
                    dark = dark,
                    accent = if (state.importReplaceAll) ErrRed else OkGreen
                )
            }

            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        (if (dark) GlassBorderDark else GlassBorderLight).copy(alpha = 0.5f)
                    )
            )
            Spacer(Modifier.height(6.dp))

            StatusRow(
                label = s.importChannel,
                value = channelLabel(state, s),
                dark = dark,
                dot = true,
                ok = state.writeChannelReady
            )
            StatusRow(
                label = s.androidVersionLabel,
                value = AndroidVersion.label(state.sdkInt),
                dark = dark,
                dot = false
            )
            StatusRow(
                label = s.shizukuStatus,
                value = when {
                    !state.shizukuInstalled -> s.importRootMissing
                    !state.shizukuGranted -> s.soNotReady
                    else -> s.importRootAvailable
                },
                dark = dark,
                dot = true,
                ok = state.shizukuGranted
            )

            if (!state.writeChannelReady) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = s.importNotReady,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarnOrange
                )
                if (state.shizukuInstalled && !state.shizukuGranted) {
                    Spacer(Modifier.height(8.dp))
                    SecondaryActionButton(
                        text = s.shizukuGrant,
                        icon = Icons.Filled.Lock,
                        dark = dark
                    ) { onAction(UiAction.GrantShizuku) }
                }
            }
        }

        // ---------------- 进度 ----------------
        if (state.importing || state.importFinished) {
            Spacer(Modifier.height(12.dp))
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.CloudUpload, s.importProgress, dark)
                Spacer(Modifier.height(10.dp))
                val total = state.importProgressTotal.coerceAtLeast(1)
                val progress = (state.importProgressFiles.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { if (state.importFinished) 1f else progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50)),
                    color = if (state.importFailed) ErrRed else OkGreen
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = s.importCopied + " " + state.importProgressFiles + " / " +
                            state.importProgressTotal,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.importFailed) ErrRed else OkGreen
                    )
                    Text(
                        text = FolderImporter.formatSize(state.importProgressBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                state.importChannelLabel?.takeIf { it.isNotBlank() }?.let { channel ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = s.importChannel + ": " + channel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
                state.importMessage?.takeIf { it.isNotBlank() }?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.importFailed) ErrRed else OkGreen
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        PrimaryActionButton(
            text = if (state.importing) s.importRunning else s.importStart,
            icon = Icons.Filled.CloudUpload,
            // 源有内容 + 目标有落点,才能开跑;选完文件夹立刻就能点
            enabled = !state.importing &&
                (state.importSourceUri != null || state.importSourcePath.isNotBlank()) &&
                (state.importTargetUri != null || state.importTargetPath.isNotBlank()),
            dark = dark
        ) { onAction(UiAction.RunImport) }

        Spacer(Modifier.height(24.dp))
    }

    // ---------------- 手输路径弹窗 ----------------
    val dialogTarget = pathDialogFor
    if (dialogTarget != null) {
        AlertDialog(
            onDismissRequest = { pathDialogFor = null },
            title = {
                Text(
                    text = if (dialogTarget) s.importTargetPane else s.importSourcePane,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
            },
            text = {
                Column {
                    OutlinedTextField(
                        value = pathDialogText,
                        onValueChange = { pathDialogText = it },
                        singleLine = false,
                        minLines = 2,
                        maxLines = 4,
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace
                        ),
                        placeholder = {
                            Text(
                                text = s.importManualHint,
                                style = MaterialTheme.typography.bodySmall
                            )
                        },
                        label = { Text(s.importPathDialogTitle) }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = s.importManualHint,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (dark) TextSecondaryDark else TextSecondaryLight
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onAction(UiAction.SetImportPath(dialogTarget, pathDialogText.trim()))
                    pathDialogFor = null
                }) {
                    Text(s.importPathDialogOk)
                }
            },
            dismissButton = {
                TextButton(onClick = { pathDialogFor = null }) {
                    Text(s.cancel)
                }
            }
        )
    }
}

/**
 * 顶部提示条:粉 → 紫的淡渐变 + 一圈细描边,跟参考图那块提示一个位置。
 * 纯装饰,不抢卡片的风头。
 */
@Composable
private fun ImportHint(text: String, dark: Boolean) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = if (dark) {
                        listOf(AccentPink.copy(alpha = 0.18f), AccentViolet.copy(alpha = 0.14f))
                    } else {
                        listOf(AccentPink.copy(alpha = 0.16f), AccentViolet.copy(alpha = 0.11f))
                    }
                )
            )
            .border(
                1.dp,
                (if (dark) GlassBorderDark else Color(0x66FFFFFF)),
                shape
            )
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.5.sp,
            lineHeight = 18.sp,
            color = if (dark) TextSecondaryDark else TextSecondaryLight
        )
    }
}

/**
 * 一张文件夹卡片:图标 + 标题,下面直接就是可编辑的路径输入框
 * (回车或者点右边「读取」就按这个路径去读),最底下是统计。
 * 选择文件夹那套已经去掉了,只走路径。
 */
@Composable
private fun FolderPickCard(
    dark: Boolean,
    title: String,
    accent: Color,
    icon: ImageVector,
    path: String,
    placeholder: String,
    selected: Boolean,
    stats: String,
    actionText: String,
    onCommit: (String) -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val boxShape = RoundedCornerShape(14.dp)
    val focus = LocalFocusManager.current
    var text by remember(path) { mutableStateOf(path) }
    val containerColor = accent.copy(alpha = if (dark) 0.14f else 0.07f)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlass(dark, 24)
            .padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        // 标题行
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(accent, accent.copy(alpha = 0.72f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (dark) TextPrimaryDark else TextPrimaryLight
            )
            Spacer(Modifier.weight(1f))
            if (selected) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(OkGreen.copy(alpha = if (dark) 0.22f else 0.14f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "已选",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = OkGreen
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // 路径输入框:直接改,回车就按这个路径去读
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = false,
            maxLines = 3,
            shape = boxShape,
            textStyle = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.5.sp,
                lineHeight = 16.sp,
                color = if (dark) TextPrimaryDark else TextPrimaryLight
            ),
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp
                )
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = {
                onCommit(text.trim())
                focus.clearFocus()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                unfocusedTextColor = if (dark) TextPrimaryDark else TextPrimaryLight,
                focusedContainerColor = containerColor,
                unfocusedContainerColor = containerColor,
                focusedBorderColor = accent,
                unfocusedBorderColor = accent.copy(alpha = if (selected) 0.55f else 0.32f),
                cursorColor = accent
            )
        )

        Spacer(Modifier.height(8.dp))

        // 统计 + 手输路径
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stats,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.5.sp,
                color = if (dark) TextSecondaryDark else TextSecondaryLight,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable {
                        onCommit(text.trim())
                        focus.clearFocus()
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = actionText,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    color = accent
                )
            }
        }
    }
}

/** 源文件夹那行统计:没选就提示一句 */
private fun sourceStats(state: UiState, s: LocalizedStrings, dark: Boolean): String {
    if (state.importSourceUri == null && state.importSourcePath.isBlank()) return s.importPickNone
    val files = state.importSourceFiles.coerceAtLeast(0)
    val size = FolderImporter.formatSize(state.importSourceBytes)
    val dirs = if (state.importSourceDirs > 0) " · ${s.importDirCount} ${state.importSourceDirs}" else ""
    return "$files ${s.importFileUnit} · $size$dirs"
}

/** 目标那行统计 */
private fun targetStats(state: UiState, s: LocalizedStrings): String {
    if (state.importTargetUri == null && state.importTargetPath.isBlank()) return s.importTargetMissing
    val files = state.importTargetFiles.coerceAtLeast(0)
    val size = FolderImporter.formatSize(state.importTargetBytes)
    return "$files ${s.importFileUnit} · $size"
}

/** 当前落盘通道显示名 */
private fun channelLabel(state: UiState, s: LocalizedStrings): String = when (state.writeChannel) {
    "root" -> s.importChannelRoot
    "shizuku" -> s.importChannelShizuku
    "direct" -> s.importChannelDirect
    else -> s.importChannelNone
}
