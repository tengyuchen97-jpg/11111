package com.tengcd.czr

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.i18n.Strings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.inject.PtraceInjectFailure
import com.tengcd.czr.network.AuthMode
import com.tengcd.czr.network.CardQueryInfo
import com.tengcd.czr.network.LocalCardGate
import com.tengcd.czr.network.T3Client
import com.tengcd.czr.network.T3Config
import com.tengcd.czr.network.T3Panel
import com.tengcd.czr.network.toCardInfo
import com.tengcd.czr.service.HandoffWakeReceiver
import com.tengcd.czr.service.InjectService
import com.tengcd.czr.ui.message
import com.tengcd.czr.util.FolderImporter
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import com.tengcd.czr.util.ServiceState
import com.tengcd.czr.util.ShareCodec
import com.tengcd.czr.util.ShizukuShell
import com.tengcd.czr.util.ShellUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

private const val HEARTBEAT_INTERVAL_MS = 3 * 60 * 1000L

/** 公告接口挂了、本地又没缓存时的兜底文案,保证公告栏永远不是空白 */
private const val DEFAULT_NOTICE = "暂无公告内容,点右上角「刷新」重新拉取。"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    /** 心跳任务 */
    private var heartbeatJob: Job? = null

    val strings: LocalizedStrings by lazy { Strings.of(Locale.getDefault().language) }

    init {
        val ctx = getApplication<Application>()
        InjectionPrefs.init(ctx)
        ModuleStore.ensureBundled(ctx)
        ServiceState.syncFromPrefs()

        _state.update {
            it.copy(
                darkTheme = InjectionPrefs.darkTheme,
                mode = InjectionMode.from(InjectionPrefs.injectionMode),
                cardKey = InjectionPrefs.cardKey,
                localCardMode = InjectionPrefs.localCardMode,
                targetPackage = InjectionPrefs.targetPackage,
                importTargetPath = InjectionPrefs.importTargetPath
                    .ifBlank { FolderImporter.DEFAULT_TARGET_PATH },
                importReplaceAll = InjectionPrefs.importReplaceAll,
                loginCard = InjectionPrefs.t3Card,
                loginToken = InjectionPrefs.t3Token,
                loggedIn = if (AuthMode.LOCAL_CARD) InjectionPrefs.cardKey.isNotBlank() else tokenStillValid()
            )
        }

        restoreImportDirs()
        observeServiceState()
        InjectService.start(ctx)
        refreshRuntime()
        if (tokenStillValid()) startHeartbeat()
        refreshNotice(silent = true)
        checkUpdate()
    }

    // ---------------- 对外入口 ----------------

    fun onAction(action: UiAction) {
        when (action) {
            is UiAction.SelectTab -> _state.update { it.copy(tab = action.tab) }
            UiAction.ToggleTheme -> {
                val next = !_state.value.darkTheme
                InjectionPrefs.darkTheme = next
                _state.update { it.copy(darkTheme = next) }
            }
            UiAction.Inject -> inject()
            UiAction.InjectAndLaunch -> injectAndLaunch()
            UiAction.LaunchTarget -> launchTarget()
            UiAction.RefreshRuntime -> refreshRuntime()
            UiAction.StartService -> InjectService.start(getApplication())
            is UiAction.SetMode -> {
                InjectionPrefs.injectionMode = action.mode.value
                _state.update { it.copy(mode = action.mode) }
            }
            is UiAction.SelectSoVariant -> selectSoVariant(action.variant)
            UiAction.PickLocalSo -> emit(UiEvent.PickLocalSoFile)
            UiAction.UseBuiltinSo -> useBuiltinSo()
            UiAction.UseLocalSo -> useLocalSo()
            UiAction.ClearLocalSo -> clearLocalSo()
            is UiAction.CardKeyChanged -> _state.update { it.copy(cardKey = action.text) }
            UiAction.QueryCard -> queryCard()
            UiAction.UnbindCard -> unbindCard()
            UiAction.GenerateShareCode -> generateShareCode()
            UiAction.DismissDialog -> Unit
            UiAction.PickImportSource -> pickImportDir(forTarget = false)
            UiAction.PickImportTarget -> pickImportDir(forTarget = true)
            is UiAction.SetImportPath -> setImportPath(action.forTarget, action.path)
            UiAction.ClearImportSource -> clearImportSource()
            UiAction.ToggleImportReplaceAll -> {
                val next = !_state.value.importReplaceAll
                InjectionPrefs.importReplaceAll = next
                _state.update { it.copy(importReplaceAll = next) }
            }
            UiAction.RunImport -> runImport()
            UiAction.GrantShizuku -> grantShizuku()
            is UiAction.LoginCardChanged ->
                _state.update { it.copy(loginCard = action.text, loginError = null) }
            UiAction.Login -> login()
            UiAction.Logout -> logout()
            UiAction.RefreshNotice -> refreshNotice()
            UiAction.CheckUpdate -> checkUpdate(manual = true)
            is UiAction.OpenUrl -> emit(UiEvent.OpenUrl(action.url))
        }
    }

    // ---------------- T3 网络验证 ----------------

    /** 上次的 token 还没过期就直接进首页 */
    private fun tokenStillValid(): Boolean {
        val token = InjectionPrefs.t3Token
        if (token.isBlank()) return false
        val expire = InjectionPrefs.t3Expire
        return expire <= 0L || expire > System.currentTimeMillis()
    }



    /** 本地卡密版的登录:不走网络,LocalCardGate 比对通过就放行 */
    private fun localLogin(card: String) {
        val ctx = getApplication<Application>()
        _state.update { it.copy(loginBusy = true, loginError = null) }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { LocalCardGate.bind(ctx, card) }
            val info = withContext(Dispatchers.IO) { LocalCardGate.query(ctx, card) }
            if (ok) {
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loggedIn = true,
                        loginError = null,
                        loginToken = "local",
                        loginExpire = info.expireTime.ifBlank { "永久" },
                        cardKey = card,
                        cardInfo = info,
                        tab = AppTab.HOME
                    )
                }
                emit(UiEvent.Toast(strings.loginSuccess))
                refreshRuntime()
            } else {
                val msg = when (info.message) {
                    "empty" -> strings.loginEmpty
                    "expired" -> strings.expired
                    "count_exhausted" -> strings.countExhausted
                    else -> strings.cardInvalid
                }
                _state.update { it.copy(loginBusy = false, loginError = msg) }
            }
        }
    }

    private fun login() {
        val cur = _state.value
        if (cur.loginBusy) return
        val card = cur.loginCard.trim()
        if (card.isEmpty()) {
            _state.update { it.copy(loginError = strings.loginEmpty) }
            return
        }
        // 本地卡密版:不联网,直接在本地比对
        if (AuthMode.LOCAL_CARD) {
            localLogin(card)
            return
        }
        // 服务器地址 / appkey / 编码集全部写死,界面没有任何修改入口
        val config = T3Config.official()
        if (!config.ready) {
            _state.update { it.copy(loginError = strings.loginNeedServer) }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(loginBusy = true, loginError = null) }
            val ctx = getApplication<Application>()
            val device = T3Client.deviceId(ctx)
            val result = T3Client.login(ctx, config, card, device)
            if (result.ok) {
                InjectionPrefs.t3Token = result.token
                // 服务端没返回到期时间时给个保守期限,免得一次登录就能永久离线使用;
                // 次数卡本来就没有到期时间,不能给它套 24 小时,否则第二天又要重新登录再扣一次
                val isCountCard = result.expireAt <= 0L && result.remainCount >= 0
                InjectionPrefs.t3Expire = when {
                    result.expireAt > 0L -> result.expireAt
                    isCountCard -> 0L
                    else -> System.currentTimeMillis() + 24L * 60L * 60L * 1000L
                }
                InjectionPrefs.t3Card = card
                InjectionPrefs.cardKey = card
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loggedIn = true,
                        loginError = null,
                        loginToken = result.token,
                        loginExpire = result.expireText.ifBlank {
                            if (isCountCard) "剩余 ${result.remainCount} 次" else ""
                        },
                        cardKey = card,
                        cardInfo = result.toCardInfo(card),
                        tab = AppTab.HOME
                    )
                }
                emit(UiEvent.Toast(strings.loginSuccess))
                startHeartbeat()
                refreshNotice(silent = true)
                refreshRuntime()
                checkUpdate()
            } else {
                val errText = result.message.ifBlank { strings.loginFailed }
                // 后台把「单码卡密登录」接口的卡密类型限成时长卡时,次数卡会被直接拒,
                // 这里把原因说清楚,省得看着一句「卡密类型不符」不知道去哪改
                val needTypeHint = errText.contains("类型") || errText.contains("次数") ||
                    errText.contains("计次") || errText.contains("时长")
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loginError = if (needTypeHint) {
                            "$errText\n(后台该登录接口的「卡密类型」要勾上次数卡或通用)"
                        } else errText
                    )
                }
            }
        }
    }

    private fun logout(requestServer: Boolean = true) {
        stopHeartbeat()
        viewModelScope.launch {
            val config = T3Config.official()
            val token = InjectionPrefs.t3Token
            val ctx = getApplication<Application>()
            if (!AuthMode.LOCAL_CARD && requestServer && config.ready && token.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        T3Client.heartbeat(config, token, T3Client.deviceId(ctx), InjectionPrefs.t3Card)
                    }
                }
            }
            InjectionPrefs.t3Token = ""
            InjectionPrefs.t3Expire = 0L
            _state.update {
                it.copy(
                    loggedIn = false,
                    loginToken = "",
                    loginExpire = "",
                    loginError = null,
                    tab = AppTab.HOME,
                    cardInfo = null
                )
            }
        }
    }

    /** 服务端说卡不能用了:直接踢回验证页,别再让人以为还登着 */
    private fun forceLogout(reason: String) {
        stopHeartbeat()
        InjectionPrefs.t3Token = ""
        InjectionPrefs.t3Expire = 0L
        _state.update {
            it.copy(
                loggedIn = false,
                loginToken = "",
                loginExpire = "",
                cardInfo = null,
                tab = AppTab.HOME,
                loginError = reason.ifBlank { strings.loginFailed }
            )
        }
        emit(UiEvent.Toast(reason.ifBlank { strings.loginFailed }))
    }

    // ---------------- 心跳 / 公告 ----------------

    /** 心跳:每 3 分钟问一次,连不上 3 次才踢,被服务端明确判死立刻踢 */
    private fun startHeartbeat() {
        stopHeartbeat()
        if (AuthMode.LOCAL_CARD) return   // 本地版没有心跳,不联网
        heartbeatJob = viewModelScope.launch {
            var fails = 0
            while (isActive) {
                delay(HEARTBEAT_INTERVAL_MS)
                val config = T3Config.official()
                val token = InjectionPrefs.t3Token
                if (!config.ready || token.isBlank()) break
                val ctx = getApplication<Application>()
                val result = runCatching {
                    T3Client.heartbeat(config, token, T3Client.deviceId(ctx), InjectionPrefs.t3Card)
                }.getOrNull()

                if (result == null) {
                    fails++
                    if (fails >= 3) {
                        forceLogout(strings.checkNetwork)
                        break
                    }
                    continue
                }
                if (result.ok) {
                    fails = 0
                    if (result.expireAt > 0L) InjectionPrefs.t3Expire = result.expireAt
                    _state.update { cur ->
                        val info = cur.cardInfo
                        cur.copy(
                            loginExpire = result.expireText.ifBlank { cur.loginExpire },
                            cardInfo = info?.copy(
                                expireTime = result.expireText.ifBlank { info.expireTime },
                                remainCount = if (result.remainCount >= 0) result.remainCount else info.remainCount,
                                unbindCount = if (result.unbindCount >= 0) result.unbindCount else info.unbindCount,
                                boundDevice = result.boundDevice.ifBlank { info.boundDevice }
                            )
                        )
                    }
                } else if (result.banned || result.expired || result.exhausted) {
                    // 只有服务端明确说「封了 / 过期 / 次数用完」才踢人
                    forceLogout(result.message)
                    break
                } else {
                    // 次数卡在部分后台没开心跳接口,回个参数错是正常的,不能拿来踢人
                    fails++
                    if (fails >= 5) {
                        // 连续失败就停心跳,会话保留,别把用户踹回验证页
                        break
                    }
                }
            }
        }
    }

    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    // ---------------- 版本更新 ----------------

    /**
     * 版本检查:直接问后台「检测版本是否最新版」,把本机版本(T3Panel.CLIENT_VER)发过去。
     * 后台返回新的版本号 → 弹更新框;返回「已是最新版」→ 不弹。
     * 后台只配了「最新版序号」接口时,退回去拿它跟本机版本比。
     */
    private fun checkUpdate(manual: Boolean = false) {
        if (AuthMode.LOCAL_CARD) {
            // 本地版不依赖后台,更新交给安装包自己发
            if (manual) emit(UiEvent.Toast("本地版不联网检查更新"))
            return
        }
        val config = T3Config.official()
        if (!config.ready) return
        if (_state.value.updateChecking) return

        // 这一版在后台对应的版本号(和后台最新版号对齐,发新版时改 T3Panel.CLIENT_VER)
        val localVer = T3Panel.CLIENT_VER

        viewModelScope.launch {
            _state.update { it.copy(updateChecking = true, localVersion = localVer) }

            var latest = ""
            var needUpdate = false
            var logText = ""
            var downUrl = ""

            // ① 首选:检测版本(后台自己比,最准)
            val chk = runCatching { T3Client.checkVersion(config, localVer) }.getOrNull()
            if (chk != null && chk.reached) {
                val msg = chk.message
                val alreadyNew = msg.contains("已是最新") || msg.contains("最新版") && !chk.ok
                if (chk.version.isNotBlank() && compareVersion(chk.version, localVer) > 0) {
                    latest = chk.version
                    needUpdate = true
                } else if (!chk.ok && !alreadyNew &&
                    (msg.contains("新版本") || msg.contains("升级") || msg.contains("更新"))
                ) {
                    // 后台只说「有新版本」没给号,也算要更新
                    needUpdate = true
                    latest = chk.version
                }
                if (chk.updateLog.isNotBlank()) logText = chk.updateLog
                if (chk.updateUrl.isNotBlank()) downUrl = chk.updateUrl
            }

            // ② 兜底:后台没配「检测版本」接口(参数错/接口不存在)时,问「最新版序号」自己比
            if (!needUpdate) {
                val latestRes = runCatching { T3Client.latestVersion(config) }.getOrNull()
                if (latestRes != null && latestRes.ok && latestRes.version.isNotBlank()) {
                    if (compareVersion(latestRes.version, localVer) > 0) {
                        latest = latestRes.version
                        needUpdate = true
                    }
                    if (logText.isBlank() && latestRes.updateLog.isNotBlank()) {
                        logText = latestRes.updateLog
                    }
                    if (downUrl.isBlank() && latestRes.updateUrl.isNotBlank()) {
                        downUrl = latestRes.updateUrl
                    }
                }
            }

            _state.update {
                it.copy(
                    updateChecking = false,
                    localVersion = localVer,
                    latestVersion = latest
                )
            }

            if (!needUpdate) {
                if (manual) emit(UiEvent.Toast("已经是最新版本 $localVer"))
                return@launch
            }

            // 同一版本只自动弹一次,手动检查每次都给
            val prompted = InjectionPrefs.updatePromptedVersion
            if (!manual && latest.isNotBlank() && prompted == latest) return@launch
            if (latest.isNotBlank()) InjectionPrefs.updatePromptedVersion = latest

            // 弹框正文优先用后台「检测版本」的更新说明,其次公告,最后兜一句
            val notice = logText.ifBlank {
                _state.value.announcement.orEmpty()
            }.ifBlank {
                InjectionPrefs.t3NoticeCache
            }.ifBlank {
                if (latest.isNotBlank()) "检测到新版本 v$latest,更新后继续使用。" else "检测到新版本,更新后继续使用。"
            }
            val url = downUrl.ifBlank { InjectionPrefs.updateUrl }
                .ifBlank { firstUrl(notice) }
                .ifBlank { firstUrl(logText) }

            emit(
                UiEvent.UpdatePrompt(
                    localVersion = localVer,
                    latestVersion = latest.ifBlank { "最新版" },
                    announcement = notice,
                    url = url
                )
            )
        }
    }

    /** 从一段文字里捞第一个 http 链接(公告里经常直接写下载地址) */
    private fun firstUrl(text: String): String {
        if (text.isBlank()) return ""
        val m = Regex("""https?://[^\s,，。;；"'<>()（）]+""").find(text) ?: return ""
        return m.value.trimEnd('.', '。', ',', '，')
    }

    /** 1.10 > 1.9,按段比,缺失段当 0 */
    private fun compareVersion(a: String, b: String): Int {
        val pa = a.split('.', '-', '_').mapNotNull { it.trim().toIntOrNull() }
        val pb = b.split('.', '-', '_').mapNotNull { it.trim().toIntOrNull() }
        val n = maxOf(pa.size, pb.size)
        for (i in 0 until n) {
            val x = pa.getOrElse(i) { 0 }
            val y = pb.getOrElse(i) { 0 }
            if (x != y) return if (x > y) 1 else -1
        }
        return 0
    }

    /** 公告:走 T3 的公告接口,拉不到就显示上次缓存的 */
    private fun refreshNotice(silent: Boolean = false) {
        if (AuthMode.LOCAL_CARD) {
            // 本地卡密版也要有公告:先把上次缓存的那份铺上(断网也有内容),
            // 再后台静默拉一次最新的。拉不到就保持缓存,不影响进 App。
            val cached = InjectionPrefs.t3NoticeCache
            _state.update {
                it.copy(
                    announcement = cached.ifBlank { AuthMode.LOCAL_NOTICE },
                    announcementUpdated = InjectionPrefs.t3NoticeTime,
                    announcementLoading = false,
                    announcementFailed = false
                )
            }
            viewModelScope.launch {
                val config = T3Config.official()
                if (!config.ready) return@launch
                val result = runCatching {
                    T3Client.notice(config, InjectionPrefs.t3Card, InjectionPrefs.t3Token)
                }.getOrNull()
                if (result != null && result.ok && result.notice.isNotBlank()) {
                    InjectionPrefs.t3NoticeCache = result.notice
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = result.notice,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
            }
            return
        }
        val config = T3Config.official()
        val cached = InjectionPrefs.t3NoticeCache
        _state.update {
            it.copy(
                announcement = it.announcement ?: cached.ifBlank { null },
                announcementUpdated = InjectionPrefs.t3NoticeTime,
                announcementLoading = true,
                announcementFailed = false
            )
        }
        viewModelScope.launch {
            if (!config.ready) {
                _state.update {
                    it.copy(
                        announcementLoading = false,
                        announcementFailed = cached.isBlank() && !silent
                    )
                }
                return@launch
            }
            val result = runCatching {
                T3Client.notice(config, InjectionPrefs.t3Card, InjectionPrefs.t3Token)
            }.getOrNull()

            when {
                result == null || !result.ok -> {
                    _state.update {
                        it.copy(
                            announcementLoading = false,
                            announcement = cached.ifBlank { it.announcement ?: DEFAULT_NOTICE },
                            announcementFailed = false
                        )
                    }
                }
                result.notice.isBlank() -> {
                    // 接口通了,后台没写公告
                    InjectionPrefs.t3NoticeCache = ""
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = null,
                            announcementLoading = false,
                            announcementFailed = false,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
                else -> {
                    InjectionPrefs.t3NoticeCache = result.notice
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = result.notice,
                            announcementLoading = false,
                            announcementFailed = false,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
            }
        }
    }

    private fun nowText(): String =
        java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
            .format(java.util.Date())

    // ---------------- 运行态 ----------------

    private fun observeServiceState() {
        viewModelScope.launch {
            ServiceState.frameworkActive.collect { active ->
                _state.update { it.copy(frameworkActive = active) }
            }
        }
        viewModelScope.launch {
            ServiceState.serviceRunning.collect { running ->
                _state.update { it.copy(serviceRunning = running) }
            }
        }
    }

    fun refreshRuntime() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val target = InjectionPrefs.targetPackage
            val info = withContext(Dispatchers.IO) {
                val pids = PackageUtil.findPids(target)
                val dataDir = PackageUtil.dataDir(ctx, target)
                val label = try {
                    val pm = ctx.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(target, 0)).toString()
                } catch (t: Throwable) {
                    ""
                }
                RuntimeInfo(
                    installed = PackageUtil.isInstalled(ctx, target),
                    label = label,
                    pids = pids,
                    dirWritable = PermissionUtil.canWriteDir(File(dataDir ?: "", "files")),
                    sameUid = PackageUtil.sameUid(ctx, target),
                    rootAvailable = FolderImporter.hasRoot(),
                    channel = FolderImporter.channelState(
                        ctx,
                        InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH }
                    ),
                    importDirWritable = FolderImporter.canWrite(
                        File(InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH })
                    )
                )
            }
            // 本地 so 没了的场景:自动退回内置,不然「本地」被隐藏后两个格子都不亮
            if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                !ModuleStore.localFile(ctx).isFile
            ) {
                InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
            }
            _state.update {
                it.copy(
                    targetPackage = target,
                    targetLabel = info.label,
                    targetInstalled = info.installed,
                    targetRunning = info.pids.isNotEmpty(),
                    targetPid = info.pids.firstOrNull() ?: -1,
                    targetDirAccessible = info.dirWritable,
                    sameUid = info.sameUid,
                    localModuleReady = ModuleStore.isDownloaded(ctx),
                    localModulePath = ModuleStore.effectiveFile(ctx).absolutePath,
                    moduleVersion = InjectionPrefs.moduleVersion,
                    moduleMd5 = InjectionPrefs.moduleMd5,
                    remoteVersion = InjectionPrefs.remoteVersion,
                    soVariants = ModuleStore.BUILTIN_VARIANTS,
                    selectedSo = InjectionPrefs.soVariant,
                    soSource = InjectionPrefs.soSource,
                    activeSoPath = InjectionPrefs.modulePath,
                    localSoSourcePath = readableSoPath(InjectionPrefs.localSoSourcePath),
                    localSoReady = ModuleStore.localFile(ctx).isFile,
                    soSize = ModuleStore.currentInfo(ctx).size,
                    soValid = ModuleStore.currentInfo(ctx).ready,
                    soPlaceholder = ModuleStore.currentInfo(ctx).placeholder,
                    frameworkError = InjectionPrefs.frameworkError,
                    frameworkLoadedPath = InjectionPrefs.frameworkPath,
                    writeChannel = info.channel.label,
                    writeChannelReady = info.channel.ready,
                    shizukuInstalled = info.channel.shizukuInstalled,
                    shizukuGranted = info.channel.shizukuGranted,
                    sdkInt = info.channel.sdkInt,
                    frameworkInstalled = XposedDetector.isFrameworkInstalled(ctx),
                    frameworkActive = InjectionPrefs.frameworkActive,
                    serviceRunning = ServiceState.serviceRunning.value,
                    rootAvailable = info.rootAvailable,
                    targetDirWritable = info.importDirWritable
                )
            }
        }
    }

    private data class RuntimeInfo(
        val installed: Boolean,
        val label: String,
        val pids: List<Int>,
        val dirWritable: Boolean,
        val sameUid: Boolean,
        val rootAvailable: Boolean,
        val importDirWritable: Boolean,
        val channel: FolderImporter.ChannelState
    )

    // ---------------- 写入通道 ----------------

    /** 申请 Shizuku 授权(界面收到事件后拉起授权框) */
    private fun grantShizuku() {
        val ctx = getApplication<Application>()
        if (!ShizukuShell.installed(ctx)) {
            emit(UiEvent.Toast(strings.shizukuNotInstalled))
            return
        }
        if (!ShizukuShell.alive()) {
            emit(UiEvent.Toast(strings.shizukuNotRunning))
            return
        }
        if (ShizukuShell.granted()) {
            emit(UiEvent.Toast(strings.shizukuGranted))
            refreshRuntime()
            return
        }
        emit(UiEvent.RequestShizukuPermission)
    }

    /** 授权结果回来 */
    fun onShizukuResult(granted: Boolean) {
        emit(UiEvent.Toast(if (granted) strings.shizukuGranted else strings.shizukuDenied))
        refreshRuntime()
    }

    // ---------------- 注入 ----------------

    private fun inject() {
        val current = _state.value
        if (current.injecting) return

        // 注入前不再弹任何"请更新 / 请先准备"的对话框,也不再拿"模块没就绪"拦人:
        // 直接用当前选中的那份 SO 往里打,缺的东西下面现补。
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }

        viewModelScope.launch {
            val ctx = getApplication<Application>()
            // 进程注入要求目标真在跑:现场查一次 pid,不依赖界面状态(一键注入刚拉起游戏时状态还没刷新)
            if (current.mode == InjectionMode.PROCESS) {
                val running = withContext(Dispatchers.IO) {
                    PackageUtil.findPids(current.targetPackage).isNotEmpty()
                }
                if (!running) {
                    emit(UiEvent.Toast(strings.targetNotRunning))
                    return@launch
                }
            }
            withContext(Dispatchers.IO) {
                // 本机 SO 被删了就自动退回内置;内置变体没铺过的现铺一遍
                if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                    !ModuleStore.localFile(ctx).isFile
                ) {
                    InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
                }
                ModuleStore.ensureBundled(ctx)
                ModuleStore.refreshPrefs(ctx)
            }
            _state.update { it.copy(injecting = true) }
            emit(UiEvent.Toast(strings.injectRunning))
            ServiceState.lastInjectOk.value = null
            InjectService.inject(
                getApplication(),
                current.mode,
                current.targetPackage
            )
            val ok = awaitInjectResult()
            val raw = ServiceState.lastInjectDetail.value
            val kind = raw
                ?.let { runCatching { PtraceInjectFailure.valueOf(it.substringBefore(':')) }.getOrNull() }
                ?: PtraceInjectFailure.UNKNOWN
            val detail = raw?.substringAfter(':', "")?.trim()?.takeIf { it.isNotEmpty() }
            _state.update { it.copy(injecting = false, injectDetail = detail) }
            if (ok == true) {
                emit(UiEvent.Toast(strings.injectDone))
            } else {
                emit(UiEvent.Toast(kind.message(strings)))
            }
            refreshRuntime()
        }
    }

    private suspend fun awaitInjectResult(): Boolean? {
        repeat(25) {
            delay(300)
            ServiceState.lastInjectOk.value?.let { return it }
        }
        return ServiceState.lastInjectOk.value
    }

    /**
     * 一键:注入 + 启动游戏。
     *
     * 进程注入要求目标已经在跑,所以先起游戏、等它把进程拉起来再附加;
     * 框架注入是目标启动时由模块自己加载,那就先把 SO/模块准备好再起游戏。
     */
    private fun injectAndLaunch() {
        val current = _state.value
        if (current.injecting) return
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }
        val ctx = getApplication<Application>()

        if (current.mode == InjectionMode.PROCESS) {
            if (!PackageUtil.launch(ctx, current.targetPackage)) {
                emit(UiEvent.Toast(strings.targetNotFound))
                return
            }
            viewModelScope.launch {
                // 等游戏进程真的起来,再去附加(最多等 8 秒)
                var up = false
                var waited = 0
                while (waited < 16) {
                    delay(500)
                    waited++
                    val pids = withContext(Dispatchers.IO) {
                        PackageUtil.findPids(current.targetPackage)
                    }
                    if (pids.isNotEmpty()) {
                        up = true
                        break
                    }
                }
                if (!up) {
                    emit(UiEvent.Toast(strings.targetNotRunning))
                    refreshRuntime()
                    return@launch
                }
                refreshRuntime()
                inject()
            }
        } else {
            inject()
            viewModelScope.launch {
                delay(1200)
                launchTarget()
            }
        }
    }

    private fun launchTarget() {
        val current = _state.value
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.installTargetFirst))
            return
        }
        val ctx = getApplication<Application>()
        val launched = PackageUtil.launch(ctx, current.targetPackage)
        if (!launched) {
            emit(UiEvent.Toast(strings.targetNotFound))
            return
        }
        if (current.mode == InjectionMode.PROCESS) {
            viewModelScope.launch {
                delay(3000)
                HandoffWakeReceiver.send(ctx, current.mode, current.targetPackage)
                refreshRuntime()
            }
        }
    }

    // ---------------- SO 选择 ----------------

    /** 选中哪个变体,注入就用哪个 */
    private fun selectSoVariant(variant: String) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, variant) }
            _state.update {
                it.copy(
                    selectedSo = variant,
                    soSource = InjectionPrefs.SO_SOURCE_BUILTIN,
                    activeSoPath = InjectionPrefs.modulePath
                )
            }
            emit(UiEvent.Toast(strings.soSwitchedTo + " " + variant))
            refreshRuntime()
        }
    }

    /** 从"本机 SO"切回内置变体 */
    private fun useBuiltinSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, _state.value.selectedSo) }
            emit(UiEvent.Toast(strings.soSwitchedBuiltin))
            refreshRuntime()
        }
    }

    /** 已经导入过本机 SO 的话,直接切过去用,不必再选一次文件 */
    private fun useLocalSo() {
        val ctx = getApplication<Application>()
        if (!ModuleStore.localFile(ctx).isFile) {
            emit(UiEvent.PickLocalSoFile)
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoSwitched))
            refreshRuntime()
        }
    }

    private fun clearLocalSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.clearLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoCleared))
            refreshRuntime()
        }
    }

    /**
     * 老版本把 content:// 原始串直接存进了偏好,界面上是一长串 %E6%87%82 的转义,
     * 看着跟加密数据一样。读出来的时候统一还原成人能读的路径。
     */
    private fun readableSoPath(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        if (!raw.startsWith("content://", ignoreCase = true)) return raw
        val ctx = getApplication<Application>()
        return runCatching {
            FolderImporter.fileDisplayPath(ctx, Uri.parse(raw))
        }.getOrDefault(Uri.decode(raw))
    }

    /** 界面把用户从本机挑中的那个 so 交过来(文件选择器回调) */
    fun onLocalSoPicked(uri: Uri?) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val input = ctx.contentResolver.openInputStream(uri)
                        ?: return@withContext null
                    // uri.toString() 是百分号转义串,界面上看着像乱码,先换成能读的路径
                    ModuleStore.importLocalSo(ctx, input, FolderImporter.fileDisplayPath(ctx, uri))
                } catch (t: Throwable) {
                    null
                }
            }
            if (saved == null) {
                emit(UiEvent.Toast(strings.localSoFailed))
            } else {
                emit(UiEvent.Toast(strings.localSoLoaded))
            }
            refreshRuntime()
        }
    }

    // ---------------- 卡密 ----------------

    private fun queryCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (AuthMode.LOCAL_CARD) {
                val raw = withContext(Dispatchers.IO) { LocalCardGate.query(ctx, card) }
                val info = if (raw.valid) raw else raw.copy(
                    message = when (raw.message) {
                        "empty" -> strings.loginEmpty
                        "invalid" -> strings.cardInvalid
                        "expired" -> strings.expired
                        "count_exhausted" -> strings.countExhausted
                        else -> raw.message.ifBlank { strings.cardInvalid }
                    }
                )
                _state.update { it.copy(cardQuerying = false, cardInfo = info) }
                if (info.valid) {
                    InjectionPrefs.cardKey = card
                    emit(UiEvent.Toast(strings.loginSuccess))
                } else {
                    emit(UiEvent.Toast(strings.cardInvalid))
                }
                return@launch
            }

            val config = T3Config.official()
            if (!config.ready) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.loginNeedServer))
                return@launch
            }

            // 次数卡别走「单码卡密查询」:那个调用码就是登录接口,再查一次等于再登录一次,
            // 后台会再扣一次次数。次数卡改成用心跳接口刷新剩余次数,只查不扣。
            val cur = _state.value.cardInfo
            val countCard = cur != null && cur.card == card && cur.remainCount >= 0 &&
                InjectionPrefs.t3Expire <= 0L
            val token = InjectionPrefs.t3Token

            // 兜一层:极端网络卡死时 20 秒也要把「请求中」放下来
            val result = withTimeoutOrNull(20_000L) {
                if (countCard && token.isNotBlank()) {
                    T3Client.heartbeat(config, token, T3Client.deviceId(ctx), card)
                } else {
                    T3Client.query(
                        config = config,
                        card = card,
                        deviceId = T3Client.deviceId(ctx),
                        token = token
                    )
                }
            }
            if (result == null) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.networkFailed))
                return@launch
            }
            // 查询接口没探通时,别把登录时拿到的那份信息清掉;
            // 心跳刷回来的数据可能不全(比如没有到期时间),缺的字段用上一份补
            val fresh = result.toCardInfo(card)
            val prev = _state.value.cardInfo?.takeIf { it.card == card }
            val info = when {
                !result.ok && !result.reached -> prev ?: fresh
                prev == null -> fresh
                else -> fresh.copy(
                    expireTime = fresh.expireTime.ifBlank { prev.expireTime },
                    remainCount = if (fresh.remainCount >= 0) fresh.remainCount else prev.remainCount,
                    unbindCount = if (fresh.unbindCount >= 0) fresh.unbindCount else prev.unbindCount,
                    boundDevice = fresh.boundDevice.ifBlank { prev.boundDevice },
                    valid = fresh.valid || prev.valid
                )
            }
            _state.update { it.copy(cardQuerying = false, cardInfo = info) }
            if (info.valid) {
                InjectionPrefs.cardKey = card
                emit(UiEvent.Toast(strings.loginSuccess))
            } else if (info.banned) {
                emit(UiEvent.Toast(strings.banned))
            } else if (info.message == "expired") {
                emit(UiEvent.Toast(strings.expired))
            } else if (info.message == "count_exhausted") {
                emit(UiEvent.Toast(strings.countExhausted))
            } else {
                emit(UiEvent.Toast(result.message.ifBlank { strings.cardInvalid }))
            }
        }
    }

    private fun unbindCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (AuthMode.LOCAL_CARD) {
                val ok = withContext(Dispatchers.IO) { LocalCardGate.unbind(ctx, card) }
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(if (ok) strings.unbindSuccess else strings.cardInvalid))
                if (ok) queryCard()
                return@launch
            }

            val config = T3Config.official()
            if (!config.ready) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.loginNeedServer))
                return@launch
            }

            val result = T3Client.unbind(
                config = config,
                card = card,
                deviceId = T3Client.deviceId(ctx),
                token = InjectionPrefs.t3Token
            )
            _state.update { it.copy(cardQuerying = false) }
            if (result.ok) {
                emit(UiEvent.Toast(strings.unbindSuccess))
                queryCard()
            } else {
                emit(UiEvent.Toast(result.message.ifBlank { strings.requestFailed }))
            }
        }
    }

    private fun generateShareCode() {
        val payload = buildString {
            append("pkg=").append(InjectionPrefs.targetPackage).append(';')
            append("so=").append(_state.value.localModulePath ?: "").append(';')
            append("card=").append(_state.value.cardKey)
        }
        val code = ShareCodec.encode(payload)
        _state.update { it.copy(shareCode = code) }
        emit(UiEvent.Toast(strings.copied))
    }


    // ---------------- 资源导入(左源文件夹 -> 右目标文件夹 覆盖) ----------------

    private fun pickImportDir(forTarget: Boolean) = emit(UiEvent.PickFolderTree(forTarget))

    /** 界面把选中的源文件夹交过来(SAF 回调) */
    fun onImportSourcePicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (t: Throwable) {
                // 有些 ROM 的 DocumentsUI 不给持久权限,这一轮能读就行
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importSourceUri = uri.toString()
            _state.update {
                it.copy(
                    importSourceUri = uri.toString(),
                    importSourcePath = stat.path,
                    importSourceName = stat.name,
                    importSourceFiles = stat.files,
                    importSourceDirs = stat.dirs,
                    importSourceBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importSourcePicked + " · " + stat.files + " " + strings.importFileUnit))
            }
        }
    }

    /** 界面把选中的目标文件夹交过来(SAF 回调) */
    fun onImportTargetPicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (t: Throwable) {
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importTargetUri = uri.toString()
            InjectionPrefs.importTargetPath = ""
            _state.update {
                it.copy(
                    importTargetUri = uri.toString(),
                    importTargetPath = stat.path,
                    importTargetName = stat.name,
                    importTargetFiles = stat.files,
                    importTargetBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importTargetPicked))
            }
            refreshRuntime()
        }
    }

    /** 手输绝对路径(Android/data 这类 SAF 选不到的地方走这条) */
    private fun setImportPath(forTarget: Boolean, raw: String) {
        val path = raw.trim().trimEnd('/')
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            if (path.isBlank()) {
                if (forTarget) {
                    InjectionPrefs.importTargetUri = null
                    InjectionPrefs.importTargetPath = ""
                    _state.update {
                        it.copy(
                            importTargetUri = null, importTargetPath = "",
                            importTargetName = "", importTargetFiles = 0, importTargetBytes = 0
                        )
                    }
                }
                return@launch
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statPath(File(path)) }
            if (forTarget) {
                InjectionPrefs.importTargetUri = null
                InjectionPrefs.importTargetPath = path
                _state.update {
                    it.copy(
                        importTargetUri = null,
                        importTargetPath = path,
                        importTargetName = stat.name,
                        importTargetFiles = stat.files,
                        importTargetBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(
                    UiEvent.Toast(
                        if (File(path).isDirectory) strings.importTargetSet
                        else strings.importTargetWillCreate
                    )
                )
            } else {
                if (!File(path).isDirectory) {
                    emit(UiEvent.Toast(strings.importNoAccess))
                    return@launch
                }
                InjectionPrefs.importSourceUri = null
                _state.update {
                    it.copy(
                        importSourceUri = null,
                        importSourcePath = path,
                        importSourceName = stat.name,
                        importSourceFiles = stat.files,
                        importSourceDirs = stat.dirs,
                        importSourceBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(UiEvent.Toast(strings.importSourcePicked))
            }
            refreshRuntime()
        }
    }

    private fun clearImportSource() {
        InjectionPrefs.importSourceUri = null
        _state.update {
            it.copy(
                importSourceUri = null,
                importSourcePath = "",
                importSourceName = "",
                importSourceFiles = 0,
                importSourceDirs = 0,
                importSourceBytes = 0L,
                importFinished = false,
                importFailed = false,
                importMessage = null
            )
        }
    }

    /** 冷启动把上次的源/目标找回来 */
    private fun restoreImportDirs() {
        InjectionPrefs.importSourceUri?.let { onImportSourcePicked(Uri.parse(it), silent = true) }
        val targetUri = InjectionPrefs.importTargetUri
        if (!targetUri.isNullOrBlank()) {
            onImportTargetPicked(Uri.parse(targetUri), silent = true)
        } else {
            _state.update { it.copy(importTargetPath = InjectionPrefs.importTargetPath) }
        }
    }

    private fun buildSource(cur: UiState): FolderImporter.Source? {
        val uri = cur.importSourceUri
        if (!uri.isNullOrBlank()) return FolderImporter.Source.Tree(Uri.parse(uri))
        val path = cur.importSourcePath
        if (path.isNotBlank() && File(path).isDirectory) return FolderImporter.Source.Path(File(path))
        return null
    }

    private fun buildTarget(cur: UiState): FolderImporter.Target? {
        val uri = cur.importTargetUri
        if (!uri.isNullOrBlank()) return FolderImporter.Target.Tree(Uri.parse(uri))
        val path = cur.importTargetPath
        if (path.isNotBlank()) return FolderImporter.Target.Path(File(path))
        return null
    }

    private fun runImport() {
        val cur = _state.value
        if (cur.importing) return
        val source = buildSource(cur)
        if (source == null) {
            emit(UiEvent.Toast(strings.importPickNone))
            return
        }
        val target = buildTarget(cur)
        if (target == null) {
            emit(UiEvent.Toast(strings.importTargetMissing))
            return
        }
        val ctx = getApplication<Application>()
        // 安卓 12 以上写别的应用目录要先有通道,没有就直说"尚未就绪",别跑了才报错
        val targetPath = (target as? FolderImporter.Target.Path)?.dir?.absolutePath
            ?: (target as? FolderImporter.Target.Tree)?.let { FolderImporter.displayPath(ctx, it.uri) }
        val channel = FolderImporter.channelState(ctx, targetPath)
        if (!channel.ready) {
            emit(UiEvent.Toast(strings.importNotReady))
            return
        }
        viewModelScope.launch {
            _state.update {
                it.copy(
                    importing = true,
                    importFinished = false,
                    importFailed = false,
                    importProgressFiles = 0,
                    importProgressTotal = cur.importSourceFiles,
                    importProgressBytes = 0L,
                    importChannelLabel = null,
                    importMessage = null
                )
            }
            val outcome = withContext(Dispatchers.IO) {
                FolderImporter.run(ctx, source, target, cur.importReplaceAll) { p ->
                    _state.update {
                        it.copy(
                            importProgressFiles = p.copied,
                            importProgressBytes = p.bytes,
                            importProgressTotal = if (p.total > 0) p.total else it.importProgressTotal
                        )
                    }
                }
            }
            val channelLabel = when (outcome.channel) {
                FolderImporter.CHANNEL_SAF -> strings.importChannelSaf
                FolderImporter.CHANNEL_DIRECT -> strings.importChannelDirect
                FolderImporter.CHANNEL_ROOT -> strings.importChannelRoot
                else -> "-"
            }
            _state.update {
                it.copy(
                    importing = false,
                    importFinished = true,
                    importFailed = !outcome.ok,
                    importProgressFiles = outcome.copied,
                    importProgressBytes = outcome.bytes,
                    importChannelLabel = channelLabel,
                    importMessage = if (outcome.ok) {
                        strings.importDone + " · " + outcome.copied + " " + strings.importFileUnit +
                            " · " + FolderImporter.formatSize(outcome.bytes)
                    } else {
                        strings.importFailedMsg + ": " +
                            (outcome.error ?: strings.importNoAccess)
                    }
                )
            }
            emit(UiEvent.Toast(if (outcome.ok) strings.importDone else strings.importFailedMsg))
            refreshRuntime()
        }
    }

    // ---------------- 小工具 ----------------

    private fun emit(event: UiEvent) {
        _events.trySend(event)
    }

    fun progressPercent(): Int = (_state.value.downloadProgress * 100f).roundToInt()
}
