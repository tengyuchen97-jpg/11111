package com.tengcd.czr.network

import android.content.Context
import android.net.Uri
import android.os.Build
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * T3 网络验证的接入参数。
 */
data class T3Config(
    val baseUrl: String,
    val appId: String,
    val appKey: String,
    val aesKey: String,
    /** Base64 自定义编码集,必须 64 位 */
    val charset: String = T3Panel.B64_CHARSET,
    /** 请求体格式:官方只有 form,保留字段兼容老配置 */
    val format: String = "form"
) {
    /** 官方协议只要服务器地址;appid 是后台自己的标识,可留空 */
    val ready: Boolean
        get() = baseUrl.isNotBlank()

    companion object {
        /**
         * 正式接入参数:全部写死。
         * 界面上没有任何入口能改服务器 / appkey / 编码集,用户改不了,也不走本地卡密。
         */
        fun official(): T3Config = T3Config(
            baseUrl = T3Panel.SERVER,
            appId = "",
            appKey = T3Panel.APPKEY,
            aesKey = T3Panel.RC4_KEY,
            charset = T3Panel.B64_CHARSET,
            format = "form"
        )

        fun fromPrefs(): T3Config = T3Config(
            baseUrl = InjectionPrefs.t3BaseUrl,
            appId = InjectionPrefs.t3AppId,
            appKey = InjectionPrefs.t3AppKey,
            aesKey = InjectionPrefs.t3AesKey,
            charset = InjectionPrefs.t3Charset,
            format = InjectionPrefs.t3ReqFormat
        )
    }
}

/**
 * 一次验证请求的结果。登录 / 查询 / 解绑 / 心跳 / 公告 都用它。
 */
data class T3Result(
    val ok: Boolean,
    val message: String,
    val token: String = "",
    val expireAt: Long = 0L,
    val expireText: String = "",
    val remainCount: Int = -1,
    val unbindCount: Int = -1,
    val boundDevice: String = "",
    val banned: Boolean = false,
    val expired: Boolean = false,
    val exhausted: Boolean = false,
    /** 服务端明确说这张卡不能用了(被踢/被封/过期),调用方应该退登 */
    val invalid: Boolean = false,
    val notice: String = "",
    /** 服务端确实给了业务响应(不是路径 404),探路时用来决定还要不要试下一个地址 */
    val reached: Boolean = false,
    /** 最新版本号(只有 latest / checkver 这两个接口会给) */
    val version: String = "",
    /** 更新说明(后台「检测版本」接口的 uplog 字段,更新弹框里当公告正文) */
    val updateLog: String = "",
    /** 新版下载地址(后台「检测版本」接口的 upurl 字段) */
    val updateUrl: String = "",
    val raw: String = ""
)

/**
 * T3 网络验证客户端:卡密登录、卡密查询、心跳保活、解绑设备、拉公告。
 *
 * 走的是 T3 官方协议:
 *   接口 = 验证服务器 + "/" + 调用码
 *   参数值 = HEX(自定义Base64(值)),签名 s = HEX(自定义Base64(md5(参数串 + appkey)))
 *   返回 = 自定义Base64 解码后是 JSON
 *
 * 验证服务器默认 w.t3yanzheng.com,官方还有 w2~w5 和 w.t3data.net 备用,
 * 一个连不上会自动换下一个。
 */
object T3Client {

    private const val ACTION_LOGIN = "login"
    private const val ACTION_LOGIN_COUNT = "login_count"
    private const val ACTION_QUERY = "query"
    private const val ACTION_QUERY_COUNT = "query_count"
    private const val ACTION_UNBIND = "unbind"
    private const val ACTION_HEARTBEAT = "heartbeat"
    private const val ACTION_NOTICE = "notice"
    private const val ACTION_LATEST = "latest"
    private const val ACTION_CHECKVER = "checkver"

    /** T3 官方验证服务器(全部是接口机,不是 www 官网) */
    private val OFFICIAL_SERVERS = listOf(
        "https://w.t3yanzheng.com",
        "https://w2.t3yanzheng.com",
        "https://w3.t3yanzheng.com",
        "https://w4.t3yanzheng.com",
        "https://w5.t3yanzheng.com",
        "https://w.t3data.net"
    )

    private const val UA = "TengcdTool/1.0 (Android)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    // ---------------- 对外接口 ----------------

    /** 卡密登录(次数卡在部分后台走的是「计次卡登录」接口,这里自动兜一次) */
    suspend fun login(
        context: Context,
        config: T3Config,
        card: String,
        deviceId: String
    ): T3Result {
        val first = call(config, ACTION_LOGIN, card, deviceId, "")
        if (first.ok) return first
        // 单码登录只认时长卡,次数卡会直接回「卡密不存在 / 卡密类型不符」。
        // 后台把「计次卡登录」的调用码填到 T3Panel.CODE_LOGIN_COUNT,这里就自动改走那个接口。
        if (T3Panel.CODE_LOGIN_COUNT.isNotBlank()) {
            val retry = call(config, ACTION_LOGIN_COUNT, card, deviceId, "")
            if (retry.ok || retry.reached) return retry
        }
        return first
    }

    /** 卡密查询:到期时间 / 剩余次数 / 绑定设备 / 解绑次数 */
    suspend fun query(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result = call(config, ACTION_QUERY, card, deviceId, token)

    /** 解绑当前设备 */
    suspend fun unbind(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result = call(config, ACTION_UNBIND, card, deviceId, token)

    /** 心跳保活 */
    suspend fun heartbeat(
        config: T3Config,
        token: String,
        deviceId: String,
        card: String = ""
    ): T3Result = call(config, ACTION_HEARTBEAT, card, deviceId, token)

    /** 公告(不需要卡密,启动页也能拉) */
    suspend fun notice(config: T3Config, card: String = "", token: String = ""): T3Result =
        call(config, ACTION_NOTICE, card, "", token)

    /** 最新版序号 */
    suspend fun latestVersion(config: T3Config): T3Result =
        call(config, ACTION_LATEST, "", "", "")

    /** 检测版本是否最新版(ver = 客户端版本) */
    suspend fun checkVersion(config: T3Config, ver: String): T3Result =
        call(config, ACTION_CHECKVER, "", "", ver)

    // ---------------- 请求调度 ----------------

    private suspend fun call(
        config: T3Config,
        action: String,
        card: String,
        deviceId: String,
        token: String
    ): T3Result = withContext(Dispatchers.IO) {
        val bases = serverCandidates(config.baseUrl)
        if (bases.isEmpty()) {
            return@withContext T3Result(false, "还没填验证服务器地址")
        }

        val code = T3Panel.codeOf(action)
        var last = T3Result(false, "连不上验证服务器", reached = false)

        for (base in bases) {
            val raw = post(
                url = join(base, code),
                params = buildParams(config, action, card, deviceId, token)
            )
            val parsed = parse(config, raw, action)
            if (parsed.ok) return@withContext parsed
            // 服务器已经给了业务响应(卡密不存在 / 过期 / 被封),不用再换服务器
            if (parsed.invalid || parsed.reached) return@withContext parsed
            last = parsed
        }
        last
    }

    /** 用户填的地址优先,填的是官方域名时把它后面几台备机也带上 */
    private fun serverCandidates(raw: String): List<String> {
        val list = ArrayList<String>()
        val base = raw.trim().trimEnd('/')
        if (base.isNotBlank()) list.add(base)
        if (base.isBlank() || base.contains("t3yanzheng.com") || base.contains("t3data.net")) {
            OFFICIAL_SERVERS.forEach { if (!list.contains(it)) list.add(it) }
        }
        return list
    }

    private fun join(base: String, code: String): String {
        val b = base.trim().trimEnd('/')
        return "$b/$code"
    }

    private fun buildParams(
        config: T3Config,
        action: String,
        card: String,
        deviceId: String,
        token: String
    ): Map<String, String> {
        val charset = config.charset
        val time = System.currentTimeMillis() / 1000L
        val params = LinkedHashMap<String, String>()

        // 各接口自己的参数(顺序要与签名串一致)
        when (action) {
            ACTION_LOGIN, ACTION_QUERY, ACTION_LOGIN_COUNT, ACTION_QUERY_COUNT -> {
                if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
            }
            ACTION_UNBIND -> {
                if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
            }
            ACTION_HEARTBEAT -> {
                // T3 心跳接口的入参就是 statecode,多传反而可能被判参数错误
                if (token.isNotBlank()) {
                    params[T3Panel.P_STATE] = token
                } else {
                    if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                    if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
                }
            }
            ACTION_CHECKVER -> params[T3Panel.P_VER] = token.ifBlank { "1" }
            else -> Unit
        }
        params["t"] = time.toString()

        // 值编码
        val encoded = LinkedHashMap<String, String>()
        params.forEach { (k, v) -> encoded[k] = T3Panel.encodeValue(v, charset) }

        // 签名:参数串 + &appkey
        val signSource = buildString {
            encoded.forEach { (k, v) -> append(k).append('=').append(v).append('&') }
            append(config.appKey.ifBlank { T3Panel.APPKEY })
        }
        val sign = T3Panel.encodeValue(Md5Util.md5(signSource), charset)

        val body = LinkedHashMap<String, String>()
        body.putAll(encoded)
        body["s"] = sign
        return body
    }

    private fun post(url: String, params: Map<String, String>): String {
        return try {
            val builder = FormBody.Builder()
            params.forEach { (k, v) -> builder.add(k, v) }
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "*/*")
                .post(builder.build() as RequestBody)
                .build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (text.isBlank()) "" else text
            }
        } catch (t: Throwable) {
            ""
        }
    }

    // ---------------- 返回解析 ----------------

    private fun parse(config: T3Config, raw: String, action: String): T3Result {
        val text = raw.trim()
        if (text.isEmpty()) {
            return T3Result(false, "服务器没有响应", reached = false)
        }

        var json = asJson(text)
        if (json == null) json = parseKv(text)
        if (json == null) json = decryptToJson(config, text)
        if (json == null) {
            if (text.contains("<html", true)) {
                return T3Result(false, "验证服务器地址不对(返回的是网页)", reached = false, raw = text.take(200))
            }
            if (T3Panel.usableCharset(config.charset)) {
                return T3Result(false, "返回内容解不开,检查后台 Base64 编码集(要 64 位)", reached = true, raw = text.take(200))
            }
            return T3Result(
                false,
                "返回内容解不开,检查后台 Base64 编码集(现在是 ${config.charset.trim().length} 位,要 64 位)",
                reached = true,
                raw = text.take(200)
            )
        }

        val flat = flatten(json)
        val code = firstInt(flat, "code", "status", "ret", "errcode", "err_no", "result")
        val msgRaw = firstString(flat, "msg", "message", "info", "errmsg", "tips", "error")
        val token = firstString(
            flat, "statecode", "state_code", "state", "token", "access_token",
            "session", "sessionid", "sign_token"
        )
        val expireRaw = firstString(
            flat, "end_time", "expire_time", "expire", "expireTime", "endtime",
            "vip_time", "expiry", "expired_at", "due_time"
        )
        val expireAt = parseExpire(expireRaw)

        // 文案里带「成功」的一律先当成功提示处理,不然「剩余可用次数:10」「到期时间:永久」
        // 这种正常回包会被下面的关键词误判成次数用完 / 已过期(次数卡一直用不了就是这来的)
        val msgLower = msgRaw.lowercase(Locale.US)
        val msgIsSuccess = msgRaw.contains("成功") || msgLower.contains("success") ||
            msgLower.contains("login ok") || msgLower.trim() == "ok"

        val banned = flat.optBoolean("banned", false) ||
            flat.optInt("is_ban", 0) == 1 ||
            (!msgIsSuccess && (msgRaw.contains("封禁") ||
                msgRaw.contains("禁用", true) ||
                msgLower.contains("banned")))
        // 只在明确的失败措辞上判过期(不能见到「到期」两个字就算,次数卡回包里会带「到期时间」)
        val expired = !msgIsSuccess && (
            msgRaw.contains("已过期") ||
                msgRaw.contains("过期了") ||
                msgRaw.contains("卡密过期") ||
                msgRaw.contains("已到期") ||
                msgRaw.contains("已失效") ||
                msgLower.contains("expired")
            )
        // 次数用完必须是明确措辞;「次数」+「用」这种太宽,「剩余可用次数」直接中招
        val exhausted = !msgIsSuccess && (
            msgRaw.contains("次数不足") ||
                msgRaw.contains("次数已用完") ||
                msgRaw.contains("次数用完") ||
                msgRaw.contains("次数用尽") ||
                msgRaw.contains("次数耗尽") ||
                msgRaw.contains("次数为0") ||
                msgRaw.contains("次数为零") ||
                msgRaw.contains("可用次数不足") ||
                msgRaw.contains("余额不足") ||
                msgLower.contains("no quota") ||
                msgLower.contains("quota exceeded")
            )

        val successFlag = when {
            flat.has("success") -> flat.optBoolean("success", false)
            flat.has("ok") -> flat.optBoolean("ok", false)
            else -> false
        }

        val noticeText = if (action == ACTION_NOTICE) extractNotice(flat) else ""
        // 最新版序号 / 检测版本:版本号有可能放在 msg 里("1.1"),也可能放 data 里
        val versionText = if (action == ACTION_LATEST || action == ACTION_CHECKVER) {
            firstString(
                flat, "version", "ver", "latest", "latest_ver", "newver",
                "new_version", "ver_name", "banben", "new_ver"
            ).ifBlank { extractVersion(msgRaw) }
                .ifBlank { extractVersion(flat.optString("data")) }
                .ifBlank { extractVersion(flat.optString("info")) }
        } else ""

        // 「检测版本 / 最新版序号」接口还会带更新说明和下载地址:
        // {"code":200,"ver":"1.1","uplog":"更新内容...","upurl":"https://...apk"}
        val versionAction = action == ACTION_LATEST || action == ACTION_CHECKVER
        val updateLog = if (versionAction) {
            firstString(flat, "uplog", "up_log", "update_log", "updatelog", "up_content", "log")
        } else ""
        val updateUrl = if (versionAction) {
            firstString(
                flat, "upurl", "up_url", "update_url", "downurl", "down_url",
                "download_url", "apk", "url"
            )
        } else ""

        // 成功判定:次数卡的返回码跟时长卡不完全一样(有的后台次数卡回 200/201,
        // 有的回 200 但 msg 里只有「剩余次数:x」),所以除了 code=200 之外,
        // 「拿到 statecode + 2xx」和「msg 明确说成功 + 2xx」也算登录成功。
        // 卡密不存在 / 机器码不符这类回包既没有 statecode,msg 也不是成功措辞,照样进不来。
        val ok = when {
            banned || exhausted -> false
            expired && token.isBlank() -> false
            successFlag -> true
            code == 200 -> true
            token.isNotBlank() && (code == null || code in 200..299) -> true
            msgIsSuccess && (code == null || code in 200..299) -> true
            code == null -> token.isNotBlank() || noticeText.isNotBlank() ||
                flat.has("end_time") || flat.has("expire_time") || flat.has("remain") ||
                flat.has("num") || flat.has("remain_count") || flat.has("times")
            else -> false
        }

        val reached = flat.has("code") || flat.has("status") || flat.has("msg") ||
            flat.has("message") || successFlag || token.isNotBlank() || noticeText.isNotBlank()

        val message = msgRaw.trim().ifBlank {
            when {
                ok -> "ok"
                code != null -> "验证失败(返回码 $code)"
                else -> "验证失败"
            }
        }

        // 参数错 / 签名错 / 接口不存在 这类是「我们这边配错了」,不代表卡废了,
        // 不能拿来踢人下线(次数卡心跳接口没开的时候就会被误判成卡无效)
        val configError = !msgIsSuccess && (
            msgRaw.contains("参数") || msgRaw.contains("签名") ||
                msgRaw.contains("接口不存在") || msgRaw.contains("接口错误") ||
                msgRaw.contains("调用码") || msgLower.contains("sign") ||
                msgLower.contains("param") || msgLower.contains("interface")
            )

        val invalid = !ok && !configError && (
            code == 401 || code == 402 || code == 403 || code == 404 || code == 410 ||
                code == 301 || code == 302 ||
                (code != null && code > 200 && code < 300) ||
                banned || expired || exhausted
            )

        return T3Result(
            ok = ok,
            message = message,
            token = token,
            expireAt = expireAt,
            expireText = formatExpire(expireAt, expireRaw),
            remainCount = firstInt(
                flat, "remain", "remain_count", "count", "left", "balance", "num", "times", "remain_times"
            ) ?: -1,
            unbindCount = firstInt(
                flat, "unbind_count", "unbind_times", "unbind_num", "allow_unbind", "unbind"
            ) ?: -1,
            boundDevice = firstString(
                flat, "imei", "device", "machine_code", "bound_device", "bind_device", "device_id"
            ),
            banned = banned,
            expired = expired,
            exhausted = exhausted,
            invalid = invalid,
            notice = noticeText,
            reached = reached,
            version = versionText,
            updateLog = updateLog,
            updateUrl = updateUrl,
            raw = text.take(400)
        )
    }

    /** 从任意文案里抠一个 x.y 形式的版本号出来("已是最新版本1.0" / "1.1") */
    private val VERSION_RE = Regex("""\d{1,3}(?:\.\d{1,3}){1,3}""")

    private fun extractVersion(text: String): String {
        if (text.isBlank()) return ""
        val m = VERSION_RE.find(text) ?: return ""
        return m.value
    }

    private fun asJson(text: String): JSONObject? {
        if (!text.startsWith("{")) return null
        return try {
            JSONObject(text)
        } catch (t: Throwable) {
            null
        }
    }

    /** code=0&msg=ok&token=xxx 这种老式返回 */
    private fun parseKv(text: String): JSONObject? {
        if (!text.contains("=") || text.contains("<")) return null
        return try {
            val json = JSONObject()
            text.split("&").forEach { pair ->
                val idx = pair.indexOf('=')
                if (idx > 0) {
                    json.put(pair.substring(0, idx), pair.substring(idx + 1))
                }
            }
            if (json.length() == 0) null else json
        } catch (t: Throwable) {
            null
        }
    }

    /** 整体加密的返回:自定义 Base64 / RC4 都试一遍 */
    private fun decryptToJson(config: T3Config, raw: String): JSONObject? {
        val plain = T3Panel.decodePayload(raw, config.charset) ?: return null
        return asJson(plain) ?: parseKv(plain)
    }

    /** data 字段可能是对象也可能是字符串,统一摊平到一层 */
    private fun flatten(json: JSONObject): JSONObject {
        val out = JSONObject(json.toString())
        val data = json.optJSONObject("data")
        if (data != null) {
            val keys = data.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (!out.has(key)) out.put(key, data.get(key))
            }
        } else {
            val dataText = json.optString("data")
            if (dataText.startsWith("{")) {
                try {
                    val inner = JSONObject(dataText)
                    val keys = inner.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (!out.has(key)) out.put(key, inner.get(key))
                    }
                } catch (t: Throwable) {
                    // data 就是一串文本,不用管
                }
            }
        }
        return out
    }

    private fun firstString(json: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = json.optString(key)
            if (value.isNotBlank() && value != "null") return value.trim()
        }
        return ""
    }

    private fun firstInt(json: JSONObject, vararg keys: String): Int? {
        for (key in keys) {
            if (!json.has(key)) continue
            val value = json.opt(key)
            val num = when (value) {
                is Number -> value.toInt()
                is String -> value.trim().toIntOrNull()
                else -> null
            }
            if (num != null) return num
        }
        return null
    }

    private fun extractNotice(json: JSONObject): String {
        val direct = firstString(
            json, "notice", "announcement", "gonggao", "content", "text", "notice_content"
        )
        if (direct.isNotBlank()) return cleanNotice(direct)
        val data = json.optString("data")
        if (data.isNotBlank() && data != "null") return cleanNotice(data)
        val msg = firstString(json, "msg", "message", "info")
        return if (msg.isNotBlank() && msg != "ok") cleanNotice(msg) else ""
    }

    private fun cleanNotice(text: String): String = text
        .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
        .replace(Regex("</p>", RegexOption.IGNORE_CASE), "\n")
        .replace(Regex("<[^>]+>"), "")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .trim()

    private fun parseExpire(raw: String): Long {
        val value = raw.trim()
        if (value.isEmpty() || value == "0" || value.equals("null", true)) return 0L
        value.toLongOrNull()?.let { num ->
            return if (num > 10_000_000_000L) num else num * 1000L
        }
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd",
            "yyyy/MM/dd HH:mm:ss",
            "yyyy/MM/dd"
        )
        for (pattern in patterns) {
            try {
                val format = SimpleDateFormat(pattern, Locale.CHINA)
                format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
                val date = format.parse(value) ?: continue
                return date.time
            } catch (t: Throwable) {
                // 换下一个格式
            }
        }
        return 0L
    }

    private fun formatExpire(expireAt: Long, raw: String): String {
        if (expireAt <= 0L) return raw.trim()
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
            format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
            format.format(expireAt)
        } catch (t: Throwable) {
            raw.trim()
        }
    }

    /** 设备指纹:优先用系统给的 ANDROID_ID 派生的那个 */
    fun deviceId(context: Context): String = try {
        LocalCardGate.deviceId(context)
    } catch (t: Throwable) {
        val fallback = (Build.MODEL.orEmpty() + Build.BRAND.orEmpty() + Build.ID.orEmpty())
        Md5Util.md5(fallback).take(16).uppercase(Locale.US)
    }

    /** 展示用:把域名裁一裁,别在界面上撑爆一行 */
    fun prettyHost(url: String): String {
        if (url.isBlank()) return "-"
        return try {
            Uri.parse(url).host ?: url
        } catch (t: Throwable) {
            url
        }
    }
}

/** 把 T3 的返回换成卡密页要展示的那一份信息 */
fun T3Result.toCardInfo(card: String): CardQueryInfo = CardQueryInfo(
    card = card,
    expireTime = expireText.ifBlank { if (remainCount >= 0) "计次卡" else "" },
    remainCount = remainCount,
    unbindCount = unbindCount,
    boundDevice = boundDevice,
    banned = banned,
    valid = ok,
    message = when {
        ok -> message
        banned -> "banned"
        expired -> "expired"
        exhausted -> "count_exhausted"
        else -> message
    }
)
