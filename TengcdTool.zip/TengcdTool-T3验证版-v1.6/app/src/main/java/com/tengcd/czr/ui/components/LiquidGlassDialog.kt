package com.tengcd.czr.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight

/** 玻璃弹窗:标题 + 正文 + 1~2 个按钮 */
@Composable
fun LiquidGlassDialog(
    dark: Boolean,
    title: String,
    message: String,
    confirmText: String,
    cancelText: String? = null,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .liquidGlass(dark, 26)
                .padding(20.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = if (dark) TextPrimaryDark else TextPrimaryLight
            )
            if (message.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (cancelText != null) {
                    SecondaryActionButton(
                        text = cancelText,
                        icon = null,
                        dark = dark,
                        modifier = Modifier.weight(1f),
                        onClick = onDismiss
                    )
                }
                PrimaryActionButton(
                    text = confirmText,
                    icon = null,
                    enabled = true,
                    dark = dark,
                    modifier = Modifier.weight(1f),
                    onClick = onConfirm
                )
            }
        }
    }
}


/**
 * 更新弹窗:最上面一颗「公告」按钮,下面是公告内容,最下面「更新」。
 * 点「公告」可以把正文收起来/放出来。
 */
@Composable
fun UpdatePromptDialog(
    dark: Boolean,
    localVersion: String,
    latestVersion: String,
    announcement: String,
    noticeLabel: String,
    updateText: String,
    onUpdate: () -> Unit,
    onDismiss: () -> Unit
) {
    var showNotice by remember { mutableStateOf(true) }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .liquidGlass(dark, 26)
                .padding(20.dp)
        ) {
            // 顶上那颗「公告」按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val pillShape = RoundedCornerShape(50)
                Row(
                    modifier = Modifier
                        .clip(pillShape)
                        .liquidGlass(dark, 50)
                        .clickable { showNotice = !showNotice }
                        .padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Campaign,
                        contentDescription = null,
                        tint = AccentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        text = noticeLabel,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (dark) TextPrimaryDark else TextPrimaryLight
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(
                    text = if (latestVersion.isNotBlank() && latestVersion != "最新版") {
                        "v$localVersion → v$latestVersion"
                    } else {
                        "当前 v$localVersion"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 12.sp,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
            }

            if (showNotice) {
                Spacer(Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 230.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = announcement,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (dark) TextPrimaryDark else TextPrimaryLight
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            PrimaryActionButton(
                text = updateText,
                icon = null,
                enabled = true,
                dark = dark,
                modifier = Modifier.fillMaxWidth(),
                onClick = onUpdate
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "稍后再说",
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDismiss() }
                    .padding(vertical = 6.dp),
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }
    }
}

/** 圆形加载指示 */
@Composable
fun LoadingSpinner(size: Int = 18, stroke: Int = 2) {
    CircularProgressIndicator(
        modifier = Modifier.size(size.dp),
        color = AccentBlue,
        strokeWidth = stroke.dp
    )
}

/** 下载进度弹窗 */
@Composable
fun DownloadProgressDialog(
    dark: Boolean,
    title: String,
    message: String,
    progress: Float,
    indeterminate: Boolean = false
) {
    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .liquidGlass(dark, 24)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LoadingSpinner(size = 16, stroke = 2)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (dark) TextPrimaryDark else TextPrimaryLight
                )
            }
            Spacer(Modifier.height(12.dp))
            if (indeterminate) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    LoadingSpinner(size = 22, stroke = 3)
                }
            } else {
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
        }
    }
}
