package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.NoticeCard
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.WarnOrange
import com.tengcd.czr.util.AndroidVersion

/**
 * 首页。左边一个总览:框架在不在、服务跑没跑、目标装没装、SO 是哪份、
 * 写目录走哪条通道。
 */
@Composable
fun HomeScreen(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 顶部这块重复的大标题 + 提示小字已经去掉(顶栏已经有「遄懂」了),
        // 首页直接从公告开始。
        Spacer(Modifier.height(4.dp))

        // 公告放首页最上面,进 App 一眼就能看到
        NoticeCard(state = state, s = s, dark = dark) { onAction(it) }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Info, s.homeStatus, dark)
            Spacer(Modifier.height(8.dp))
            StatusRow(
                label = s.frameworkStatus,
                value = if (state.frameworkInstalled) s.statusActivated else s.statusNotActivated,
                dark = dark,
                dot = true,
                ok = state.frameworkInstalled,
                warn = !state.frameworkInstalled
            )
            StatusRow(
                label = s.moduleServiceRunning,
                value = if (state.serviceRunning) s.serviceRunning else s.serviceStopped,
                dark = dark,
                dot = true,
                ok = state.serviceRunning,
                warn = !state.serviceRunning
            )
            StatusRow(
                label = s.targetApp,
                value = if (state.targetInstalled) {
                    state.targetLabel.ifBlank { state.targetPackage }
                } else {
                    s.targetNotInstalled
                },
                dark = dark,
                dot = true,
                ok = state.targetInstalled,
                warn = !state.targetInstalled
            )
            Spacer(Modifier.height(6.dp))
            KeyValueRow(
                label = s.homeSoNow,
                value = when (state.soSource) {
                    "local" -> s.soLocal
                    "remote" -> s.soRemote
                    else -> s.soBuiltin + " " + state.selectedSo
                },
                dark = dark,
                valueColor = if (state.soValid) OkGreen else ErrRed
            )
            KeyValueRow(
                label = s.homeWriteChannel,
                value = channelText(state, s),
                dark = dark,
                valueColor = if (state.writeChannelReady) OkGreen else WarnOrange
            )
            KeyValueRow(
                label = s.shizukuStatus,
                value = AndroidVersion.label(state.sdkInt),
                dark = dark
            )
            if (state.loggedIn && state.loginExpire.isNotBlank()) {
                KeyValueRow(
                    label = s.homeAccount,
                    value = state.loginExpire,
                    dark = dark,
                    valueColor = OkGreen
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // 一键:按当前注入方式把 SO 打进去,顺手把游戏拉起来
        PrimaryActionButton(
            text = if (state.injecting) s.injectRunning else s.homeOneKeyInject,
            icon = Icons.Filled.PlayArrow,
            enabled = !state.injecting,
            dark = dark
        ) { onAction(UiAction.InjectAndLaunch) }

        Spacer(Modifier.height(18.dp))
    }
}

/** 通道名:跟导入页那个保持一致 */
private fun channelText(state: UiState, s: LocalizedStrings): String = when (state.writeChannel) {
    "root" -> s.importChannelRoot
    "shizuku" -> s.importChannelShizuku
    "direct" -> s.importChannelDirect
    else -> s.importChannelNone
}
