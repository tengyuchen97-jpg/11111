package com.tengcd.czr.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** 背景渐变:浅色是柔雾紫粉,深色是深邃蓝黑 */
val LightGradientTop = Color(0xFFF5F0FF)
val LightGradientMid = Color(0xFFEDE7FF)
val LightGradientBottom = Color(0xFFFFF5F8)

val DarkGradientTop = Color(0xFF0F0E1A)
val DarkGradientMid = Color(0xFF141224)
val DarkGradientBottom = Color(0xFF0A0912)

val AccentBlue = Color(0xFF4D8DFF)
val AccentViolet = Color(0xFF8B5CF6)
val AccentPink = Color(0xFFEC4899)
val AccentCyan = Color(0xFF06B6D4)

val TextPrimaryLight = Color(0xFF1A1825)
val TextSecondaryLight = Color(0xFF6E6A85)
val TextPrimaryDark = Color(0xFFF0EEF8)
val TextSecondaryDark = Color(0xFF9D98B8)

val GlassBorderLight = Color(0xB3FFFFFF)
val GlassBorderDark = Color(0x2EFFFFFF)
val GlassFillLight = Color(0x73FFFFFF)
val GlassFillDark = Color(0x17FFFFFF)

val OkGreen = Color(0xFF10B981)
val WarnOrange = Color(0xFFF59E0B)
val ErrRed = Color(0xFFEF4444)

fun appBackgroundBrush(dark: Boolean): Brush = Brush.verticalGradient(
    colors = if (dark) {
        listOf(DarkGradientTop, DarkGradientMid, DarkGradientBottom)
    } else {
        listOf(LightGradientTop, LightGradientMid, LightGradientBottom)
    }
)
