//
// liboverupdate.so —— 免 root 过更新。
//
// 原来那份「过更新模块」是 Xposed 模块,必须框架注入(LSPosed 那套,通常要 root)才挂得上 hook。
// 这里换个做法:直接在目标进程里把证书校验那几个入口函数改掉,不依赖 Xposed、不依赖 root,
// 进程注入(免 root 那条路)把本库 dlopen 进游戏进程就生效。
//
// 改的都是 TLS 链路上的判定函数:
//   X509_verify_cert            链验证 -> 永远通过
//   X509_STORE_CTX_get_error    错误码 -> 永远 0(OK)
//   SSL_get_verify_result       握手结果里的验证结论 -> 永远 OK
//   SSL_CTX_set_verify          不再要求校验(默认就是不校验)
//   SSL_CTX_set_custom_verify   自定义校验回调(证书固定/校验证书的常见入口)-> 不装
//   SSL_CTX_set_verify_depth    深度限制 -> 不设
//   SSL_set1_host               主机名校验 -> 跳过
//
// 覆盖范围:游戏里所有走 libssl/libcrypto(含 Unity/UE 自带的 OpenSSL、Conscrypt 的
// libjavacrypto)的 HTTPS 请求。它是按库扫符号的,新加载进来的库会再扫一遍。
//
// 全部在目标进程里做,失败也不影响游戏:任何一步出错只写日志,不抛异常不退出。
//

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAG "overupdate"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ---------------------------------------------------------------- 替换函数

static int rep_X509_verify_cert(void *ctx) {
    (void) ctx;
    return 1;
}

static int rep_SSL_get_verify_result(const void *ssl) {
    (void) ssl;
    return 0;  // X509_V_OK
}

static int rep_X509_STORE_CTX_get_error(void *ctx) {
    (void) ctx;
    return 0;  // X509_V_OK
}

static void rep_SSL_CTX_set_verify(void *ctx, int mode, void *cb) {
    (void) ctx;
    (void) mode;
    (void) cb;
}

static void rep_SSL_CTX_set_custom_verify(void *ctx, int mode, void *cb) {
    (void) ctx;
    (void) mode;
    (void) cb;
}

static void rep_SSL_CTX_set_verify_depth(void *ctx, int depth) {
    (void) ctx;
    (void) depth;
}

static int rep_SSL_set1_host(void *ssl, const char *host) {
    (void) ssl;
    (void) host;
    return 1;
}

static int rep_mbedtls_ssl_get_verify_result(const void *ssl) {
    (void) ssl;
    return 0;
}

static void rep_mbedtls_ssl_conf_authmode(void *conf, int authmode) {
    (void) conf;
    (void) authmode;
}

static int rep_mbedtls_x509_crt_verify(void *crt, void *trust_ca, void *ca_crl,
                                       const char *cn, uint32_t *flags,
                                       void *f_vrfy, void *p_vrfy) {
    (void) crt;
    (void) trust_ca;
    (void) ca_crl;
    (void) cn;
    (void) f_vrfy;
    (void) p_vrfy;
    if (flags != nullptr) *flags = 0;
    return 0;
}

static void rep_SSL_CTX_set_cert_verify_callback(void *ctx, void *cb, void *arg) {
    (void) ctx;
    (void) cb;
    (void) arg;
}

struct PatchTarget {
    const char *symbol;
    void *replacement;
};

static const PatchTarget kTargets[] = {
        {"X509_verify_cert",           (void *) rep_X509_verify_cert},
        {"SSL_get_verify_result",      (void *) rep_SSL_get_verify_result},
        {"X509_STORE_CTX_get_error",   (void *) rep_X509_STORE_CTX_get_error},
        {"SSL_CTX_set_verify",         (void *) rep_SSL_CTX_set_verify},
        {"SSL_CTX_set_custom_verify",  (void *) rep_SSL_CTX_set_custom_verify},
        {"SSL_CTX_set_verify_depth",   (void *) rep_SSL_CTX_set_verify_depth},
        {"SSL_set1_host",              (void *) rep_SSL_set1_host},
        {"SSL_CTX_set_cert_verify_callback", (void *) rep_SSL_CTX_set_cert_verify_callback},
        // 个别游戏(老 Unity / mbedTLS 栈)用的是 mbedTLS,一并放开
        {"mbedtls_ssl_get_verify_result",    (void *) rep_mbedtls_ssl_get_verify_result},
        {"mbedtls_ssl_conf_authmode",        (void *) rep_mbedtls_ssl_conf_authmode},
        {"mbedtls_x509_crt_verify",          (void *) rep_mbedtls_x509_crt_verify},
};

static const int kTargetCount = (int) (sizeof(kTargets) / sizeof(kTargets[0]));

// ---------------------------------------------------------------- 入口改写

static void make_range(void *addr, size_t len, int prot) {
    size_t page = (size_t) sysconf(_SC_PAGESIZE);
    uintptr_t start = (uintptr_t) addr & ~(page - 1);
    uintptr_t end = ((uintptr_t) addr + len + page - 1) & ~(page - 1);
    mprotect((void *) start, end - start, prot);
}

/**
 * 把 target 的头几条指令换成「跳到 replacement」。
 * 只支持"整函数替换"——我们从不回头调原函数,所以不需要保存被覆盖的指令。
 */
static bool patch_entry(void *target, void *replacement) {
    if (target == nullptr || replacement == nullptr) return false;
    if ((uintptr_t) target < 4096) return false;

#if defined(__aarch64__)
    uint32_t code[4];
    code[0] = 0x58000050u;  // ldr x16, #8
    code[1] = 0xD61F0200u;  // br  x16
    uint64_t dest = (uint64_t) replacement;
    memcpy(&code[2], &dest, sizeof(dest));

    // 补丁可能横跨两页,按页区间整体放开写权限,别只放一页
    make_range(target, sizeof(code), PROT_READ | PROT_WRITE | PROT_EXEC);
    memcpy(target, code, sizeof(code));
    __builtin___clear_cache((char *) target, (char *) target + sizeof(code));
    make_range(target, sizeof(code), PROT_READ | PROT_EXEC);
    return true;

#elif defined(__arm__)
    uintptr_t addr = (uintptr_t) target;
    bool thumb = (addr & 1u) != 0;
    addr &= ~(uintptr_t) 1u;
    void *p = (void *) addr;

    make_range(p, 16, PROT_READ | PROT_WRITE | PROT_EXEC);

    uint32_t dest = (uint32_t) (uintptr_t) replacement;
    if (thumb) {
        // movw r12, #lo ; movt r12, #hi ; bx r12 ; nop
        uint16_t lo = (uint16_t) (0xF240u | ((dest >> 12) & 0x0Fu));
        uint16_t lo2 = (uint16_t) (0x0C00u | (dest & 0xFFFu));
        uint16_t hi = (uint16_t) (0xF2C0u | ((dest >> 28) & 0x0Fu));
        uint16_t hi2 = (uint16_t) (0x0C00u | ((dest >> 16) & 0xFFFu));
        uint16_t bx = 0x4760u;   // bx r12
        uint16_t nop = 0xBF00u;
        uint16_t code[4] = {lo, lo2, hi, hi2};
        memcpy(p, code, 8);
        memcpy((char *) p + 8, &bx, 2);
        memcpy((char *) p + 10, &nop, 2);
        __builtin___clear_cache((char *) p, (char *) p + 12);
        make_range(p, 12, PROT_READ | PROT_EXEC);
    } else {
        uint32_t insn = 0xE51FF004u;  // ldr pc, [pc, #-4]
        memcpy(p, &insn, 4);
        memcpy((char *) p + 4, &dest, 4);
        __builtin___clear_cache((char *) p, (char *) p + 8);
        make_range(p, 8, PROT_READ | PROT_EXEC);
    }
    return true;

#else
    (void) target;
    (void) replacement;
    return false;
#endif
}

// ---------------------------------------------------------------- 扫库打补丁

/** 已经改过的地址,避免重复打补丁把入口写成跳自己 */
static uintptr_t g_done[256];
static int g_doneCount = 0;
static int g_patchCount = 0;
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

static bool already_done(uintptr_t addr) {
    for (int i = 0; i < g_doneCount; i++) {
        if (g_done[i] == addr) return true;
    }
    return false;
}

static void remember(uintptr_t addr) {
    if (g_doneCount < (int) (sizeof(g_done) / sizeof(g_done[0]))) {
        g_done[g_doneCount++] = addr;
    }
}

/** 在一个库句柄里找符号并打补丁 */
static void patch_in_handle(void *handle) {
    if (handle == nullptr) return;
    for (int i = 0; i < kTargetCount; i++) {
        void *addr = dlsym(handle, kTargets[i].symbol);
        if (addr == nullptr) continue;
        uintptr_t a = (uintptr_t) addr & ~(uintptr_t) 1u;
        pthread_mutex_lock(&g_lock);
        bool skip = already_done(a);
        if (!skip) remember(a);
        pthread_mutex_unlock(&g_lock);
        if (skip) continue;
        if (patch_entry(addr, kTargets[i].replacement)) {
            g_patchCount++;
            LOGI("patched %s @ %p", kTargets[i].symbol, addr);
        } else {
            LOGI("patch failed %s @ %p", kTargets[i].symbol, addr);
        }
    }
}

struct LibHit {
    char names[512][160];
    int count;
};

static int collect_lib(struct dl_phdr_info *info, size_t, void *data) {
    auto *hit = (LibHit *) data;
    if (info->dlpi_name == nullptr || info->dlpi_name[0] == '\0') return 0;
    if (hit->count >= 512) return 0;
    // 同一路径只留一份
    for (int i = 0; i < hit->count; i++) {
        if (strcmp(hit->names[i], info->dlpi_name) == 0) return 0;
    }
    strncpy(hit->names[hit->count], info->dlpi_name, sizeof(hit->names[0]) - 1);
    hit->names[hit->count][sizeof(hit->names[0]) - 1] = '\0';
    hit->count++;
    return 0;
}

static void scan_all() {
    // 1) 全局符号表里能直接找到的
    void *global = dlopen(nullptr, RTLD_NOW);
    patch_in_handle(global);

    // 2) 已经加载进来的每一个库,单独再翻一遍(很多游戏把 OpenSSL 编进自己的 so)
    auto *hit = (LibHit *) calloc(1, sizeof(LibHit));
    if (hit == nullptr) return;
    dl_iterate_phdr(collect_lib, hit);
    for (int i = 0; i < hit->count; i++) {
        void *h = dlopen(hit->names[i], RTLD_NOW | RTLD_NOLOAD);
        if (h == nullptr) continue;
        patch_in_handle(h);
        // 句柄不 dlclose:让补丁一直有效
    }
    free(hit);
}

// ---------------------------------------------------------------- 状态文件

static char g_statusPath[512];

/** 本 so 自己的路径 -> 同目录下的状态文件,调用方(本 app)读它显示结果 */
static void init_status_path() {
    Dl_info info;
    if (dladdr((void *) patch_entry, &info) == 0 || info.dli_fname == nullptr) return;
    strncpy(g_statusPath, info.dli_fname, sizeof(g_statusPath) - 1);
    char *slash = strrchr(g_statusPath, '/');
    if (slash == nullptr) return;
    strcpy(slash + 1, "overupdate.status");
}

static void write_status(const char *text) {
    if (g_statusPath[0] == '\0') return;
    FILE *f = fopen(g_statusPath, "w");
    if (f == nullptr) return;
    fputs(text, f);
    fclose(f);
}

static void *rescan_thread(void *) {
    // 游戏启动早期可能后面才加载 libssl / 自己的 ssl 库,前 40 秒每隔一秒补扫一遍
    for (int i = 0; i < 40; i++) {
        struct timespec ts{};
        ts.tv_sec = 1;
        nanosleep(&ts, nullptr);
        int before = g_patchCount;
        scan_all();
        if (g_patchCount != before) {
            char buf[512];
            snprintf(buf, sizeof(buf), "ok\ntotal=%d\nupdated=%ld\npacks=%d\n",
                     g_patchCount, (long) time(nullptr), g_patchCount);
            write_status(buf);
        }
    }
    return nullptr;
}

static void bootstrap() {
    static bool started = false;
    if (started) return;
    started = true;

    init_status_path();
    scan_all();
    LOGI("first pass done, patched=%d", g_patchCount);

    char buf[512];
    if (g_patchCount > 0) {
        snprintf(buf, sizeof(buf), "ok\ntotal=%d\nupdated=%ld\npacks=%d\n",
                 g_patchCount, (long) time(nullptr), g_patchCount);
    } else {
        snprintf(buf, sizeof(buf), "none\ntotal=0\nupdated=%ld\npacks=0\n",
                 (long) time(nullptr));
    }
    write_status(buf);

    pthread_t th;
    if (pthread_create(&th, nullptr, rescan_thread, nullptr) == 0) {
        pthread_detach(th);
    }
}

extern "C" __attribute__((constructor)) void overupdate_ctor() {
    bootstrap();
}

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void) vm;
    (void) reserved;
    bootstrap();
    return JNI_VERSION_1_6;
}
