package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.Md5Util
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import java.io.File
import java.util.zip.ZipFile

/**
 * 免 root 过更新。
 *
 * 以前「过更新」挂的是那份 Xposed 模块(JustTrustMePP),只有框架注入(LSPosed,通常要 root)
 * 才跑得起来。这里换了个写法:自己带一个原生库 liboverupdate.so,进程注入时先把它
 * dlopen 进游戏进程,它进去以后直接把 TLS 校验的那几个入口函数改掉
 * (X509_verify_cert / SSL_get_verify_result / SSL_CTX_set_verify / SSL_CTX_set_custom_verify /
 *  mbedTLS 那几个),证书校验一律放行。不依赖 Xposed、不依赖 root,
 * 走的就是原来那条免 root 的进程注入通道。
 *
 * 目标进程里是不是真的打上了补丁,它自己会写一行状态到目标数据目录,
 * 注入完这边读出来显示,不靠猜。
 */
object OverUpdate {

    private const val SO_NAME = "liboverupdate.so"
    private const val STATUS_NAME = "overupdate.status"

    /** 逐个试的架构顺序:先试本机装的那份,再试另外两种 */
    private val ABIS = listOf("arm64-v8a", "armeabi-v7a")

    /** 目标数据目录里的状态文件 */
    fun statusFile(context: Context, targetPkg: String): File? {
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        return File(File(dataDir, "files"), STATUS_NAME)
    }

    private fun targetFilesDir(context: Context, targetPkg: String): File? {
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        val dir = File(dataDir, "files")
        return if (PermissionUtil.canWriteDir(dir) || PermissionUtil.canWriteDir(File(dataDir))) dir else null
    }

    /** 本机安装目录里那份(按设备主 ABI 装进来的) */
    private fun installedLib(context: Context): File? =
        File(context.applicationInfo.nativeLibraryDir, SO_NAME)
            .takeIf { it.isFile && it.length() > 0L }

    /**
     * 从安装包 lib/<abi>/ 里再抽一份出来。
     * 游戏是 32 位进程时,64 位那份 dlopen 不进,得用 32 位那份。
     */
    private fun extractFromApk(context: Context, abi: String, dir: File): File? {
        val dst = File(dir, "liboverupdate_$abi.so")
        if (dst.isFile && dst.length() > 0L) return dst
        return try {
            ZipFile(context.applicationInfo.sourceDir).use { zip ->
                val entry = zip.getEntry("lib/$abi/$SO_NAME") ?: return null
                zip.getInputStream(entry).use { input ->
                    dst.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                }
            }
            dst.setReadable(true, false)
            dst.setExecutable(true, false)
            dst.takeIf { it.isFile && it.length() > 0L }
        } catch (t: Throwable) {
            null
        }
    }

    /** 备好要注入的补丁库(可能有多份,按架构逐个试) */
    private fun prepare(context: Context, targetPkg: String): List<File> {
        val dir = targetFilesDir(context, targetPkg) ?: return emptyList()
        val out = mutableListOf<File>()

        installedLib(context)?.let { src ->
            val dst = File(dir, SO_NAME)
            val same = dst.isFile && dst.length() == src.length() &&
                Md5Util.md5(dst) == Md5Util.md5(src)
            if (same || Md5Util.copyWithVerify(src, dst, Md5Util.md5(src))) {
                dst.setReadable(true, false)
                dst.setExecutable(true, false)
                out.add(dst)
            }
        }
        for (abi in ABIS) {
            extractFromApk(context, abi, dir)?.let { f ->
                if (out.none { it.absolutePath == f.absolutePath }) out.add(f)
            }
        }
        return out
    }

    data class Report(val ok: Boolean, val detail: String)

    /**
     * 往目标进程打补丁库。打进去不代表万事大吉:状态文件里有 total>0 才算真的改掉了校验函数。
     */
    fun install(context: Context, targetPkg: String, pids: List<Int>): Report {
        if (pids.isEmpty()) return Report(false, "目标没在跑,过更新没装上")

        val libs = prepare(context, targetPkg)
        if (libs.isEmpty()) return Report(false, "过更新库复制不进目标目录(权限不足)")

        statusFile(context, targetPkg)?.delete()

        var lastError: String? = null
        for (lib in libs) {
            var loaded = 0
            for (pid in pids) {
                val r = PtraceInjector.inject(pid, lib.absolutePath, null)
                if (r.isSuccess) {
                    loaded++
                } else {
                    lastError = PtraceInjector.lastDetail
                        ?: (r as? PtraceInjectResult.Failure)?.detail
                }
            }
            if (loaded == 0) continue

            val text = runCatching {
                statusFile(context, targetPkg)?.readText()
            }.getOrNull().orEmpty()
            val hits = Regex("total=(\\d+)").find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            return when {
                hits > 0 -> Report(true, "过更新已生效(证书校验已放开,$hits 处)")
                text.startsWith("none") ->
                    Report(true, "过更新库已载入,这一轮还没扫到 TLS 库,游戏联网后会自动再补一遍")
                else -> Report(true, "过更新库已注入")
            }
        }
        return Report(false, "过更新库注入失败:" + (lastError ?: "未知原因"))
    }
}
