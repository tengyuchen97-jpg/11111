package com.tengcd.czr.xposed

import android.content.Context
import android.os.Build
import dalvik.system.DexClassLoader
import dalvik.system.InMemoryDexClassLoader
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.io.File
import java.nio.ByteBuffer
import java.util.zip.ZipFile

/**
 * 过更新模块(内置 JustTrustMePP)。
 *
 * 它做的事很简单:在目标进程里把 OkHttp / Conscrypt / HttpsURLConnection 那几个
 * 证书固定(CertificatePinner、HostnameVerifier、TrustManager、SSL socket)全部放开,
 * 目标检查更新走的那几条请求就不再被 pinning 拦住,配合代理/本地响应就能把更新提示过掉。
 *
 * 集成方式:
 *  - 原来那份模块 apk 的 classes.dex 原样放进本模块的 assets/patch/justtrustmepp.dex
 *  - 目标进程起来后按需加载这个 dex,反射调它的入口 XC_LoadPackage 回调
 *  - 开关在偏好里(over_update):关掉就一个 hook 都不装
 *
 * 为什么用独立 DexClassLoader 而不是把它的代码并进本模块:
 *  它自带一整套 androidx,并进来会让本模块的包大一圈、还容易和已有的 androidx 版本打架;
 *  独立加载互不干扰,而且在目标进程里只加载它自己的那份。
 */
object UpdateBypass {

    /** assets 里那份 dex 的位置 */
    private const val DEX_ENTRY = "assets/patch/justtrustmepp.dex"

    /** 过更新模块的入口类(和它 apk 里 assets/xposed_init 写的一致) */
    private const val HOOK_CLASS = "com.junge.JustTrustMePP.Hook"

    /** 入口方法:handleLoadPackage(XC_LoadPackage.LoadPackageParam) */
    private const val HOOK_METHOD = "handleLoadPackage"

    private const val OUR_PACKAGE = "com.tengcd.czr"

    /** 本进程里已经装过了(每个目标进程各自一份,静态变量正好) */
    @Volatile
    private var installed = false

    /** 上一次失败原因,界面/日志里能看 */
    @Volatile
    var lastError: String? = null
        private set

    val isInstalled: Boolean get() = installed

    /**
     * 装上过更新 hook。装过就不再重复装。
     *
     * @param apkPath 本模块安装包路径(initZygote 给的,拿不到就靠 context 去 PackageManager 查)
     * @param lpparam 框架传进来的目标进程参数,里面带着目标的 ClassLoader
     * @param context 目标应用的 Context,还没有就传 null
     */
    fun install(
        apkPath: String?,
        lpparam: XC_LoadPackage.LoadPackageParam?,
        context: Context? = null
    ): Boolean {
        if (installed) return true
        if (lpparam == null) {
            lastError = "没拿到目标进程参数"
            return false
        }
        val apk = resolveApk(apkPath, context)
        if (apk == null) {
            lastError = "找不到本模块安装包"
            log("过更新:找不到本模块安装包")
            return false
        }
        val bytes = try {
            readDexBytes(apk)
        } catch (t: Throwable) {
            lastError = "读过更新 dex 失败:" + (t.message ?: t.javaClass.simpleName)
            log("过更新:" + lastError)
            return false
        }
        if (bytes == null || bytes.isEmpty()) {
            lastError = "安装包里没有过更新 dex"
            log("过更新:" + lastError)
            return false
        }

        val loader = try {
            buildLoader(bytes, context)
        } catch (t: Throwable) {
            lastError = "加载过更新 dex 失败:" + (t.message ?: t.javaClass.simpleName)
            log("过更新:" + lastError)
            return false
        }

        return try {
            val klass = Class.forName(HOOK_CLASS, true, loader)
            val entry = klass.getDeclaredConstructor().newInstance()
            val method = klass.getMethod(
                HOOK_METHOD,
                XC_LoadPackage.LoadPackageParam::class.java
            )
            method.invoke(entry, lpparam)
            installed = true
            lastError = null
            log("过更新已开启(目标=" + lpparam.packageName + ")")
            true
        } catch (t: Throwable) {
            val cause = t.cause ?: t
            lastError = "过更新入口执行失败:" + (cause.message ?: cause.javaClass.simpleName)
            log("过更新:" + lastError)
            false
        }
    }

    /** 安卓 8 以上直接在内存里加载(不用落盘、不怕目标目录没权限),以下才写到缓存目录 */
    private fun buildLoader(bytes: ByteArray, context: Context?): ClassLoader {
        val parent = UpdateBypass::class.java.classLoader
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return InMemoryDexClassLoader(ByteBuffer.wrap(bytes), parent)
        }
        val dir = File(
            (context?.codeCacheDir ?: File("/data/local/tmp")).absolutePath,
            "patch"
        )
        if (!dir.isDirectory) dir.mkdirs()
        val dex = File(dir, "justtrustmepp.dex")
        if (!dex.isFile || dex.length() != bytes.size.toLong()) {
            dex.outputStream().use { it.write(bytes) }
        }
        return DexClassLoader(dex.absolutePath, dir.absolutePath, null, parent)
    }

    /** 从模块安装包里把 dex 读出来 */
    private fun readDexBytes(apk: File): ByteArray? = ZipFile(apk).use { zip ->
        val entry = zip.getEntry(DEX_ENTRY) ?: return null
        zip.getInputStream(entry).use { it.readBytes() }
    }

    private fun resolveApk(apkPath: String?, context: Context?): File? {
        apkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        val ctx = context ?: return null
        return try {
            val info = ctx.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    private fun log(msg: String) {
        try {
            XposedBridge.log("[Tengcd] $msg")
        } catch (t: Throwable) {
        }
    }
}
