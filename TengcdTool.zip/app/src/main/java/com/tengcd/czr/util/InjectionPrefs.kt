package com.tengcd.czr.util

import android.content.Context
import android.content.SharedPreferences

/**
 * 全局配置存取。所有状态都落在一个 SharedPreferences 里,
 * 跨进程(注入服务 / HookInit)读的话走 SoProvider.call()。
 */
object InjectionPrefs {

    private const val FILE = "honffx_inject"

    const val KEY_MODULE_PATH = "module_path"
    const val KEY_MODULE_VERSION = "module_version"
    const val KEY_MODULE_MD5 = "module_md5"
    const val KEY_REMOTE_VERSION = "remote_version"
    const val KEY_SO_URL = "so_url"
    const val KEY_ANNOUNCEMENT = "announcement"
    const val KEY_TARGET_PACKAGE = "target_package"
    const val KEY_CARD_KEY = "card_key"
    const val KEY_MODE = "injection_mode"
    const val KEY_DARK = "dark_theme"
    const val KEY_FRAMEWORK_ACTIVE = "framework_active"
    const val KEY_LAST_INJECT = "last_inject_time"
    const val KEY_BOOT_AUTOSTART = "boot_autostart"
    const val KEY_CONFIG_URL = "config_url"
    const val KEY_LOCAL_CARD_MODE = "local_card_mode"
    const val KEY_LOCAL_CARD = "local_card"
    const val KEY_BOUND_DEVICE = "bound_device"

    /** 当前选中的内置 SO 变体(模块概览下面那个选择器) */
    const val KEY_SO_VARIANT = "so_variant"

    /** 注入源:builtin = 用内置变体,local = 用本机读取进来的 so */
    const val KEY_SO_SOURCE = "so_source"

    /** 本机读取的 so 原始路径(只做展示,真正注入用的是私有目录那份) */
    const val KEY_LOCAL_SO_SOURCE_PATH = "local_so_source_path"

    /** 内置 so 的解包指纹(安装包版本 + 安装时间),换了包要重新解包 */
    const val KEY_SO_BUNDLE_STAMP = "so_bundle_stamp"

    /** 框架注入:目标进程里模块加载失败的原因(由目标进程回报) */
    const val KEY_FRAMEWORK_ERROR = "framework_error"

    /** 框架注入:目标进程里实际加载成功的 so 路径 */
    const val KEY_FRAMEWORK_PATH = "framework_path"

    /** 框架注入:目标进程已经收到注入信号(= LSPosed 确实把模块塞进去了) */
    const val KEY_FRAMEWORK_HOOKED = "framework_hooked"

    /** 框架注入:最近一次回报的阶段 hooked / loaded / error */
    const val KEY_FRAMEWORK_STAGE = "framework_stage"

    /** 框架注入:最近一次回报的时间戳 */
    const val KEY_FRAMEWORK_STAGE_AT = "framework_stage_at"

    /** 框架注入:回报来自哪个进程(排查用) */
    const val KEY_FRAMEWORK_PROCESS = "framework_process"

    /** 资源导入:上次选中的源文件夹(SAF tree uri) */
    const val KEY_IMPORT_FOLDER_URI = "import_folder_uri"

    /** 资源导入:源文件夹(SAF) */
    const val KEY_IMPORT_SOURCE_URI = "import_source_uri"

    /** 资源导入:目标文件夹(SAF) */
    const val KEY_IMPORT_TARGET_URI = "import_target_uri"

    /** 资源导入:目标文件夹(手输绝对路径) */
    const val KEY_IMPORT_TARGET_PATH = "import_target_path"

    /** 资源导入:true = 先清空目标再写 */
    const val KEY_IMPORT_REPLACE_ALL = "import_replace_all"

    /** T3 网络验证:服务器地址 / appid / appkey / 通信密钥 */
    const val KEY_T3_BASE_URL = "t3_base_url"
    const val KEY_T3_APP_ID = "t3_app_id"
    const val KEY_T3_APP_KEY = "t3_app_key"
    const val KEY_T3_AES_KEY = "t3_aes_key"
    const val KEY_T3_CHARSET = "t3_charset"

    /** T3 网络验证:上次登录留下的 token / 到期时间 / 卡密 */
    const val KEY_T3_TOKEN = "t3_token"
    const val KEY_T3_EXPIRE = "t3_expire"
    const val KEY_T3_CARD = "t3_card"
    const val KEY_T3_COUNT_CARD = "t3_count_card"
    const val KEY_T3_VERIFIED = "t3_verified"
    const val KEY_T3_REMAIN_COUNT = "t3_remain_count"
    const val KEY_T3_REMAIN_TIME = "t3_remain_time"
    const val KEY_T3_CARD_TYPE = "t3_card_type"
    const val KEY_T3_COUNT_CARD_ID = "t3_count_card_id"
    const val KEY_T3_MACHINE_CODE = "t3_machine_code"

    /** T3:记住卡密,下次打开直接进(不用再输一遍) */
    const val KEY_T3_AUTOLOGIN = "t3_autologin"

    /** T3:上次登录成功的时间(毫秒) */
    const val KEY_T3_LOGIN_AT = "t3_login_at"

    /** T3:上次成功读到的后台版本号(读不到时拿来兜底,免得每次都提示"没读到") */
    const val KEY_T3_REMOTE_VER = "t3_remote_ver"
    const val KEY_T3_REMOTE_VER_AT = "t3_remote_ver_at"

    /** T3:请求体格式 auto / json / form */
    const val KEY_T3_REQ_FORMAT = "t3_req_format"

    /** T3:探测成功后记住的接口路径,下次直接打,不用再试 */
    const val KEY_T3_PATH_LOGIN = "t3_path_login"
    const val KEY_T3_PATH_QUERY = "t3_path_query"
    const val KEY_T3_PATH_UNBIND = "t3_path_unbind"
    const val KEY_T3_PATH_HEARTBEAT = "t3_path_heartbeat"
    const val KEY_T3_PATH_NOTICE = "t3_path_notice"

    /** T3:公告缓存,断网时也能显示上次拉的 */
    const val KEY_T3_NOTICE = "t3_notice_cache"
    const val KEY_T3_NOTICE_TIME = "t3_notice_time"

    /** T3 后台给的 appkey(用户给的那个 32 位 md5 串) */
    const val DEFAULT_T3_APP_KEY = "f736fd5efeb7a9ab1b6bdfcc7b364a78"

    /** RC4 加解密密钥(后台「Rc4算法加解密密钥」) */
    const val DEFAULT_T3_AES_KEY = "7lo18aX1QialEA5"

    /** T3 官方验证接口服务器(接口 = 服务器 + 调用码,不带 php 路径) */
    const val DEFAULT_T3_BASE_URL = "https://w.t3yanzheng.com"

    /** Base64 自定义编码集(后台「Base64算法编码集」,必须是 64 位) */
    const val DEFAULT_T3_CHARSET =
        "kXcZ3OBKtPVsR5w1Fdmjl2GLg4SYfNhrUWopiI6+z/TnvbauQeCy9Aq8HMJ70DEx"

    const val DEFAULT_SO_VARIANT = "v0.24"
    const val SO_SOURCE_BUILTIN = "builtin"
    const val SO_SOURCE_LOCAL = "local"
    const val SO_SOURCE_REMOTE = "remote"

    const val DEFAULT_TARGET_PACKAGE = "com.pi.czrxdfirst"

    /** 远端配置地址:换成你自己的服务端就行 */
    const val DEFAULT_CONFIG_URL = "https://example.com/api/honffx/config.json"

    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences =
        sp ?: throw IllegalStateException("InjectionPrefs.init() 还没调用")

    private fun putString(key: String, value: String?) {
        p().edit().putString(key, value).apply()
    }

    var modulePath: String?
        get() = p().getString(KEY_MODULE_PATH, null)
        set(v) = putString(KEY_MODULE_PATH, v)

    var moduleVersion: String?
        get() = p().getString(KEY_MODULE_VERSION, null)
        set(v) = putString(KEY_MODULE_VERSION, v)

    var moduleMd5: String?
        get() = p().getString(KEY_MODULE_MD5, null)
        set(v) = putString(KEY_MODULE_MD5, v)

    var remoteVersion: String?
        get() = p().getString(KEY_REMOTE_VERSION, null)
        set(v) = putString(KEY_REMOTE_VERSION, v)

    var soUrl: String?
        get() = p().getString(KEY_SO_URL, null)
        set(v) = putString(KEY_SO_URL, v)

    var announcement: String?
        get() = p().getString(KEY_ANNOUNCEMENT, null)
        set(v) = putString(KEY_ANNOUNCEMENT, v)

    var targetPackage: String
        get() = p().getString(KEY_TARGET_PACKAGE, DEFAULT_TARGET_PACKAGE) ?: DEFAULT_TARGET_PACKAGE
        set(v) = putString(KEY_TARGET_PACKAGE, v)

    var cardKey: String
        get() = p().getString(KEY_CARD_KEY, "") ?: ""
        set(v) = putString(KEY_CARD_KEY, v)

    var injectionMode: Int
        get() = p().getInt(KEY_MODE, 0)
        set(v) = p().edit().putInt(KEY_MODE, v).apply()

    var darkTheme: Boolean
        get() = p().getBoolean(KEY_DARK, false)
        set(v) = p().edit().putBoolean(KEY_DARK, v).apply()

    var frameworkActive: Boolean
        get() = p().getBoolean(KEY_FRAMEWORK_ACTIVE, false)
        set(v) = p().edit().putBoolean(KEY_FRAMEWORK_ACTIVE, v).apply()

    var lastInjectTime: Long
        get() = p().getLong(KEY_LAST_INJECT, 0L)
        set(v) = p().edit().putLong(KEY_LAST_INJECT, v).apply()

    var bootAutoStart: Boolean
        get() = p().getBoolean(KEY_BOOT_AUTOSTART, false)
        set(v) = p().edit().putBoolean(KEY_BOOT_AUTOSTART, v).apply()

    var configUrl: String
        get() = p().getString(KEY_CONFIG_URL, DEFAULT_CONFIG_URL) ?: DEFAULT_CONFIG_URL
        set(v) = putString(KEY_CONFIG_URL, v)

    /**
     * 卡密一律走 T3 网络验证,这里恒为 false。
     * 老安装包在 SharedPreferences 里留下的 true 也不再生效,杜绝用本地卡密绕过验证。
     */
    var localCardMode: Boolean
        get() = false
        set(v) = p().edit().putBoolean(KEY_LOCAL_CARD_MODE, false).apply()

    /** 本地卡密(本地校验模式下用,多个用英文逗号分隔) */
    var localCard: String
        get() = p().getString(KEY_LOCAL_CARD, "遄懂666") ?: "遄懂666"
        set(v) = putString(KEY_LOCAL_CARD, v)

    var boundDevice: String?
        get() = p().getString(KEY_BOUND_DEVICE, null)
        set(v) = putString(KEY_BOUND_DEVICE, v)

    /** 当前选中的内置 SO 变体名,例如 v0.19 / v0.20 / v0.23 / v0.24 */
    var soVariant: String
        get() = p().getString(KEY_SO_VARIANT, DEFAULT_SO_VARIANT) ?: DEFAULT_SO_VARIANT
        set(v) = putString(KEY_SO_VARIANT, v)

    /** builtin / local */
    var soSource: String
        get() = p().getString(KEY_SO_SOURCE, SO_SOURCE_BUILTIN) ?: SO_SOURCE_BUILTIN
        set(v) = putString(KEY_SO_SOURCE, v)

    /** 本机选中的 so 在手机上的原始路径(展示用) */
    var importFolderUri: String?
        get() = p().getString(KEY_IMPORT_FOLDER_URI, null)
        set(v) = putString(KEY_IMPORT_FOLDER_URI, v)

    /** 资源导入:源文件夹 SAF uri */
    var importSourceUri: String?
        get() = p().getString(KEY_IMPORT_SOURCE_URI, null)
        set(v) = putString(KEY_IMPORT_SOURCE_URI, v)

    /** 资源导入:目标文件夹 SAF uri */
    var importTargetUri: String?
        get() = p().getString(KEY_IMPORT_TARGET_URI, null)
        set(v) = putString(KEY_IMPORT_TARGET_URI, v)

    /** 资源导入:目标文件夹绝对路径(手输那条路) */
    var importTargetPath: String
        get() = p().getString(KEY_IMPORT_TARGET_PATH, FolderImporter.DEFAULT_TARGET_PATH)
            ?: FolderImporter.DEFAULT_TARGET_PATH
        set(v) = putString(KEY_IMPORT_TARGET_PATH, v)

    /** true = 整目录替换(先清空目标) */
    var importReplaceAll: Boolean
        get() = p().getBoolean(KEY_IMPORT_REPLACE_ALL, false)
        set(v) = p().edit().putBoolean(KEY_IMPORT_REPLACE_ALL, v).apply()

    var localSoSourcePath: String?
        get() = p().getString(KEY_LOCAL_SO_SOURCE_PATH, null)
        set(v) = putString(KEY_LOCAL_SO_SOURCE_PATH, v)

    /** 上次解包内置 so 时的安装包指纹 */
    var soBundleStamp: String?
        get() = p().getString(KEY_SO_BUNDLE_STAMP, null)
        set(v) = putString(KEY_SO_BUNDLE_STAMP, v)

    /** 目标进程回报的模块加载失败原因 */
    var frameworkError: String?
        get() = p().getString(KEY_FRAMEWORK_ERROR, null)
        set(v) = putString(KEY_FRAMEWORK_ERROR, v)

    /** 目标进程里真正加载成功的 so 路径 */
    var frameworkPath: String?
        get() = p().getString(KEY_FRAMEWORK_PATH, null)
        set(v) = putString(KEY_FRAMEWORK_PATH, v)

    /** 目标进程有没有收到注入信号(收到 = LSPosed 模块开关和作用域都没问题) */
    var frameworkHooked: Boolean
        get() = p().getBoolean(KEY_FRAMEWORK_HOOKED, false)
        set(v) = p().edit().putBoolean(KEY_FRAMEWORK_HOOKED, v).apply()

    /** 最近一次回报阶段:hooked / loaded / error */
    var frameworkStage: String?
        get() = p().getString(KEY_FRAMEWORK_STAGE, null)
        set(v) = putString(KEY_FRAMEWORK_STAGE, v)

    var frameworkStageAt: Long
        get() = p().getLong(KEY_FRAMEWORK_STAGE_AT, 0L)
        set(v) = p().edit().putLong(KEY_FRAMEWORK_STAGE_AT, v).apply()

    /** 回报来自哪个进程 */
    var frameworkProcess: String?
        get() = p().getString(KEY_FRAMEWORK_PROCESS, null)
        set(v) = putString(KEY_FRAMEWORK_PROCESS, v)

    /** 一次把框架状态全部清干净(重新注入 / 换目标时用) */
    fun resetFrameworkState() {
        p().edit()
            .putBoolean(KEY_FRAMEWORK_ACTIVE, false)
            .putBoolean(KEY_FRAMEWORK_HOOKED, false)
            .remove(KEY_FRAMEWORK_STAGE)
            .remove(KEY_FRAMEWORK_PROCESS)
            .remove(KEY_FRAMEWORK_ERROR)
            .remove(KEY_FRAMEWORK_PATH)
            .apply()
    }

    // ---------------- T3 网络验证 ----------------

    /**
     * T3 验证接口服务器:写死,只读。
     * 老安装包里存过什么脏值都不认,统一用官方接口机,用户改不了。
     */
    var t3BaseUrl: String
        get() = DEFAULT_T3_BASE_URL
        set(v) = Unit

    var t3AppId: String
        get() = ""
        set(v) = Unit

    var t3AppKey: String
        get() = DEFAULT_T3_APP_KEY
        set(v) = Unit

    var t3AesKey: String
        get() = DEFAULT_T3_AES_KEY
        set(v) = Unit

    /** Base64 自定义编码集(64 位):同样写死只读 */
    var t3Charset: String
        get() = DEFAULT_T3_CHARSET
        set(v) = Unit

    /** 登录成功后服务端给的 token */
    var t3Token: String
        get() = p().getString(KEY_T3_TOKEN, "") ?: ""
        set(v) = putString(KEY_T3_TOKEN, v)

    /** token 到期时间(毫秒时间戳,0 = 服务端没给,按不过期处理) */
    var t3Expire: Long
        get() = p().getLong(KEY_T3_EXPIRE, 0L)
        set(v) = p().edit().putLong(KEY_T3_EXPIRE, v).apply()

    /** 上次登录用的卡密,退出登录后还能自动带出来 */
    var t3Card: String
        get() = p().getString(KEY_T3_CARD, "") ?: ""
        set(v) = putString(KEY_T3_CARD, v)

    /**
     * 这张是计次卡。计次卡每重登一次就扣一次次数,
     * 所以心跳失败时不能自动重登,重启后也要知道这一点。
     */
    var t3CountCard: Boolean
        get() = p().getBoolean(KEY_T3_COUNT_CARD, false)
        set(v) = p().edit().putBoolean(KEY_T3_COUNT_CARD, v).apply()

    /** 已经验证通过(有些后台登录只给「验证通过」不给 statecode,靠这个记住登录态) */
    var t3Verified: Boolean
        get() = p().getBoolean(KEY_T3_VERIFIED, false)
        set(v) = p().edit().putBoolean(KEY_T3_VERIFIED, v).apply()

    /**
     * 记住卡密:第一次登录成功后置 true,以后打开 App 直接进主界面,
     * 不再弹验证页。手动点「退出验证」时清掉。
     */
    var t3AutoLogin: Boolean
        get() = p().getBoolean(KEY_T3_AUTOLOGIN, false)
        set(v) = p().edit().putBoolean(KEY_T3_AUTOLOGIN, v).apply()

    /** 上次登录成功的时间(毫秒时间戳,0 = 从没登过) */
    var t3LoginAt: Long
        get() = p().getLong(KEY_T3_LOGIN_AT, 0L)
        set(v) = p().edit().putLong(KEY_T3_LOGIN_AT, v).apply()

    /**
     * 剩余次数。-1 = 还不知道 / 不是次数卡。
     * T3 后台没有"只读查次数"的接口(状态接口回的 available 是剩余秒数),
     * 次数只在登录回包里出现,所以这里缓存登录时读到的那一份,
     * 界面上永远有数可显示,不用为了看次数反复登录把次数烧光。
     */
    var t3RemainCount: Int
        get() = p().getInt(KEY_T3_REMAIN_COUNT, -1)
        set(v) = p().edit().putInt(KEY_T3_REMAIN_COUNT, v).apply()

    /**
     * 上面那份「剩余次数 / 卡类型」是**哪一张卡**的。
     * 以前不分卡,查一张新卡时会把上一张卡的次数和类型补上去,
     * 表现就是"查询结果总是错的"(输入 A 卡却显示 B 卡的数字)。
     */
    var t3CountCardId: String
        get() = p().getString(KEY_T3_COUNT_CARD_ID, "") ?: ""
        set(v) = putString(KEY_T3_COUNT_CARD_ID, v)

    /** 上次读到剩余次数的时间(展示用) */
    var t3RemainTime: String
        get() = p().getString(KEY_T3_REMAIN_TIME, "") ?: ""
        set(v) = putString(KEY_T3_REMAIN_TIME, v)

    /** 卡类型原文,后台 amount 字段:1年 / 30天 / 99次 */
    var t3CardType: String
        get() = p().getString(KEY_T3_CARD_TYPE, "") ?: ""
        set(v) = putString(KEY_T3_CARD_TYPE, v)

    /** 上次绑定/登录时用的机器码(卡密页展示 + 复制给后台改绑用) */
    var t3MachineCode: String
        get() = p().getString(KEY_T3_MACHINE_CODE, "") ?: ""
        set(v) = putString(KEY_T3_MACHINE_CODE, v)

    /** 上次读到的后台版本号:这次网络没通/字段空就用它,不再动不动提示读不到版本号 */
    var t3RemoteVersion: String
        get() = p().getString(KEY_T3_REMOTE_VER, "") ?: ""
        set(v) = putString(KEY_T3_REMOTE_VER, v)

    /** 上次从服务器读到后台版本号的时间(毫秒),界面显示「什么时候读到的」用 */
    var t3RemoteVersionAt: Long
        get() = p().getLong(KEY_T3_REMOTE_VER_AT, 0L)
        set(v) = p().edit().putLong(KEY_T3_REMOTE_VER_AT, v).apply()

    /** 请求体格式:auto(先 JSON 再表单) / json / form */
    var t3ReqFormat: String
        get() = p().getString(KEY_T3_REQ_FORMAT, "auto") ?: "auto"
        set(v) = putString(KEY_T3_REQ_FORMAT, v)

    /** 探路成功后记住的接口路径 */
    private fun readPath(key: String): String =
        p().getString(key, "") ?: ""

    private fun savePath(key: String, value: String) =
        p().edit().putString(key, value).apply()

    var t3PathLogin: String
        get() = readPath(KEY_T3_PATH_LOGIN)
        set(v) = savePath(KEY_T3_PATH_LOGIN, v)

    var t3PathQuery: String
        get() = readPath(KEY_T3_PATH_QUERY)
        set(v) = savePath(KEY_T3_PATH_QUERY, v)

    var t3PathUnbind: String
        get() = readPath(KEY_T3_PATH_UNBIND)
        set(v) = savePath(KEY_T3_PATH_UNBIND, v)

    var t3PathHeartbeat: String
        get() = readPath(KEY_T3_PATH_HEARTBEAT)
        set(v) = savePath(KEY_T3_PATH_HEARTBEAT, v)

    var t3PathNotice: String
        get() = readPath(KEY_T3_PATH_NOTICE)
        set(v) = savePath(KEY_T3_PATH_NOTICE, v)

    /** 公告缓存(断网也能看上次的) */
    var t3NoticeCache: String
        get() = p().getString(KEY_T3_NOTICE, "") ?: ""
        set(v) = putString(KEY_T3_NOTICE, v)

    var t3NoticeTime: String
        get() = p().getString(KEY_T3_NOTICE_TIME, "") ?: ""
        set(v) = putString(KEY_T3_NOTICE_TIME, v)

    fun pathOf(action: String): String = when (action) {
        "login" -> t3PathLogin
        "query" -> t3PathQuery
        "unbind" -> t3PathUnbind
        "heartbeat" -> t3PathHeartbeat
        "notice" -> t3PathNotice
        else -> ""
    }

    fun savePathOf(action: String, path: String) {
        when (action) {
            "login" -> t3PathLogin = path
            "query" -> t3PathQuery = path
            "unbind" -> t3PathUnbind = path
            "heartbeat" -> t3PathHeartbeat = path
            "notice" -> t3PathNotice = path
        }
    }

    /** 换了服务器/换了后台,之前记的路径就不作数了 */
    fun clearT3Paths() {
        p().edit()
            .remove(KEY_T3_PATH_LOGIN)
            .remove(KEY_T3_PATH_QUERY)
            .remove(KEY_T3_PATH_UNBIND)
            .remove(KEY_T3_PATH_HEARTBEAT)
            .remove(KEY_T3_PATH_NOTICE)
            .apply()
    }
}
