package com.tengcd.czr.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process
import java.io.File

/**
 * 目标应用相关:装没装、跑没跑、uid 一不一样、数据目录能不能读。
 */
object PackageUtil {

    fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (t: Throwable) {
        false
    }

    fun versionName(context: Context, pkg: String): String? = try {
        context.packageManager.getPackageInfo(pkg, 0).versionName
    } catch (t: Throwable) {
        null
    }

    fun uidOf(context: Context, pkg: String): Int = try {
        context.packageManager.getApplicationInfo(pkg, 0).uid
    } catch (t: Throwable) {
        -1
    }

    fun selfUid(): Int = Process.myUid()

    /** 同一个 sharedUserId 下,两个包 uid 会一致;不一致就没法用进程注入 */
    fun sameUid(context: Context, pkg: String): Boolean {
        val other = uidOf(context, pkg)
        return other != -1 && other == selfUid()
    }

    fun sourceDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).sourceDir
    } catch (t: Throwable) {
        null
    }

    fun dataDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).dataDir
    } catch (t: Throwable) {
        null
    }

    fun nativeLibDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).nativeLibraryDir
    } catch (t: Throwable) {
        null
    }

    fun launch(context: Context, pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            context.startActivity(intent)
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** 扫描 /proc,按 cmdline 找 pid;一个包可能有多个进程 */
    fun findPids(pkg: String): List<Int> = findPids(pkg, -1)

    /**
     * 扫描 /proc 找目标进程。
     *
     * 安卓 9 以后读别人的 /proc/<pid>/cmdline 经常被拦(返回空),
     * 老代码一读不到就 continue,于是目标明明在跑,界面上永远显示「未运行」。
     * 现在按两层来认:
     *   ① cmdline 直接等于包名 / 包名:xxx  —— 最准,读到就以此为准
     *   ② /proc/<pid>/status 里的 Name(comm,最多 15 字符)与包名一致 + Uid 对得上
     *
     * 以前还有第三层「只要 uid 对得上、进程名沾一点包名就算」,那一层是误报的根:
     * 共用 uid 的机器上,自己应用的进程名里也带着同一个片段(包名互含),
     * 于是目标根本没启动,界面照样报「有进程」。这层已经删掉。
     */
    fun findPids(pkg: String, uid: Int): List<Int> {
        val result = ArrayList<Int>()
        if (pkg.isBlank()) return result
        val entries = File("/proc").list() ?: return result
        val comm = pkg.take(15)                      // status 里的 Name 就是进程名截 15 字符
        val shortComm = pkg.substringAfterLast('.').take(15)
        for (name in entries) {
            val pid = name.toIntOrNull() ?: continue
            if (pid <= 1) continue
            // 进程目录都读不了就不算
            if (!procDirAccessible(pid)) continue

            // ① cmdline:能读到就以它为唯一依据
            val cmdline = readCmdline(pid)
            if (!cmdline.isNullOrBlank()) {
                if (cmdline == pkg || cmdline.startsWith("$pkg:") || cmdline.startsWith("$pkg ")) {
                    result.add(pid)
                }
                continue
            }

            // ② status:Name 必须和目标包名严格对上,再核对 uid
            val pname = readNameOfPid(pid)
            if (pname.isBlank()) continue
            val pidUid = readUidOfPid(pid)
            if (uid > 0 && pidUid != uid) continue
            if (pname == comm || pname == shortComm) {
                result.add(pid)
            }
        }
        result.sort()
        return result
    }

    /**
     * 进程目录可不可访问:能列出 /proc/<pid> 里的东西就算能。
     * 界面上「运行中 / 未运行」就按这个判。
     */
    fun procDirAccessible(pid: Int): Boolean {
        if (pid <= 0) return false
        return try {
            val dir = File("/proc/$pid")
            dir.isDirectory && dir.list()?.isNotEmpty() == true
        } catch (t: Throwable) {
            false
        }
    }

    /** status 里的 Name: 字段(就是 comm,最多 15 字符) */
    fun readNameOfPid(pid: Int): String = try {
        val status = File("/proc/$pid/status").readLines()
        var name = ""
        for (line in status) {
            if (line.startsWith("Name:")) {
                name = line.substring(5).trim()
                break
            }
        }
        name
    } catch (t: Throwable) {
        ""
    }

    fun readCmdline(pid: Int): String? = try {
        val text = File("/proc/$pid/cmdline").readBytes()
        var end = 0
        while (end < text.size && text[end] != 0.toByte()) end++
        String(text, 0, end, Charsets.UTF_8).trim()
    } catch (t: Throwable) {
        null
    }

    fun readUidOfPid(pid: Int): Int = try {
        val status = File("/proc/$pid/status").readLines()
        var uid = -1
        for (line in status) {
            if (line.startsWith("Uid:")) {
                val parts = line.substring(4).trim().split(Regex("\\s+"))
                uid = parts.firstOrNull()?.toIntOrNull() ?: -1
                break
            }
        }
        uid
    } catch (t: Throwable) {
        -1
    }

    /**
     * 这个进程是 64 位还是 32 位。
     *
     * 过更新打补丁库要按这个来:64 位进程只能吃 arm64 那份,32 位只能吃 armv7 那份。
     * 以前不判、两份都往每个 pid 上投,投错的那次要把目标所有线程冻住做一整轮
     * 远程调用(还会走 memfd 兜底),白折腾好几秒,游戏模块的注入就跟着废了。
     *
     * @return true = 64 位,false = 32 位,null = 判断不出来
     */
    fun isPid64(pid: Int): Boolean? {
        if (pid <= 0) return null
        // ① /proc/<pid>/exe -> /system/bin/app_process64 / app_process32
        try {
            val exe = File("/proc/$pid/exe").canonicalPath
            if (exe.contains("app_process64")) return true
            if (exe.contains("app_process32")) return false
        } catch (t: Throwable) {
        }
        // ② maps 里第一个带 /lib64/ 或 /lib/ 的库,定死架构
        try {
            val maps = File("/proc/$pid/maps")
            if (maps.canRead()) {
                var saw32 = false
                for (line in maps.readLines()) {
                    val path = line.substringAfterLast(' ', "").trim()
                    if (path.isEmpty()) continue
                    if (path.contains("/lib64/") || path.contains("linker64")) return true
                    // 注意:64 位游戏自己的库路径里也有 /lib/ 这一层(…/lib/arm64/…),
                    // 所以这里只记一笔、不立刻下定论,整份 maps 没有 lib64 才判 32 位
                    if (path.contains("/lib/") || path.contains("armeabi") ||
                        path.contains("linker")
                    ) {
                        saw32 = true
                    }
                }
                if (saw32) return false
            }
        } catch (t: Throwable) {
        }
        return null
    }

    fun processNameOfPid(pid: Int): String {
        val cmd = try {
            File("/proc/$pid/cmdline").readText(Charsets.UTF_8).replace('\u0000', ' ').trim()
        } catch (t: Throwable) {
            ""
        }
        // 安卓 10+ 读不到别人的 cmdline 时,退回 status 里的 Name,别在界面上显示空进程名
        return cmd.ifBlank { readNameOfPid(pid) }
    }

    fun isRunning(pkg: String): Boolean = findPids(pkg).isNotEmpty()

    fun installedTargets(context: Context): List<Pair<String, String>> {
        val pm: PackageManager = context.packageManager
        val list = ArrayList<Pair<String, String>>()
        val pkgs = pm.getInstalledPackages(0)
        for (info in pkgs) {
            val p = info.packageName
            if (p == context.packageName) continue
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            } catch (t: Throwable) {
                p
            }
            list.add(p to label)
        }
        return list
    }
}
