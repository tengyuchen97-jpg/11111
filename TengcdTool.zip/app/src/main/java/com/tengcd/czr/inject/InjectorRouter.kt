package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 */
object InjectorRouter {

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        // 换过安装包也要先把内置 so 重新解包一遍,别拿旧的占位文件去加载
        ModuleStore.ensureBundled(context)

        if (!ModuleStore.isDownloaded(context)) {
            // 只开了过更新、还没导游戏 SO 时:过更新自己也能单独跑,别一句"模块没就绪"全挡了
            if (InjectionPrefs.overUpdate) {
                return@withContext if (mode == InjectionMode.PROCESS) {
                    processInjectPatchOnly(context, targetPkg)
                } else {
                    // 框架模式下补丁库由目标进程自己加载,这边只要开关是开的就行
                    PtraceInjectResult.Success(
                        pid = -1,
                        soPath = "",
                        detail = "过更新已就绪(目标启动时自动加载)," +
                            "游戏 SO 还没导入,导入后再注入模块"
                    )
                }
            }
            // 选中的这一版本机没有真 so、只有空文件占位时说清楚是哪一版,
            // 不再偷偷换成别的版本去注入(以前就是这么被换回 v0.24 的)。
            val f = ModuleStore.effectiveFile(context)
            val why = if (f.isFile) {
                "选中的 " + ModuleStore.sourceLabel() + " 本机还没有 so 文件(空文件占位)," +
                    "把这个版本的 so 放进私有目录或导入本机 SO 后再注入"
            } else {
                "选中的 " + ModuleStore.sourceLabel() + " 还没解包出文件"
            }
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry)
        }
    }

    /**
     * 只打过更新、不注游戏模块(用户还没导 SO 时也能单独验证过更新有没有用)。
     */
    private fun processInjectPatchOnly(context: Context, targetPkg: String): PtraceInjectResult {
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.SAME_UID_REQUIRED,
                "本应用与目标应用的 uid 不一致(需要 sharedUserId 相同)"
            )
        }
        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_FOUND, "目标没在跑")
        }
        // 两份都备好:目标主进程 64 位、子进程可能是 32 位,
        // 投错位数的那份必然 dlopen 失败,还白冻一次目标线程。
        val lib64 = OverUpdate.stageLib(context, targetPkg, true)
        val lib32 = OverUpdate.stageLib(context, targetPkg, false)
        if (lib64 == null && lib32 == null) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE,
                "过更新补丁库复制不进目标目录(权限不足)"
            )
        }

        var last: PtraceInjectResult? = null
        for (pid in pids) {
            val lib = (if (PackageUtil.isPid64(pid) ?: true) lib64 else lib32)
                ?: lib64 ?: lib32 ?: continue
            val r = PtraceInjector.injectMany(pid, listOf(lib.absolutePath), null)
            if (r is PtraceInjectResult.Success) {
                val text = OverUpdate.describe(context, targetPkg, injected = true)
                InjectionPrefs.patchDetail = text
                return PtraceInjectResult.Success(pid, lib.absolutePath, text)
            }
            last = r
        }
        val detail = PtraceInjector.lastDetail
        return (last as? PtraceInjectResult.Failure)?.copy(detail = detail)
            ?: PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN, detail)
    }

    /**
     * 框架注入:我们不需要自己动手,只要把"用哪个 so"写进交接文件,
     * 目标进程起来时由 HookInit 自己从安装包里抽出来加载。
     * 过更新同理:目标进程里 HookInit 会自己把补丁库 System.load 进去(免 root)。
     */
    private suspend fun frameworkInject(context: Context, targetPkg: String): PtraceInjectResult {
        if (!XposedDetector.isFrameworkInstalled(context)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED)
        }
        val info = ModuleStore.currentInfo(context)
        if (!info.ready) {
            val why = when {
                !info.exists -> "还没解包出内置 SO"
                info.placeholder -> "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
                !info.isElf -> "内置 SO 不是有效的 ELF 文件"
                else -> "内置 SO 不完整"
            }
            return PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }

        // 每次重新注入都先把上次的状态抹掉,免得界面一直显示"已激活"
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null
        InjectionPrefs.patchDetail = null

        val soPath = info.file.absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            // 目标还没跑:这不叫失败,下次它启动时模块会自己载入
            return PtraceInjectResult.Success(
                pid = -1,
                soPath = soPath,
                detail = "已准备好(" + ModuleStore.sourceLabel() + "),启动目标后自动加载"
            )
        }

        // 目标在跑:等目标进程回报(它下次启动才会重新加载)
        delay(2500)
        val patchNote = if (InjectionPrefs.overUpdate) InjectionPrefs.patchDetail else null
        if (InjectionPrefs.frameworkActive) {
            return PtraceInjectResult.Success(
                pids.first(), soPath,
                listOfNotNull("已生效", patchNote).joinToString(" · ")
            )
        }
        val error = InjectionPrefs.frameworkError
        return PtraceInjectResult.Success(
            pid = pids.first(),
            soPath = soPath,
            detail = listOfNotNull(
                if (error.isNullOrBlank()) {
                    "已准备好(" + ModuleStore.sourceLabel() + "),重启目标后生效"
                } else {
                    "已准备好,但目标加载失败:" + error
                },
                patchNote
            ).joinToString(" · ")
        )
    }

    /**
     * 进程注入:目标在跑 -> 把 so 挪到目标数据目录 -> ptrace 附加 -> 远程 dlopen。
     *
     * 过更新也走这里,而且**跟游戏模块合并成同一次注入**:
     * 一次附加、一次冻结、依次 dlopen 两个库。
     * 以前是「先注模块,再开第二次会话注补丁库」,第二次附加经常直接被拒,
     * 于是「过更新和 so 一起用」就变成了两边都用不了 —— 这是这次要修的核心。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?
    ): PtraceInjectResult {
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.SAME_UID_REQUIRED,
                "本应用与目标应用的 uid 不一致(需要 sharedUserId 相同)"
            )
        }
        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_FOUND, "目标没在跑")
        }
        val staged = ModuleStore.stageForTarget(context, targetPkg)
            ?: ModuleStore.stageForTargetPrivileged(context, targetPkg)
            ?: return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE,
                "复制不进目标数据目录(权限不足)"
            )

        // 过更新补丁库:同一次会话里排在模块前面加载(先把更新检测按住,再进模块)
        val patchNotes = ArrayList<String>()
        // 64 / 32 两份都备好,按每个 pid 的实际位数投对应那份(以前是写死 64 位)
        val patchLib64 = if (InjectionPrefs.overUpdate) OverUpdate.stageLib(context, targetPkg, true) else null
        val patchLib32 = if (InjectionPrefs.overUpdate) OverUpdate.stageLib(context, targetPkg, false) else null
        if (InjectionPrefs.overUpdate && patchLib64 == null && patchLib32 == null) {
            patchNotes.add("过更新补丁库复制不进目标目录,这次跳过")
        }
        InjectionPrefs.patchDetail = null

        var last: PtraceInjectResult? = null
        var ok: PtraceInjectResult.Success? = null

        for (pid in pids) {
            val patchLib = (if (PackageUtil.isPid64(pid) ?: true) patchLib64 else patchLib32)
                ?: patchLib64 ?: patchLib32
            // ① 有补丁库就一次把两个库都送进去(单次会话)
            if (patchLib != null) {
                val many = PtraceInjector.injectMany(
                    pid, listOf(patchLib.absolutePath, staged.absolutePath), entry
                )
                if (many is PtraceInjectResult.Success) {
                    ok = many
                    break
                }
                last = many
                // ② 合并注入失败就退回只注模块 —— 游戏模块是主线,不能被补丁拖死
                val only = PtraceInjector.inject(pid, staged.absolutePath, entry)
                if (only is PtraceInjectResult.Success) {
                    ok = only
                    patchNotes.add("补丁库这次没跟上(合并注入失败),模块已注入")
                    break
                }
                last = only
            } else {
                val only = PtraceInjector.inject(pid, staged.absolutePath, entry)
                if (only is PtraceInjectResult.Success) {
                    ok = only
                    break
                }
                last = only
            }
        }

        if (ok == null) {
            // 把原生侧的具体原因带出去,界面上直接看得到卡在哪一步
            PtraceInjector.lastDetail?.let { detail ->
                val all = last
                if (all is PtraceInjectResult.Failure) {
                    return PtraceInjectResult.Failure(all.kind, detail)
                }
            }
            return last ?: PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN)
        }

        // ③ 读补丁库写回来的状态,给一句实话(不猜"应该生效了")
        if (InjectionPrefs.overUpdate) {
            // 原生侧如果留了"补丁库没跟上"这类说明,一并带出来
            ok.detail?.takeIf { it.isNotBlank() && it.contains("没加载上") }?.let { patchNotes.add(it) }
            patchNotes.add(OverUpdate.describe(context, targetPkg, injected = patchLib64 != null || patchLib32 != null))
            InjectionPrefs.patchDetail = patchNotes.lastOrNull()
        }

        return if (patchNotes.isEmpty()) {
            ok
        } else {
            ok.copy(detail = listOfNotNull(ok.detail, patchNotes.joinToString(" · ")).joinToString(" · "))
        }
    }
}
