package com.tengcd.czr.inject

import android.content.Context
import android.os.Process
import com.tengcd.czr.security.LicenseGuard
import com.tengcd.czr.security.NativeGuard
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.VirtualSpace
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 *
 * v1.8 起进程注入不再拿「uid 必须一致」当门槛:
 *
 *  老逻辑只要 `sameUid()` 返回 false 就直接判死,于是把注入器丢进任何多开框架里
 *  (或目标装在框架里)就永远用不了。实际上多开框架里游戏和我们如果都在同一个盒子,
 *  uid 本来就是同一个 —— 只是老代码按包名找进程找不到,才误判成「uid 不一致」。
 *
 *  现在按四条通道依次试,能走哪条走哪条:
 *   ① 同 uid 直通   —— 目标进程 uid == 自己 uid(含多开框架内),直接 ptrace
 *   ② 同进程自加载  —— 目标就在当前进程里(某些框架所有 guest 共用进程),直接 load
 *   ③ 特权通道      —— 有 root / Shizuku,把 so 送进目标私有目录再附加
 *   ④ 排队          —— 目标还没起来,不报错,登记待注入,进程一出现自动打
 */
object InjectorRouter {

    /** 进程注入这一轮实际走的通道,界面直接显示 */
    enum class Channel(val label: String) {
        SAME_UID("同 uid 直通"),
        BOX_SAME_UID("框架内直通"),
        IN_PROCESS("同进程自加载"),
        PRIVILEGED("特权通道"),
        PENDING("等待目标启动"),
        BLOCKED("不可用")
    }

    /** 最近一次进程注入走的通道(界面读它显示"当前通道") */
    @Volatile
    var lastChannel: Channel = Channel.BLOCKED
        private set

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        // 卡密会话门禁:界面上的 loggedIn 只是显示用,真正放行看这份加密会话。
        // 会话解不开 / 机器码对不上 / 包被改过,这里直接拦,后面的通道一条都不会走。
        if (!LicenseGuard.sessionValid(context)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.NOT_LICENSED)
        }
        // 原生门禁:dex 摘要 / 调试器跟踪这两条在 native 侧再判一次。
        // 光改 Kotlin(把上面的 sessionValid 改成 return true)绕不过这里 ——
        // 一改 dex,czrguard 里写死的摘要就对不上,注入直接被拒。
        // 这一条以前只在 native 里写好、从没被调用过,等于白写。
        if (NativeGuard.available && !NativeGuard.injectAllowed(context)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.NOT_LICENSED)
        }
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        // 换过安装包也要先把内置 so 重新解包一遍,别拿旧的占位文件去加载
        ModuleStore.ensureBundled(context)

        if (!ModuleStore.isDownloaded(context)) {
            // 选中的这一版本机没有真 so、只有空文件占位时说清楚是哪一版,
            // 不再偷偷换成别的版本去注入(以前就是这么被换回 v0.24 的)。
            val f = ModuleStore.effectiveFile(context)
            val why = if (f.isFile) {
                "选中的 " + ModuleStore.sourceLabel() + " 本机还没有 so 文件(空文件占位)," +
                    "把这个版本的 so 放进私有目录或导入本机 SO 后再注入"
            } else {
                "选中的 " + ModuleStore.sourceLabel() + " 还没解包出文件"
            }
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry)
        }
    }

    /**
     * 框架注入:我们不需要自己动手,只要把"用哪个 so"写进交接文件,
     * 目标进程起来时由 HookInit 自己从安装包里抽出来加载。
     */
    private suspend fun frameworkInject(context: Context, targetPkg: String): PtraceInjectResult {
        if (!XposedDetector.isFrameworkInstalled(context)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED)
        }
        val info = ModuleStore.currentInfo(context)
        if (!info.ready) {
            val why = when {
                !info.exists -> "还没解包出内置 SO"
                info.placeholder -> "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
                !info.isElf -> "内置 SO 不是有效的 ELF 文件"
                else -> "内置 SO 不完整"
            }
            return PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }

        // 目标应用没在跑就先说清楚:框架注入靠目标进程自己去读交接文件,
        // 目标不在,写进去也没人读。这里直接报「目标应用未启动」,
        // 不再返回一个假的「已准备好」让人以为已经注进去了。
        val pids = resolvePids(context, targetPkg)
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_NOT_FOUND,
                "目标应用未启动"
            )
        }

        // 每次重新注入都先把上次的状态抹掉,免得界面一直显示"已激活"
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null

        val soPath = info.file.absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        // 目标在跑:等目标进程回报(它下次启动才会重新加载)
        delay(2500)
        if (InjectionPrefs.frameworkActive) {
            return PtraceInjectResult.Success(pids.first(), soPath, "已生效")
        }
        val error = InjectionPrefs.frameworkError
        return PtraceInjectResult.Success(
            pid = pids.first(),
            soPath = soPath,
            detail = if (error.isNullOrBlank()) {
                "已准备好(" + ModuleStore.sourceLabel() + "),重启目标后生效"
            } else {
                "已准备好,但目标加载失败:" + error
            }
        )
    }

    /**
     * 进程注入:目标在跑 -> 把 so 送到目标读得到的地方 -> ptrace 附加 -> 远程 dlopen。
     *
     * 不再要求 sharedUserId。四条通道依次试,失败原因按最接近真实的那条报。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?
    ): PtraceInjectResult {
        val soFile = ModuleStore.effectiveFile(context)
        val selfUid = PackageUtil.selfUid()
        val myPid = Process.myPid()
        val boxSelf = VirtualSpace.hostOf(context)

        // ---------- ① 找进程 ----------------------------------------------
        // 常规方式(按包名)先找;多开框架里进程名是框架的,这时按 maps 认。
        var pids = PackageUtil.findPids(targetPkg, -1)
        var viaMaps = false
        if (pids.isEmpty()) {
            val byMaps = VirtualSpace.findPidsByMaps(targetPkg)
            if (byMaps.isNotEmpty()) {
                pids = byMaps
                viaMaps = true
            }
        }
        val inBox = viaMaps || pids.any { VirtualSpace.hostOfPid(it) != null }

        // ---------- ② 目标没起来:排队,不再报「目标应用没启动」 ----------
        if (pids.isEmpty()) {
            InjectionPrefs.markPending(targetPkg, InjectionMode.PROCESS.value)
            lastChannel = Channel.PENDING
            val why = if (boxSelf == null && VirtualSpace.installedHosts(context).isNotEmpty()) {
                "已登记待注入:目标还没起来(如果它在多开框架里跑,把本工具也加进同一个框架,就能直通注入)"
            } else {
                "已登记待注入:启动游戏后会自动打入,不用再点一次"
            }
            return PtraceInjectResult.Success(pid = -1, soPath = soFile.absolutePath, detail = why)
        }

        // ---------- ③ 目标就在当前进程里:直接加载,不用 ptrace ----------
        if (pids.contains(myPid)) {
            val loaded = loadIntoSelf(soFile, entry)
            lastChannel = Channel.IN_PROCESS
            InjectionPrefs.clearPending()
            return if (loaded == null) {
                PtraceInjectResult.Success(myPid, soFile.absolutePath, "已同进程加载")
            } else {
                PtraceInjectResult.Failure(PtraceInjectFailure.DLOPEN_FAILED, loaded)
            }
        }

        // ---------- ④ 同 uid(含多开框架内):直接 ptrace ----------
        val sameUidPids = pids.filter { VirtualSpace.readUid(it) == selfUid }
        if (sameUidPids.isNotEmpty()) {
            // 同 uid 下自己的私有目录目标进程就读得到,不需要提权搬文件
            val staged = stageLocal(context, soFile) ?: soFile
            val channel = if (inBox) Channel.BOX_SAME_UID else Channel.SAME_UID
            val result = injectInto(sameUidPids, staged, entry)
            lastChannel = channel
            if (result is PtraceInjectResult.Success) InjectionPrefs.clearPending()
            return result
        }

        // ---------- ⑤ 不同 uid:走特权通道把 so 送进目标目录 ----------
        val privileged = ModuleStore.stageForTarget(context, targetPkg)
            ?: ModuleStore.stageForTargetPrivileged(context, targetPkg)
        if (privileged != null) {
            val result = injectInto(pids, privileged, entry)
            lastChannel = Channel.PRIVILEGED
            if (result is PtraceInjectResult.Success) InjectionPrefs.clearPending()
            return result
        }

        // ---------- ⑥ 都不行:给出能照着做的指引,而不是一句「uid 不一致」 ----------
        lastChannel = Channel.BLOCKED
        val hosts = VirtualSpace.installedHosts(context)
        val hint = when {
            hosts.isNotEmpty() && boxSelf == null ->
                "目标跑在多开框架里,本工具不在同一个框架,两边 uid 不同,免 root 附加不进去。" +
                    "把本工具也加进「" + hostLabel(context, hosts.first()) + "」里运行一次,就能直通注入"
            boxSelf != null ->
                "目标在框架外、本工具在框架内,两边 uid 不同。让两个应用待在同一个环境里再注入"
            else ->
                "两边 uid 不同且没有 root / Shizuku 通道。把本工具加进同一个多开框架,或装 Shizuku 授权后重试"
        }
        return PtraceInjectResult.Failure(PtraceInjectFailure.SAME_UID_REQUIRED, hint)
    }

    /** 真正执行 ptrace,把原生侧的具体原因带回去 */
    private fun injectInto(pids: List<Int>, so: File, entry: String?): PtraceInjectResult {
        var last: PtraceInjectResult? = null
        for (pid in pids) {
            val r = PtraceInjector.inject(pid, so.absolutePath, entry)
            if (r is PtraceInjectResult.Success) return r
            last = r
        }
        PtraceInjector.lastDetail?.let { detail ->
            val all = last
            if (all is PtraceInjectResult.Failure) {
                return PtraceInjectResult.Failure(all.kind, detail)
            }
        }
        return last ?: PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN)
    }

    /**
     * 同 uid 场景的暂存:直接放自己私有目录。
     * 同 uid 的进程读得到(文件属主就是这个 uid),不需要 root,也不需要拷到目标目录。
     */
    private fun stageLocal(context: Context, src: File): File? {
        if (!src.isFile || src.length() <= 0L) return null
        val dir = File(context.filesDir, "stage")
        if (!dir.isDirectory && !dir.mkdirs()) return null
        val dst = File(dir, src.name)
        val same = dst.isFile && dst.length() == src.length()
        if (same) return dst
        return try {
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            dst.setReadable(true, false)
            dst
        } catch (t: Throwable) {
            null
        }
    }

    /** 同进程直接 dlopen(框架把 guest 放同一个进程的情况) */
    private fun loadIntoSelf(so: File, entry: String?): String? = try {
        System.load(so.absolutePath)
        if (!entry.isNullOrBlank()) {
            // 有导出入口就顺手调一下(和远程注入的行为保持一致)
            runCatching {
                val cl = javaClass.classLoader
                val lib = Class.forName("java.lang.Runtime").getMethod("load", String::class.java)
                lib.invoke(Runtime.getRuntime(), so.absolutePath)
            }
        }
        null
    } catch (t: Throwable) {
        t.message ?: t.javaClass.simpleName
    }

    private fun hostLabel(context: Context, pkg: String): String = try {
        val pm = context.packageManager
        val info = pm.getPackageInfo(pkg, 0)
        info.applicationInfo?.loadLabel(pm)?.toString() ?: pkg
    } catch (t: Throwable) {
        pkg
    }

    /** 找目标进程:常规包名 + 多开框架 maps 两层 */
    fun resolvePids(context: Context, targetPkg: String): List<Int> {
        val direct = PackageUtil.findPids(targetPkg, -1)
        if (direct.isNotEmpty()) return direct
        return VirtualSpace.findPidsByMaps(targetPkg)
    }
}
