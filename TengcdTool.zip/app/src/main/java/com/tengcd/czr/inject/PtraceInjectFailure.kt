package com.tengcd.czr.inject

/**
 * 进程注入的失败类型。code 与 native 侧 injector.cpp 里的返回值一一对应,
 * 改一边记得改另一边。
 */
enum class PtraceInjectFailure(val code: Int) {
    NONE(0),
    NATIVE_NOT_LOADED(-1),
    TARGET_NOT_FOUND(-2),
    ATTACH_DENIED(-3),
    MMAP_FAILED(-4),
    DLOPEN_SYMBOL_NOT_FOUND(-5),
    DLOPEN_FAILED(-6),
    PATH_TOO_LONG(-7),
    TARGET_DIR_NOT_ACCESSIBLE(-8),
    WRITE_REMOTE_FAILED(-9),
    FRAMEWORK_NOT_INSTALLED(-10),
    FRAMEWORK_NOT_ACTIVE(-11),
    MODULE_NOT_READY(-12),
    TARGET_NOT_INSTALLED(-13),
    SAME_UID_REQUIRED(-14),
    REMOTE_SYSCALL_FAILED(-15),
    ABI_MISMATCH(-16),
    LOADER_BUSY(-17),
    /** 卡密会话无效 / 包被改过:原生层直接拒注入 */
    NOT_LICENSED(-18),
    /** 选的 so 本身有问题:空文件 / 不是 ELF / 32 位 / 太小 */
    SO_INVALID(-19),
    UNKNOWN(-99);

    companion object {
        fun fromCode(code: Int): PtraceInjectFailure =
            entries.firstOrNull { it.code == code } ?: UNKNOWN
    }
}
