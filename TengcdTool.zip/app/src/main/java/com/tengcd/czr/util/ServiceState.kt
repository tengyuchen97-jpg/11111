package com.tengcd.czr.util

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * 跨组件共享的运行态:注入服务在跑没有、框架模块在目标里激活没有。
 * Provider(被目标进程调用)、Service、ViewModel 都读写这里。
 *
 * 1.3 起框架状态拆成两档,别再混成一个 boolean:
 *   - hooked  = 目标进程已经收到模块注入信号(LSPosed 的开关/作用域没问题)
 *   - active  = 模块 so 在目标进程里真的加载成功了
 * 只有 hooked=true 而 active=false 时,界面才会提示"注进去了但 so 没加载",
 * 这样用户一眼能分清是 LSPosed 没生效,还是 so 本身加载失败。
 */
object ServiceState {

    val serviceRunning = MutableStateFlow(false)
    val frameworkActive = MutableStateFlow(false)
    val frameworkHooked = MutableStateFlow(false)
    val frameworkStage = MutableStateFlow<String?>(null)
    val lastInjectOk = MutableStateFlow<Boolean?>(null)
    val lastInjectDetail = MutableStateFlow<String?>(null)

    fun onReportedActive() {
        frameworkHooked.value = true
        frameworkActive.value = true
        frameworkStage.value = "loaded"
        InjectionPrefs.frameworkActive = true
        InjectionPrefs.frameworkHooked = true
        InjectionPrefs.frameworkStage = "loaded"
        InjectionPrefs.frameworkStageAt = System.currentTimeMillis()
    }

    fun onReportedHooked(process: String?) {
        frameworkHooked.value = true
        frameworkStage.value = "hooked"
        InjectionPrefs.frameworkHooked = true
        InjectionPrefs.frameworkStage = "hooked"
        InjectionPrefs.frameworkStageAt = System.currentTimeMillis()
        if (!process.isNullOrBlank()) InjectionPrefs.frameworkProcess = process
    }

    fun onReportedError(detail: String?) {
        frameworkActive.value = false
        frameworkStage.value = "error"
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkStage = "error"
        InjectionPrefs.frameworkStageAt = System.currentTimeMillis()
        InjectionPrefs.frameworkError = detail
    }

    fun reset() {
        frameworkActive.value = false
        frameworkHooked.value = false
        frameworkStage.value = null
        InjectionPrefs.resetFrameworkState()
    }

    fun syncFromPrefs() {
        frameworkActive.value = InjectionPrefs.frameworkActive
        frameworkHooked.value = InjectionPrefs.frameworkHooked
        frameworkStage.value = InjectionPrefs.frameworkStage
    }
}
