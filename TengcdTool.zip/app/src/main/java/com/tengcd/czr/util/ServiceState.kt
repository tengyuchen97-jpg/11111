package com.tengcd.czr.util

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * 跨组件共享的运行态:注入服务在跑没有、框架模块在目标里激活没有。
 * Provider(被目标进程调用)、Service、ViewModel 都读写这里。
 *
 * ⚠️ 两个状态必须分清楚,别再混:
 *  - selfLoaded      :框架把模块注入到了「模块自己」的进程。只说明框架认得这个模块。
 *  - frameworkActive :**目标游戏进程**里真的把 so 加载起来了。界面上那个「已激活」只能看它。
 *
 * v1.6.160 补的一条:frameworkActive 现在还要看「报成功的那个进程还在不在」。
 * 游戏进程被系统/盒子收掉之后,pid 就没了,界面不许再挂着上一轮的绿灯,
 * 否则就是「框架显示注入成功、游戏里其实什么都没跑」。
 */
object ServiceState {

    val serviceRunning = MutableStateFlow(false)

    /** 目标游戏进程回报的注入状态(唯一可以显示成「已激活」的依据) */
    val frameworkActive = MutableStateFlow(false)

    /** 框架识别到模块(模块自己被注入),不等于游戏里注入成功 */
    val frameworkSelfLoaded = MutableStateFlow(false)

    val lastInjectOk = MutableStateFlow<Boolean?>(null)
    val lastInjectDetail = MutableStateFlow<String?>(null)

    /** 上一次目标进程报成功的时间(进程已经没了也保留,界面可以显示「上次成功于…」) */
    val lastActiveAt = MutableStateFlow(0L)

    /** 只有目标进程报上来的才算「已注入游戏」 */
    fun onReportedActive() {
        frameworkActive.value = true
        lastActiveAt.value = System.currentTimeMillis()
        InjectionPrefs.frameworkActive = true
        InjectionPrefs.frameworkActiveAt = System.currentTimeMillis()
    }

    /** 模块自己被框架注入(框架认得模块了) */
    fun onSelfLoaded() {
        frameworkSelfLoaded.value = true
        InjectionPrefs.frameworkSelfLoaded = true
    }

    /** 目标进程报了失败:把「已激活」撤掉,别再挂着骗人 */
    fun onReportedFailure(detail: String?) {
        frameworkActive.value = false
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkActiveAt = 0L
        lastInjectOk.value = false
        lastInjectDetail.value = detail
    }

    /**
     * 从磁盘同步。
     *
     * 关键:**只认还活着的那个进程报的成功**。进程已经没了,就把绿灯撤掉,
     * 但把「上次成功的时间」留着给界面显示,别让用户以为这一轮也成功了。
     */
    fun syncFromPrefs() {
        val alive = InjectionPrefs.frameworkProcessAlive()
        frameworkActive.value = InjectionPrefs.frameworkActive && alive
        frameworkSelfLoaded.value = InjectionPrefs.frameworkSelfLoaded
        lastInjectDetail.value = InjectionPrefs.frameworkError
        val at = InjectionPrefs.frameworkActiveAt
        if (at > 0L) lastActiveAt.value = at
        if (!alive && InjectionPrefs.frameworkActive) {
            // 记录在案,但这一轮不再算成功
            lastInjectDetail.value = (InjectionPrefs.frameworkError
                ?: "上一次回报成功,但那个游戏进程已经结束了(这一次还没收到回报)")
        }
    }
}
