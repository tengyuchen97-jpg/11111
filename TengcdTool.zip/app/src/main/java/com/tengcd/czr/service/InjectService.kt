package com.tengcd.czr.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.tengcd.czr.MainActivity
import com.tengcd.czr.R
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.InjectorRouter
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.inject.PtraceInjectResult
import com.tengcd.czr.ipc.SoSocketServer
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.ServiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 注入服务。前台跑着,顺便把本地 socket 服务拉起来,
 * 让被 hook 的目标进程随时能来问模块路径。
 */
class InjectService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** 待注入看门狗 */
    private var watchdogJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        InjectionPrefs.init(this)
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification(getString(R.string.app_name), ""))
        ServiceState.serviceRunning.value = true
        SoSocketServer.start()
        startPendingWatchdog()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_INJECT -> {
                val mode = InjectionMode.from(intent.getIntExtra(EXTRA_MODE, 0))
                val target = intent.getStringExtra(EXTRA_TARGET) ?: InjectionPrefs.targetPackage
                val entry = intent.getStringExtra(EXTRA_ENTRY)
                doInject(mode, target, entry)
            }
            ACTION_STOP -> {
                stopSelfSafely()
            }
            else -> {
                // 只是被拉起来保活,啥也不用做
            }
        }
        return START_STICKY
    }

    /**
     * 待注入看门狗。
     *
     * 场景:用户没先开游戏就点「一键注入」。
     * 老逻辑到这儿直接弹「目标应用没启动」,用户得自己去开游戏再点一次。
     * 现在的做法是登记一条待注入,这里每 1.5 秒看一眼目标进程 ——
     * 不管是正常启动、还是多开框架里起来的(进程名不是包名,走 maps 认),
     * 一出现就自动打进去,用户只需要点那一次。
     */
    private fun startPendingWatchdog() {
        if (watchdogJob?.isActive == true) return
        watchdogJob = scope.launch {
            var lastTryAt = 0L
            var lastTarget = ""
            while (true) {
                delay(1500)
                try {
                    val target = InjectionPrefs.pendingTarget?.trim().orEmpty()
                    if (target.isEmpty()) continue
                    val at = InjectionPrefs.pendingAt
                    // 挂太久就自动放弃,别一直占着
                    if (at > 0L && System.currentTimeMillis() - at > 30 * 60 * 1000L) {
                        InjectionPrefs.clearPending()
                        continue
                    }
                    // 同一个目标 20 秒内只试一次,免得反复附加把目标搞卡
                    if (target == lastTarget && System.currentTimeMillis() - lastTryAt < 20_000L) continue
                    val pids = InjectorRouter.resolvePids(this@InjectService, target)
                    if (pids.isEmpty()) continue
                    lastTryAt = System.currentTimeMillis()
                    lastTarget = target
                    val mode = InjectionMode.from(
                        InjectionPrefs.pendingMode.takeIf { it >= 0 } ?: InjectionMode.PROCESS.value
                    )
                    val result = InjectorRouter.inject(this@InjectService, mode, target)
                    ServiceState.lastInjectOk.value = result.isSuccess
                    ServiceState.lastInjectDetail.value = when (result) {
                        is PtraceInjectResult.Success -> result.detail
                        is PtraceInjectResult.Failure ->
                            result.kind.name + (result.detail?.let { ":$it" } ?: "")
                    }
                    if (result is PtraceInjectResult.Success && result.pid > 0) {
                        InjectionPrefs.clearPending()
                        notify(getString(R.string.app_name), "目标已启动,已自动注入")
                    }
                } catch (t: Throwable) {
                    // 看门狗自己绝不能把服务带崩
                }
            }
        }
    }

    private fun doInject(mode: InjectionMode, target: String, entry: String?) {
        scope.launch {
            notify(getString(R.string.app_name), "正在注入…")
            val result = InjectorRouter.inject(this@InjectService, mode, target, entry)
            ServiceState.lastInjectOk.value = result.isSuccess
            val detail = when (result) {
                is PtraceInjectResult.Success -> result.detail
                is PtraceInjectResult.Failure -> result.kind.name + (result.detail?.let { ":$it" } ?: "")
            }
            ServiceState.lastInjectDetail.value = detail
            if (result.isSuccess) {
                InjectionPrefs.lastInjectTime = System.currentTimeMillis()
                ModuleStore.refreshPrefs(this@InjectService)
                // ⚠️ 这里绝不能把 frameworkActive 置 true:
                //    「已注入游戏」只能由游戏进程里的模块回报,界面自己点亮就是假绿灯。
            }
            notify(getString(R.string.app_name), if (result.isSuccess) "注入完成" else "注入失败")
        }
    }

    private fun notify(title: String, text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(title, text))
    }

    private fun buildNotification(title: String, text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setContentIntent(pending)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "注入服务",
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = "保持模块加载服务运行"
        manager.createNotificationChannel(channel)
    }

    override fun onDestroy() {
        ServiceState.serviceRunning.value = false
        scope.cancel()
        super.onDestroy()
    }

    private fun stopSelfSafely() {
        SoSocketServer.stop()
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
    }

    companion object {
        const val CHANNEL_ID = "honffx_service"
        const val NOTIFICATION_ID = 1001

        const val ACTION_INJECT = "com.tengcd.czr.action.INJECT"
        const val ACTION_STOP = "com.tengcd.czr.action.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_TARGET = "target"
        const val EXTRA_ENTRY = "entry"

        fun start(context: Context) {
            val intent = Intent(context, InjectService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun inject(context: Context, mode: InjectionMode, target: String, entry: String? = null) {
            val intent = Intent(context, InjectService::class.java).apply {
                action = ACTION_INJECT
                putExtra(EXTRA_MODE, mode.value)
                putExtra(EXTRA_TARGET, target)
                putExtra(EXTRA_ENTRY, entry)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, InjectService::class.java).apply { action = ACTION_STOP }
            try {
                context.startService(intent)
            } catch (t: Throwable) {
            }
        }
    }
}
