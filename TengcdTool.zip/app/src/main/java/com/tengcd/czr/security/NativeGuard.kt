package com.tengcd.czr.security

/**
 * 原生层自检/门禁。
 *
 * 这里只做两件 Java 侧做不到的事:
 *  1. [selfIntegrity] —— 打开自己的 apk,把里面每个 classes*.dex 的 SHA-256 算出来,
 *     跟编译时写死在 .so 里的期望值比。dex 被改过(去广告、改判断、塞内置卡密)
 *     摘要必然对不上,这里直接返回 0。
 *  2. [injectAllowed] —— 进程注入前的原生门禁。注入逻辑本身就在原生层,
 *     所以这一层没法靠改 smali 绕过去,要绕就得连 .so 一起改。
 */
object NativeGuard {

    // 和注入器同一个库:门禁跟注入逻辑在同一份 .so 里,
    // 想绕开就得整个替换 .so,而不是改两句 Kotlin。
    private const val LIB = "ptrace_injector"

    private val loadError: Throwable? = try {
        System.loadLibrary(LIB)
        null
    } catch (t: Throwable) {
        t
    }

    val available: Boolean get() = loadError == null

    /** 1 = 正常;0 = dex 摘要对不上; -1 = 取不到自己的 apk(不判死) */
    external fun selfIntegrity(): Int

    /** 原生门禁:环境正常才允许注入 */
    external fun injectAllowed(context: android.content.Context): Boolean
}
