package com.tengcd.czr.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import com.tengcd.czr.network.LocalCardGate
import java.io.File
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 卡密会话 + 运行环境自检。
 *
 * 为什么要有这一层:
 * 以前「登录成功 = 一个 loggedIn 布尔值」,谁把那个布尔值改成 true(或者塞一张
 * 内置卡密)就整包通了。现在登录成功只代表「后台肯给这张卡发了凭证」,
 * 真正放行注入的是这里的一份**加密会话**:里面有机器码、到期时间、签发时间、
 * 卡密哈希,全部用本机派生出来的密钥做 AES-GCM 加密,GCM 自带完整性校验,
 * 少一个字节、改一个字节都解不开。把 loggedIn 改成 true 没有任何用,
 * 因为注入入口查的是会话能不能解开、里面的机器码对不对、时间对不对。
 *
 * 另外每次放行前都会过一遍环境自检:包名签名、是否 debuggable、有没有被调试器
 * 挂上、进程里有没有 hook 框架、dex 有没有被改过(最后一条由原生层算)。
 */
object LicenseGuard {

    private const val PREF = "czr_lic"
    private const val KEY_BLOB = "s"

    /** 允许的时钟误差 */
    private const val MAX_SKEW_MS = 5L * 60L * 1000L

    /** 多久没跟后台说过话就要求重新登录(离线宽限) */
    private const val OFFLINE_MAX_MS = 72L * 60L * 60L * 1000L

    /** 到期后还给这么点宽限,免得卡刚过期就闪退 */
    private const val EXPIRE_GRACE_MS = 24L * 60L * 60L * 1000L

    /**
     * 本工程的签名证书 SHA-256(DER)。
     * 拆成四段异或过的整数,不直接以明文字节躺在 dex 里。
     * 换签名文件(tengcd.jks)时必须同步改这里,否则整包一句「环境异常」。
     */
    private val CERT_ENC = intArrayOf(
        0xB4DDA76E.toInt(), 0x42C6A539, 0x324E09F3, 0xF7CE7FBD.toInt(),
        0x0616210F, 0xF1C2FB0A.toInt(), 0xA869AAD0.toInt(), 0xD193838F.toInt()
    )
    private val CERT_XOR = 0x5A3C91E7

    @Volatile
    private var lastReason: String? = null

    fun lastBlockReason(): String? = lastReason

    /**
     * 签名信任度:true = 还是 tengcd.jks 原签名;false = 重签过 / 换了证书。
     *
     * ⚠️ 只当**信号**,不参与任何放行判断 —— 也永远不要拿它去拦卡密。
     * 想拿它做风控,就把它当参数报给后台(后台自己决定要不要盯账号),
     * 或者在 logcat 里看一眼这台机器是不是被重新打包过。
     */
    fun signatureTrusted(context: Context): Boolean =
        runCatching { certOk(context) }.getOrDefault(false)

    // ---------------------------------------------------------------- 环境自检

    /**
     * 运行环境是否可信。
     * 注意:这里刻意把每一项都做成分散的小函数,改一处不影响别的判断。
     */
    fun environmentOk(context: Context): Boolean {
        // 签名不参与放行判断(1.8.181):
        // 改 so / 重新打包必然重签,拿签名当卡密门,锁死的是自己和自己的更新流程;
        // 破解者只要 hook certOk 一处就能反手绕过去,挡不住人还白伤己。
        // 现在签名只当信号(signatureTrusted 上报 / 打日志),卡密的权威判断只认服务端会话 + 原生门禁。
        if (!notDebuggable(context)) {
            lastReason = "debuggable"
            return false
        }
        if (traced()) {
            lastReason = "tracer"
            return false
        }
        val native = runCatching { NativeGuard.selfIntegrity() }.getOrDefault(-1)
        // -1 表示原生层取不到自己的 apk(极个别魔改系统),此时不当作破解;
        // 0 才是「算出来的 dex 摘要跟编译时写死的不一样」= 包被改过。
        if (native == 0) {
            lastReason = "dex"
            return false
        }
        if (hookLibMapped()) {
            lastReason = "hook"
            return false
        }
        lastReason = null
        return true
    }

    private fun expectedCert(): ByteArray {
        val raw = ByteArray(CERT_ENC.size * 4)
        var k = 0
        for (v in CERT_ENC) {
            val x = v xor CERT_XOR
            raw[k++] = ((x ushr 24) and 0xFF).toByte()
            raw[k++] = ((x ushr 16) and 0xFF).toByte()
            raw[k++] = ((x ushr 8) and 0xFF).toByte()
            raw[k++] = (x and 0xFF).toByte()
        }
        return raw
    }

    private fun certOk(context: Context): Boolean {
        val actual = try {
            apkCertDigest(context)
        } catch (t: Throwable) {
            null
        } ?: return false
        return MessageDigest.isEqual(actual, expectedCert())
    }

    private fun apkCertDigest(context: Context): ByteArray? {
        val pm = context.packageManager
        val pkg = context.packageName
        val sig = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
            val si = info.signingInfo ?: return null
            if (si.hasMultipleSigners()) si.apkContentsSigners?.firstOrNull()
            else si.signingCertificateHistory?.lastOrNull()
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
        } ?: return null
        return sha256(sig.toByteArray())
    }

    private fun notDebuggable(context: Context): Boolean {
        val flags = context.applicationInfo.flags
        return (flags and ApplicationInfo.FLAG_DEBUGGABLE) == 0
    }

    /** /proc/self/status 里的 TracerPid:被 ptrace 挂上了就不是 0 */
    private fun traced(): Boolean = try {
        val text = File("/proc/self/status").readText()
        val line = text.lineSequence().firstOrNull { it.startsWith("TracerPid:") }
        val pid = line?.substringAfter(':')?.trim()?.toIntOrNull() ?: 0
        pid != 0
    } catch (t: Throwable) {
        false
    }

    /** 进程里有没有 hook 框架的库。注意不判 Xposed 本身 —— 本工程自己就是 Xposed 模块 */
    private fun hookLibMapped(): Boolean = try {
        val maps = File("/proc/self/maps").readText()
        val bad = arrayOf("frida", "gum-js", "gum-agent", "libsubstrate", "libxhook", "libepic.so")
        bad.any { maps.contains(it, ignoreCase = true) }
    } catch (t: Throwable) {
        false
    }

    // ---------------------------------------------------------------- 会话

    private data class Session(
        val machine: String,
        val expireAt: Long,
        val issuedAt: Long,
        val lastSeen: Long,
        val cardHash: String,
        val tokenHash: String
    )

    /** 后台验证通过时调一次:把这次登录的结果封成加密会话 */
    fun openSession(context: Context, card: String, expireAt: Long, token: String) {
        runCatching {
            val now = System.currentTimeMillis()
            val machine = machineOf(context)
            val s = Session(
                machine = machine,
                expireAt = expireAt,
                issuedAt = now,
                lastSeen = now,
                cardHash = shortHash(card),
                tokenHash = shortHash(token)
            )
            store(context, s)
        }
    }

    /**
     * 放行判断。注入、写交接文件、服务启动全走这里。
     * 任何一项不满足都返回 false,调用方直接拦,不要再给别的路。
     */
    fun sessionValid(context: Context): Boolean {
        val s = load(context) ?: run {
            lastReason = "no_session"
            return false
        }
        val now = System.currentTimeMillis()
        if (s.machine != machineOf(context)) {
            lastReason = "machine"
            closeSession(context)
            return false
        }
        // 时钟往回拨:上次见到的时间比现在还晚,直接判失效(防止把手机时间调回去续命)
        if (s.lastSeen > now + MAX_SKEW_MS) {
            lastReason = "clock"
            return false
        }
        // 签发时间在未来 = 有人改过系统时间再登录
        if (s.issuedAt > now + MAX_SKEW_MS) {
            lastReason = "issued"
            return false
        }
        // 太久没跟后台对过账:要求重新登录,别让一份离线会话当永久通行证用。
        // 判的是 lastSeen(心跳会推),不是 issuedAt —— 一直在用的人不该被这条拦。
        if (now - s.lastSeen > OFFLINE_MAX_MS) {
            lastReason = "stale"
            return false
        }
        if (s.expireAt > 0L && now > s.expireAt + EXPIRE_GRACE_MS) {
            lastReason = "expired"
            return false
        }
        if (!environmentOk(context)) return false
        // 刷新 lastSeen,让"把时间调回去"这条路走不通
        runCatching { store(context, s.copy(lastSeen = now)) }
        return true
    }

    /**
     * 心跳/查询成功时调一次:续一下会话的新鲜度。
     *
     * 会话本身不重签(机器码、卡密哈希、到期时间都不动),只把 lastSeen / issuedAt 往前推,
     * 这样「72 小时没跟后台说过话就要求重新验证」这条规则不会把一直在用的人误伤。
     */
    fun touch(context: Context) {
        runCatching {
            val s = load(context) ?: return
            val now = System.currentTimeMillis()
            if (now <= s.lastSeen) return
            store(context, s.copy(issuedAt = now, lastSeen = now))
        }
    }

    fun closeSession(context: Context) {
        runCatching {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .remove(KEY_BLOB).apply()
        }
    }

    private fun machineOf(context: Context): String =
        runCatching { LocalCardGate.deviceId(context) }.getOrDefault("")

    private fun store(context: Context, s: Session) {
        val payload = buildString {
            append("2|").append(s.machine).append('|')
            append(s.expireAt).append('|').append(s.issuedAt).append('|')
            append(s.lastSeen).append('|').append(s.cardHash).append('|').append(s.tokenHash)
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12)
        runCatching { java.security.SecureRandom().nextBytes(iv) }
        cipher.init(Cipher.ENCRYPT_MODE, keyFor(context), GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(payload.toByteArray(Charsets.UTF_8))
        val blob = ByteArray(iv.size + ct.size)
        System.arraycopy(iv, 0, blob, 0, iv.size)
        System.arraycopy(ct, 0, blob, iv.size, ct.size)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY_BLOB, Base64.encodeToString(blob, Base64.NO_WRAP))
            .apply()
    }

    private fun load(context: Context): Session? = runCatching {
        val b64 = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_BLOB, null) ?: return null
        val blob = Base64.decode(b64, Base64.NO_WRAP)
        if (blob.size <= 12) return null
        val iv = blob.copyOfRange(0, 12)
        val ct = blob.copyOfRange(12, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, keyFor(context), GCMParameterSpec(128, iv))
        val text = String(cipher.doFinal(ct), Charsets.UTF_8)
        val p = text.split('|')
        if (p.size < 7 || p[0] != "2") return null
        Session(
            machine = p[1],
            expireAt = p[2].toLongOrNull() ?: 0L,
            issuedAt = p[3].toLongOrNull() ?: 0L,
            lastSeen = p[4].toLongOrNull() ?: 0L,
            cardHash = p[5],
            tokenHash = p[6]
        )
    }.getOrNull()

    /**
     * 会话密钥:机器码 + 包名 + 签名摘要 + 常量,再 SHA-256。
     * 换到别的机器 / 改过签名的包,解出来的都是乱码(其实是 GCM 校验直接失败)。
     */
    private fun keyFor(context: Context): SecretKeySpec {
        val md = MessageDigest.getInstance("SHA-256")
        md.update("czr-lic-v2".toByteArray(Charsets.UTF_8))
        md.update(machineOf(context).toByteArray(Charsets.UTF_8))
        md.update(context.packageName.toByteArray(Charsets.UTF_8))
        md.update(expectedCert())
        md.update(0x7E.toByte())
        md.update(0x11.toByte())
        return SecretKeySpec(md.digest(), "AES")
    }

    private fun sha256(data: ByteArray): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(data)

    private fun shortHash(text: String): String {
        val d = sha256(("czr#" + text.trim()).toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (i in 0 until 8) sb.append(String.format("%02x", d[i]))
        return sb.toString()
    }
}
