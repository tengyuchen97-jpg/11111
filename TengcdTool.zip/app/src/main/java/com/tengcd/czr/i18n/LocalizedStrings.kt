package com.tengcd.czr.i18n

/**
 * 界面文案接口。加语言就在 Strings.kt 里再实现一份,
 * 这里不动。字段名和 UI 代码一一对应。
 */
interface LocalizedStrings {
    val lang: String

    val appTitle: String
    val tabUpdate: String
    val tabInject: String
    val tabCard: String
    val tabImport: String

    // 资源导入
    val importTitle: String
    val importDesc: String
    val importTargetLabel: String
    val importSource: String
    val importPick: String
    val importPickNone: String
    val importSelected: String
    val importFileCount: String
    val importSourcePane: String
    val importTargetPane: String
    val importSourceHint: String
    val importTargetHint: String
    val importSourcePicked: String
    val importTargetPicked: String
    val importTargetSet: String
    val importTargetWillCreate: String
    val importTargetMissing: String
    val importFileUnit: String
    val importModeTitle: String
    val importModeMerge: String
    val importModeReplace: String
    val importModeMergeDesc: String
    val importModeReplaceDesc: String
    val importManualPath: String
    val importManualHint: String
    val importEmptyDir: String
    val importDirCount: String
    val importChannelSaf: String
    val importPathDialogTitle: String
    val importPathDialogOk: String
    val importSwapHint: String

    // ---- 导入参数(honffx.config) ----
    val importTabOld: String
    val importTabParam: String
    val importParamTitle: String
    val importParamDesc: String
    val importParamPathLabel: String
    val importParamRead: String
    val importParamSave: String
    val importParamReading: String
    val importParamSaving: String
    val importParamSaved: String
    val importParamSaveFailed: String
    val importParamReadFailed: String
    val importParamEmpty: String
    val importParamPlaceholder: String
    val importTotalSize: String
    val importStart: String
    val importRunning: String
    val importProgress: String
    val importCopied: String
    val importChannel: String
    val importChannelDirect: String
    val importChannelRoot: String
    val importRootAvailable: String
    val importRootMissing: String
    val importNeedRoot: String
    val importCoverHint: String
    val importConfirmTitle: String
    val importConfirmMessage: String
    val importDone: String
    val importFailedMsg: String
    val importClearedSelection: String
    val importNoAccess: String

    // 注入失败详情
    val abiMismatch: String
    val remoteSyscallFailed: String
    /** 在目标进程里申请内存失败(以前误报成"系统拒绝附加") */
    val remoteAllocFailed: String
    /** 往目标进程写数据失败 */
    val writeRemoteFailed: String
    /** 选的 so 不能用:空文件 / 不是 ELF / 32 位 */
    val soInvalid: String
    val loaderBusy: String
    val injectDetailLabel: String
    val themeLight: String
    val themeDark: String

    val announcement: String
    val announcementLoading: String
    val announcementEmpty: String
    val announcementFailed: String

    val moduleOverview: String
    val localModule: String
    val frameworkStatus: String
    val remoteModuleVersion: String
    val statusReady: String
    val statusNotReady: String
    val statusActivated: String
    val statusNotActivated: String
    val moduleNotDownloaded: String
    val moduleFileMissing: String

    val checkUpdate: String
    val launchGame: String
    val currentIsLatest: String
    val foundNewVersion: String
    val moduleHasUpdate: String
    val moduleUpdateSuccess: String
    val needUpdateModule: String
    val updateMissingUrl: String
    val verifyFailedKeepOriginal: String
    val moduleReplaceFailed: String
    val downloadFailed: String
    val downloadingModule: String
    val checking: String
    val fetchingVersion: String
    val pleaseDownloadFirst: String
    val pageDownloadModule: String
    val redownload: String
    val downloadNow: String
    val confirm: String
    val cancel: String
    val knowIt: String

    val injectTitle: String
    val frameworkInject: String
    val processInject: String
    val frameworkPrepare: String
    val processPrepare: String
    val frameworkPrepareDesc: String
    val processPrepareDesc: String
    val frameworkModuleInactive: String
    val frameworkModuleActive: String
    val moduleReady: String
    val moduleNotReady: String
    val oneKeyInject: String
    val injectMode: String
    /** 首页「运行状态」里那一行:框架注入 / 进程注入 */
    val injectStateLabel: String
    val targetApp: String
    val targetProcess: String
    val targetDir: String
    val targetDirOk: String
    val targetDirNo: String
    val moduleVersionLabel: String
    val localPath: String
    val remoteVersionLabel: String
    val checkRuntimeCondition: String
    val notSameUid: String
    val targetNotRunning: String
    val attachDenied: String
    val linkerRejected: String
    val targetNotFound: String
    val injectFailed: String
    val injectDone: String
    val injectRunning: String
    val injectorUnavailable: String
    val moduleNotCopied: String
    val targetNotInstalled: String
    val installTargetFirst: String
    val needFrameworkFirst: String
    val frameworkScopeHint: String
    val serviceRunning: String
    val serviceStopped: String
    val moduleServiceRunning: String

    val soSelect: String
    val soSourceLabel: String
    val soBuiltin: String
    val soLocal: String
    val soRemote: String
    val soReady: String
    val soNotReady: String
    val soSwitchedTo: String
    val soSwitchedBuiltin: String
    val soSizeLabel: String
    val soPlaceholderHint: String
    val soInvalidHint: String
    val soSelectorHint: String

    /** 塔菲那组:标题 + 当前选中的版本 */
    val soTafeiLabel: String
    val soTafeiNone: String
    /** 加密件提示(除 v0.27 外都加密,加密件得先解密才能加载) */
    val soEncryptedHint: String

    // 写入通道 / Shizuku
    val refresh: String
    val androidVersionLabel: String
    val shizukuStatus: String
    val shizukuGrant: String
    val shizukuNotInstalled: String
    val shizukuNotRunning: String
    val shizukuGranted: String
    val shizukuDenied: String
    val importChannelShizuku: String
    val importChannelNone: String
    val importNotReady: String

    val localSoTitle: String
    val localSoDesc: String
    val localSoPick: String
    val localSoNone: String
    val localSoSourcePathLabel: String
    val localSoStagedPathLabel: String
    val localSoUseHint: String
    val localSoClear: String
    val localSoLoaded: String
    val localSoFailed: String
    val localSoCleared: String

    val cardTitle: String
    val cardQuery: String
    val cardHint: String
    val cardInvalid: String
    val cardQueryResult: String
    val expireTime: String
    val remainCount: String
    val onlineCount: String
    val bindDevice: String
    val unbindCount: String
    val unbindDevice: String
    val unbinding: String
    val unbindSuccess: String
    val noBinding: String
    val banned: String
    val expired: String
    val countExhausted: String
    val notUsed: String
    val inUse: String
    val querying: String
    val requestFailed: String
    val localVerify: String
    
    val linkTitle: String
    val linkOpen: String
    /** 卡密验证页那个「加入QQ群」按钮 */
    val qqGroupJoin: String
    val qqGroupHint: String
    val copy: String
    val copied: String

    val operationFailed: String
    val checkNetwork: String
    val networkFailed: String
    val unlimited: String
    /** 服务端这次没给这一项(别显示成「不限」) */
    val notReturned: String
    val forever: String
    val yes: String
    val no: String

    // ---------------- v0.6:首页 / T3 验证 / SO 来源 ----------------
    val tabHome: String get() = "首页"
    val homeDesc: String get() = "先选 SO 再注入;要刷游戏资源就去导入。"
    val homeOneKeyInject: String get() = "一键注入并启动游戏"
    val homeStatus: String get() = "运行状态"
    val homeQuick: String get() = "快捷入口"
    val homeGoInject: String get() = "去注入"
    val homeGoImport: String get() = "去导入"
    val homeSoNow: String get() = "当前 SO"
    val homeWriteChannel: String get() = "写入通道"
    val homeAccount: String get() = "卡密"
    val loginTitle: String get() = "卡密验证"
    val loginSubtitle: String get() = "输入卡密,验证通过后进入首页"
    val loginCardLabel: String get() = "卡密"
    val cardKeyHint: String get() = "输入你的卡密"
    val loginButton: String get() = "登录"
    val loginBusy: String get() = "正在验证…"
    val loginEmpty: String get() = "先输入卡密"
    val loginNeedServer: String get() = "还没填 T3 验证服务器地址"
    val loginFailed: String get() = "验证失败"
    val loginSuccess: String get() = "验证通过"
    val loginExpire: String get() = "到期时间"
    val loginServerTitle: String get() = "T3 验证服务器"
    val loginServerFixed: String get() = "卡密验证为了获取人数,大牛不要破解我"
    val loginServerHint: String get() = "验证后台域名,例如 https://api.xxx.com(可带端口)"
    val loginAppId: String get() = "appid(可留空)"
    val loginAppKey: String get() = "appkey(已预置)"
    val loginAesKey: String get() = "RC4 密钥(已预置)"
    val loginCharset: String get() = "Base64 编码集(要 64 位)"
    val loginSave: String get() = "保存"
    val loginServerSaved: String get() = "服务器设置已保存"
    val loginLogout: String get() = "退出登录"
    val soSourceTitle: String get() = "SO 来源"
    val soSourceBuiltin: String get() = "内置"
    val localSoSwitched: String get() = "已切到本机 SO"
    val soSourceLocal: String get() = "本地"
    val importReadPath: String get() = "读取"
    val importPathHint: String get() = "点「读取」或者粘一个路径"
    val importTargetPathHint: String get() = "目标文件夹路径"
    val importPathInvalid: String get() = "这个路径不是文件夹"

    // ---------------- v0.9:公告 / T3 请求格式 ----------------
    val noticeRefresh: String get() = "刷新"
    val noticeUpdated: String get() = "更新于"
    val reqFormatTitle: String get() = "请求格式"
    val reqFormatAuto: String get() = "自动"
    val reqFormatJson: String get() = "JSON"
    val reqFormatForm: String get() = "表单"
    val reqFormatHint: String get() = "后台不认 JSON 就切表单;自动会先试 JSON 再试表单"

    // ---------------- 更新 ----------------
    /** 版本号对不上弹的那个框:只讲更新本身,别再混公告正文(公告归首页公告卡) */
    val updateTitle: String get() = "更新公告"
    val updateNow: String get() = "立即下载"
    val updateOk: String get() = "知道了"
    val updateLater: String get() = "稍后再说"
    /** 更新框底下的取消按钮(比主按钮小一号,放主按钮下面) */
    val updateCancel: String get() = "取消"
    val updateChecking: String get() = "正在检查更新…"
    val updateLatest: String get() = "当前已是最新版"
    val updateNoUrl: String get() = "后台还没配下载地址,先去联系管理员"
    /** 检测版本接口通了、但版本号字段是空的:如实说读不到,不能谎报"已是最新版" */
    val updateVersionFailed: String get() = "没读到后台版本号,检查一下网络再试"
    /** 设备确实没联网:如实说,并告诉用户已经在自动重试,恢复网络就会弹 */
    val updateNetworkFailed: String get() = "设备没联网,恢复网络后会自动重试"
    /** 有网、但这次没拿到接口响应(VPN 握手 / 切网 / 后台重启):别赖"没网",会自动重试 */
    val updateNoResponse: String get() = "这次没读到后台版本,正在自动重试…"
    /** 接口通了、后台回 200,但版本号字段是空的:这是后台配置问题,不是网络问题 */
    val updateNoBackendVersion: String get() = "接口通了,但后台没填版本号(后台→版本管理里填一下)"
    /** 界面上"后台版本号"读不到时显示的占位 */
    val versionNotRead: String get() = "未读到"
    /** 版本行里"后台版本"这个标签 */
    val versionBackendLabel: String get() = "后台版本"
    /** 本次没读到、上面显示的是上次成功读到的号:说清楚,别让人以为这次成功了 */
    val updateFromCacheHint: String get() = "本次没读到后台版本号,上面显示的是上次读到的"
    val updateVersionLabel: String get() = "最新版本"
    val updateCurrentLabel: String get() = "当前版本"
    val updateLogTitle: String get() = "更新内容"
    val updatePill: String get() = "更新"
    /** 公告框正文:后台没给公告内容时的兜底 */
    val updateDialogFallback: String get() = "请下载最新版本后继续使用。"

    // ---------------- 主页状态:进程 ----------------
    val processStatusLabel: String get() = "进程状态"
    /** 进程在跑 + 目标目录能访问 = 可以直接注入 */
    val statusInjectReady: String get() = "已就绪"
    val statusRunning: String get() = "正在运行"
    val statusNotRunning: String get() = "未运行"
    val processNoTarget: String get() = "还没选目标"

    // ---------------- 计次卡 ----------------
    val cardTypeLabel: String get() = "卡类型"
    /** 计次卡没有到期时间,别写成「不限」——那会让人以为这张卡永久有效 */
    val expireByCount: String get() = "按次计费,无到期时间"

    // ---------------- 机器码 / 次数 ----------------
    /** 卡密绑定的机器码,换设备后要拿这串找后台改绑 */
    val machineCodeLabel: String get() = "机器码"
    val machineCodeCopy: String get() = "复制"
    val machineCodeCopied: String get() = "机器码已复制"
    /** 次数卡的剩余次数来自登录回包,这里标一下是什么时候读到的 */
    val remainCountAt: String get() = "次数读取于"
}