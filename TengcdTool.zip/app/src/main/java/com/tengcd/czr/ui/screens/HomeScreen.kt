package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.NoticeCard
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.network.T3Panel

/**
 * 首页。左边一个总览:框架在不在、服务跑没跑、目标装没装、SO 是哪份、
 * 写目录走哪条通道。
 */
@Composable
fun HomeScreen(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 顶部这块重复的大标题 + 提示小字已经去掉(顶栏已经有「遄懂」了),
        // 首页直接从公告开始。
        Spacer(Modifier.height(4.dp))

        // 公告放首页最上面,进 App 一眼就能看到
        NoticeCard(state = state, s = s, dark = dark) { onAction(it) }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            SectionHeader(Icons.Filled.Info, s.homeStatus, dark)
            Spacer(Modifier.height(8.dp))
            StatusRow(
                label = s.frameworkStatus,
                value = if (state.frameworkInstalled) s.statusActivated else s.statusNotActivated,
                dark = dark,
                dot = true,
                ok = state.frameworkInstalled,
                warn = !state.frameworkInstalled
            )
            // 「保持模块加载服务运行」这行删了,换成进程状态:
            // 这个值现在是实时轮询出来的(每 2 秒查一次目标进程),
            // 游戏一打开立刻变「正在运行 + PID」,退出一会儿就变「未运行」,
            // 不用再手动点刷新。
            // 进程状态按「目标可访问」判:
            //   进程在跑 + 目标目录能访问 = 已就绪(绿),这时直接注入就行;
            //   进程在跑但目录碰不到 = 正在运行(黄),得先给 Shizuku / root;
            //   没跑 = 未运行(黄)。值来自每 2 秒一次的实时轮询。
            val running = state.targetRunning
            // 判定口径:目标目录能访问就写「已就绪」。
            // 以前要求「进程在跑 + 目录可访问」两个都满足,可目标进程常常是点进游戏才起、
            // 或者刚被系统杀掉,目录权限其实早就拿到了、随时能注入,首页却挂着「未运行」,
            // 用户看到的就是「明明写着目录可访问,你怎么说未运行」——纯误报。
            // 现在只要目录可访问就给「已就绪」,进程在跑就顺带把 PID 带上。
            // 框架注入模式不看目标目录(so 从模块包里送进目标进程,根本不写对方目录),
            // 所以这里按「框架已激活 + 模块 so 就绪」判,别再因为目录碰不到把框架模式判成未就绪。
            val injectReady = if (state.mode == InjectionMode.FRAMEWORK) {
                state.frameworkActive && state.soValid
            } else {
                state.targetDirAccessible
            }
            val pidText = if (state.targetPid > 0) " · PID " + state.targetPid else ""
            StatusRow(
                label = s.processStatusLabel,
                value = when {
                    injectReady -> s.statusInjectReady + pidText
                    running -> s.statusRunning + pidText
                    state.targetInstalled -> s.statusNotRunning
                    else -> s.targetNotInstalled
                },
                dark = dark,
                dot = true,
                ok = injectReady,
                warn = !injectReady
            )
            StatusRow(
                label = s.targetApp,
                value = if (state.targetInstalled) {
                    state.targetLabel.ifBlank { state.targetPackage }
                } else {
                    s.targetNotInstalled
                },
                dark = dark,
                dot = true,
                ok = state.targetInstalled,
                warn = !state.targetInstalled
            )
            Spacer(Modifier.height(6.dp))
            KeyValueRow(
                label = s.homeSoNow,
                value = when (state.soSource) {
                    "local" -> s.soLocal
                    "remote" -> s.soRemote
                    else -> s.soBuiltin + " " + state.selectedSo
                },
                dark = dark,
                valueColor = if (state.soValid) OkGreen else ErrRed
            )
            // 运行状态里只留「注入状态」:当前选的是框架注入还是进程注入。
            // 写入通道 / Shizuku 那两行跟注入本身没关系,已经去掉。
            KeyValueRow(
                label = s.injectStateLabel,
                value = if (state.mode == InjectionMode.PROCESS) s.processInject else s.frameworkInject,
                dark = dark,
                valueColor = OkGreen
            )
            if (state.loggedIn && state.loginExpire.isNotBlank()) {
                KeyValueRow(
                    label = s.homeAccount,
                    value = state.loginExpire,
                    dark = dark,
                    valueColor = OkGreen
                )
            }
            Spacer(Modifier.height(10.dp))
            // 检查更新:以前只有后台"检测更新"接口在跑,界面上没有任何按钮,
            // 有新版本用户根本看不见。这里给个明摆着的入口。
            SecondaryActionButton(
                text = if (state.updateChecking) s.updateChecking else
                    (if (state.updateAvailable) s.updatePill + " v" + state.updateVersion else s.checkUpdate),
                dark = dark,
                icon = Icons.Filled.Refresh,
                enabled = !state.updateChecking
            ) {
                onAction(if (state.updateAvailable) UiAction.ShowUpdate else UiAction.CheckUpdate)
            }
            // 版本号直接摆在界面上:本机是几、后台读到的又是几,一眼看得清。
            // 以前只有一个 toast,读失败了只知道"没读到",不知道后台到底回了什么。
            Spacer(Modifier.height(8.dp))
            KeyValueRow(
                label = s.updateCurrentLabel,
                value = "v" + T3Panel.APP_VERSION + "  ·  " + s.versionBackendLabel + " " +
                    (if (state.backendVersion.isNotBlank()) "v" + state.backendVersion
                    else s.versionNotRead),
                dark = dark,
                valueColor = if (state.backendVersion.isNotBlank()) OkGreen else ErrRed
            )
            if (state.updateDiag.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = state.updateDiag,
                    color = ErrRed,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // 一键:按当前注入方式把 SO 打进去,顺手把游戏拉起来
        PrimaryActionButton(
            text = if (state.injecting) s.injectRunning else s.homeOneKeyInject,
            icon = Icons.Filled.PlayArrow,
            enabled = !state.injecting,
            dark = dark
        ) { onAction(UiAction.InjectAndLaunch) }

        Spacer(Modifier.height(18.dp))
    }
}

