package com.tengcd.czr.ui

import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.inject.PtraceInjectFailure

/** 注入失败 -> 人话。和截图里那些提示一一对应 */
fun PtraceInjectFailure.message(s: LocalizedStrings): String = when (this) {
    PtraceInjectFailure.NONE -> s.injectDone
    PtraceInjectFailure.NATIVE_NOT_LOADED -> s.injectorUnavailable
    PtraceInjectFailure.TARGET_NOT_FOUND -> s.targetNotRunning
    PtraceInjectFailure.ATTACH_DENIED -> s.attachDenied
    PtraceInjectFailure.MMAP_FAILED -> s.remoteAllocFailed
    PtraceInjectFailure.DLOPEN_SYMBOL_NOT_FOUND -> s.linkerRejected
    PtraceInjectFailure.DLOPEN_FAILED -> s.linkerRejected
    PtraceInjectFailure.PATH_TOO_LONG -> s.linkerRejected
    PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE -> s.moduleNotCopied
    PtraceInjectFailure.WRITE_REMOTE_FAILED -> s.writeRemoteFailed
    PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED -> s.needFrameworkFirst
    PtraceInjectFailure.FRAMEWORK_NOT_ACTIVE -> s.frameworkModuleInactive
    PtraceInjectFailure.MODULE_NOT_READY -> s.pleaseDownloadFirst
    PtraceInjectFailure.TARGET_NOT_INSTALLED -> s.targetNotInstalled
    PtraceInjectFailure.SAME_UID_REQUIRED -> s.notSameUid
    PtraceInjectFailure.REMOTE_SYSCALL_FAILED -> s.remoteSyscallFailed
    PtraceInjectFailure.ABI_MISMATCH -> s.abiMismatch
    PtraceInjectFailure.LOADER_BUSY -> s.loaderBusy
    PtraceInjectFailure.NOT_LICENSED -> s.licenseRequired
    PtraceInjectFailure.SO_INVALID -> s.soInvalid
    PtraceInjectFailure.UNKNOWN -> s.injectFailed
}
