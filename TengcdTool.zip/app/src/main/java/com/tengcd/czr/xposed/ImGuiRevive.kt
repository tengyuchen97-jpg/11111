package com.tengcd.czr.xposed

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.lang.ref.WeakReference
import java.nio.ByteBuffer

/**
 * 让悬浮菜单「每轮都出得来」。
 *
 * 背景:
 *   v0.19~v0.29 这套 so 自己会在加载时去挂 Activity 回调(onActivityCreated / onActivityResumed),
 *   拿到 Activity 之后调 Java 层 ImGui.setupImGuiViewOnMainThread() 把 GLES3JNIView 贴上去。
 *   第一轮没问题;但盒子(PINKBOX)复用进程再开一局时,Application 换成了一个**新实例**,
 *   老 so 注册的回调挂在老 Application 上,新的一轮再也收不到任何 Activity 事件 ——
 *   于是「只能第一次出窗,之后都不出」。
 *
 * 这里不再等 so 自己找 Activity,改成:
 *   每一轮由模块自己盯住 Activity.onResume,拿到当前 Activity 就主动把菜单挂上去。
 *   挂之前先把上一次留下的静态状态(display / 重建标记)清干净,等于让 so 的 Java 层
 *   每次都以「全新一次」的姿态走一遍 setupImGuiViewInternal。
 *
 * 和 6.2 那种 VO_Start / VO_Shutdown 显式启停的库思路一致:每轮都显式地重新来一遍,
 * 而不是指望库内部的一次性初始化。
 */
object ImGuiRevive {

    private const val LOG = "[Tengcd]"
    private const val VIEW_TAG = "imgui_overlay_view"
    private const val CONTENT_ID = 0x1020002
    private const val DEX_ASSET = "imgui_payload.dex"
    private const val IMGUI_CLASS = "com.example.imgui.ImGui"
    private const val VIEW_CLASS = "com.example.imgui.GLES3JNIView"

    /** 已经挂到第几轮了,-1 = 还没挂过 */
    @Volatile
    private var mountedGeneration = -1

    @Volatile
    private var imguiClass: Class<*>? = null

    @Volatile
    private var viewClass: Class<*>? = null

    @Volatile
    private var ownedLoader: ClassLoader? = null

    @Volatile
    private var lastResumed: WeakReference<Activity>? = null

    @Volatile
    private var mountedOn: WeakReference<Activity>? = null

    /** 上一次尝试挂载的时刻(节流,别每 200ms 就往主线程塞一次) */
    @Volatile
    private var lastAttemptAt = 0L

    /** 记录最近一次 resume 的 Activity(由 HookInit 的 Activity.onResume hook 调) */
    fun noteResumed(activity: Activity) {
        lastResumed = WeakReference(activity)
    }

    /** 新一轮开始(换 Application 实例)时调用,让这一轮重新挂一次 */
    fun resetForNewGeneration() {
        mountedGeneration = -1
        mountedOn = null
    }

    /**
     * 把菜单挂到当前 Activity 上。
     * 必须在主线程调用(调用方负责 post 到主线程)。
     *
     * @return true = 这一轮的菜单已经在窗口上了
     */
    @Synchronized
    fun revive(context: Context, generation: Int): Boolean {
        if (mountedGeneration == generation) return true

        val now = System.currentTimeMillis()
        if (now - lastAttemptAt < 1500L) return false
        lastAttemptAt = now

        val activity = pickActivity()
        if (activity == null) {
            XposedBridge.log("$LOG [revive] 还拿不到 Activity,等下一次 resume")
            return false
        }
        val root = contentOf(activity)
        if (root == null) {
            XposedBridge.log("$LOG [revive] content view 还没准备好")
            return false
        }

        // 已经贴在当前窗口上了(比如 so 自己挂成功了) —— 不用重复挂
        if (root.findViewWithTag<View>(VIEW_TAG) != null) {
            mountedGeneration = generation
            mountedOn = WeakReference(activity)
            XposedBridge.log("$LOG [revive] 第 ${generation} 轮:菜单已在窗口上")
            return true
        }

        val loader = resolveClasses(context, activity.classLoader)
        val imgui = imguiClass
        if (loader == null || imgui == null) {
            XposedBridge.log("$LOG [revive] 找不到 ImGui 的 Java 类,挂载跳过")
            return false
        }

        // 上一轮留下的静态引用先清掉,免得 Java 层以为「已经挂过了」
        clearStaleState(imgui)

        return try {
            imgui.getMethod("setupImGuiViewOnMainThread", Activity::class.java)
                .invoke(null, activity)
            mountedGeneration = generation
            mountedOn = WeakReference(activity)
            XposedBridge.log("$LOG [revive] 第 ${generation} 轮:已请求挂载到 ${activity.javaClass.name}")
            verifyLater(activity, generation)
            true
        } catch (t: Throwable) {
            XposedBridge.log("$LOG [revive] 挂载失败: ${t.javaClass.simpleName} ${t.message}")
            false
        }
    }

    /** 挂完 1.2 秒后回头看一眼,窗口上到底有没有那个 view(只用于日志定位) */
    private fun verifyLater(activity: Activity, generation: Int) {
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            try {
                val root = contentOf(activity)
                val ok = root?.findViewWithTag<View>(VIEW_TAG) != null
                XposedBridge.log("$LOG [revive] 第 $generation 轮挂载校验:${if (ok) "view 在" else "view 不在"}")
            } catch (t: Throwable) {
            }
        }, 1200L)
    }

    // ------------------------------------------------------------------ 找 Activity

    /**
     * 拿当前该挂菜单的 Activity。
     * 优先用我们 hook 到的最近一次 onResume(最准,一定是当前可见的),
     * 拿不到再反射 ActivityThread.mActivities 里翻一遍。
     */
    private fun pickActivity(): Activity? {
        lastResumed?.get()?.let { a ->
            if (isAlive(a)) return a
        }
        val viaThread = activityFromThread()
        if (viaThread != null) {
            lastResumed = WeakReference(viaThread)
            return viaThread
        }
        return null
    }

    private fun isAlive(a: Activity): Boolean = try {
        !a.isFinishing && (Build.VERSION.SDK_INT < 17 || !a.isDestroyed)
    } catch (t: Throwable) {
        false
    }

    @Suppress("PrivateApi")
    private fun activityFromThread(): Activity? {
        return try {
            val atCls = Class.forName("android.app.ActivityThread")
            val thread = atCls.getMethod("currentActivityThread").invoke(null) ?: return null
            val f = atCls.getDeclaredField("mActivities").apply { isAccessible = true }
            val map = f.get(thread) as? Map<*, *> ?: return null
            var best: Activity? = null
            for (v in map.values) {
                if (v == null) continue
                val af = v.javaClass.getDeclaredField("activity").apply { isAccessible = true }
                val a = af.get(v) as? Activity ?: continue
                if (!isAlive(a)) continue
                val pf = runCatching {
                    v.javaClass.getDeclaredField("paused").apply { isAccessible = true }.getBoolean(v)
                }.getOrDefault(true)
                if (!pf) return a
                if (best == null) best = a
            }
            best
        } catch (t: Throwable) {
            null
        }
    }

    private fun contentOf(a: Activity): ViewGroup? = try {
        a.findViewById<View>(CONTENT_ID) as? ViewGroup
    } catch (t: Throwable) {
        null
    }

    // ------------------------------------------------------------------ 类

    /**
     * 找到 ImGui / GLES3JNIView 这两个类。
     * 正常情况下 so 加载时它们已经被定义在进程里了,直接按名字拿;
     * 拿不到就用随包带的 payload dex 自己定义一份(不依赖 so 到底定义没定义)。
     */
    @Synchronized
    private fun resolveClasses(context: Context, gameLoader: ClassLoader?): ClassLoader? {
        imguiClass?.let { if (viewClass != null) return ownedLoader }

        val candidates = ArrayList<ClassLoader>()
        gameLoader?.let { candidates.add(it) }
        ImGuiRevive::class.java.classLoader?.let { candidates.add(it) }

        for (cl in candidates) {
            val pair = tryPair(cl) ?: continue
            imguiClass = pair.first
            viewClass = pair.second
            ownedLoader = cl
            XposedBridge.log("$LOG [revive] 找到 ImGui 类:${cl.javaClass.simpleName}")
            return cl
        }

        // 自己从 assets 里的 payload dex 定义(和 so 内嵌的是同一份)
        val bytes = readAsset(context, DEX_ASSET) ?: run {
            XposedBridge.log("$LOG [revive] 没有 $DEX_ASSET")
            return null
        }
        val parent = gameLoader ?: ClassLoader.getSystemClassLoader()
        val own = try {
            if (Build.VERSION.SDK_INT >= 26) {
                dalvik.system.InMemoryDexClassLoader(ByteBuffer.wrap(bytes), parent)
            } else {
                val f = File(context.codeCacheDir, "imgui_payload_${android.os.Process.myPid()}.dex")
                f.writeBytes(bytes)
                dalvik.system.DexClassLoader(f.absolutePath, null, null, parent)
            }
        } catch (t: Throwable) {
            XposedBridge.log("$LOG [revive] 定义 payload dex 失败:${t.javaClass.simpleName} ${t.message}")
            null
        } ?: return null

        val pair = tryPair(own) ?: run {
            XposedBridge.log("$LOG [revive] payload dex 里没有 ImGui 类")
            return null
        }
        imguiClass = pair.first
        viewClass = pair.second
        ownedLoader = own
        XposedBridge.log("$LOG [revive] 用 payload dex 定义了 ImGui 类")
        return own
    }

    private fun tryPair(cl: ClassLoader): Pair<Class<*>, Class<*>>? = try {
        val i = Class.forName(IMGUI_CLASS, false, cl)
        val v = Class.forName(VIEW_CLASS, false, cl)
        i to v
    } catch (t: Throwable) {
        null
    }

    private fun readAsset(context: Context, name: String): ByteArray? = try {
        context.assets.open(name).use { it.readBytes() }
    } catch (t: Throwable) {
        null
    }

    // ------------------------------------------------------------------ 清状态

    /**
     * 把 ImGui 类里跨轮残留的静态状态清掉。
     * 只动我们确定安全的几个(display / 重建标记),不碰 sRecreateHandler 这种 final 字段。
     */
    private fun clearStaleState(imgui: Class<*>) {
        setStatic(imgui, "display", null)
        setStatic(imgui, "sPendingRecreate", null)
        resetBoolean(imgui, "sRecreating")
        resetLong(imgui, "sLastRecreateAt")
    }

    private fun fieldOf(cls: Class<*>, name: String): java.lang.reflect.Field? = try {
        cls.getDeclaredField(name).apply { isAccessible = true }
    } catch (t: Throwable) {
        null
    }

    private fun setStatic(cls: Class<*>, name: String, value: Any?) {
        try {
            fieldOf(cls, name)?.set(null, value)
        } catch (t: Throwable) {
        }
    }

    private fun resetBoolean(cls: Class<*>, name: String) {
        try {
            val f = fieldOf(cls, name) ?: return
            if (f.type == java.lang.Boolean.TYPE) f.setBoolean(null, false)
        } catch (t: Throwable) {
        }
    }

    private fun resetLong(cls: Class<*>, name: String) {
        try {
            val f = fieldOf(cls, name) ?: return
            if (f.type == java.lang.Long.TYPE) f.setLong(null, 0L)
        } catch (t: Throwable) {
        }
    }
}
