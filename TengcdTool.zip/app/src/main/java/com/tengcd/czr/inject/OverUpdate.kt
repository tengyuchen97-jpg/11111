package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.PackageUtil
import java.io.File
import java.util.zip.ZipFile

/**
 * 免 root 过更新(第二版)。
 *
 * 干活的是自带的原生库 liboverupdate.so:进到游戏进程里以后
 *   ① 放开 TLS 证书校验;
 *   ② 把游戏里「查更新 / 查版本 / 弹更新框」那些方法的**函数本体**改成直接返回 0
 *      (上一版只改方法表,而 IL2CPP 的 AOT 直接调用根本不看方法表,所以开了跟没开一样);
 * 结果写进目标目录 files/overupdate.status,这边读出来直接显示,不靠猜。
 *
 * 这里只负责:把库搬进目标读得到的位置、把结果翻译成人话。
 * 真正"塞进进程"的动作在 @see InjectorRouter(和游戏模块合并成一次注入)。
 */
object OverUpdate {

    private const val SO_NAME = "liboverupdate.so"
    private const val STATUS_NAME = "overupdate.status"

    private const val ABI64 = "arm64-v8a"
    private const val ABI32 = "armeabi-v7a"

    /** 目标数据目录里的状态文件 */
    fun statusFile(context: Context, targetPkg: String): File? {
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        return File(File(dataDir, "files"), STATUS_NAME)
    }

    /** 给界面用:上次跑完状态是什么(没有就 null) */
    fun readStatusText(context: Context, targetPkg: String): String? {
        val f = statusFile(context, targetPkg) ?: return null
        return runCatching { if (f.isFile) f.readText() else null }.getOrNull()
    }

    /** 本机安装目录里那份(设备主 ABI 装进来的那份) */
    private fun installedLib(context: Context, abi: String): File? {
        val dir = context.applicationInfo.nativeLibraryDir ?: return null
        if (abi == ABI32 && dir.contains("64")) return null
        if (abi == ABI64 && !dir.contains("64")) return null
        return File(dir, SO_NAME).takeIf { it.isFile && it.length() > 0L }
    }

    /**
     * 从自己的安装包里抽一份出来。
     *
     * 安装目录里只有设备主 ABI 的那一份,而目标进程可能是另一个位数
     * (有的游戏主进程 64 位、子进程 32 位),包里 lib/<abi>/ 两份都在。
     */
    private fun extractFromApk(context: Context, abi: String): File? {
        val dst = File(context.cacheDir, "liboverupdate_$abi.so")
        return try {
            ZipFile(context.applicationInfo.sourceDir).use { zip ->
                val entry = zip.getEntry("lib/$abi/$SO_NAME") ?: return null
                // 升级安装后缓存里的旧库要换掉:大小对不上就重新抽
                if (!dst.isFile || dst.length() != entry.size) {
                    zip.getInputStream(entry).use { input ->
                        dst.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                    }
                }
            }
            dst.setReadable(true, false)
            dst.takeIf { it.isFile && it.length() > 0L }
        } catch (t: Throwable) {
            null
        }
    }

    /** 备好这一位数要注入的那一份补丁库(已经搬进目标目录) */
    fun stageLib(context: Context, targetPkg: String, is64: Boolean): File? {
        val abi = if (is64) ABI64 else ABI32
        val src = installedLib(context, abi) ?: extractFromApk(context, abi) ?: return null
        // 两份库用不同文件名,别互相覆盖
        val dstName = "liboverupdate_" + abi.replace("-", "_") + ".so"
        return ModuleStore.stageFileInto(context, targetPkg, src, dstName)
    }

    /** 状态文件里的一行 key=value / hit=xxx */
    private fun field(text: String, key: String): String? =
        Regex("(?m)^" + Regex.escape(key) + "=(.*)$").find(text)?.groupValues?.get(1)?.trim()

    private fun count(text: String, key: String): Int = field(text, key)?.toIntOrNull() ?: 0

    private fun hits(text: String, key: String, limit: Int = 3): List<String> =
        Regex("(?m)^" + Regex.escape(key) + "=(.*)$").findAll(text)
            .map { it.groupValues[1].trim() }
            .filter { it.isNotEmpty() }
            .take(limit)
            .toList()

    /**
     * 把目标进程写的状态翻译成一句人话。
     *
     * v4 的库做的是两件确定的事,状态也按这两件报,不再拿"扫了多少类"充数:
     *   ① Java 层证书校验放开(OkHttp / Conscrypt / WebView)
     *   ② 原生层证书校验放开(BoringSSL/OpenSSL 的 GOT 指针替换)
     *   外加 ③ 更新弹窗拦截(文字命中强更关键词的 Dialog 不放出来)
     */
    fun describe(context: Context, targetPkg: String, injected: Boolean?): String {
        val text = readStatus(context, targetPkg)
        if (text.isNullOrBlank()) {
            return if (injected == false) {
                "过更新库没送进去"
            } else {
                "过更新库已送进游戏进程,状态还没回写(游戏跑起来后会自动补扫)"
            }
        }
        val tls = count(text, "total")
        val blocked = count(text, "dialog")
        val round = count(text, "round")
        val state = field(text, "state") ?: "running"
        val libs = hits(text, "hit")
        val javaState = field(text, "java") ?: "waiting"
        val javaHits = Regex("""^ok\((\d+)\)""").find(javaState)
            ?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val javaMiss = field(text, "java_miss") ?: ""

        // 请求层的战绩:这几条直接告诉用户"更新请求到底拦到没"
        val netState = field(text, "net_state") ?: ""
        val netHit = count(text, "net_hit")
        val redirect = count(text, "redirect")
        val verSpoof = count(text, "ver_spoof")

        val parts = ArrayList<String>()
        if (javaHits > 0) parts.add("Java 层证书校验放开 $javaHits 处")
        if (tls > 0) parts.add("原生证书校验放开 $tls 处")
        if (blocked > 0) parts.add("已拦更新弹窗 $blocked 个")
        if (netHit > 0) parts.add("已掐断检查更新请求 $netHit 次")
        if (verSpoof > 0) parts.add("版本号已伪装成最新($verSpoof 次)")
        if (redirect > 0) parts.add("已跳过更新页 $redirect 次")

        if (parts.isEmpty()) {
            val why = when {
                state == "booting" -> "库刚进去,还在等游戏把网络库加载起来"
                javaMiss.isNotBlank() -> "本进程里没找到 okhttp/conscrypt 那批类(游戏可能不用 Java 层网络栈)"
                else -> "还没匹配到可放行的校验点,游戏跑起来后会自动补扫(已扫 $round 轮)"
            }
            return "过更新库已进去,$why"
        }
        val libText = if (libs.isEmpty()) "" else "(涉及 " + libs.take(3).joinToString("、") + ")"
        var line = "过更新已生效:" + parts.joinToString(" · ") + libText
        if (netState.isNotBlank()) line += "｜请求拦截 $netState"
        return line
    }
    /** 读状态文件,给一点重试时间(目标进程刚注入时可能还没写完) */
    private fun readStatus(context: Context, targetPkg: String, timeoutMs: Long = 3000): String? {
        val file = statusFile(context, targetPkg) ?: return null
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val text = runCatching { if (file.isFile) file.readText() else null }.getOrNull()
            if (!text.isNullOrBlank()) return text
            try {
                Thread.sleep(150L)
            } catch (t: InterruptedException) {
                break
            }
        }
        return runCatching { if (file.isFile) file.readText() else null }.getOrNull()
    }
}
