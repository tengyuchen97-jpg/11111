package com.tengcd.czr.util

import android.content.Context
import android.os.Process
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

/**
 * 虚拟空间 / 双开框架适配层(备用框架那一套)。
 *
 * 为什么需要它:
 *  多开框架(双开助手、平行空间、MultiSpace、BlackBox 这一系)里跑的游戏,
 *  进程名根本不是游戏包名,是框架的 `:stub.s3` / `:p0` 这类名字,
 *  uid 也是框架的 uid。老代码按「包名找进程 + uid 必须一致」去判,于是:
 *    - 游戏明明开着,界面永远「目标应用没启动」
 *    - 进程注入永远卡在「uid 不一致」
 *
 * 这里的三个能力把这两个死结解开:
 *   ① hostOf():本应用自己是不是跑在某个多开框架里,是哪个
 *   ② findPidsByMaps():不管进程叫什么都认——从 /proc/<pid>/maps 里找目标包名的痕迹
 *   ③ sameUidAs():目标进程的真实 uid 和我们一不一样(一样就能直接 ptrace,不需要 root)
 *
 * 关键认知:多开框架里,游戏和我们的 uid 都是框架的 uid,所以只要注入器也装进
 * 同一个框架里跑,两边就是同一个 uid —— 这时候进程注入天然可用,不需要 root,
 * 也不需要 sharedUserId。这就是「没有 UID 也能用」的全部原理。
 */
object VirtualSpace {

    /** 市面上常见的多开 / 虚拟空间框架。只用作识别,加新的一点不影响 */
    private val KNOWN_HOSTS = listOf(
        "com.dualspacepro.multispace",
        "com.dualspace.pro",
        "com.lbe.parallel",
        "com.lbe.parallel.intl",
        "com.parallel.space.lite",
        "com.excelliance.dualaid",
        "io.virtualapp",
        "io.virtualapp.pro",
        "com.lody.virtual",
        "com.polestar.super.clone",
        "com.polestar.domultiple",
        "top.niunaijun.blackbox",
        "com.bly.tool",
        "com.svm.pro",
        "com.duoyi.space",
        "com.cloneapp.parallelspace",
        "multi.parallel.dualspace.cloner",
        "com.chaozh.iReaderFree.parallel",
        "com.pengyou.cloneapp",
        "com.parallel.space.pro",
        "com.nomone.cloneapp",
        "com.bbk.launcher2"
    )

    @Volatile
    private var cachedHost: String? = null

    @Volatile
    private var hostChecked = false

    /** 设备上装了哪些多开框架 */
    fun installedHosts(context: Context): List<String> = KNOWN_HOSTS.filter { isInstalled(context, it) }

    /**
     * 本应用此刻跑在哪个多开框架里;没在盒子里返回 null。
     *
     * 判定顺序(从硬到软):
     *   ① 进程名:盒子里的 guest 进程名是「框架包名:stub.sN」,和自己的包名对不上
     *   ② 同 uid 的包里出现了已安装的框架包(正常安装时一个 uid 只有一个包)
     */
    fun hostOf(context: Context): String? {
        if (hostChecked) return cachedHost
        val hit = detectHost(context)
        cachedHost = hit
        hostChecked = true
        return hit
    }

    /** 探到盒子状态后允许重算一次(用户从盒子里切到桌面时状态会变) */
    fun resetCache() {
        hostChecked = false
        cachedHost = null
    }

    private fun detectHost(context: Context): String? {
        // ① 进程名
        val pid = Process.myPid()
        val cmd = readCmdline(pid).orEmpty().trim()
        if (cmd.isNotEmpty()) {
            val procPkg = cmd.substringBefore(':')
            if (procPkg.isNotBlank() && procPkg != context.packageName &&
                (isInstalled(context, procPkg) || KNOWN_HOSTS.any { procPkg.contains(it) })
            ) {
                return procPkg
            }
        }

        // ② 同 uid 的包
        val pkgs = try {
            context.packageManager.getPackagesForUid(Process.myUid())?.toList().orEmpty()
        } catch (t: Throwable) {
            emptyList()
        }
        for (p in pkgs) {
            if (p == context.packageName) continue
            if (isInstalled(context, p)) return p
        }
        return null
    }

    /**
     * 按 maps 认进程。
     *
     * 多开框架里游戏的 base.apk / odex / 数据目录路径里一定带着包名,
     * 而 /proc/<pid>/maps 在同 uid 下是读得到的。同名进程名认不出来的时候,
     * 这是唯一靠谱的办法。
     *
     * @param sameUidOnly true = 只看和自己同 uid 的进程(不同 uid 的 maps 本来也读不到)
     */
    fun findPidsByMaps(pkg: String, sameUidOnly: Boolean = true): List<Int> {
        val out = ArrayList<Int>()
        if (pkg.isBlank()) return out
        val selfUid = Process.myUid()
        val selfPid = Process.myPid()
        val entries = try {
            File("/proc").list()
        } catch (t: Throwable) {
            null
        } ?: return out
        for (name in entries) {
            val pid = name.toIntOrNull() ?: continue
            if (pid <= 1 || pid == selfPid) continue
            if (sameUidOnly && readUid(pid) != selfUid) continue
            if (mapsContains(pid, pkg)) out.add(pid)
        }
        out.sort()
        return out
    }

    /** 这个进程是某个多开框架的进程吗(读 cmdline 前缀) */
    fun hostOfPid(pid: Int): String? {
        val cmd = readCmdline(pid).orEmpty()
        if (cmd.isBlank()) return null
        val prefix = cmd.substringBefore(':')
        if (prefix.isBlank()) return null
        if (KNOWN_HOSTS.any { prefix == it || prefix.startsWith("$it.") }) return prefix
        return null
    }

    /**
     * 目标此刻在不在盒子里跑。
     * 只要能按 maps 找到它的进程、而那个进程的 cmdline 又是框架名,就算在盒子里。
     */
    fun targetInBox(context: Context, targetPkg: String): Boolean {
        val pids = findPidsByMaps(targetPkg, sameUidOnly = false)
        for (pid in pids) {
            val host = hostOfPid(pid)
            if (host != null && host != targetPkg) return true
        }
        return false
    }

    /** 目标进程的 uid(读不到返回 -1) */
    fun uidOfPid(pid: Int): Int = readUid(pid)

    fun readUid(pid: Int): Int = try {
        val lines = File("/proc/$pid/status").readLines()
        var uid = -1
        for (line in lines) {
            if (line.startsWith("Uid:")) {
                uid = line.substring(4).trim().substringBefore('\t').substringBefore(' ').toIntOrNull() ?: -1
                break
            }
        }
        uid
    } catch (t: Throwable) {
        -1
    }

    fun readCmdline(pid: Int): String? = try {
        val raw = File("/proc/$pid/cmdline").readBytes()
        val end = raw.indexOf(0)
        val bytes = if (end >= 0) raw.copyOf(end) else raw
        String(bytes).trim().ifBlank { null }
    } catch (t: Throwable) {
        null
    }

    /** 逐行扫 maps,读到即停(整个文件的字符串比 contains 省内存) */
    private fun mapsContains(pid: Int, needle: String): Boolean = try {
        BufferedReader(FileReader("/proc/$pid/maps")).use { reader ->
            var line = reader.readLine()
            while (line != null) {
                if (line.contains(needle)) return true
                line = reader.readLine()
            }
        }
        false
    } catch (t: Throwable) {
        false
    }

    private fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (t: Throwable) {
        false
    }
}
