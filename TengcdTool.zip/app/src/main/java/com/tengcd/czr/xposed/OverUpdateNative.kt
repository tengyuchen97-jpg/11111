package com.tengcd.czr.xposed

import java.io.File

/**
 * 过更新原生库在「框架注入」这一侧的入口。
 *
 * 框架模式(LSPosed / 免 root 的补丁框架)下,目标进程里本来就有我们的 Java 代码,
 * 所以不用 ptrace:直接从模块安装包里把 lib/<abi>/liboverupdate.so 抽到目标自己的
 * cache 目录,System.load 进去就行 —— 一样免 root,而且比进程注入稳。
 *
 * 库进去以后自己起线程干活(放开证书校验 + 干掉更新检测方法),结论通过
 * [status] 直接读回来(状态文件写在目标进程的私有目录里,App 那边读不到,所以走 JNI)。
 */
object OverUpdateNative {

    @Volatile
    var loaded: Boolean = false
        private set

    @Volatile
    var lastError: String? = null
        private set

    /** 库里的自检/扫描状态(一行行 key=value,和 overupdate.status 内容一样) */
    external fun status(): String

    /** 立刻再扫一轮(游戏后面才加载的程序集可以用它补) */
    external fun scanNow(): Int

    /**
     * 把抽出来的 so 加载进当前进程。加载过就直接返回 true。
     */
    fun load(libFile: File?): Boolean {
        if (loaded) return true
        if (libFile == null || !libFile.isFile || libFile.length() <= 0L) {
            lastError = "补丁库文件不存在"
            return false
        }
        return try {
            System.load(libFile.absolutePath)
            loaded = true
            lastError = null
            true
        } catch (t: Throwable) {
            lastError = t.message ?: t.javaClass.simpleName
            false
        }
    }

    /** 给界面看的一句话总结 */
    fun summary(): String {
        if (!loaded) return "过更新库没加载上(" + (lastError ?: "未知原因") + ")"
        val text = try {
            status()
        } catch (t: Throwable) {
            return "过更新库已加载,读状态失败"
        }
        if (text.isBlank()) return "过更新库已加载,还在扫描"
        fun field(key: String): String? =
            Regex("(?m)^" + Regex.escape(key) + "=(.*)$").find(text)?.groupValues?.get(1)?.trim()

        val tls = field("total")?.toIntOrNull() ?: 0
        val blocked = field("dialog")?.toIntOrNull() ?: 0
        val round = field("round")?.toIntOrNull() ?: 0
        val names = Regex("(?m)^hit=(.*)$").findAll(text).map { it.groupValues[1] }.take(2).toList()
        val javaState = field("java") ?: "waiting"
        val javaHits = Regex("""^ok\((\d+)\)""").find(javaState)
            ?.groupValues?.get(1)?.toIntOrNull() ?: 0

        val parts = ArrayList<String>()
        if (javaHits > 0) parts.add("Java 层证书校验放开 $javaHits 处")
        if (tls > 0) parts.add("原生证书校验放开 $tls 处")
        if (blocked > 0) parts.add("已拦更新弹窗 $blocked 个")

        val netHit = field("net_hit")?.toIntOrNull() ?: 0
        val redirect = field("redirect")?.toIntOrNull() ?: 0
        val verSpoof = field("ver_spoof")?.toIntOrNull() ?: 0
        if (netHit > 0) parts.add("已掐断检查更新请求 $netHit 次")
        if (verSpoof > 0) parts.add("版本号已伪装成最新($verSpoof 次)")
        if (redirect > 0) parts.add("已跳过更新页 $redirect 次")

        if (parts.isEmpty()) {
            return "过更新库已加载,还没匹配到可放行的校验点(已扫 $round 轮,游戏跑起来后自动补扫)"
        }
        val libText = if (names.isEmpty()) "" else "(" + names.joinToString("、") + ")"
        var line = "过更新已生效:" + parts.joinToString(" · ") + libText
        field("net_state")?.takeIf { it.isNotBlank() }?.let { line += "｜请求拦截 $it" }
        return line
    }
}
