package com.tengcd.czr.xposed

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.os.Bundle
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * 过更新 · 请求拦截层(框架注入路线)。
 *
 * 和 [UpdateBypass](放证书)配成一套:
 *   UpdateBypass    → 让抓包/中间人那条路不被证书固定挡住
 *   本类            → 直接把「检查更新」这条请求按住,游戏走它自己的"检查失败"分支
 *
 * 为什么按请求下手:
 *   弹窗拦截是最后一步(已经弹了才拦),很多游戏的强更根本不用 Dialog ——
 *   它们自己画在 Unity / 自定义 View 里,或者干脆「更新页 → 下载页」两个 Activity。
 *   而几乎所有这类游戏的更新判定都有同一个前置:先发一条"查版本"的请求。
 *   这条请求失败/超时,游戏的标准分支就是"跳过更新,进游戏"(这也是断网能进的原因)。
 *
 * 四刀,按风险从低到高,各自独立开关:
 *   ① DNS 黑洞   :命中更新域名的解析直接抛 UnknownHostException —— 最像真断网,最稳
 *   ② 路径拦截   :同域名不同接口的游戏(登录域名下 /api/checkUpdate),按 URL 路径关键字拦
 *   ③ 版本号伪装 :游戏拿自己 versionCode 跟服务器比,这里把它读成很大的数 = 永远"最新版"
 *   ④ 更新页跳转 :真开了更新页/下载页 Activity,直接 finish 掉并拉回游戏主界面
 *
 * 分寸:
 *   - 白名单优先:login / auth / pay / report / stat 这些关键字一律放行,宁可漏拦不误伤;
 *   - 任何一步读不到、对不上、抛异常,都当"没命中"处理,原样放行;
 *   - 开关和关键字从偏好读,读不到就用内置默认值。
 */
object UpdateRequestBlock {

    /** 一整套拦截规则。默认值针对"独立更新域名 + 标准 REST 查版本"的常见手游 */
    data class Rules(
        /** 命中就做 DNS 黑洞(只匹配域名,不匹配路径) */
        val hostKeywords: List<String> = listOf(
            "update", "upgrade", "newversion", "new-version", "checkver",
            "versioncheck", "version-check", "forceupdate", "appupdate"
        ),
        /** 命中就把这条 URL 的请求掐掉(要开 [blockByPath] 才生效) */
        val pathKeywords: List<String> = listOf(
            "/update", "checkupdate", "check_update", "getversion", "get_version",
            "newversion", "versioncheck", "forceupdate", "upgrade", "patch.json"
        ),
        /** 命中就把这个 Activity 当成更新页,finish 掉并回主界面 */
        val activityKeywords: List<String> = listOf(
            "update", "upgrade", "newversion", "download", "forceupdate"
        ),
        /** 白名单:域名含这些词一律放行(登录/支付/统计) */
        val safeHostKeywords: List<String> = listOf(
            "login", "auth", "account", "passport", "pay", "order", "report",
            "stat", "track", "analytics", "log"
        ),
        /** 打开 ②路径拦截(默认关:同域名游戏容易误伤,先看清楚再开) */
        val blockByPath: Boolean = false,
        /** 打开 ③版本号伪装 */
        val spoofVersion: Boolean = true,
        /** 伪装的版本号(要比服务器上的大) */
        val fakeVersionCode: Long = 999999999L,
        /** 伪装的版本名 */
        val fakeVersionName: String = "9.9.9",
        /** 打开 ④更新页跳转 */
        val redirectUpdatePage: Boolean = true
    )

    // 规则默认值写在 data class 的默认参数里(上面),这样调用方 new Rules() 就是完整一套。
    // 调整方向:hostKeywords 只放"更新语义"的词;version/stat/log 这种泛词千万别往这里塞,
    // 塞进去容易把登录和统计一起掐掉 —— 白名单 safeHostKeywords 优先命中。

    private val dnsHits = AtomicInteger(0)
    private val pathHits = AtomicInteger(0)
    private val redirects = AtomicInteger(0)
    private val spoofed = AtomicInteger(0)
    private val sawUrls = java.util.concurrent.ConcurrentLinkedQueue<String>()

    @Volatile
    private var installed = false

    @Volatile
    var lastError: String? = null
        private set

    val isInstalled: Boolean get() = installed

    /** 一行状态,给界面显示 */
    fun summary(): String {
        if (!installed) return lastError ?: "更新请求拦截未安装"
        val parts = ArrayList<String>()
        if (dnsHits.get() > 0) parts.add("DNS 拦下 ${dnsHits.get()} 条")
        if (pathHits.get() > 0) parts.add("接口拦下 ${pathHits.get()} 条")
        if (spoofed.get() > 0) parts.add("版本号伪装 ${spoofed.get()} 次")
        if (redirects.get() > 0) parts.add("跳更新页 ${redirects.get()} 次")
        return if (parts.isEmpty()) "更新请求拦截已装上(还没命中)"
        else "更新请求拦截:" + parts.joinToString(" · ")
    }

    /** 这次见过的主机名,帮用户定位真正的更新接口 */
    fun seenUrls(): List<String> = sawUrls.toList()

    /**
     * 装上全套拦截。可重复调用,只装一次。
     *
     * @param lpparam   框架给的目标进程参数(里面有目标自己的 ClassLoader)
     * @param targetPkg 目标包名,版本号伪装只认这一个包
     */
    fun install(lpparam: XC_LoadPackage.LoadPackageParam?, targetPkg: String, rules: Rules = Rules()) {
        if (installed) return
        if (lpparam == null) {
            lastError = "没拿到目标进程参数"
            return
        }
        var ok = 0
        ok += hookDns(rules)
        ok += hookUrlRecorder(lpparam)
        if (rules.blockByPath) ok += hookUrlBlock(lpparam, rules)
        if (rules.spoofVersion) ok += hookVersionSpoof(lpparam, targetPkg, rules)
        if (rules.redirectUpdatePage) ok += hookUpdateActivity(rules)
        installed = ok > 0
        if (!installed) lastError = "一条 hook 都没挂上"
    }

    // ---------------------------------------------------------------- ① DNS 黑洞

    private fun hookDns(rules: Rules): Int {
        var n = 0
        val hook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam?) {
                val host = param?.args?.getOrNull(0) as? String ?: return
                rememberUrl(host)
                if (!hostBlocked(host, rules)) return
                dnsHits.incrementAndGet()
                // 抛 UnknownHostException 是最"自然"的失败方式:任何联网代码都必然处理它
                param.setThrowable(UnknownHostException(host))
            }
        }
        n += try {
            XposedHelpers.findAndHookMethod(
                InetAddress::class.java, "getAllByName", String::class.java, hook
            ); 1
        } catch (t: Throwable) { 0 }

        n += try {
            XposedHelpers.findAndHookMethod(
                InetAddress::class.java, "getByName", String::class.java, hook
            ); 1
        } catch (t: Throwable) { 0 }

        n += try {
            XposedHelpers.findAndHookMethod(
                InetAddress::class.java, "getAllByName", String::class.java,
                InetAddress::class.java, hook
            ); 1
        } catch (t: Throwable) { 0 }
        return n
    }

    private fun hostBlocked(host: String, rules: Rules): Boolean {
        val low = host.lowercase()
        if (low.isEmpty()) return false
        // 白名单优先:登录/支付/统计一定放行,不然进都进不去
        if (rules.safeHostKeywords.any { low.contains(it) }) return false
        return rules.hostKeywords.any { low.contains(it) }
    }

    private fun rememberUrl(url: String) {
        if (url.isEmpty()) return
        if (sawUrls.size > 40) return
        if (sawUrls.contains(url)) return
        sawUrls.add(url)
    }

    // ---------------------------------------------------------------- 记录见过的 URL

    /**
     * 只记录不拦。抓包器只能看到域名,看不到路径 ——
     * 这里把游戏实际请求过的 URL 记下来,状态里能看到,下次就知道该拦哪条。
     */
    private fun hookUrlRecorder(lpparam: XC_LoadPackage.LoadPackageParam): Int {
        var n = 0
        val hook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam?) {
                val arg = param?.args?.getOrNull(0)
                val text = when (arg) {
                    is String -> arg
                    else -> arg?.toString()
                }
                if (text != null && text.startsWith("http", true)) rememberUrl(text.take(200))
            }
        }
        // java.net.URL(String)
        n += try {
            XposedBridge.hookAllConstructors(java.net.URL::class.java, hook); 1
        } catch (t: Throwable) { 0 }

        // okhttp3 的 URL 解析(v3: HttpUrl.parse / v4: HttpUrl.get)
        for (cls in listOf("okhttp3.HttpUrl", "okhttp3.HttpUrl\$Companion")) {
            try {
                val c = XposedHelpers.findClass(cls, lpparam.classLoader)
                XposedBridge.hookAllMethods(c, "parse", hook)
                XposedBridge.hookAllMethods(c, "get", hook)
                n++
            } catch (t: Throwable) {
            }
        }
        return n
    }

    // ---------------------------------------------------------------- ② 路径拦截

    /**
     * 同域名同接口的游戏(登录域名下的 /api/checkUpdate),DNS 拦不住,只能按 URL 掐。
     *
     * 为什么默认关:
     *   不同游戏的更新接口路径差别很大,猜错了会把登录/进服请求一起掐掉。
     *   先用 [seenUrls] 看清楚真实路径,确认了再打开。
     */
    private fun hookUrlBlock(lpparam: XC_LoadPackage.LoadPackageParam, rules: Rules): Int {
        var n = 0

        // java.net.URL 构造:抛 MalformedURLException(checked,调用方必须处理)
        val urlHook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam?) {
                val s = param?.args?.getOrNull(0) as? String ?: return
                if (!urlBlocked(s, rules)) return
                pathHits.incrementAndGet()
                param.setThrowable(java.net.MalformedURLException("blocked: $s"))
            }
        }
        n += try {
            XposedBridge.hookAllConstructors(java.net.URL::class.java, urlHook); 1
        } catch (t: Throwable) { 0 }

        // okhttp:Request.Builder.url(String / HttpUrl)
        try {
            val b = XposedHelpers.findClass("okhttp3.Request\$Builder", lpparam.classLoader)
            val h = object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam?) {
                    val s = param?.args?.getOrNull(0)?.toString() ?: return
                    if (!urlBlocked(s, rules)) return
                    pathHits.incrementAndGet()
                    // 抛 IOException 而不是 IllegalArgumentException:网络层代码基本都 catch 它
                    param.setThrowable(java.io.IOException("blocked: $s"))
                }
            }
            XposedBridge.hookAllMethods(b, "url", h)
            n++
        } catch (t: Throwable) {
        }
        return n
    }

    private fun urlBlocked(url: String, rules: Rules): Boolean {
        val low = url.lowercase()
        if (low.isEmpty()) return false
        if (rules.safeHostKeywords.any { low.contains(it) }) return false
        return rules.pathKeywords.any { low.contains(it) }
    }

    // ---------------------------------------------------------------- ③ 版本号伪装

    /**
     * 游戏查自己版本号,基本都走 PackageManager.getPackageInfo。
     * 这里把返回的 PackageInfo 改掉:versionCode 变成一个很大的数 → 游戏比完认为"已是最新"。
     *
     * 只改目标包自己的,别的包一概不动(查模块列表/查安装器那些照旧)。
     */
    private fun hookVersionSpoof(
        lpparam: XC_LoadPackage.LoadPackageParam,
        targetPkg: String,
        rules: Rules
    ): Int {
        var n = 0
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam?) {
                val pkg = param?.args?.getOrNull(0) as? String ?: return
                if (pkg != targetPkg) return
                val info = param.result as? PackageInfo ?: return
                try {
                    XposedHelpers.setIntField(info, "versionCode", rules.fakeVersionCode.toInt())
                } catch (t: Throwable) {
                }
                try {
                    XposedHelpers.setObjectField(info, "versionName", rules.fakeVersionName)
                } catch (t: Throwable) {
                }
                try {
                    // API 28+:getLongVersionCode() 读的是这个字段,不改它前面那两项白改
                    XposedHelpers.setLongField(info, "longVersionCode", rules.fakeVersionCode)
                } catch (t: Throwable) {
                }
                spoofed.incrementAndGet()
            }
        }

        val cls = try {
            XposedHelpers.findClass("android.app.ApplicationPackageManager", lpparam.classLoader)
        } catch (t: Throwable) {
            null
        } ?: return 0

        // (String, int) —— 老签名,一直在用
        n += try {
            XposedHelpers.findAndHookMethod(
                cls, "getPackageInfo", String::class.java, Int::class.javaPrimitiveType, hook
            ); 1
        } catch (t: Throwable) { 0 }

        // (String, PackageInfoFlags) —— API 33+
        n += try {
            XposedHelpers.findAndHookMethod(
                cls, "getPackageInfo", String::class.java,
                "android.content.pm.PackageManager\$PackageInfoFlags", hook
            ); 1
        } catch (t: Throwable) { 0 }
        return n
    }

    // ---------------------------------------------------------------- ④ 更新页跳转

    /**
     * 真弹了更新页(独立 Activity)就把这一页收掉,直接回游戏主界面 ——
     * 这就是"直接跳转游戏"。
     *
     * 防循环:只主动拉一次主界面;之后如果游戏自己又开更新页(服务器还在推),
     * 只 finish 不再拉,避免出现"拉起游戏 → 又被推去更新页 → 再拉起"的死循环。
     */
    private fun hookUpdateActivity(rules: Rules): Int {
        val pulled = AtomicBoolean(false)
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam?) {
                val act = param?.thisObject as? Activity ?: return
                val name = act.javaClass.name.lowercase()
                if (!rules.activityKeywords.any { name.contains(it) }) return
                // 更新页就是游戏主界面本身?那就不动它
                if (name.contains("mainactivity") || name.contains("unityplayeractivity")) return
                try {
                    act.finish()
                } catch (t: Throwable) {
                }
                redirects.incrementAndGet()
                if (!pulled.compareAndSet(false, true)) return
                try {
                    val app: Context = act.applicationContext
                    val intent: Intent? = app.packageManager.getLaunchIntentForPackage(app.packageName)
                    intent?.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                    if (intent != null) app.startActivity(intent)
                } catch (t: Throwable) {
                    XposedBridge.log("[Tengcd] redirect failed: ${t.message}")
                }
            }
        }
        return try {
            XposedHelpers.findAndHookMethod(
                Activity::class.java, "onCreate", Bundle::class.java, hook
            )
            1
        } catch (t: Throwable) {
            0
        }
    }
}
