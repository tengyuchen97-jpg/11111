package com.tengcd.czr.xposed

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.SystemClock
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.ShellUtil
import java.io.File

/**
 * 「模块在 LSPosed / Xposed 里勾没勾」的判定。
 *
 * 注入页那格「框架状态 已激活 / 未激活」就是它给的答案,判据全是硬证据,
 * 从最硬往软退:
 *
 *  1. 本进程被框架注入过(框架桥类在手 / HookInit 在本进程跑过)
 *     —— 只要本应用被勾进作用域,这条必然成立,骗不了人
 *  2. 有 root 时直接读 LSPosed 自己的模块配置(勾选=1 才算)
 *  3. 本次开机之后,框架把本模块加载进过任意进程(游戏 / 盒内)并留下回执
 *     —— 勾选还在,重启前不会自己消失,所以整个开机周期内都认
 *  4. 盒内框架(PINKBOX 之类)加载过本模块
 *
 * 反例保护:
 *  - 在管理器里取消勾选 + 重启设备后,回执时间早于开机时间,第 3 条自动失效
 *  - 框架压根没装、也没任何回执,恒为未激活
 *
 * 为什么不再用「10 分钟新鲜度」(v1.8 那次改动):勾选是常驻事实,不是一次事件。
 * 用户明明在 LSPosed 里勾着、游戏也注入了,只是十分钟没动作,界面就翻成「未激活」,
 * 这个才是之前那一版最大的毛病。
 */
object ModuleEnabled {

    /** 判定结果缓存:状态不会毫秒级乱跳,省掉反复读配置的开销 */
    private const val CACHE_MS = 3000L

    /** 开机时刻允许的误差(su/预置数据写入有延迟) */
    private const val BOOT_GRACE_MS = 15_000L

    @Volatile
    private var cachedAt = 0L

    @Volatile
    private var cachedValue = false

    /** 模块此刻算不算「已激活」 */
    fun isEnabled(context: Context): Boolean {
        val now = System.currentTimeMillis()
        if (cachedAt != 0L && now - cachedAt < CACHE_MS) return cachedValue
        val value = compute(context, now)
        cachedAt = now
        cachedValue = value
        return value
    }

    /** 一句话说明是靠哪条判据认出来的,给日志/排查用 */
    fun evidence(context: Context): String {
        val list = ArrayList<String>()
        if (ActiveCheck.activeInSelf(context)) list.add("self-injected")
        if (LsposedConfig.moduleTicked(context) == true) list.add("lsposed-config")
        if (tickedThisBoot()) list.add("receipt-this-boot")
        if (ActiveCheck.boxHosted() && InjectionPrefs.frameworkSelfLoaded) list.add("box")
        return if (list.isEmpty()) "none" else list.joinToString("+")
    }

    private fun compute(context: Context, now: Long): Boolean {
        // ① 本进程被框架注入了 —— 最硬的证据
        if (ActiveCheck.activeInSelf(context)) return true
        // ② 能读到 LSPosed 的勾选配置,就照它说的算
        if (LsposedConfig.moduleTicked(context) == true) return true
        // ③ 本次开机之后框架加载过本模块 = 勾选着
        if (tickedThisBoot()) return true
        // ④ 盒内框架加载过本模块
        if (ActiveCheck.boxHosted() && InjectionPrefs.frameworkSelfLoaded) return true
        return false
    }

    /** 本次开机之后有没有「框架加载了本模块」的回执 */
    private fun tickedThisBoot(): Boolean {
        if (!InjectionPrefs.frameworkSelfLoaded) return false
        val at = InjectionPrefs.frameworkSelfAt
        if (at <= 0L) return false
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        return at >= boot - BOOT_GRACE_MS
    }

    /**
     * LSPosed 的模块勾选配置。
     *
     * 位置在 /data/adb/lspd/config/modules_config.db(老的 EdXposed 是
     * /data/user_de/0/org.meowcat.edxposed.manager/),普通应用读不到,
     * 只有 root 能把文件拷出来再查。读不到就返回 null,上层继续用别的证据。
     */
    private object LsposedConfig {

        private const val LSPD_DB = "/data/adb/lspd/config/modules_config.db"
        private const val EDXPOSED_DB =
            "/data/user_de/0/org.meowcat.edxposed.manager/conf/modules.conf.db"

        private const val CACHE_MS = 60_000L

        @Volatile
        private var cachedAt = 0L

        @Volatile
        private var cachedValue: Boolean? = null

        fun moduleTicked(context: Context): Boolean? {
            val now = System.currentTimeMillis()
            if (cachedAt != 0L && now - cachedAt < CACHE_MS) return cachedValue
            val value = runCatching { read(context) }.getOrNull()
            cachedAt = now
            cachedValue = value
            return value
        }

        /** true = 勾着;false = 明确没勾;null = 读不到,别下结论 */
        private fun read(context: Context): Boolean? {
            if (!ShellUtil.hasRoot()) return null
            val pkg = context.packageName
            for (path in arrayOf(LSPD_DB, EDXPOSED_DB)) {
                val copy = copyOut(context, path) ?: continue
                val hit = query(copy, pkg) ?: continue
                return hit
            }
            return null
        }

        private fun copyOut(context: Context, path: String): File? {
            val out = File(context.cacheDir, "lsp_modules_config.db")
            out.delete()
            val cmd = "cat \"$path\" > \"${out.absolutePath}\" 2>/dev/null; " +
                "chmod 644 \"${out.absolutePath}\" 2>/dev/null; " +
                "chcon u:object_r:app_data_file:s0 \"${out.absolutePath}\" 2>/dev/null; true"
            val r = ShellUtil.execRoot(cmd, 8000) ?: return null
            if (!r.ok && r.code != 0) return null
            return if (out.isFile && out.length() > 64) out else null
        }

        /** 查 modules 表里本包的 enabled;表结构对不上就返回 null */
        private fun query(file: File, pkg: String): Boolean? {
            var db: SQLiteDatabase? = null
            return try {
                db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
                db.rawQuery(
                    "SELECT enabled FROM modules WHERE module_pkg_name = ? LIMIT 1",
                    arrayOf(pkg)
                ).use { c ->
                    if (c.moveToFirst()) c.getInt(0) != 0 else null
                }
            } catch (t: Throwable) {
                null
            } finally {
                runCatching { db?.close() }
                runCatching { file.delete() }
            }
        }
    }
}
