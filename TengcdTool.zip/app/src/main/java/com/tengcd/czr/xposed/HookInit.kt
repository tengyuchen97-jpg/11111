package com.tengcd.czr.xposed

import android.app.Activity
import android.app.Application
import android.app.Instrumentation
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process as AndroidProcess
import android.provider.Settings
import android.widget.Toast
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import com.tengcd.czr.util.SoVault
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * ============================================================
 * v1.6.162 -- 每轮自己把菜单挂上去(治「只有第一次出窗」)
 * ============================================================
 *
 * 1.6.160/1.6.161 把「每轮换新目录 + 新文件名 + soname 唯一化」做足了,
 * 盒子第二次依然不出窗。原因不在 so 怎么加载,而在**没人去挂载**:
 *
 * 这套库自己注册了 ActivityLifecycleCallbacks(onActivityCreated / onActivityResumed),
 * 只有 Activity 生命周期事件来了,它才会去调 Java 层的
 * ImGui.setupImGuiViewOnMainThread() 把悬浮层贴上去。而这份回调挂在
 * **上一轮那个 Application 实例**上。盒子复用进程再开一局时 Application 被换成
 * 新实例,旧回调再也收不到任何事件 —— 于是第一轮之后永远静默。
 *
 * 1.6.162 改成:模块自己在 **Activity.onResume** 这一层挂钩(进程级,不随
 * Application 换代失效),每一轮拿到当前 Activity 就主动把菜单挂上去,挂之前
 * 先清掉上一轮残留的静态状态,让 so 的 Java 层每次都按「全新一次」走一遍。
 * 思路和 6.2 那种显式启停的库一致:每轮显式重来一遍,不再指望库内部的一次性初始化。
 * 实现在同级 ImGuiRevive.kt。
 *
 * 版本号 1.6.162 / 1162。
 *
 * ============================================================
 * v1.6.161 —— soname 唯一化
 * ============================================================
 *
 * 1.6.160 已经把「每轮换新目录 + 新文件名」做足了,盒子第二次照样不出窗。
 * 真正的原因不在文件名,在 so 自己的 SONAME:
 *
 *   这份库的 SONAME 写死 `libhonffx.so`。盒子复用同一个进程时,上一轮那份库
 *   还挂在 linker 的已加载表里;链接器按 **soname** 认库,不看路径。
 *   于是 dlopen 一个新路径 → 直接返回**旧句柄**,JNI_OnLoad 一次都不重跑,
 *   窗口创建代码根本没执行 —— 而 System.load 不抛异常,界面照样报「注入成功」。
 *   这也解释了为什么把目标包删掉再加回来就好:那是全新进程,已加载表是空的。
 *
 * 这一版动的是那份**副本**:
 *   - 文件名改成中性的 `libh<随机>_g<轮次>_<变体>.so`(不带 honffx 字样);
 *   - 副本里 .dynstr 的 `libhonffx.so` 等长替换成 `libh<4位随机>.so`(12 字节,
 *     长度不变、偏移不动),链接器当它是一份从没见过的库,真加载、真跑初始化;
 *   - 改完再过一遍 validateSo,不通过就退回原样副本;
 *   - 加载时先试改过 soname 的,失败再把同目录其它副本挨个试一遍。
 *
 * 版本号 1.6.161 / 1161。
 *
 * ============================================================
 * v1.6.160 —— 「每次注入都当第一次」加载器
 * ============================================================
 *
 * 上一版(1.6.4)在真机上连开几次都没问题,但在盒子里
 * **第一次能用、之后每次都是「注入成功但不出悬浮窗」**,
 * 而且用户手动把盒子里的目标包删掉再加回来,又立刻能用。
 *
 * 这条现象说明:卡住的不是「so 找得到找不到」,而是**上一轮留在那儿的东西**。
 * 盒子把 guest 的数据放在宿主自己的虚拟目录里,那个目录会跨启动一直留着;
 * 我们上一轮往里面写的 so 副本、临时文件、锁文件,以及盒子复用同一进程时
 * 本模块的静态「已加载」标记,都会让第二次注入变成一次空跑 ——
 * 界面看到模块确实在,于是报「注入成功」,而 so 的初始化根本没重跑,窗口自然不出来。
 * 删掉目标包 = 把这些残留全清了,所以又能用。
 *
 * 这一版的做法:
 *
 *  1. **每一轮注入都用一个全新的目录 + 全新文件名**
 *     `honffx/run_<pid>_<轮次>_<时间戳>/libhonffx_<变体>_<轮次>.so`
 *     —— 绝不复用上一轮的文件。dlopen 认的是路径,新路径就是一份新的库,
 *     so 的 JNI_OnLoad 一定会重新执行(盒内进程被复用时这是唯一能重新拉起它的办法)。
 *
 *  2. **加载前先把上一轮的残留清干净**:旧 run 目录、`libhonffx*.so`、`*.tmp`、
 *     `*.lock`,包括盒子的虚拟目录里那一份。等于每一轮都替你做了
 *     「把目标包删掉再加回来」这个动作。**不碰游戏自己的数据,也不碰 honffx.config。**
 *
 *  3. **一个进程里能重新来**:盯着 Application 实例变化 + handleBindApplication /
 *     attach / onCreate / callApplicationOnCreate 四个时机,只要检测到
 *     「应用又启动了一轮」,就换新目录重新加载一次,不再被上一轮的静态标记挡住。
 *
 *  4. **等得久一点**:主线程 200ms 探一次,最多探 120 秒(盒内首帧常常很慢)。
 *
 *  5. **加载结果按真实映射判断**,System.load 没抛异常还不够,还要能在
 *     /proc/self/maps 里看到这份库,才报成功。
 *
 *  6. 全程失败原因回报界面 + 弹在游戏里,别让界面挂着假绿灯。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    /** 第几轮(换一个 Application 实例 = 新的一轮) */
    @Volatile
    private var generation = 0

    /** 已经完成加载的轮次,-1 = 一轮都没成功过 */
    @Volatile
    private var loadedGeneration = -1

    /** 当前这一轮正在加载(防重入) */
    @Volatile
    private var loading = false

    /** 上一次处理过的 Application 实例(盒内复用进程时它会换) */
    @Volatile
    private var lastApp: Application? = null

    @Volatile
    private var lastAttemptAt = 0L

    @Volatile
    private var attemptCount = 0

    /** 这一轮已经试了几次加载(节流用) */
    @Volatile
    private var attemptsThisGeneration = 0

    @Volatile
    private var totalLoads = 0

    @Volatile
    private var seenReported = false

    @Volatile
    private var hooksInstalled = false

    @Volatile
    private var probeStarted = false

    /** Activity.onResume 是进程级 hook,只装一次 */
    @Volatile
    private var activityHookInstalled = false

    /** 最近一次 System.load 的原始报错 */
    @Volatile
    private var lastLoadError: String? = null

    /** 最近一次真的加载成功的路径 */
    @Volatile
    private var loadedPath: String? = null

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    // ------------------------------------------------------------------ 入口

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return
        val proc = lpparam.processName?.takeIf { it.isNotBlank() } ?: currentProcessName()

        // ⚠️ 第一件事就是回报「框架已经加载本模块」,必须放在任何 return 之前。
        // 虚拟空间框架只在它虚拟运行的 app 进程里注入模块,永远不会注入模块自己的界面进程。
        if (pkg != OUR_PACKAGE && !proc.startsWith(OUR_PACKAGE)) {
            reportModuleSeen(pkg, proc)
        }

        // 被注入的是我们自己的应用 = 框架认得这个模块。
        // ⚠️ 判「这是不是自己进程」只能看包名/进程名:盒内会把整个模块 dex 塞进游戏进程,
        //    拿「classloader 能加载出我们的类」当依据的话,游戏进程会被误判成自己进程。
        if (pkg == OUR_PACKAGE || proc == OUR_PACKAGE || proc.startsWith("$OUR_PACKAGE:")) {
            markSelfActive()
            return
        }
        if (pkg == "android" || pkg == "com.android.systemui") return

        // 盒子宿主自己的进程(不是它里面的 guest)不碰
        if (isBoxHostOwnProcess(pkg, proc)) return

        if (!shouldRunIn(pkg)) return

        XposedBridge.log("[Tengcd] handleLoadPackage pkg=$pkg proc=$proc pid=${AndroidProcess.myPid()} boxed=${isBoxed()}")
        startProbe(pkg, proc, lpparam?.classLoader)
    }

    /**
     * 这个进程要不要加载 so。
     *
     * 盒内:除了自己和盒子宿主,guest 进程一律加载(作用域由框架那边控制)。
     * 盒外(LSPosed 一类):仍按偏好的目标包名 / 马甲包判断,避免全机乱载。
     */
    private fun shouldRunIn(pkg: String): Boolean {
        if (isBoxed()) return true
        val target = readTargetPackage()
        if (target.isNullOrBlank()) return true
        return pkg == target || pkg in SAME_GAME_PACKAGES
    }

    // ------------------------------------------------------------------ 触发

    /**
     * 主线程轮询 + 四个时机 hook。
     *
     * 轮询不能停:盒内 attach 时机不可靠,而且**进程被复用**的时候
     * 只有轮询才能发现「Application 换了一个新的」。
     */
    private fun startProbe(pkg: String, proc: String, loader: ClassLoader?) {
        installHooks(pkg, proc, loader)
        if (probeStarted) return
        probeStarted = true
        val handler = Handler(Looper.getMainLooper())
        var ticks = 0
        val probe = object : Runnable {
            override fun run() {
                ticks += 1
                val app = currentApplication()
                if (app != null) {
                    maybeLoad(app, pkg, proc, "poll")
                    // 本轮 so 已经进去了,就盯着 Activity「有没有真的把菜单挂上」
                    if (loadedGeneration == generation) {
                        requestRevive(app, generation)
                    }
                }
                handler.postDelayed(
                    this,
                    if (ticks < PROBE_MAX_TIMES) PROBE_INTERVAL_MS else PROBE_SLOW_INTERVAL_MS
                )
            }
        }
        handler.postDelayed(probe, 0)
    }

    /** 把能挂的时机全挂上。任何一个触发都够用,全失败还有轮询。 */
    private fun installHooks(pkg: String, proc: String, loader: ClassLoader?) {
        if (hooksInstalled) return
        hooksInstalled = true

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val app = param?.thisObject as? Application ?: return
                        Handler(Looper.getMainLooper()).post { maybeLoad(app, pkg, proc, "attach") }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook attach failed: ${t.message}")
        }

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "onCreate",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val app = param?.thisObject as? Application ?: return
                        maybeLoad(app, pkg, proc, "onCreate")
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook onCreate failed: ${t.message}")
        }

        try {
            XposedHelpers.findAndHookMethod(
                Instrumentation::class.java,
                "callApplicationOnCreate",
                Application::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val app = param?.args?.getOrNull(0) as? Application ?: return
                        maybeLoad(app, pkg, proc, "callApplicationOnCreate")
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook callApplicationOnCreate failed: ${t.message}")
        }

        // 盒内复用进程时,应用重新起来会再走一次 handleBindApplication。
        // 这是「同一进程里又开了一轮」最硬的信号,挂上它才能重新拉 so。
        try {
            val cl = loader ?: Application::class.java.classLoader
            XposedHelpers.findAndHookMethod(
                "android.app.ActivityThread",
                cl,
                "handleBindApplication",
                "android.app.ActivityThread\$AppBindData",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            val app = currentApplication() ?: return@postDelayed
                            maybeLoad(app, pkg, proc, "bindApplication")
                        }, 50L)
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook handleBindApplication failed: ${t.message}")
        }

        // 每轮由我们自己把当前 Activity 递过去。
        // so 自己的 ActivityLifecycleCallbacks 挂在上一轮的 Application 上,
        // 盒子复用进程换了个新 Application 之后它就永远收不到了 —— 这才是
        // 「只能第一次出悬浮窗」的真正原因。这里从 Activity 这一层重新挂钩,
        // 进程级 hook 不随 Application 换代失效。
        installActivityHook(loader)
    }

    /** Activity.onResume 只装一次(进程级),之后每轮都靠它拿当前 Activity */
    private fun installActivityHook(loader: ClassLoader?) {
        if (activityHookInstalled) return
        activityHookInstalled = true
        try {
            XposedHelpers.findAndHookMethod(
                "android.app.Activity",
                loader ?: Activity::class.java.classLoader,
                "onResume",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val a = param?.thisObject as? Activity ?: return
                        if (a.packageName != OUR_PACKAGE) {
                            ImGuiRevive.noteResumed(a)
                        }
                        val gen = generation
                        if (loadedGeneration == gen) {
                            requestRevive(a.applicationContext, gen)
                        }
                    }
                }
            )
            XposedBridge.log("[Tengcd] Activity.onResume hook 已装")
        } catch (t: Throwable) {
            activityHookInstalled = false
            XposedBridge.log("[Tengcd] hook Activity.onResume failed: ${t.message}")
        }
    }

    /**
     * 让 ImGui 把菜单挂到当前 Activity 上。
     * 会 post 到主线程(挂 view 必须在主线程),内部有节流和幂等判断,可以放心反复调。
     */
    private fun requestRevive(context: Context, gen: Int) {
        try {
            Handler(Looper.getMainLooper()).post {
                try {
                    ImGuiRevive.revive(context, gen)
                } catch (t: Throwable) {
                    XposedBridge.log("[Tengcd] revive 异常: ${t.javaClass.simpleName} ${t.message}")
                }
            }
        } catch (t: Throwable) {
        }
    }

    // ------------------------------------------------------------------ 自激活

    private fun markSelfActive() {
        try {
            ActiveCheck.markSelfHooked()
        } catch (t: Throwable) {
        }
        try {
            com.tengcd.czr.util.InjectionPrefs.frameworkSelfLoaded = true
            com.tengcd.czr.util.InjectionPrefs.frameworkSelfAt = System.currentTimeMillis()
            com.tengcd.czr.util.InjectionPrefs.frameworkSelfPkg = currentProcessName().ifBlank { OUR_PACKAGE }
        } catch (t: Throwable) {
        }
        try {
            val app = currentApplication()
            if (app != null) {
                ActiveCheck.writeMarker(app)
                com.tengcd.czr.util.ServiceState.onSelfLoaded()
            }
        } catch (t: Throwable) {
        }
    }

    /** 回报「框架已经把这个模块加载进当前进程」(界面那行「框架识别模块」的唯一证据) */
    private fun reportModuleSeen(pkg: String, proc: String) {
        val handler = Handler(Looper.getMainLooper())
        for (delay in SEEN_RETRY_DELAYS_MS) {
            handler.postDelayed({
                if (seenReported) return@postDelayed
                val context = currentApplication() ?: return@postDelayed
                var ok = false
                try {
                    context.contentResolver.call(
                        Uri.parse("content://$OUR_PACKAGE.so"),
                        "report_module_seen",
                        pkg,
                        Bundle().apply {
                            putString("process", proc)
                            putInt("pid", AndroidProcess.myPid())
                            putBoolean("boxed", isBoxed())
                        }
                    )
                    ok = true
                } catch (t: Throwable) {
                    XposedBridge.log("[Tengcd] report seen call failed: ${t.message}")
                }
                if (!ok) {
                    try {
                        val uri = Uri.parse("content://$OUR_PACKAGE.so/seen")
                            .buildUpon()
                            .appendQueryParameter("pkg", pkg)
                            .appendQueryParameter("process", proc)
                            .build()
                        context.contentResolver.query(uri, null, null, null, null)?.close()
                        ok = true
                    } catch (t: Throwable) {
                        XposedBridge.log("[Tengcd] report seen query failed: ${t.message}")
                    }
                }
                if (ok) seenReported = true
            }, delay)
        }
    }

    /** 反射拿当前进程的 Application:两条路都试,盒内总有一条通 */
    private fun currentApplication(): Application? {
        try {
            val cls = Class.forName("android.app.ActivityThread")
            val at = cls.getMethod("currentActivityThread").invoke(null)
            val app = cls.getMethod("getApplication").invoke(at)
            if (app is Application) return app
        } catch (t: Throwable) {
        }
        try {
            val cls = Class.forName("android.app.ActivityThread")
            val app = cls.getMethod("currentApplication").invoke(null)
            if (app is Application) return app
        } catch (t: Throwable) {
        }
        return null
    }

    // ------------------------------------------------------------------ 每一轮

    /**
     * 判定「要不要现在加载」。
     *
     * 关键点:盒内进程被复用时,同一个进程会拿到**新的 Application 实例**。
     * 老代码用一个静态 loaded 一刀切,第二轮就永远空跑 —— 现在按 Application 实例分轮:
     * 换了实例就开新一轮,换新目录、换新文件名,让 so 的初始化真正重跑一遍。
     */
    @Synchronized
    private fun maybeLoad(app: Application, pkg: String, proc: String, stage: String) {
        val prev = lastApp
        if (app !== prev) {
            if (prev != null || loadedGeneration >= 0) {
                generation += 1
                attemptsThisGeneration = 0
                // 新一轮 = 需要重新挂一次菜单
                try { ImGuiRevive.resetForNewGeneration() } catch (t: Throwable) {}
                XposedBridge.log("[Tengcd] 新一轮应用启动(第 ${generation + 1} 轮) stage=$stage proc=$proc")
            }
            lastApp = app
        }
        if (generation == 0) generation = 1
        if (loadedGeneration == generation) return

        // 节流:同一轮里最快 3 秒试一次,最多试 40 次(约两分钟)。
        // 不节流的话轮询每 200ms 就会重抄一份 so、重载一次,机器直接被拖死。
        val now = System.currentTimeMillis()
        if (attemptsThisGeneration >= MAX_ATTEMPTS_PER_GEN) {
            if (attemptsThisGeneration == MAX_ATTEMPTS_PER_GEN) {
                attemptsThisGeneration += 1
                XposedBridge.log("[Tengcd] 这一轮试了 $MAX_ATTEMPTS_PER_GEN 次都没成,等下一次应用启动")
                report(
                    app, false, pkg, proc, null,
                    (lastLoadError ?: "so 一直没加载成功") + " / 试了 $MAX_ATTEMPTS_PER_GEN 次"
                )
            }
            return
        }
        if (now - lastAttemptAt < RETRY_GAP_MS) return
        attemptsThisGeneration += 1
        doLoad(app, pkg, proc, stage)
    }

    private fun doLoad(context: Context, pkg: String, proc: String, stage: String) {
        if (loading) return
        loading = true
        attemptCount += 1
        lastAttemptAt = System.currentTimeMillis()
        val myGeneration = generation
        val reasons = ArrayList<String>()
        try {
            // ① 清掉上一轮留在磁盘上的所有东西(相当于把目标包删掉再加回来)
            purgeStale(context, reasons)

            // ② 这一轮专用的目录(每次都是新的,不复用)
            val runDir = newRunDir(context, myGeneration)

            // ③ 把 so 抄一份到这一轮的目录里,用这一轮专属的文件名
            var target: File? = null
            if (runDir != null) {
                target = stageInto(runDir, context, readVariant(), myGeneration, reasons)
            } else {
                reasons.add("没有可写的暂存目录")
            }

            // ④ 加载 + 校验真的进了内存
            if (target != null) {
                // 先试改了 soname 的那份;万一这份被库内自校验挡掉,再回退到原样副本
                val candidates = ArrayList<File>()
                candidates.add(target)
                try {
                    target.parentFile?.listFiles()
                        ?.filter { it.isFile && it.name.endsWith(".so") && it.absolutePath != target.absolutePath }
                        ?.sortedBy { it.name }
                        ?.let { candidates.addAll(it) }
                } catch (t: Throwable) {
                }
                for (cand in candidates) {
                    if (attemptLoad(cand.absolutePath)) {
                        // System.load 没抛异常 = 已经进内存了;maps 里再确认一次,拿不到就说明是系统限制,不算失败
                        done(context, pkg, proc, cand, "run-${myGeneration}")
                        return
                    }
                    reasons.add("System.load(${cand.name}) 失败:" + (lastLoadError ?: "未知"))
                }
            }

            // ⑤ 全部失败:原因写清楚,回报界面 + 弹到游戏里
            val detail = buildString {
                append(if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().take(4).joinToString(" / "))
                lastLoadError?.takeIf { it.isNotBlank() }?.let {
                    if (!contains(it)) append(" / load:").append(it.take(80))
                }
                if (!canDrawOverlay(context)) {
                    append(" / 盒子(PINKBOX)没有「显示在其他应用上层」权限")
                }
            }
            XposedBridge.log("[Tengcd] load failed ($stage) gen=$myGeneration pkg=$pkg proc=$proc: $detail")
            if (attemptCount <= 3 || attemptCount % 20 == 0) {
                toast(context, "so 没加载成功:" + detail.take(90))
            }
            report(context, false, pkg, proc, null, detail)
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] doLoad 异常: ${t.message}")
            lastLoadError = t.message
            reasons.add("加载异常:" + (t.message ?: t.javaClass.simpleName))
            report(context, false, pkg, proc, null, reasons.joinToString(" / ").take(200))
        } finally {
            loading = false
        }
    }

    private fun done(context: Context, pkg: String, proc: String, file: File, how: String) {
        loadedGeneration = generation
        totalLoads += 1
        loadedPath = file.absolutePath
        val mapped = isMapped(file.name)
        val detail = "已加载($how,第${generation}轮)${if (mapped) ",已映射" else ""}"
        XposedBridge.log("[Tengcd] so loaded via $how gen=$generation: ${file.absolutePath} mapped=$mapped")
        toast(context, "so 已载入游戏(第${generation}轮)")
        report(context, true, pkg, proc, file.absolutePath, detail)
        // 关键:so 只负责把库拉进内存,菜单得我们自己每轮挂一次
        requestRevive(context, generation)
    }

    // ------------------------------------------------------------------ 清理残留

    /**
     * 把上一轮留下的一切清掉。
     *
     * 只清我们自己会产生的东西:`honffx` 目录、`honffx/run_*`、`libhonffx*.so`、
     * `*.tmp`、`*.lock`。**不碰游戏自己的数据,也不碰 honffx.config**。
     */
    private fun purgeStale(context: Context, reasons: MutableList<String>) {
        var removed = 0
        for (dir in staleRoots(context)) {
            try {
                if (!dir.isDirectory) continue
                val children = dir.listFiles() ?: continue
                for (child in children) {
                    val name = child.name
                    val ours = child.isDirectory && name.startsWith("honffx") ||
                        name.startsWith("libhonffx") ||
                        name.endsWith(".tmp") && name.startsWith("libhonffx") ||
                        name.endsWith(".lock") && name.startsWith("libhonffx")
                    if (!ours) continue
                    if (child.isDirectory) {
                        if (child.deleteRecursively()) removed += 1
                    } else if (child.delete()) {
                        removed += 1
                    }
                }
            } catch (t: Throwable) {
                reasons.add("清理失败:" + (t.message ?: t.javaClass.simpleName))
            }
        }
        if (removed > 0) {
            XposedBridge.log("[Tengcd] 清掉上一轮残留 $removed 项")
        }
    }

    /** 需要扫的目录:盒内真实目录 + guest 自己的目录 + 盒子的虚拟目录 */
    private fun staleRoots(context: Context): List<File> {
        val roots = LinkedHashSet<File>()
        val pathRoots = ArrayList<String>()
        for (base in realBoxDirs()) pathRoots.add(base.parentFile?.absolutePath ?: base.absolutePath)
        try {
            context.filesDir?.let { pathRoots.add(it.absolutePath) }
        } catch (t: Throwable) {
        }
        try {
            context.codeCacheDir?.let { pathRoots.add(it.parentFile?.absolutePath ?: it.absolutePath) }
        } catch (t: Throwable) {
        }
        try {
            context.cacheDir?.let { pathRoots.add(it.parentFile?.absolutePath ?: it.absolutePath) }
        } catch (t: Throwable) {
        }
        // 盒子的虚拟目录(guest 的私有目录真实落点)
        for (host in boxHostPackages(context)) {
            for (p in listOf(context.packageName, targetForDirs(context))) {
                pathRoots.add("/data/data/$host/virtual/data/data/$p")
                pathRoots.add("/data/user/0/$host/virtual/data/data/$p")
                pathRoots.add("/data/data/$host/virtual/data/user/0/$p")
                pathRoots.add("/data/user/0/$host/virtual/data/user/0/$p")
            }
        }
        for (p in pathRoots.distinct()) {
            if (p.isBlank()) continue
            roots.add(File(p))
        }
        return roots.toList()
    }

    /** 这一轮专用目录 */
    private fun newRunDir(context: Context, myGeneration: Int): File? {
        val bases = ArrayList<File>()
        bases.addAll(realBoxDirs())
        try {
            context.filesDir?.let { bases.add(File(it, "honffx")) }
        } catch (t: Throwable) {
        }
        try {
            context.codeCacheDir?.let { bases.add(File(it, "honffx")) }
        } catch (t: Throwable) {
        }
        val tag = "run_${AndroidProcess.myPid()}_${myGeneration}_${System.currentTimeMillis() % 1000000}"
        for (base in bases.distinct()) {
            try {
                if (!base.isDirectory && !base.mkdirs()) continue
                val dir = File(base, tag)
                if (dir.isDirectory || dir.mkdirs()) return dir
            } catch (t: Throwable) {
            }
        }
        return null
    }

    // ------------------------------------------------------------------ so 来源

    private fun readVariant(): String = try {
        queryHandoffVariant() ?: readVariantFromPrefs() ?: ""
    } catch (t: Throwable) {
        ""
    }

    private fun queryHandoffVariant(): String? = try {
        val app = currentApplication() ?: return null
        val bundle = app.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", app.packageName, null
        )
        bundle?.getString("variant")?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    /** 把 so 抄进这一轮的目录,文件名带轮次 —— 每次都是「一份新的库」 */
    private fun stageInto(
        runDir: File,
        context: Context,
        variant: String,
        myGeneration: Int,
        reasons: MutableList<String>
    ): File? {
        val v = variant.ifBlank { "local" }
        // 文件名里**不再带 honffx**:有些 so 会按自己的库名去 /proc/self/maps 里自查,
        // 中性名字能少踩一层坑。真正解决重复加载的是下面的 soname 改写。
        val tag = randomTag(4)
        val dst = File(runDir, "libh${tag}_g${myGeneration}_$v.so")

        // ① 直接可读的路径(交接文件 / 偏好 / 外部镜像)
        for (src in sourceFiles(context, variant, reasons)) {
            if (copyTo(src, dst, reasons)) return resealCopy(dst, runDir, tag, myGeneration, v, reasons)
        }

        // ② 通过模块的 ContentProvider 拉字节(跨 uid 最稳)
        if (fetchFromProvider(context, variant, dst, reasons)) {
            return resealCopy(dst, runDir, tag, myGeneration, v, reasons)
        }

        // ③ 从模块安装包 assets 里解(内置 so 的包走这条)
        if (extractFromApk(context, variant, dst, reasons)) {
            return resealCopy(dst, runDir, tag, myGeneration, v, reasons)
        }

        return null
    }

    /**
     * 关键一步:给这一轮的副本换一个**独一无二的 soname**。
     *
     * 为什么必需:这份 so 的 SONAME 写死成 `libhonffx.so`。盒子会复用同一个进程,
     * 上一轮那份库还挂在 linker 的已加载表里;这时哪怕文件路径、文件名全换新的,
     * 链接器按 soname 认库,会直接把**旧句柄**还给我们 —— dlopen 返回成功、
     * JNI_OnLoad 一次都不重跑,so 里的窗口创建自然不执行,而界面还报"注入成功"。
     *
     * 把副本里的 soname 改成等长的唯一串(12 字节:`libh` + 5 位随机 + `.so`,与 `libhonffx.so` 等长),
     * 链接器就当它是一份从没见过的库,真加载、真跑初始化。
     * 只改 .dynstr 里那 12 个字节,长度不变,不动任何偏移。
     */
    private fun resealCopy(
        src: File,
        runDir: File,
        tag: String,
        myGeneration: Int,
        variant: String,
        reasons: MutableList<String>
    ): File? {
        val out = File(runDir, "libh${tag}x_g${myGeneration}_$variant.so")
        val newName = try {
            // 流式拷一份:24MB 的 so 不要整份读进游戏进程的内存里(盒子内存本来就紧)
            src.copyTo(out, overwrite = true)
            val old = "libhonffx.so".toByteArray(Charsets.US_ASCII)
            // soname 就在 .dynstr 里,离文件头很近;先看前 4MB,找不到再整份找
            var at = -1
            val headLen = minOf(src.length(), 4L * 1024 * 1024).toInt()
            if (headLen >= old.size) {
                val head = ByteArray(headLen)
                java.io.FileInputStream(src).use { ins ->
                    var got = 0
                    while (got < headLen) {
                        val n = ins.read(head, got, headLen - got)
                        if (n <= 0) break
                        got += n
                    }
                }
                at = indexOfBytes(head, old)
            }
            if (at < 0) at = indexOfBytes(src.readBytes(), old)
            if (at < 0) {
                reasons.add("副本里没有 soname,按原样加载")
                out.delete()
                return src
            }
            // 名字必须**正好 12 字节**:libh(4) + 5 位随机 + .so(3) = 12 = "libhonffx.so" 的长度。
            // 差一个字节就会把后面的字符留下(比如 libhab3x.soo),所以这里硬校验。
            val fresh = randomTag(5)
            val neu = ("libh" + fresh + ".so").toByteArray(Charsets.US_ASCII)
            if (neu.size != old.size) {
                reasons.add("soname 长度对不上,按原样加载")
                return src
            }
            // 就地改副本里那 12 个字节,其余一个字节都不动
            java.io.RandomAccessFile(out, "rw").use { raf ->
                raf.seek(at.toLong())
                raf.write(neu)
            }
            val bad = validateSo(out)
            if (bad != null) {
                reasons.add("改 soname 后校验不过:$bad")
                out.delete()
                return src
            }
            "libh$fresh.so"
        } catch (t: Throwable) {
            reasons.add("改 soname 失败:" + (t.message ?: t.javaClass.simpleName))
            return src
        }
        XposedBridge.log("[Tengcd] 本轮副本 soname 改成 $newName(原 libhonffx.so)")
        return out
    }

    private fun indexOfBytes(hay: ByteArray, needle: ByteArray): Int {
        if (needle.isEmpty() || hay.size < needle.size) return -1
        val first = needle[0]
        var i = 0
        val last = hay.size - needle.size
        while (i <= last) {
            if (hay[i] == first) {
                var j = 1
                while (j < needle.size && hay[i + j] == needle[j]) j++
                if (j == needle.size) return i
            }
            i++
        }
        return -1
    }

    private fun randomTag(n: Int): String {
        val cs = "abcdefghijklmnopqrstuvwxyz0123456789"
        val sb = StringBuilder(n)
        val rnd = java.util.Random(System.nanoTime() xor (AndroidProcess.myPid().toLong() shl 16))
        repeat(n) { sb.append(cs[rnd.nextInt(cs.length)]) }
        return sb.toString()
    }

    private fun copyTo(src: File, dst: File, reasons: MutableList<String>): Boolean {
        try {
            if (!src.isFile || src.length() <= 4096L) return false
            val why = validateSo(src)
            if (why != null) {
                reasons.add("${src.name}:$why")
                return false
            }
            if (dst.exists()) dst.delete()
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            try {
                dst.setReadable(true, false)
            } catch (t: Throwable) {
            }
            if (dst.length() <= 4096L) {
                reasons.add("复制后文件不完整")
                dst.delete()
                return false
            }
            val v = validateSo(dst)
            if (v != null) {
                reasons.add("复制后的 so:$v")
                dst.delete()
                return false
            }
            return true
        } catch (t: Throwable) {
            reasons.add("复制失败:" + (t.message ?: t.javaClass.simpleName))
            return false
        }
    }

    /** 所有「读得到就直接用」的 so 文件 */
    private fun sourceFiles(context: Context, variant: String, reasons: MutableList<String>): List<File> {
        val out = ArrayList<File>()

        // 交接文件 / 偏好里写的路径(模块自己的私有目录,盒内常常同 uid,读得到)
        for (p in explicitPaths(context)) {
            val f = File(p)
            if (f.isFile) out.add(f)
        }

        val names = buildList {
            if (variant.isNotBlank()) add("libhonffx_$variant.so")
            add("libhonffx_local.so")
            add("libhonffx.so")
        }

        // 模块安装包 native 库目录(全机可读)、模块私有 module 目录、外部镜像
        for (dir in moduleDirs(context)) {
            if (!dir.isDirectory) continue
            for (name in names) {
                val f = File(dir, name)
                if (f.isFile) out.add(f)
            }
        }

        if (out.isEmpty()) reasons.add("没找到可读的 so 文件")
        return out.distinct()
    }

    private fun explicitPaths(context: Context): List<String> {
        val list = ArrayList<String>()
        try {
            val app = currentApplication()
            if (app != null) {
                val bundle = app.contentResolver.call(
                    Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", app.packageName, null
                )
                bundle?.getString("path")?.takeIf { it.isNotBlank() }?.let { list.add(it) }
            }
        } catch (t: Throwable) {
        }
        readPathFromPrefs()?.takeIf { it.isNotBlank() }?.let { list.add(it) }
        readHandoffPathFile(context)?.let { list.add(it) }
        return list
    }

    /** 模块自己那几处可能放着 so 的目录 */
    private fun moduleDirs(context: Context): List<File> {
        val dirs = LinkedHashSet<File>()
        // 安装包 lib/arm64(全机可读,最稳)
        try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            info.nativeLibraryDir?.let { dirs.add(File(it)) }
        } catch (t: Throwable) {
        }
        try {
            val pc = context.createPackageContext(OUR_PACKAGE, 0)
            pc.applicationInfo?.nativeLibraryDir?.let { dirs.add(File(it)) }
        } catch (t: Throwable) {
        }
        moduleApkPath?.let { path ->
            File(path).parentFile?.let { base ->
                dirs.add(File(base, "lib/arm64"))
                dirs.add(File(base, "lib/arm"))
            }
        }
        for (base in listOf(
            "/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/10/$OUR_PACKAGE/files/module",
            "/sdcard/TengcdSO",
            "/storage/emulated/0/TengcdSO",
            "/sdcard/Download/TengcdSO",
            "/data/local/tmp/honffx"
        )) {
            dirs.add(File(base))
        }
        try {
            context.getExternalFilesDir(null)?.let { dirs.add(File(it, "module")) }
        } catch (t: Throwable) {
        }
        dirs.add(File("/sdcard/Android/data/$OUR_PACKAGE/files/module"))
        dirs.add(File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module"))
        // 同目录的依赖库先载入,免得主 so 因为缺依赖 dlopen 失败
        for (d in dirs) {
            if (d.isDirectory) loadCompanionLibs(d)
        }
        return dirs.toList()
    }

    private fun loadCompanionLibs(dir: File) {
        for (name in listOf("libc++_shared.so", "libshadowhook.so")) {
            val f = File(dir, name)
            if (!f.isFile) continue
            try {
                System.load(f.absolutePath)
            } catch (t: Throwable) {
            }
        }
    }

    private fun fetchFromProvider(
        context: Context,
        variant: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        val uris = buildList {
            if (variant.isNotBlank()) add(Uri.parse("content://$OUR_PACKAGE.so/variant/$variant"))
            add(Uri.parse("content://$OUR_PACKAGE.so/module"))
            add(Uri.parse("content://$OUR_PACKAGE.so"))
        }
        for (uri in uris) {
            try {
                val input = context.contentResolver.openInputStream(uri) ?: continue
                if (dst.exists()) dst.delete()
                input.use { src -> dst.outputStream().use { o -> src.copyTo(o, 256 * 1024) } }
                if (dst.length() <= 4096L) {
                    reasons.add("Provider 给的 so 是空的")
                    dst.delete()
                    continue
                }
                try {
                    dst.setReadable(true, false)
                } catch (t: Throwable) {
                }
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add("Provider 的 so:$why")
                    dst.delete()
                    continue
                }
                return true
            } catch (t: Throwable) {
                reasons.add("Provider 取不到:" + (t.message ?: t.javaClass.simpleName))
            }
        }
        return false
    }

    private fun extractFromApk(
        context: Context,
        variant: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        val apk = resolveModuleApk(context) ?: run {
            reasons.add("找不到模块安装包")
            return false
        }
        if (variant.isBlank()) {
            reasons.add("没拿到选中的 SO 版本")
            return false
        }
        val encEntry = "assets/so/$variant.so${SoVault.ENC_SUFFIX}"
        val plainEntry = "assets/so/$variant.so"
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(encEntry)
                var encrypted = entry != null
                if (entry == null) {
                    entry = zip.getEntry(plainEntry)
                    encrypted = false
                }
                if (entry == null) {
                    reasons.add("安装包里没有 $plainEntry")
                    return false
                }
                val raw = zip.getInputStream(entry).use { it.readBytes() }
                if (raw.isEmpty()) {
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                var bytes: ByteArray? = if (encrypted) SoVault.decrypt(raw, entry.name.substringAfterLast('/')) else raw
                if (bytes == null || !SoVault.isElf(bytes) || bytes.size <= 4096) {
                    val alt = zip.getEntry(plainEntry)
                    if (alt != null && alt.name != entry.name) {
                        val altRaw = zip.getInputStream(alt).use { it.readBytes() }
                        if (SoVault.isElf(altRaw) && altRaw.size > 4096) bytes = altRaw
                    }
                }
                val data = bytes
                if (data == null || !SoVault.isElf(data)) {
                    reasons.add("安装包里的 so 无效")
                    return false
                }
                if (dst.exists()) dst.delete()
                dst.outputStream().use { it.write(data) }
                try {
                    dst.setReadable(true, false)
                } catch (t: Throwable) {
                }
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add("安装包里的 so:$why")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:" + (t.message ?: t.javaClass.simpleName))
            return false
        }
    }

    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ 加载校验

    private fun attemptLoad(path: String): Boolean = try {
        System.load(path)
        lastLoadError = null
        true
    } catch (t: Throwable) {
        lastLoadError = t.message ?: t.javaClass.simpleName
        XposedBridge.log("[Tengcd] System.load($path) failed: $lastLoadError")
        false
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "文件太小/占位文件"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "so 是 64 位,游戏进程是 32 位" else "so 是 32 位,游戏进程是 64 位"
        }
        return null
    }

    /** so 到底进没进本进程的内存(比 System.load 返回 true 更硬的证据) */
    private fun isMapped(name: String): Boolean = try {
        File("/proc/self/maps").useLines { lines ->
            lines.any { it.contains(name) }
        }
    } catch (t: Throwable) {
        false
    }

    // ------------------------------------------------------------------ 环境判定

    private fun realBoxDirs(): List<File> {
        val out = ArrayList<File>()
        val context = currentApplication() ?: return out
        for (pkg in boxHostPackages(context)) {
            for (base in listOf("/data/data/$pkg", "/data/user/0/$pkg")) {
                for (sub in listOf("cache", "files", "code_cache")) {
                    val dir = File("$base/$sub/honffx")
                    if (canWriteDir(dir)) out.add(dir)
                }
            }
        }
        return out
    }

    /** 盒子宿主包名:固定几个 + 从 maps 里推(换皮的包名也能认出来) */
    private fun boxHostPackages(context: Context): Set<String> {
        val pkgs = LinkedHashSet<String>(BOX_PACKAGES)
        val proc = currentProcessName()
        if (proc.contains(":") && !proc.startsWith(OUR_PACKAGE)) pkgs.add(proc.substringBefore(":"))
        try {
            File("/proc/self/maps").useLines { lines ->
                lines.forEach { line ->
                    val idx = line.indexOf("/data/app/")
                    if (idx >= 0 && (line.contains("libblackbox.so") || line.contains("libpine.so"))) {
                        val path = line.substring(idx).trim()
                        val dirName = path.split("/").getOrNull(3) ?: ""
                        dirName.substringBeforeLast('-').takeIf { it.contains(".") }?.let { pkgs.add(it) }
                    }
                }
            }
        } catch (t: Throwable) {
        }
        try {
            context.packageName.takeIf { it.isNotBlank() }?.let {
                // guest 包名不是宿主,不加
            }
        } catch (t: Throwable) {
        }
        return pkgs
    }

    private fun targetForDirs(context: Context): String = try {
        readTargetPackage() ?: InjectionPrefsTarget
    } catch (t: Throwable) {
        InjectionPrefsTarget
    }

    private fun canWriteDir(dir: File): Boolean = try {
        if (!dir.isDirectory && !dir.mkdirs()) {
            false
        } else {
            val probe = File(dir, ".w")
            val ok = probe.createNewFile() || probe.exists()
            probe.delete()
            ok
        }
    } catch (t: Throwable) {
        false
    }

    private fun isBoxed(): Boolean {
        val byClass = try {
            ActiveCheck.boxClassLoaded()
        } catch (t: Throwable) {
            false
        }
        if (byClass) return true
        return try {
            File("/proc/self/maps").useLines { lines ->
                lines.any { line ->
                    val l = line.lowercase()
                    l.contains("libblackbox.so") || l.contains("libpine.so") ||
                        l.contains("/blackbox/") || l.contains("niunaijun")
                }
            }
        } catch (t: Throwable) {
            false
        }
    }

    private fun isBoxHostOwnProcess(pkg: String, proc: String): Boolean {
        if (pkg !in BOX_PACKAGES) return false
        return !proc.contains(":")
    }

    private fun canDrawOverlay(context: Context): Boolean = try {
        Settings.canDrawOverlays(context)
    } catch (t: Throwable) {
        true
    }

    private fun currentProcessName(): String = try {
        File("/proc/self/cmdline").readText().trim('\u0000', '\n', ' ')
    } catch (t: Throwable) {
        ""
    }

    private fun toast(context: Context, msg: String) {
        try {
            val text = if (msg.length > 140) msg.take(140) else msg
            Handler(Looper.getMainLooper()).post {
                try {
                    Toast.makeText(context.applicationContext ?: context, "Tengcd: $text", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                }
            }
        } catch (t: Throwable) {
        }
    }

    private fun report(
        context: Context,
        ok: Boolean,
        pkg: String,
        proc: String,
        path: String?,
        detail: String?
    ) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_state",
                if (ok) "ok" else "error",
                Bundle().apply {
                    putString("package", pkg)
                    putString("process", proc)
                    putInt("pid", AndroidProcess.myPid())
                    putInt("generation", generation)
                    putInt("loads", totalLoads)
                    putString("path", path)
                    putString("detail", detail)
                    putBoolean("overlay", canDrawOverlay(context))
                    putBoolean("boxed", isBoxed())
                    putBoolean("is64", AndroidProcess.is64Bit())
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report failed: ${t.message}")
        }
    }

    private fun readPrefs(): XSharedPreferences? = try {
        val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
        try {
            xsp.makeWorldReadable()
        } catch (t: Throwable) {
        }
        xsp.reload()
        xsp
    } catch (t: Throwable) {
        null
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)
    } catch (t: Throwable) {
        null
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = mutableListOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt"),
            File("/sdcard/TengcdSO/module_path.txt")
        )
        try {
            context.getExternalFilesDir(null)?.let { candidates.add(0, File(it, "module_path.txt")) }
        } catch (t: Throwable) {
        }
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val InjectionPrefsTarget = "com.pi.czrxdfirst"

        /** 200ms 探一次,最多 600 次 = 120 秒。盒内首帧慢,等得久一点 */
        private const val PROBE_INTERVAL_MS = 200L
        private const val PROBE_MAX_TIMES = 600

        /** 过了前两分钟改成 2 秒探一次,永不停止 —— 盒内复用进程时要靠它发现「又开了一轮」 */
        private const val PROBE_SLOW_INTERVAL_MS = 2000L

        /** 同一轮里两次尝试之间至少隔 3 秒 */
        private const val RETRY_GAP_MS = 3000L

        /** 同一轮最多试 40 次 */
        private const val MAX_ATTEMPTS_PER_GEN = 40

        private val SEEN_RETRY_DELAYS_MS = longArrayOf(0L, 400L, 1000L, 2000L, 4000L)

        /** 虚拟空间框架的宿主包名 */
        private val BOX_PACKAGES = setOf(
            "top.niunaijun.blackbox",
            "com.blackbox",
            "com.pinkbox"
        )

        /** 同一个游戏的不同马甲包 */
        private val SAME_GAME_PACKAGES = setOf(
            "com.pi.czrxdfirst",
            "com.pi.ezrxdfirst"
        )
    }
}
