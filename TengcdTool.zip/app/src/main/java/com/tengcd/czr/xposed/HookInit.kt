package com.tengcd.czr.xposed

import android.app.Application
import android.app.Instrumentation
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process as AndroidProcess
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import com.tengcd.czr.util.SoVault
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 目标包启动 -> 找到用户选的那份 so -> System.load -> 把结果回报给界面。
 *
 * ── 1.3 这一版改了什么(治「LSPosed 勾选了但用不了」) ──
 *  1. **分阶段回报**:只要模块被 LSPosed 塞进目标进程,就先报一次 "hooked";
 *     so 真加载成功再报 "loaded"。这样界面能分清到底是
 *     「LSPosed 根本没注入」还是「注入了但 so 加载失败」,不再一律显示"未激活"。
 *  2. **只在目标主进程里加载**:以前包名对上的每个进程都往里塞 so,
 *     很容易塞进游戏的子进程里(Unity 的 metric/推送进程),主进程反而没载上。
 *  3. **加载重试**:0.3s / 1.2s / 3s / 6s 各试一次,目标初始化慢也能赶上。
 *  4. **Application.attach 挂不上时有兜底**:改挂 Instrumentation.callApplicationOnCreate。
 *  5. **so 在后台线程解包并加载**:23MB 的 so 在主线程解压容易把游戏卡出 ANR。
 *  6. **变体名不再乱猜**:包里没有所选的变体就明确报出来,不再偷偷拿最大的那个顶包。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    @Volatile
    private var loaded = false

    @Volatile
    private var loading = false

    @Volatile
    private var hookedReported = false

    @Volatile
    private var prefs: XSharedPreferences? = null

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return
        if (pkg == OUR_PACKAGE || pkg == "android" || pkg == "com.android.systemui") return

        val processName = lpparam?.processName ?: pkg
        // 偏好读不到就用默认目标(以前读不到会直接 return,于是什么都查不出来)
        val target = readTargetPackage() ?: DEFAULT_TARGET
        if (pkg != target) return

        val isMain = processName == pkg
        XposedBridge.log(
            "[Tengcd] 模块已进入 pkg=$pkg proc=$processName main=$isMain " +
                "xposed=${xposedVersion()} abi=${if (AndroidProcess.is64Bit()) 64 else 32}"
        )
        hookApplication(pkg, processName, isMain)
    }

    // ---------------------------------------------------------------- 挂载点

    private fun hookApplication(pkg: String, processName: String, isMain: Boolean) {
        var hooked = false
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        onTargetStarted(context, pkg, processName, isMain)
                    }
                }
            )
            hooked = true
            XposedBridge.log("[Tengcd] Application.attach 挂上了")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] Application.attach 挂载失败:${t.message}")
        }

        if (!hooked) {
            // 兜底:有些 ROM / 加固会改 Application 的加载路径,attach 挂不上就换这个点
            try {
                XposedHelpers.findAndHookMethod(
                    Instrumentation::class.java,
                    "callApplicationOnCreate",
                    Application::class.java,
                    object : XC_MethodHook() {
                        override fun afterHookedMethod(param: MethodHookParam?) {
                            val app = param?.args?.getOrNull(0) as? Application ?: return
                            onTargetStarted(app, pkg, processName, isMain)
                        }
                    }
                )
                XposedBridge.log("[Tengcd] 已改挂 Instrumentation.callApplicationOnCreate")
            } catch (t: Throwable) {
                XposedBridge.log("[Tengcd] 兜底挂载也失败:${t.message}")
            }
        }
    }

    private fun onTargetStarted(context: Context, pkg: String, processName: String, isMain: Boolean) {
        if (context.packageName != pkg) return
        if (loaded) return

        // 第一步先证明「模块确实被注入进来了」——这一步和 so 能不能加载无关
        if (isMain) reportHooked(context, processName)

        scheduleLoad(context, pkg, processName, isMain, 0)
    }

    private fun scheduleLoad(context: Context, pkg: String, processName: String, isMain: Boolean, index: Int) {
        if (loaded || index >= LOAD_DELAYS.size) return
        Handler(Looper.getMainLooper()).postDelayed({
            if (!loaded) {
                startLoad(context, pkg, processName, isMain, index + 1)
                scheduleLoad(context, pkg, processName, isMain, index + 1)
            }
        }, LOAD_DELAYS[index])
    }

    /**
     * 解包 + System.load 都放到后台线程:
     * 二十多兆的 so 在主线程解压加载,游戏必卡(严重时直接 ANR)。
     */
    private fun startLoad(context: Context, pkg: String, processName: String, isMain: Boolean, attempt: Int) {
        if (loaded) return
        synchronized(this) {
            if (loaded || loading) return
            loading = true
        }
        Thread({
            var ok = false
            try {
                ok = loadModule(context, processName, attempt)
            } catch (t: Throwable) {
                XposedBridge.log("[Tengcd] 加载过程异常:${t.message}")
                if (isMain) report(context, "error", null, t.message ?: t.javaClass.simpleName, processName)
            } finally {
                loading = false
            }
            if (!ok) {
                XposedBridge.log("[Tengcd] 第 $attempt 次加载没成功")
            }
        }, "tengcd-load-$attempt").start()
    }

    // ---------------------------------------------------------------- 加载

    private fun loadModule(context: Context, processName: String, attempt: Int): Boolean {
        if (loaded) return true

        val handoff = queryHandoff(context)
        val target = handoff?.target?.takeIf { it.isNotBlank() }
            ?: readTargetPackage()
            ?: DEFAULT_TARGET
        if (context.packageName != target) {
            report(
                context, "error", null,
                "目标包名对不上:配置里是 $target,当前进程是 ${context.packageName}", processName
            )
            return false
        }

        val variant = pickVariant(handoff?.variant)
        val reasons = ArrayList<String>()
        val isMainProc = processName == context.packageName

        // 只往目标主进程里加载:游戏子进程塞进去没用,还可能把子进程搞崩
        if (!isMainProc) {
            XposedBridge.log("[Tengcd] 非主进程($processName),跳过加载")
            return false
        }

        // 1) 先用现成的路径试试(共用 uid / 有 root 的时候这条路能直接过)
        val candidates = listOfNotNull(
            handoff?.path,
            readPathFromPrefs(),
            readHandoffPathFile(context)
        ).distinct()
        for (path in candidates) {
            if (path.isBlank()) continue
            val f = File(path)
            if (!f.isFile) {
                reasons.add("文件不存在")
                continue
            }
            if (!f.canRead()) {
                reasons.add("目标进程读不到应用私有目录")
                continue
            }
            val why = validateSo(f)
            if (why != null) {
                reasons.add(why)
                continue
            }
            if (attemptLoad(context, f)) {
                report(context, "ok", f.absolutePath, null, processName)
                return true
            }
            reasons.add("System.load 被拒")
        }

        // 2) 走模块自己的分发口(ContentProvider):把 so 以文件流的形式拷进目标进程自己的目录。
        //    这条路不看 uid、也不依赖安装包里有没有内置 so,
        //    「内置变体」和「本机读取的 so」都能这么送进去 —— 以前只认私有路径,所以必然失败。
        val viaProvider = fetchViaProvider(context, reasons)
        if (viaProvider != null) {
            report(context, "ok", viaProvider.absolutePath, null, processName)
            return true
        }

        // 3) 从模块安装包里把选中的变体抽到目标进程自己的目录(哪个目录能加载就用哪个)
        val extracted = extractVariant(context, variant, reasons)
        if (extracted != null) {
            report(context, "ok", extracted.absolutePath, null, processName)
            return true
        }

        // 4) 上面都挂了,把原因回报给界面
        val detail = if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().joinToString(" / ")
        XposedBridge.log("[Tengcd] 第 $attempt 次加载失败:$detail")
        report(context, "error", null, detail, processName)
        return false
    }

    private fun attemptLoad(context: Context, file: File): Boolean {
        if (loaded) return true
        return try {
            System.load(file.absolutePath)
            loaded = true
            XposedBridge.log("[Tengcd] so 加载成功:${file.absolutePath}")
            true
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] System.load(${file.absolutePath}) 失败:${t.message}")
            false
        }
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF 文件"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "这个 so 是 64 位,目标进程是 32 位" else "这个 so 是 32 位,目标进程是 64 位"
        }
        return null
    }

    // ---------------------------------------------------------------- 抽取

    /** 目标进程能写、加载器也肯认的几个目录,挨个试 */
    private fun writableDirs(context: Context): List<File> {
        val list = ArrayList<File>(3)
        try {
            list.add(File(context.codeCacheDir, "honffx"))
        } catch (t: Throwable) {
        }
        list.add(File(context.filesDir, "honffx"))
        try {
            list.add(File(context.createDeviceProtectedStorageContext().filesDir, "honffx"))
        } catch (t: Throwable) {
        }
        return list
    }

    /**
     * 走模块的 ContentProvider 把 so 流式拷到目标进程自己的目录。
     *
     * 这是「LSPosed 勾选了却用不了」最关键的一条:
     * 模块的 so 一直在模块自己的私有目录里,目标进程的 uid 读不到;
     * 而安装包里又没内置 so(assets/so 是空的),从包里抽也抽不出来。
     * 换成 ContentProvider 送流,跨 uid 也不受限制,两条来源都能走通。
     */
    private fun fetchViaProvider(context: Context, reasons: MutableList<String>): File? {
        val uri = Uri.parse("content://$OUR_PACKAGE.so/module")
        for (dir in writableDirs(context)) {
            val tmp = File(dir, "libhonffx_provider.so.tmp")
            val dst = File(dir, "libhonffx_provider.so")
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                var total = 0L
                val input = try {
                    context.contentResolver.openInputStream(uri)
                } catch (t: Throwable) {
                    XposedBridge.log("[Tengcd] 打开发布口失败:${t.message}")
                    null
                } ?: run {
                    // 分发口打不开就不用再换目录试了
                    reasons.add("模块的分发口打不开(模块可能还没准备好 so)")
                    return null
                }
                input.use { ins ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            total += n
                        }
                    }
                }
                if (total <= 0L) {
                    tmp.delete()
                    reasons.add("从模块取到的 so 是空的")
                    continue
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    continue
                }
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add(why)
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (attemptLoad(context, dst)) return dst
                reasons.add("取到的 so 在 ${dir.name} 目录加载失败")
            } catch (t: Throwable) {
                tmp.delete()
                reasons.add("从模块取 so 失败:${t.message}")
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽 assets/so/<variant>.so,写到目标进程自己的目录。
     * 写不进去就换下一个目录,全失败返回 null。
     */
    private fun extractVariant(
        context: Context,
        variant: String,
        reasons: MutableList<String>
    ): File? {
        val apk = resolveModuleApk(context)
        if (apk == null) {
            reasons.add("找不到模块安装包")
            return null
        }

        val targets = writableDirs(context)

        if (!SoVault.signatureAllowed(context, OUR_PACKAGE)) {
            reasons.add("安装包签名校验失败,内置 so 拒绝解密")
            return null
        }

        for (dir in targets) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                val dst = File(dir, "libhonffx_$variant.so")
                if (!unzipEntry(apk, variant, dst, reasons)) continue
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add(why)
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (attemptLoad(context, dst)) return dst
                reasons.add("解出来的 so 在 ${dir.name} 目录加载失败,换下一个目录")
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽一份 so 写到 dst。
     * 包里的资产是加密件(xxx.so.enc),这里读出来先解密再落盘;
     * 老包没有 .enc 的话退回读明文 .so。
     */
    private fun unzipEntry(
        apk: File,
        variant: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        val encEntry = "assets/so/$variant.so${SoVault.ENC_SUFFIX}"
        val plainEntry = "assets/so/$variant.so"
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(encEntry)
                var encrypted = entry != null
                if (entry == null) {
                    entry = zip.getEntry(plainEntry)
                    encrypted = false
                }
                if (entry == null) {
                    val all = zip.entries().toList().filter {
                        it.name.startsWith("assets/so/") &&
                            (it.name.endsWith(".so") || it.name.endsWith(".so" + SoVault.ENC_SUFFIX))
                    }
                    when {
                        all.isEmpty() -> {
                            reasons.add("安装包里没有 assets/so(打包时没带 so)")
                            return false
                        }
                        all.size == 1 -> {
                            // 包里只有一个,那就是它了
                            entry = all[0]
                            encrypted = all[0].name.endsWith(SoVault.ENC_SUFFIX)
                        }
                        else -> {
                            // 有多个却对不上名字:别拿最��的那个顶包,直接说清楚
                            reasons.add(
                                "包里没有 $variant,现有:" +
                                    all.joinToString("、") { it.name.substringAfterLast('/') }
                            )
                            return false
                        }
                    }
                }
                val picked = entry ?: return false
                val raw = zip.getInputStream(picked).use { it.readBytes() }
                if (raw.isEmpty()) {
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                // 先按拿到的那份处理:密文就解密,明文直接用
                var bytes: ByteArray? = if (encrypted) {
                    SoVault.decrypt(raw, picked.name.substringAfterLast('/'))
                } else {
                    raw
                }
                // 密文解不开(或解出来不是 so)时,再试同名的明文 .so —— 明文和密文都支持
                if (bytes == null || !SoVault.isElf(bytes) || bytes.size <= 4096) {
                    val alt = zip.getEntry(plainEntry)
                    if (alt != null && alt.name != picked.name) {
                        val altRaw = zip.getInputStream(alt).use { it.readBytes() }
                        if (SoVault.isElf(altRaw) && altRaw.size > 4096) bytes = altRaw
                    }
                }
                val plainBytes = bytes
                if (plainBytes == null) {
                    reasons.add("内置 so 解密失败(安装包被改过或签名不对)")
                    return false
                }
                if (!SoVault.isElf(plainBytes)) {
                    reasons.add("抽出来的东西不是 so(assets/so 里还是占位文件?)")
                    return false
                }
                val tmp = File(dst.parentFile, dst.name + ".tmp")
                tmp.outputStream().use { it.write(plainBytes) }
                if (tmp.length() <= 0L) {
                    tmp.delete()
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    reasons.add("落盘失败")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:${t.message}")
            return false
        }
    }

    /** 模块安装包路径:优先 initZygote 给的,拿不到就去问 PackageManager */
    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- 取配置

    private data class Handoff(val path: String, val variant: String, val target: String)

    /** 问我们自己的 ContentProvider 要交接信息(最可靠的一条路) */
    private fun queryHandoff(context: Context): Handoff? = try {
        val bundle: Bundle? = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", context.packageName, null
        )
        if (bundle == null) {
            null
        } else {
            Handoff(
                path = bundle.getString("path").orEmpty(),
                variant = bundle.getString("variant").orEmpty(),
                target = bundle.getString("target").orEmpty()
            )
        }
    } catch (t: Throwable) {
        XposedBridge.log("[Tengcd] 问 Provider 没问到:${t.message}")
        null
    }

    /**
     * 选哪个变体:交接信息里的 > 偏好里的 > 默认。
     * 交接信息里写的是 "local"/"remote" 这种来源标记时不当变体名用。
     */
    private fun pickVariant(fromHandoff: String?): String {
        val h = fromHandoff?.trim().orEmpty()
        if (LOOKS_LIKE_VARIANT.matches(h)) return h
        val p = readVariantFromPrefs()?.trim().orEmpty()
        if (LOOKS_LIKE_VARIANT.matches(p)) return p
        return DEFAULT_VARIANT
    }

    /** 回报阶段:hooked(进了目标进程) / ok(so 加载成功) / error(加载失败) */
    private fun reportHooked(context: Context, processName: String) {
        if (hookedReported) return
        hookedReported = true
        Thread({
            callProvider(context, "hooked", null, null, processName)
        }, "tengcd-report-hooked").start()
    }

    private fun report(context: Context, status: String, path: String?, detail: String?, processName: String) {
        callProvider(context, status, path, detail, processName)
    }

    private fun callProvider(
        context: Context,
        status: String,
        path: String?,
        detail: String?,
        processName: String?
    ): Boolean {
        val extras = Bundle().apply {
            putString("package", context.packageName)
            putString("path", path)
            putString("detail", detail)
            putString("process", processName)
            putInt("xposed", xposedVersion())
        }
        repeat(3) { i ->
            try {
                val b = context.contentResolver.call(
                    Uri.parse("content://$OUR_PACKAGE.so"), "report_state", status, extras
                )
                if (b != null) return true
            } catch (t: Throwable) {
                XposedBridge.log("[Tengcd] 回报($status)失败:${t.message}")
            }
            if (i < 2) {
                try {
                    Thread.sleep(400)
                } catch (ignored: InterruptedException) {
                }
            }
        }
        return false
    }

    private fun readPrefs(): XSharedPreferences? {
        prefs?.let {
            try {
                it.reload()
            } catch (t: Throwable) {
            }
            return it
        }
        return try {
            val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
            @Suppress("DEPRECATION")
            try {
                xsp.makeWorldReadable()
            } catch (t: Throwable) {
            }
            xsp.reload()
            prefs = xsp
            xsp
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] 读不到偏好:${t.message}")
            null
        }
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = listOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    private fun xposedVersion(): Int = try {
        XposedBridge.getXposedVersion()
    } catch (t: Throwable) {
        -1
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"
        private const val DEFAULT_VARIANT = "v0.24"

        /** 目标初始化慢的时候也能赶上:依次等 0.3s / 1.2s / 3s / 6s */
        private val LOAD_DELAYS = longArrayOf(300L, 1200L, 3000L, 6000L)

        private val LOOKS_LIKE_VARIANT = Regex("^v?[0-9]+(\\.[0-9]+)*$")
    }
}
