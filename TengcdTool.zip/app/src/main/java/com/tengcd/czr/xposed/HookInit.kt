package com.tengcd.czr.xposed

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process as AndroidProcess
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import com.tengcd.czr.util.SoVault
import com.tengcd.czr.util.ServiceState
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 目标包启动 -> 找到用户选的那份 so -> System.load -> 回报结果。
 *
 * ⚠️ 关键点(以前"内置 so 用不了"的根因):
 *   模块的 so 放在我们自己的私有目录里,目标进程的 uid 根本读不到,
 *   直接拿那个路径去 System.load 必然失败。
 *   现在改成:目标进程从**模块安装包**(任何进程都读得到)里把选中的变体抽出来,
 *   写进目标进程自己的私有目录再加载 —— 这条路和目标本身的数据目录一致,加载器不会拒。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    @Volatile
    private var loaded = false

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return

        // 被注入的是我们自己的应用:这就是「模块已激活」最硬的证据。
        // 不加载目标 so,只把状态钉下来(界面靠它显示已激活)。
        if (pkg == OUR_PACKAGE) {
            markSelfActive()
            return
        }
        if (pkg == "android" || pkg == "com.android.systemui") return

        // 便宜的先判断一下:偏好里读得到目标包、又不是它,直接跳过,不去问 Provider
        // 例外:同一个游戏的马甲包(distribution 用的包名,只差几个字母)也要进来,
        //       否则用户换了个包名装,框架压根不送模块进来,过更新全哑火。
        val cachedTarget = readTargetPackage()
        if (!cachedTarget.isNullOrBlank() && pkg != cachedTarget && pkg !in SAME_GAME_PACKAGES) return

        // 过更新的挂载挪到 attach 之后做(需要 Context 才能把补丁库落到目标自己的目录),
        // 见下方 Application.attach 的 hook。

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        // 过更新:这时代码已起来了,把补丁库直接 load 进目标进程
                        // (免 root、不走 ptrace,和游戏模块各走各的,互不干扰)
                        if (readOverUpdate() && !OverUpdateNative.loaded) {
                            applyOverUpdate(context, lpparam)
                        }
                        // 马甲包只挂过更新那一层:模块 so 是认包名干活的,塞进名字对不上的进程只会白折腾
                        if (!cachedTarget.isNullOrBlank() && pkg != cachedTarget) return
                        // 稍等一下,让目标自己的初始化先跑完,再塞模块进去
                        Handler(Looper.getMainLooper()).postDelayed({
                            try {
                                loadModule(context, pkg)
                            } catch (t: Throwable) {
                                report(context, false, null, t.message ?: t.javaClass.simpleName)
                            }
                        }, LOAD_DELAY_MS)
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked target: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook attach failed: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- 自激活

    /**
     * 框架把本模块注入到我们自己的应用里 = 模块确实在框架里勾上并生效了。
     * 这里只做三件事:置内存标志、写带 pid 的标记文件、同步一下界面状态。
     * 不碰目标 so 的加载逻辑,免得依赖目标包名。
     */
    private fun markSelfActive() {
        try {
            ActiveCheck.markSelfHooked()
        } catch (t: Throwable) {
        }
        try {
            XposedBridge.log("[Tengcd] module injected into self (ver=" + ActiveCheck.xposedVersion() + ")")
        } catch (t: Throwable) {
        }
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        if (context.packageName != OUR_PACKAGE) return
                        try {
                            ActiveCheck.markSelfHooked()
                            ActiveCheck.writeMarker(context)
                            ServiceState.onReportedActive()
                        } catch (t: Throwable) {
                            XposedBridge.log("[Tengcd] self marker failed: ${t.message}")
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] self hook failed: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- 过更新

    /**
     * 框架模式下的过更新:把 liboverupdate.so 抽到目标进程自己的 cache 目录再 System.load。
     *
     * 为什么不再依赖那份 JustTrustMePP 的 dex:
     *   ① 那段代码靠 de.robv.android.xposed.XposedBridge 干活,免 root(进程注入)
     *      这条路根本没有那个类,加载进来就是 NoClassDefFoundError,一次都没成功过;
     *   ② 在目标进程里再塞一个带整套 androidx 的 dex,本身就是类冲突的一大来源。
     * 现在同一件事全在自己写的原生库里做(ArtMethod 替换 + GOT 指针替换),不依赖框架。
     */
    private fun applyOverUpdate(context: Context, @Suppress("UNUSED_PARAMETER") lpparam: XC_LoadPackage.LoadPackageParam?) {
        // ① 请求层:Java 侧直接把「检查更新」这条请求按住(DNS 黑洞 / 版本号伪装 / 更新页跳转)。
        //    这条路不依赖原生库,所以就算补丁库没加载上,请求拦截照样生效。
        try {
            UpdateRequestBlock.install(lpparam, context.packageName, readUpdateRules())
            XposedBridge.log("[Tengcd] 更新请求拦截:" + UpdateRequestBlock.summary())
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] 更新请求拦截挂载失败:" + t.message)
        }

        val lib = extractNativePatch(context)
        if (!OverUpdateNative.load(lib)) {
            XposedBridge.log("[Tengcd] 过更新原生库没加载上:" + (OverUpdateNative.lastError ?: "?"))
            reportPatch(context, listOfNotNull(
                "过更新库没加载上(" + (OverUpdateNative.lastError ?: "未知原因") + ")",
                UpdateRequestBlock.summary()
            ).joinToString("｜"))
            return
        }
        XposedBridge.log("[Tengcd] 过更新原生库已加载")
        reportPatch(context, mergedPatchText())

        // 给扫描线程一点时间(它 0.6 秒后才开始扫),再把结论回报给界面
        for (delay in longArrayOf(2000L, 5000L)) {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    reportPatch(context, mergedPatchText())
                } catch (t: Throwable) {
                }
            }, delay)
        }
    }

    /** 原生库的结论 + 请求拦截的结论,合成一行给界面 */
    private fun mergedPatchText(): String {
        val native = try {
            OverUpdateNative.summary()
        } catch (t: Throwable) {
            null
        }
        val net = try {
            UpdateRequestBlock.summary()
        } catch (t: Throwable) {
            null
        }
        return listOfNotNull(net, native).joinToString("｜")
    }

    /**
     * 读用户自定义的拦截关键字(偏好里那两项,逗号或换行分隔)。
     * 没填就用内置默认值 —— 默认值已经覆盖了绝大多数"独立更新域名 + 标准查版本接口"的游戏。
     */
    private fun readUpdateRules(): UpdateRequestBlock.Rules {
        val base = UpdateRequestBlock.Rules()
        val prefs = try {
            readPrefs()
        } catch (t: Throwable) {
            null
        }
        fun list(key: String): List<String> =
            prefs?.getString(key, null)
                ?.split(',', '\n')
                ?.map { it.trim().lowercase() }
                ?.filter { it.isNotEmpty() }
                .orEmpty()

        val extraHosts = list("update_block_hosts")
        val extraPaths = list("update_block_paths")
        val blockByPath = try {
            prefs?.getBoolean("update_block_by_path", false) ?: false
        } catch (t: Throwable) {
            false
        }
        return base.copy(
            hostKeywords = base.hostKeywords + extraHosts,
            pathKeywords = base.pathKeywords + extraPaths,
            blockByPath = blockByPath
        )
    }

    /** 从模块安装包里把当前 ABI 的补丁库抽到目标进程自己的 cache 目录 */
    private fun extractNativePatch(context: Context): File? {
        val abi = if (AndroidProcess.is64Bit()) "arm64-v8a" else "armeabi-v7a"
        val apk = resolveModuleApk(context) ?: return null
        val dir = File(context.codeCacheDir, "honffx")
        if (!dir.isDirectory && !dir.mkdirs()) return null
        val dst = File(dir, "liboverupdate_$abi.so")

        return try {
            ZipFile(apk).use { zip ->
                val entry = zip.getEntry("lib/$abi/liboverupdate.so") ?: return null
                // 升级安装后缓存里的旧库要换掉:大小对不上就重新抽
                if (!dst.isFile || dst.length() != entry.size) {
                    zip.getInputStream(entry).use { input ->
                        dst.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                    }
                }
            }
            dst.takeIf { it.isFile && it.length() > 0L }
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] 抽补丁库失败:" + t.message)
            null
        }
    }

    /** 把过更新的结论回报给本 App(目标进程读不到的状态就走这条路) */
    private fun reportPatch(context: Context, text: String) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"), "report_patch", text, null
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] 回报过更新状态失败:" + t.message)
        }
    }

    // ---------------------------------------------------------------- 加载

    private fun loadModule(context: Context, pkg: String) {
        if (loaded) return

        // 目标包名以 Provider 给的为准,读不到再退回偏好里存的
        val handoff = queryHandoff(context)
        val target = handoff?.target?.takeIf { it.isNotBlank() }
            ?: readTargetPackage()
            ?: DEFAULT_TARGET
        if (context.packageName != target) return

        val variant = handoff?.variant?.takeIf { it.isNotBlank() }
            ?: readVariantFromPrefs()
            ?: DEFAULT_VARIANT

        val reasons = ArrayList<String>()

        // 1) 先用现成的路径试试(共用 uid / 有 root 的时候这条路能直接过)
        val candidates = listOfNotNull(
            handoff?.path,
            readPathFromPrefs(),
            readHandoffPathFile(context)
        ).distinct()
        for (path in candidates) {
            if (path.isBlank()) continue
            val f = File(path)
            if (!f.isFile) {
                reasons.add("文件不存在")
                continue
            }
            if (!f.canRead()) {
                reasons.add("目标进程读不到应用私有目录")
                continue
            }
            val why = validateSo(f)
            if (why != null) {
                reasons.add(why)
                continue
            }
            if (attemptLoad(context, f.absolutePath)) {
                report(context, true, f.absolutePath, null)
                return
            }
            reasons.add("System.load 被拒")
        }

        // 2) 从模块安装包里把选中的变体抽到目标进程自己的目录(哪个目录能加载就用哪个)
        val extracted = extractVariant(context, variant, reasons) { file ->
            attemptLoad(context, file.absolutePath)
        }
        if (extracted != null) {
            report(context, true, extracted.absolutePath, null)
            return
        }

        // 3) 上面都挂了,把原因回报给界面
        val detail = if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().joinToString(" / ")
        XposedBridge.log("[Tengcd] load failed: $detail")
        report(context, false, null, detail)
    }

    private fun attemptLoad(context: Context, path: String): Boolean = try {
        System.load(path)
        loaded = true
        XposedBridge.log("[Tengcd] module loaded: $path")
        true
    } catch (t: Throwable) {
        XposedBridge.log("[Tengcd] System.load($path) failed: ${t.message}")
        false
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF 文件"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "这个 so 是 64 位,目标进程是 32 位" else "这个 so 是 32 位,目标进程是 64 位"
        }
        return null
    }

    // ---------------------------------------------------------------- 抽取

    /**
     * 从模块安装包里抽 assets/so/<variant>.so,写到目标进程自己的目录。
     * 写不进去就换下一个目录,全失败返回 null。
     */
    private fun extractVariant(
        context: Context,
        variant: String,
        reasons: MutableList<String>,
        attempt: (File) -> Boolean
    ): File? {
        val apk = resolveModuleApk(context)
        if (apk == null) {
            reasons.add("找不到模块安装包")
            return null
        }
        if (variant.isBlank()) {
            reasons.add("没拿到选中的 SO 版本")
            return null
        }

        val entryName = "assets/so/$variant.so${SoVault.ENC_SUFFIX}"
        val plainEntry = "assets/so/$variant.so"
        val targets = buildList {
            add(File(context.codeCacheDir, "honffx"))
            add(File(context.filesDir, "honffx"))
            try {
                add(File(context.createDeviceProtectedStorageContext().filesDir, "honffx"))
            } catch (t: Throwable) {
            }
        }

        if (!SoVault.signatureAllowed(context, OUR_PACKAGE)) {
            reasons.add("安装包签名校验失败,内置 so 拒绝解密")
            return null
        }

        for (dir in targets) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                val dst = File(dir, "libhonffx_$variant.so")
                if (!unzipEntry(apk, entryName, plainEntry, dst, reasons)) continue
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add(why)
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (attempt(dst)) return dst
                reasons.add("解出来的 so 在 ${dir.name} 目录加载失败，换下一个目录")
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽一份 so 写到 dst。
     * 包里的资产是加密件(xxx.so.enc),这里读出来先解密再落盘;
     * 老包没有 .enc 的话退回读明文 .so。
     */
    private fun unzipEntry(
        apk: File,
        encEntry: String,
        plainEntry: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(encEntry)
                var encrypted = entry != null
                if (entry == null) {
                    entry = zip.getEntry(plainEntry)
                    encrypted = false
                }
                // 变体名对不上就到此为止:以前这里会「挑包里最大的那个 so」，
                // 于是用户切到 v0.28 / v2.4 时，注入的永远是包里最大的那份 v0.24。
                // 现在只认选中的那一个变体，找不到就如实报，不偷换版本。
                if (entry == null) {
                    reasons.add("安装包里没有 assets/so/$encEntry")
                    return false
                }
                val raw = zip.getInputStream(entry).use { it.readBytes() }
                if (raw.isEmpty()) {
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                // 先按拿到的那份处理:密文就解密,明文直接用
                var bytes: ByteArray? = if (encrypted) {
                    SoVault.decrypt(raw, entry.name.substringAfterLast('/'))
                } else {
                    raw
                }
                // 密文解不开(或解出来不是 so)时,再试同名的明文 .so —— 明文和密文都支持
                if (bytes == null || !SoVault.isElf(bytes) || bytes.size <= 4096) {
                    val alt = zip.getEntry(plainEntry)
                    if (alt != null && alt.name != entry.name) {
                        val altRaw = zip.getInputStream(alt).use { it.readBytes() }
                        if (SoVault.isElf(altRaw) && altRaw.size > 4096) bytes = altRaw
                    }
                }
                val plainBytes = bytes
                if (plainBytes == null) {
                    reasons.add("内置 so 解密失败(安装包被改过或签名不对)")
                    return false
                }
                if (!SoVault.isElf(plainBytes)) {
                    reasons.add("抽出来的东西不是 so(assets/so 里还是占位文件?)")
                    return false
                }
                val tmp = File(dst.parentFile, dst.name + ".tmp")
                tmp.outputStream().use { it.write(plainBytes) }
                if (tmp.length() <= 0L) {
                    tmp.delete()
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    reasons.add("落盘失败")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:${t.message}")
            return false
        }
    }

    /** 模块安装包路径:优先 initZygote 给的,拿不到就去问 PackageManager */
    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- 取配置

    private data class Handoff(val path: String, val variant: String, val target: String)

    /** 问我们自己的 ContentProvider 要交接信息(最可靠的一条路) */
    private fun queryHandoff(context: Context): Handoff? = try {
        val bundle: Bundle? = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", context.packageName, null
        )
        if (bundle == null) {
            null
        } else {
            Handoff(
                path = bundle.getString("path").orEmpty(),
                variant = bundle.getString("variant").orEmpty(),
                target = bundle.getString("target").orEmpty()
            )
        }
    } catch (t: Throwable) {
        null
    }

    private fun report(context: Context, ok: Boolean, path: String?, detail: String?) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_state",
                if (ok) "ok" else "error",
                Bundle().apply {
                    putString("package", context.packageName)
                    putString("path", path)
                    putString("detail", detail)
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report failed: ${t.message}")
        }
    }

    private fun readPrefs(): XSharedPreferences? = try {
        val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
        @Suppress("DEPRECATION")
        try {
            xsp.makeWorldReadable()
        } catch (t: Throwable) {
        }
        xsp.reload()
        xsp
    } catch (t: Throwable) {
        null
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)
    } catch (t: Throwable) {
        null
    }

    /** 过更新开关:默认关,读不到也按关处理(不打招呼不动目标) */
    private fun readOverUpdate(): Boolean = try {
        readPrefs()?.getBoolean("over_update", false) ?: false
    } catch (t: Throwable) {
        false
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = listOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"
        private const val DEFAULT_VARIANT = ""
        private const val LOAD_DELAY_MS = 250L

        /**
         * 同一个游戏的不同马甲包。
         *
         * 换包名重新分发是很常见的做法(只差一两个字母),但模块的作用域和这里的
         * 目标判断都是写死包名的 —— 名字对不上,框架压根不会把模块送进游戏,
         * 界面上就会一直显示"没生效"。这里把知道的马甲都列上,过更新才对它们都管用。
         */
        private val SAME_GAME_PACKAGES = setOf(
            "com.pi.czrxdfirst",
            "com.pi.ezrxdfirst",
        )
    }
}
