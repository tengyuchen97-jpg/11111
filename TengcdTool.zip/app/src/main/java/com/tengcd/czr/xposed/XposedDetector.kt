package com.tengcd.czr.xposed

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.ShellUtil

/**
 * 判断设备上有没有 Xposed 系框架(原版 / EdXposed / LSPosed / LSPatch 都算)。
 *
 * ⚠️ 1.3 重写原因:
 *   旧版只按几个固定包名 getPackageInfo,一旦用户的 LSPosed 管理器是
 *   「隐藏应用/寄生管理器」形态(包名随机、或者根本没有独立包),就永远查不到,
 *   界面一直显示「未激活」,一键注入还直接报「没装框架」——其实框架好好的。
 *   现在改成多路判定:已知包名 → 全量包名扫关键词 → root 目录/模块目录 → 系统属性
 *   → 最后还有一条最硬的证据:目标进程真的回报过注入信号,那框架一定活着。
 *
 * 注意:检测不到 ≠ 不能注入。InjectorRouter 已经不再拿这个结果当门槛。
 */
object XposedDetector {

    data class Result(
        val installed: Boolean,
        val name: String?,
        val evidence: String
    )

    /** 已知的框架管理器包名(包名 → 展示名) */
    private val KNOWN: List<Pair<String, String>> = listOf(
        "org.lsposed.manager" to "LSPosed",
        "io.github.lsposed.manager" to "LSPosed",
        "org.meowcat.edxposed.manager" to "EdXposed",
        "com.solohsu.android.edxp.manager" to "EdXposed",
        "de.robv.android.xposed.installer" to "Xposed"
    )

    /** 包名里出现这些词就当框架(兜住隐藏/改名/寄生管理器) */
    private val KEYWORDS = listOf("lsposed", "xposed", "edxposed", "edxp", "lspatch")

    private const val CACHE_MS = 30_000L

    @Volatile
    private var cached: Result? = null

    @Volatile
    private var cachedAt = 0L

    fun detect(context: Context): Result {
        val now = System.currentTimeMillis()
        cached?.let {
            if (it.installed && now - cachedAt < CACHE_MS) return it
        }

        val result = detectInternal(context)
        cached = result
        cachedAt = now
        return result
    }

    private fun detectInternal(context: Context): Result {
        // 0) 最硬的证据:目标进程回报过「已被注入」,说明框架肯定在跑
        if (InjectionPrefs.frameworkActive || InjectionPrefs.frameworkHooked) {
            return Result(true, "LSPosed", "目标进程已回报注入信号")
        }

        val pm = context.packageManager

        // 1) 已知包名
        for ((pkg, label) in KNOWN) {
            try {
                val info = pm.getPackageInfo(pkg, 0)
                val name = info.applicationInfo?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() }
                return Result(true, name ?: label, "包名 $pkg")
            } catch (t: Throwable) {
            }
        }

        // 2) 全量扫一遍包名关键词(安卓 11+ 靠 manifest 里的 QUERY_ALL_PACKAGES + queries)
        try {
            @Suppress("DEPRECATION")
            val all = pm.getInstalledPackages(0)
            for (info in all) {
                val pkg = info.packageName ?: continue
                val lower = pkg.lowercase()
                if (KEYWORDS.none { lower.contains(it) }) continue
                if (lower == context.packageName) continue
                val name = info.applicationInfo?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() }
                return Result(true, name ?: pkg, "包名 $pkg")
            }
        } catch (t: Throwable) {
        }

        // 3) root / 模块目录(装了 LSPosed 的机器一般都有这些)
        val probes = listOf(
            "ls /data/adb/lspd 2>/dev/null",
            "ls /data/adb/modules 2>/dev/null | grep -i -E 'lsposed|riru|zygisk|edxposed|xposed'",
            "ls /data/adb/modules_update 2>/dev/null | grep -i -E 'lsposed|riru|zygisk'"
        )
        for (cmd in probes) {
            try {
                if (ShellUtil.exec(cmd).output.isNotBlank()) {
                    return Result(true, "LSPosed", "模块目录探测")
                }
            } catch (t: Throwable) {
            }
        }

        // 4) 系统属性(LSPosed 会在系统里挂版本号)
        for (key in listOf("ro.lsposed.version", "persist.sys.lsposed.version", "ro.xposed.version")) {
            val v = systemProperty(key)
            if (!v.isNullOrBlank()) return Result(true, "LSPosed", "$key=$v")
        }

        return Result(false, null, "未探测到框架")
    }

    private fun systemProperty(key: String): String? = try {
        val cls = Class.forName("android.os.SystemProperties")
        val get = cls.getMethod("get", String::class.java)
        (get.invoke(null, key) as? String)?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    /** 兼容旧调用:只关心有没有 */
    fun isFrameworkInstalled(context: Context): Boolean = detect(context).installed

    fun frameworkName(context: Context): String? = detect(context).name

    /** 界面上的诊断文字:为什么判定成这个结果 */
    fun evidence(context: Context): String = detect(context).evidence

    /** 目标进程回报状态后清缓存,让界面立刻变绿 */
    fun invalidate() {
        cached = null
        cachedAt = 0L
    }
}
