package com.tengcd.czr.network

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import java.util.Locale

/**
 * 机器码工具。
 *
 * ⚠️ 这里只剩「算机器码」这一件事:本地卡密比对、内置卡密、外部卡密文件
 * (card_list.txt / honffx_card.txt)那一整套已经全部删除 —— 那是最容易被
 * 改成「随便输都能进」的口子,现在卡密只认后台校验结果。
 */
object LocalCardGate {

    /**
     * 机器码(后台口子里的 imei)。
     *
     * ⚠️ 只跟「这台设备」绑定,绝对不能拼目标包名:
     * 以前是 md5(ANDROID_ID + "|" + 目标包名),用户在注入页选完目标应用 / 换一个目标应用,
     * 算出来的机器码就变了,后台一看"设备换了"直接回「请在原设备登录」——
     * 表现就是"卡密一开始能用,选完目标就用不了了 / 怎么输都进不去"。
     *
     * 现在只取 ANDROID_ID(取不到就用 Build 指纹兜底),装哪个版本、选哪个目标、换 SO 都不会变。
     * 同一台手机永远是同一串,后台绑一次就够。
     */
    /** 稳定算法:只跟设备绑定,选目标 / 换版本都不变 */
    private fun stableDeviceId(context: Context): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        } catch (t: Throwable) {
            ""
        }
        val good = androidId.isNotBlank() && !androidId.equals("9774d56d682e549c", true)
        val raw = if (good) {
            "tengcd|" + androidId.trim()
        } else {
            // 极少数系统 ANDROID_ID 拿不到 / 是个固定假值时,用 Build 指纹顶上
            "tengcd|" + Build.MODEL + "|" + Build.BRAND + "|" + Build.DEVICE + "|" + Build.ID
        }
        return Md5Util.md5(raw).take(16).uppercase(Locale.US)
    }

    /** 实际发给后台的机器码:验证通过过的那串优先,没有就用稳定算法 */
    fun deviceId(context: Context): String {
        val stored = InjectionPrefs.t3MachineCode
        if (stored.isNotBlank()) return stored
        return stableDeviceId(context)
    }

    /** 老版本算法(固定形式,给已绑定的老卡兜底):md5(ANDROID_ID + "|" + 包名) */
    private fun legacyId(context: Context, pkg: String): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        } catch (t: Throwable) {
            ""
        }
        return Md5Util.md5(androidId + "|" + pkg).take(16).uppercase(Locale.US)
    }

    /** 机器码的备用算法:老版本拼过目标包名,这串只在对账/查老卡时用得上 */
    fun legacyDeviceId(context: Context): String = legacyId(context, InjectionPrefs.targetPackage)

    /**
     * 登录时要挨个试的机器码。
     *
     * 老版本机器码里拼了「目标包名」,后台那边已经把卡绑在了老算法算出来的那串上;
     * 升级后如果只拿新算法去登录,后台统一判「请在原设备登录」,卡密看着就是坏的。
     * 所以这里全列出来,谁通就记谁,记下来之后所有请求都用同一串,不会再漂。
     */
    fun deviceCandidates(context: Context): List<String> {
        val out = ArrayList<String>()
        val stored = InjectionPrefs.t3MachineCode
        if (stored.isNotBlank()) out.add(stored)
        // 老卡最可能绑的是「还没选目标应用」时算的那串
        out.add(legacyId(context, ""))
        val cur = InjectionPrefs.targetPackage
        if (cur.isNotBlank()) out.add(legacyId(context, cur))
        out.add(stableDeviceId(context))
        return out.distinct()
    }

}
