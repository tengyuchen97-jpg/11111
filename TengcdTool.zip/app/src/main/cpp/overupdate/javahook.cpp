//
// javahook.cpp —— 免 root(进程注入)下的 Java 层证书 hook
//
// 背景:
//   免 root 这条路以前只往游戏进程里塞原生层补丁,而超自然过更新模块
//   (JustTrustMePP)干的完全是 Java 层的事 —— OkHttp 的 CertificatePinner、
//   HostnameVerifier、系统 Conscrypt 的信任链校验。原生层改了 SSL 符号
//   也拦不住这些 Java 判断,所以「照那个模块防更新」在免 root 下一直是空的。
//
// 做法(不需要 Xposed):
//   每个 java 方法在 ART 里都是一条 ArtMethod。把它标成 native、
//   把 data_ 换成我们的 C 函数、入口换成 ART 的通用 JNI 跳板,
//   调用方照常按 Java 方法调,ART 会把参数原样交给我们的函数。
//   这是「替换」而不是「拦截」:不碰原方法体,不需要恢复,失败就静默跳过。
//
// 上一版为什么把游戏卡在加载画面(这一版逐条治掉):
//   a) hook 名单里有 com.android.org.conscrypt.TrustManagerImpl.verifyChain /
//      checkTrustedRecursive —— 这俩返回的是 List<X509Certificate> / byte[],
//      却被换成了「返回第一个参数」,调用方拿到类型不对的对象,
//      HTTPS 一发起就炸在主线程上,表现就是卡加载。
//      -> 这版只替换返回 void / boolean 的方法,返回其它类型的一律不碰。
//   b) hook 是按「方法名」匹配的,同名重载一锅端(TrustManagerImpl 里
//      checkServerTrusted 有三个重载,返回类型不一样)。
//      -> 这版名字 + 返回类型 + 参数类型逐项比对,全中才动手。
//   c) 名单照抄超自然模块即可,不该自己加戏加内部方法。
//

#include "javahook.h"

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define TAG "overupdate"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

namespace {

    // ---------------------------------------------------------------- ArtMethod

    const uint32_t kAccNative = 0x0100;
    const uint32_t kAccAbstract = 0x0400;
    const uint32_t kAccFastNative = 0x00080000;
    const uint32_t kAccCriticalNative = 0x00200000;

    /**
     * ArtMethod 的头(Android 8 起到 15 布局一致):
     *   declaring_class_(4) access_flags_(4) dex_code_item_offset_(4) dex_method_index_(4)
     *   method_index_(2) hotness_count_(2)
     * 之后按指针宽度对齐,放 PtrSizedFields{ data_, entry_point_from_quick_compiled_code_ }。
     * 64 位:data_ 在 24、entry 在 32;32 位:20 / 24。
     */
    inline uint32_t *flags_slot(void *m) { return (uint32_t *) ((char *) m + 4); }

    inline void **data_slot(void *m) {
        return (void **) ((char *) m + (sizeof(void *) == 8 ? 24 : 20));
    }

    inline void **entry_slot(void *m) {
        return (void **) ((char *) m + (sizeof(void *) == 8 ? 32 : 24));
    }

    void *g_genericEntry = nullptr;
    bool g_layoutTried = false;

    /**
     * ART 的通用 JNI 跳板。
     * 取两个已知的普通 native 方法对比:两个不同的 native 方法,入口指针必须完全相同
     * (都指向同一个 generic JNI trampoline),data_ 必须非空。
     * 只有这两个条件同时成立,才能说明我们算出来的偏移是对的 —— 这是整套东西的地基,
     * 偏移算错的话写下去就是把目标进程写坏,所以宁可不 hook 也绝不硬来。
     */
    void *find_generic_jni_entry(JNIEnv *env) {
        if (g_layoutTried) return g_genericEntry;
        g_layoutTried = true;

        jclass obj = env->FindClass("java/lang/Object");
        if (obj == nullptr) {
            env->ExceptionClear();
            return nullptr;
        }
        jmethodID a = env->GetMethodID(obj, "hashCode", "()I");
        jmethodID b = env->GetMethodID(obj, "getClass", "()Ljava/lang/Class;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (a == nullptr || b == nullptr) return nullptr;

        void *da = *data_slot((void *) a);
        void *db = *data_slot((void *) b);
        void *ea = *entry_slot((void *) a);
        void *eb = *entry_slot((void *) b);

        if (ea == nullptr || eb == nullptr || ea != eb || da == nullptr || db == nullptr) {
            LOGI("art layout check failed (e=%p/%p d=%p/%p)", ea, eb, da, db);
            return nullptr;
        }
        g_genericEntry = ea;
        return g_genericEntry;
    }

    /**
     * 把一条 ArtMethod 换成我们的 C 函数。
     * 任何一项前置检查不过就直接放弃 —— 宁可 hook 不上,也不能写坏进程。
     */
    bool patch_art_method(void *art, void *replacement, void *genericEntry) {
        if (art == nullptr || replacement == nullptr || genericEntry == nullptr) return false;
        if ((uintptr_t) art < 4096) return false;

        uint32_t *slot = flags_slot(art);
        uint32_t flags = *slot;
        // 布局校验:方法标志不可能为 0 或全 1
        if (flags == 0u || flags == 0xFFFFFFFFu) return false;
        // abstract 方法没有实现体,标成 native 没有意义还可能出事
        if ((flags & kAccAbstract) != 0) return false;
        // critical native 走另一套调用约定,不能乱标
        if ((flags & kAccCriticalNative) == kAccCriticalNative) return false;

        flags = (flags & ~(kAccFastNative | kAccCriticalNative)) | kAccNative;
        *slot = flags;
        *data_slot(art) = replacement;
        *entry_slot(art) = genericEntry;
        return true;
    }

    // ---------------------------------------------------------------- 替换函数
    // 签名按 JNI 约定(env, this/class, ...);参数个数多了不会被读到,一个函数对付多个重载。
    // 注意:只能给「返回类型跟这里对得上」的方法用,所以下面每个函数都带返回值注释。

    /** 给返回 void 的方法用:什么都不做,校验被跳过 */
    extern "C" void jh_void_noop(JNIEnv *, jobject, ...) {
    }

    /** 给返回 boolean 的方法用:永远通过 */
    extern "C" jboolean jh_true(JNIEnv *, jobject, ...) {
        return JNI_TRUE;
    }

    /**
     * WebViewClient.onReceivedSslError(WebView, SslErrorHandler, SslError) 的替换。
     *
     * 超自然模块里这一条是「直接调 handler.proceed()」,不是空跑 ——
     * 空跑的话 WebView 会一直停在错误页,等于把网页卡死。所以这里要真的调进去。
     */
    extern "C" void jh_ssl_error_proceed(JNIEnv *env, jobject, jobject view,
                                        jobject handler, jobject error) {
        (void) view;
        (void) error;
        if (env == nullptr || handler == nullptr) return;
        jclass cls = env->GetObjectClass(handler);
        if (cls == nullptr) {
            env->ExceptionClear();
            return;
        }
        jmethodID proceed = env->GetMethodID(cls, "proceed", "()V");
        if (proceed != nullptr) {
            env->CallVoidMethod(handler, proceed);
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cls);
    }

    // ---------------------------------------------------------------- JNI 小工具

    JavaVM *g_vm = nullptr;
    bool g_attached = false;
    bool g_vmTried = false;

    JNIEnv *env_or_null() {
        if (!g_vmTried) {
            g_vmTried = true;
            void *sym = dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");
            if (sym == nullptr) {
                void *h = dlopen("libart.so", RTLD_NOW);
                if (h != nullptr) sym = dlsym(h, "JNI_GetCreatedJavaVMs");
            }
            if (sym != nullptr) {
                auto fn = (jint(*)(JavaVM **, jsize, jsize *)) sym;
                JavaVM *vm = nullptr;
                jsize n = 0;
                if (fn(&vm, 1, &n) == JNI_OK && vm != nullptr && n > 0) g_vm = vm;
            }
        }
        if (g_vm == nullptr) return nullptr;

        JNIEnv *env = nullptr;
        jint r = g_vm->GetEnv((void **) &env, JNI_VERSION_1_6);
        if (r == JNI_EDETACHED) {
            if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
            g_attached = true;
        } else if (r != JNI_OK) {
            return nullptr;
        }
        return env;
    }

    /** 目标应用的 ClassLoader(okhttp 这些类挂在游戏的 loader 上,不是系统的) */
    jobject app_class_loader(JNIEnv *env) {
        jclass at = env->FindClass("android/app/ActivityThread");
        if (at == nullptr) {
            env->ExceptionClear();
            return nullptr;
        }

        jobject app = nullptr;
        jmethodID cur = env->GetStaticMethodID(
                at, "currentActivityThread", "()Landroid/app/ActivityThread;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (cur != nullptr) {
            jobject thread = env->CallStaticObjectMethod(at, cur);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
            } else if (thread != nullptr) {
                jmethodID ga = env->GetMethodID(at, "getApplication", "()Landroid/app/Application;");
                if (env->ExceptionCheck()) env->ExceptionClear();
                if (ga != nullptr) {
                    app = env->CallObjectMethod(thread, ga);
                    if (env->ExceptionCheck()) {
                        env->ExceptionClear();
                        app = nullptr;
                    }
                }
                env->DeleteLocalRef(thread);
            }
        }
        if (app == nullptr) {
            // 兜底:老系统上 getApplication 偶尔还没赋值,直接读静态字段
            jfieldID f = env->GetStaticFieldID(
                    at, "mInitialApplication", "Landroid/app/Application;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (f != nullptr) {
                app = env->GetStaticObjectField(at, f);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    app = nullptr;
                }
            }
        }
        env->DeleteLocalRef(at);
        if (app == nullptr) return nullptr;

        jclass ctx = env->FindClass("android/content/ContextWrapper");
        if (ctx == nullptr) {
            env->ExceptionClear();
            env->DeleteLocalRef(app);
            return nullptr;
        }
        jmethodID gcl = env->GetMethodID(ctx, "getClassLoader", "()Ljava/lang/ClassLoader;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(ctx);
        if (gcl == nullptr) {
            env->DeleteLocalRef(app);
            return nullptr;
        }
        jobject loader = env->CallObjectMethod(app, gcl);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            loader = nullptr;
        }
        env->DeleteLocalRef(app);
        return loader;
    }

    jclass load_class(JNIEnv *env, jobject loader, const char *name) {
        if (loader == nullptr) return nullptr;
        jclass cl = env->FindClass("java/lang/ClassLoader");
        if (cl == nullptr) {
            env->ExceptionClear();
            return nullptr;
        }
        jmethodID load = env->GetMethodID(
                cl, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(cl);
        if (load == nullptr) return nullptr;

        jstring s = env->NewStringUTF(name);
        if (s == nullptr) return nullptr;
        auto klass = (jclass) env->CallObjectMethod(loader, load, s);
        env->DeleteLocalRef(s);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return nullptr;
        }
        return klass;
    }

    // ---------------------------------------------------------------- 记录状态

    pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
    int g_hits = 0;
    char g_state[480] = "waiting";
    char g_hooked[24][72];
    int g_hookedCount = 0;
    char g_skipped[12][96];
    int g_skippedCount = 0;

    void remember(const char *label) {
        pthread_mutex_lock(&g_lock);
        g_hits++;
        if (g_hookedCount < (int) (sizeof(g_hooked) / sizeof(g_hooked[0]))) {
            snprintf(g_hooked[g_hookedCount], sizeof(g_hooked[0]), "%s", label);
            g_hookedCount++;
        }
        pthread_mutex_unlock(&g_lock);
    }

    void remember_skipped(const char *label) {
        pthread_mutex_lock(&g_lock);
        if (g_skippedCount < (int) (sizeof(g_skipped) / sizeof(g_skipped[0]))) {
            snprintf(g_skipped[g_skippedCount], sizeof(g_skipped[0]), "%s", label);
            g_skippedCount++;
        }
        pthread_mutex_unlock(&g_lock);
    }

    bool already(const char *label) {
        bool found = false;
        pthread_mutex_lock(&g_lock);
        for (int i = 0; i < g_hookedCount; i++) {
            if (strcmp(g_hooked[i], label) == 0) {
                found = true;
                break;
            }
        }
        pthread_mutex_unlock(&g_lock);
        return found;
    }

    /** Class.getName() 拿到类型的规范名(数组是 [Ljava...; 这种形式) */
    void class_name_of(JNIEnv *env, jobject type, char *out, size_t cap) {
        out[0] = '\0';
        jclass clsCls = env->FindClass("java/lang/Class");
        if (clsCls == nullptr) {
            env->ExceptionClear();
            return;
        }
        jmethodID getName = env->GetMethodID(clsCls, "getName", "()Ljava/lang/String;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(clsCls);
        if (getName == nullptr || type == nullptr) return;

        auto s = (jstring) env->CallObjectMethod(type, getName);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return;
        }
        if (s == nullptr) return;
        const char *c = env->GetStringUTFChars(s, nullptr);
        if (c != nullptr) {
            snprintf(out, cap, "%s", c);
            env->ReleaseStringUTFChars(s, c);
        }
        env->DeleteLocalRef(s);
    }

    struct HookTarget {
        const char *className;
        const char *methodName;
        const char *retType;            // 必须精确对上:"void" / "boolean"
        const char *params[4];          // 参数类型规范名,按顺序
        int paramCount;                 // -1 = 不校验参数个数(只用于兜底匹配)
        void *replacement;
        bool appLoader;                 // true = 游戏自己的 ClassLoader;false = 系统(boot)
        const char *label;
    };

    /**
     * 名单照抄超自然过更新模块(JustTrustMePP)的 hook 清单 ——
     * okhttp3 / okhttp2 的 CertificatePinner、OkHostnameVerifier,
     * 加上系统 Conscrypt 的 TrustManagerImpl.三个 checkServerTrusted 重载。
     *
     * 注意每条都必须「返回 void 或 boolean」。返回 List / 数组的内部方法
     * (verifyChain、checkTrustedRecursive 之类)一律不进这张表,原因见文件头。
     */
    const HookTarget kTargets[] = {
            // ---- okhttp 3/4:证书固定。check 是 void,跳过就等于不做 pinning 比对
            {"okhttp3.CertificatePinner", "check",
                    "void", {"java.lang.String", "java.util.List"}, 2,
                    (void *) jh_void_noop, true, "okhttp3.CertificatePinner.check"},
            // okhttp 4 里真正的活在这条(internal),两个都打上才稳
            {"okhttp3.CertificatePinner", "check$okhttp",
                    "void", {"java.lang.String", "kotlin.jvm.functions.Function0"}, 2,
                    (void *) jh_void_noop, true, "okhttp3.CertificatePinner.check$okhttp"},

            // ---- okhttp 2:老版本仍在用 com.squareup.okhttp 这个包名
            {"com.squareup.okhttp.CertificatePinner", "check",
                    "void", {"java.lang.String", "java.util.List"}, 2,
                    (void *) jh_void_noop, true, "com.squareup.okhttp.CertificatePinner.check"},

            // ---- 主机名校验:返回 boolean,永远 true
            {"okhttp3.internal.tls.OkHostnameVerifier", "verify",
                    "boolean", {"java.lang.String", "javax.net.ssl.SSLSession"}, 2,
                    (void *) jh_true, true, "OkHostnameVerifier.verify(SSLSession)"},
            {"okhttp3.internal.tls.OkHostnameVerifier", "verify",
                    "boolean", {"java.lang.String", "java.security.cert.X509Certificate"}, 2,
                    (void *) jh_true, true, "OkHostnameVerifier.verify(X509Certificate)"},

            // ---- okhttp 2 的主机名校验(包名是 com.squareup.okhttp.internal.tls)
            {"com.squareup.okhttp.internal.tls.OkHostnameVerifier", "verify",
                    "boolean", {"java.lang.String", "javax.net.ssl.SSLSession"}, 2,
                    (void *) jh_true, true, "okhttp2 OkHostnameVerifier(SSLSession)"},
            {"com.squareup.okhttp.internal.tls.OkHostnameVerifier", "verify",
                    "boolean", {"java.lang.String", "java.security.cert.X509Certificate"}, 2,
                    (void *) jh_true, true, "okhttp2 OkHostnameVerifier(X509Certificate)"},

            // ---- WebView:证书错误时直接 proceed(模块里就是这么干的)
            {"android.webkit.WebViewClient", "onReceivedSslError",
                    "void", {"android.webkit.WebView", "android.webkit.SslErrorHandler",
                             "android.webkit.SslError"}, 3,
                    (void *) jh_ssl_error_proceed, true, "WebViewClient.onReceivedSslError"},

            // ---- 系统 Conscrypt:信任链校验。三个重载都是 void,空跑 = 直接放行
            {"com.android.org.conscrypt.TrustManagerImpl", "checkServerTrusted",
                    "void", {"[Ljava.security.cert.X509Certificate;", "java.lang.String"}, 2,
                    (void *) jh_void_noop, false, "TrustManagerImpl.checkServerTrusted(2)"},
            {"com.android.org.conscrypt.TrustManagerImpl", "checkServerTrusted",
                    "void", {"[Ljava.security.cert.X509Certificate;", "java.lang.String",
                             "byte[]"}, 3,
                    (void *) jh_void_noop, false, "TrustManagerImpl.checkServerTrusted(3)"},
            {"com.android.org.conscrypt.TrustManagerImpl", "checkServerTrusted",
                    "void", {"[Ljava.security.cert.X509Certificate;", "java.lang.String",
                             "javax.net.ssl.SSLSession"}, 3,
                    (void *) jh_void_noop, false, "TrustManagerImpl.checkServerTrusted(session)"},

            // ==== 下面几条对着超自然模块(JustTrustMePP)的名单补齐 ====
            // 它原表里有 21 条,前面 12 条是主力(正在用的 okhttp / 系统 TLS / WebView),
            // 这里补的是剩下那批「给自定义 SSL 与老网络库兜底」的校验点。

            // 老 Apache HTTP 的 socket 安全性判断:返回 boolean,永远认为安全
            {"org.apache.http.conn.ssl.SSLSocketFactory", "isSecure",
                    "boolean", {"java.net.Socket"}, 1,
                    (void *) jh_true, false, "apache SSLSocketFactory.isSecure(boot)"},
            {"org.apache.http.conn.ssl.SSLSocketFactory", "isSecure",
                    "boolean", {"java.net.Socket"}, 1,
                    (void *) jh_true, true, "apache SSLSocketFactory.isSecure(app)"},

            // httpclientandroidlib(不少老 SDK 内嵌的那套):主机名校验,void,空跑等于放行
            {"ch.boye.httpclientandroidlib.conn.ssl.AbstractVerifier", "verify",
                    "void", {"java.lang.String", "[Ljava.lang.String;",
                             "[Ljava.lang.String;", "boolean"}, 4,
                    (void *) jh_void_noop, true, "httpclientandroidlib AbstractVerifier.verify"},

            // WebView 加载错误同样吞掉(模块里这条是空实现)
            {"android.webkit.WebViewClient", "onReceivedError",
                    "void", {"android.webkit.WebView", "int", "java.lang.String",
                             "java.lang.String"}, 4,
                    (void *) jh_void_noop, true, "WebViewClient.onReceivedError"},
    };

    /**
     * 在一个类里找「名字 + 返回类型 + 参数类型全对上」的方法,对上才替换。
     * 少一项就跳过 —— 这就是上一版卡加载的根本原因,不能再省这一步。
     */
    int hook_exact(JNIEnv *env, jclass klass, const HookTarget &t, void *genericEntry) {
        if (klass == nullptr || already(t.label)) return 0;

        jclass classCls = env->FindClass("java/lang/Class");
        jclass methodCls = env->FindClass("java/lang/reflect/Method");
        if (classCls == nullptr || methodCls == nullptr) {
            env->ExceptionClear();
            return 0;
        }
        jmethodID getDeclared = env->GetMethodID(
                classCls, "getDeclaredMethods", "()[Ljava/lang/reflect/Method;");
        jmethodID getName = env->GetMethodID(methodCls, "getName", "()Ljava/lang/String;");
        jmethodID getParams = env->GetMethodID(
                methodCls, "getParameterTypes", "()[Ljava/lang/Class;");
        jmethodID getRet = env->GetMethodID(methodCls, "getReturnType", "()Ljava/lang/Class;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (getDeclared == nullptr || getName == nullptr ||
            getParams == nullptr || getRet == nullptr) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            env->DeleteLocalRef(classCls);
            env->DeleteLocalRef(methodCls);
            return 0;
        }

        auto methods = (jobjectArray) env->CallObjectMethod(klass, getDeclared);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            env->DeleteLocalRef(classCls);
            env->DeleteLocalRef(methodCls);
            return 0;
        }
        if (methods == nullptr) {
            env->DeleteLocalRef(classCls);
            env->DeleteLocalRef(methodCls);
            return 0;
        }

        int patched = 0;
        jsize n = env->GetArrayLength(methods);
        for (jsize i = 0; i < n; i++) {
            jobject m = env->GetObjectArrayElement(methods, i);
            if (m == nullptr) continue;

            bool match = false;
            do {
                // 1 方法名
                auto nameStr = (jstring) env->CallObjectMethod(m, getName);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    break;
                }
                if (nameStr == nullptr) break;
                const char *nm = env->GetStringUTFChars(nameStr, nullptr);
                bool nameOk = nm != nullptr && strcmp(nm, t.methodName) == 0;
                if (nm != nullptr) env->ReleaseStringUTFChars(nameStr, nm);
                env->DeleteLocalRef(nameStr);
                if (!nameOk) break;

                // 2 返回类型(这条最关键:void / boolean 之外一概不碰)
                jobject ret = env->CallObjectMethod(m, getRet);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    break;
                }
                char retName[160];
                class_name_of(env, ret, retName, sizeof(retName));
                if (ret != nullptr) env->DeleteLocalRef(ret);
                if (strcmp(retName, t.retType) != 0) break;

                // 3 参数个数 + 每个参数的类型
                auto params = (jobjectArray) env->CallObjectMethod(m, getParams);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    break;
                }
                if (params == nullptr) break;
                jsize pc = env->GetArrayLength(params);
                bool paramsOk = true;
                if (t.paramCount >= 0 && pc != t.paramCount) {
                    paramsOk = false;
                } else {
                    for (jsize k = 0; k < pc && k < 4; k++) {
                        jobject p = env->GetObjectArrayElement(params, k);
                        char pn[160];
                        class_name_of(env, p, pn, sizeof(pn));
                        if (p != nullptr) env->DeleteLocalRef(p);
                        if (strcmp(pn, t.params[k]) != 0) {
                            paramsOk = false;
                            break;
                        }
                    }
                }
                env->DeleteLocalRef(params);
                if (!paramsOk) break;

                match = true;
            } while (false);

            if (match) {
                void *art = (void *) env->FromReflectedMethod(m);
                if (patch_art_method(art, t.replacement, genericEntry)) patched++;
            }
            env->DeleteLocalRef(m);
        }
        env->DeleteLocalRef(methods);
        env->DeleteLocalRef(classCls);
        env->DeleteLocalRef(methodCls);

        if (patched > 0) remember(t.label);
        return patched;
    }

    /** 类没加载 / 方法对不上时记一笔,状态里能看到,方便下次排查 */
    void note_miss(const char *label, const char *why) {
        char buf[96];
        snprintf(buf, sizeof(buf), "%s(%s)", label, why);
        remember_skipped(buf);
    }

    // ---------------------------------------------------------------- 更新弹窗拦截
    //
    // 思路:把 android.app.Dialog.show() 换成我们的函数。
    //   - 弹窗文字命中"强制更新/版本过低/发现新版本"这类 → 不调原方法 = 不弹出来
    //   - 其它任何情况 → **恢复原方法并真的调进去**,弹窗照常显示
    //
    // 为什么必须"恢复后再调",不能直接空跑:
    //   Dialog.show() 是所有 Java 弹窗的必经之路。空跑就等于把游戏里所有弹窗
    //   全部吞掉(公告、奖励、设置面板全没了),那是另一种坏体验。
    //   所以这里走备份-恢复-调用-再替换,保证没命中的弹窗一个都不受影响。
    //
    // 读不到文字(还没 setContentView、或者 view 树是自定义控件)、任何一步出异常,
    // 一律按"不拦"处理 —— 宁可漏拦一个更新框,也绝不误伤正常界面。

    struct SavedArt {
        void *art = nullptr;
        uint32_t flags = 0;
        void *data = nullptr;
        void *entry = nullptr;
        bool valid = false;
    };

    static SavedArt g_dialogShow;
    static pthread_mutex_t g_dlgLock = PTHREAD_MUTEX_INITIALIZER;
    static int g_blocked = 0;
    static bool g_dlgHooked = false;

    static const char *kBlockWords[] = {
            "强制更新", "版本过低", "必须更新", "立即更新", "马上升级",
            "发现新版本", "检测到新版本", "检查到新版本", "请更新", "请先更新",
            "版本过旧", "需要更新", "更新后即可", "更新后才能",
            "force update", "update required", "new version found",
            "please update", "must update",
    };

    bool text_hits_update(const char *text) {
        if (text == nullptr || text[0] == '\0') return false;
        char low[2048];
        size_t j = 0;
        for (size_t i = 0; text[i] != '\0' && j + 1 < sizeof(low); i++) {
            char c = text[i];
            if (c >= 'A' && c <= 'Z') c = (char) (c - 'A' + 'a');
            low[j++] = c;
        }
        low[j] = '\0';
        for (const char *w : kBlockWords) {
            if (strstr(low, w) != nullptr) return true;
        }
        return false;
    }

    /** 递归收 view 树里 TextView 的文字,最多 60 个节点 / 6 层,防止卡死 */
    void collect_text(JNIEnv *env, jobject view, char *out, size_t cap, int depth, int *budget) {
        if (view == nullptr || out == nullptr || budget == nullptr) return;
        if (depth > 6 || *budget <= 0) return;
        (*budget)--;

        jclass viewCls = env->FindClass("android/view/View");
        jclass groupCls = env->FindClass("android/view/ViewGroup");
        jclass classCls = env->FindClass("java/lang/Class");
        if (viewCls == nullptr || groupCls == nullptr || classCls == nullptr) {
            env->ExceptionClear();
            return;
        }
        jmethodID isGroup = env->GetMethodID(classCls, "isInstance",
                                             "(Ljava/lang/Object;)Z");
        if (env->ExceptionCheck()) env->ExceptionClear();

        jobject vcls = nullptr;
        jmethodID getClassId = env->GetMethodID(
                viewCls, "getClass", "()Ljava/lang/Class;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (getClassId != nullptr) {
            vcls = env->CallObjectMethod(view, getClassId);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                vcls = nullptr;
            }
        }
        char clsName[200];
        clsName[0] = '\0';
        if (vcls != nullptr) {
            jmethodID getName = env->GetMethodID(classCls, "getName",
                                                 "()Ljava/lang/String;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (getName != nullptr) {
                auto s = (jstring) env->CallObjectMethod(vcls, getName);
                if (env->ExceptionCheck()) env->ExceptionClear();
                if (s != nullptr) {
                    const char *c = env->GetStringUTFChars(s, nullptr);
                    if (c != nullptr) {
                        snprintf(clsName, sizeof(clsName), "%s", c);
                        env->ReleaseStringUTFChars(s, c);
                    }
                    env->DeleteLocalRef(s);
                }
            }
            env->DeleteLocalRef(vcls);
        }
        env->DeleteLocalRef(classCls);
        env->DeleteLocalRef(viewCls);

        // TextView 及其子类(Button / EditText 都算)取文字
        if (strstr(clsName, "TextView") != nullptr) {
            jclass tc = env->GetObjectClass(view);
            if (tc != nullptr) {
                jmethodID getText = env->GetMethodID(
                        tc, "getText", "()Ljava/lang/CharSequence;");
                if (env->ExceptionCheck()) env->ExceptionClear();
                if (getText != nullptr) {
                    auto cs = (jstring) env->CallObjectMethod(view, getText);
                    if (env->ExceptionCheck()) env->ExceptionClear();
                    if (cs != nullptr) {
                        const char *c = env->GetStringUTFChars(cs, nullptr);
                        if (c != nullptr) {
                            size_t used = strlen(out);
                            if (used + strlen(c) + 2 < cap) {
                                snprintf(out + used, cap - used, "%s ", c);
                            }
                            env->ReleaseStringUTFChars(cs, c);
                        }
                        env->DeleteLocalRef(cs);
                    }
                }
                env->DeleteLocalRef(tc);
            }
        }

        if (isGroup == nullptr || groupCls == nullptr) return;
        jboolean isG = env->CallBooleanMethod(groupCls, isGroup, view);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            env->DeleteLocalRef(groupCls);
            return;
        }
        if (isG != JNI_TRUE) {
            env->DeleteLocalRef(groupCls);
            return;
        }
        jmethodID count = env->GetMethodID(groupCls, "getChildCount", "()I");
        jmethodID childAt = env->GetMethodID(groupCls, "getChildAt",
                                             "(I)Landroid/view/View;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (count != nullptr && childAt != nullptr) {
            jint n = env->CallIntMethod(view, count);
            if (env->ExceptionCheck()) env->ExceptionClear();
            for (jint i = 0; i < n && *budget > 0; i++) {
                jobject child = env->CallObjectMethod(view, childAt, i);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    break;
                }
                if (child == nullptr) continue;
                collect_text(env, child, out, cap, depth + 1, budget);
                env->DeleteLocalRef(child);
            }
        }
        env->DeleteLocalRef(groupCls);
    }

    /** 这个弹窗是不是"要你更新"的那种 */
    bool dialog_should_block(JNIEnv *env, jobject dialog) {
        if (dialog == nullptr) return false;

        jclass dcls = env->GetObjectClass(dialog);
        if (dcls == nullptr) {
            env->ExceptionClear();
            return false;
        }
        jmethodID getWindow = env->GetMethodID(
                dcls, "getWindow", "()Landroid/view/Window;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(dcls);
        if (getWindow == nullptr) return false;

        jobject window = env->CallObjectMethod(dialog, getWindow);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return false;
        }
        if (window == nullptr) return false;

        jclass wcls = env->GetObjectClass(window);
        jmethodID getDecor = env->GetMethodID(
                wcls, "getDecorView", "()Landroid/view/View;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(wcls);
        if (getDecor == nullptr) {
            env->DeleteLocalRef(window);
            return false;
        }
        jobject decor = env->CallObjectMethod(window, getDecor);
        env->DeleteLocalRef(window);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return false;
        }
        if (decor == nullptr) return false;   // 还没 content,不拦

        char text[2048];
        text[0] = '\0';
        int budget = 60;
        collect_text(env, decor, text, sizeof(text), 0, &budget);
        env->DeleteLocalRef(decor);

        if (env->ExceptionCheck()) env->ExceptionClear();
        return text_hits_update(text);
    }

    void art_restore(const SavedArt &s) {
        if (!s.valid || s.art == nullptr) return;
        *flags_slot(s.art) = s.flags;
        *data_slot(s.art) = s.data;
        *entry_slot(s.art) = s.entry;
    }

    void art_as_native(const SavedArt &s, void *repl, void *generic) {
        if (!s.valid || s.art == nullptr) return;
        uint32_t f = (s.flags & ~(kAccFastNative | kAccCriticalNative)) | kAccNative;
        *flags_slot(s.art) = f;
        *data_slot(s.art) = repl;
        *entry_slot(s.art) = generic;
    }

    extern "C" void jh_dialog_show(JNIEnv *env, jobject thiz) {
        if (env == nullptr) return;

        int blocked = 0;
        if (g_dlgHooked) {
            if (dialog_should_block(env, thiz)) blocked = 1;
        }
        if (env->ExceptionCheck()) env->ExceptionClear();

        if (blocked) {
            pthread_mutex_lock(&g_lock);
            g_blocked++;
            pthread_mutex_unlock(&g_lock);
            return;   // 不调原方法 = 这个弹窗不显示
        }

        // 放行:先把原方法还原,调完再重新挂上
        pthread_mutex_lock(&g_dlgLock);
        art_restore(g_dialogShow);
        env->CallVoidMethod(thiz, (jmethodID) g_dialogShow.art);
        if (env->ExceptionCheck()) env->ExceptionClear();
        art_as_native(g_dialogShow, (void *) jh_dialog_show, g_genericEntry);
        pthread_mutex_unlock(&g_dlgLock);
    }

    // ---------------------------------------------------------------- 请求层:掐掉"检查更新"
    //
    // 和上面的弹窗拦截配成一套。弹窗拦截是最后一步(已经弹了才拦),而很多游戏的强更
    // 根本不用 Dialog:自己画在 Unity / 自定义 View 里,或者开一个独立的更新页 Activity。
    // 但它们在弹之前都必然干过同一件事 —— 发一条"查版本"的请求。
    // 这条请求失败,游戏的标准分支就是"跳过更新直接进游戏"(这也是断网能进的原因)。
    //
    // 三刀:
    //   ① DNS 黑洞:更新域名解析直接失败,最像真断网,任何网络栈都吃这套;
    //   ② 版本号伪装:游戏拿自己 versionCode 跟服务器比,这里读成很大的数 = 永远最新版;
    //   ③ 更新页跳转:真开起了更新页 Activity,finish 掉并把游戏主界面拉回来。
    //
    // 分寸:白名单(登录/支付/统计)优先放行;读不到、对不上、抛异常一律按"没命中"放行。

    static SavedArt g_dnsGetAll;
    static SavedArt g_pkgInfo;
    static SavedArt g_actCreate;
    static bool g_dnsHooked = false;
    static bool g_pkgHooked = false;
    static bool g_actHooked = false;

    static pthread_mutex_t g_netLock;
    static pthread_once_t g_netOnce = PTHREAD_ONCE_INIT;

    static void init_net_lock() {
        // 递归锁:原方法内部万一又调到被我们 hook 的同一个方法,不能把自己锁死
        pthread_mutexattr_t a;
        pthread_mutexattr_init(&a);
        pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE);
        pthread_mutex_init(&g_netLock, &a);
        pthread_mutexattr_destroy(&a);
    }

    static int g_dnsBlocked = 0;
    static int g_netRedirect = 0;
    static int g_verSpoof = 0;
    static int g_redirectedOnce = 0;

    static const char *kUpdateHostKeys[] = {
            "update", "upgrade", "newversion", "new-version", "checkver",
            "versioncheck", "version-check", "forceupdate", "appupdate",
    };
    static const char *kSafeHostKeys[] = {
            "login", "auth", "account", "passport", "pay", "order",
            "report", "stat", "track", "analytics", "log",
    };
    static const char *kUpdateActivityKeys[] = {
            "update", "upgrade", "newversion", "download", "forceupdate",
    };

    static bool contains_any_ci(const char *hay, const char **keys, int n) {
        if (hay == nullptr || hay[0] == '\0') return false;
        char low[320];
        size_t j = 0;
        for (size_t i = 0; hay[i] != '\0' && j + 1 < sizeof(low); i++) {
            char c = hay[i];
            if (c >= 'A' && c <= 'Z') c = (char) (c - 'A' + 'a');
            low[j++] = c;
        }
        low[j] = '\0';
        for (int i = 0; i < n; i++) {
            if (keys[i] != nullptr && strstr(low, keys[i]) != nullptr) return true;
        }
        return false;
    }

    static bool host_should_block(const char *host) {
        int safeN = (int) (sizeof(kSafeHostKeys) / sizeof(kSafeHostKeys[0]));
        if (contains_any_ci(host, kSafeHostKeys, safeN)) return false;   // 白名单优先
        int upN = (int) (sizeof(kUpdateHostKeys) / sizeof(kUpdateHostKeys[0]));
        return contains_any_ci(host, kUpdateHostKeys, upN);
    }

    static void save_method(SavedArt &s, void *art) {
        s.art = art;
        s.flags = *flags_slot(art);
        s.data = *data_slot(art);
        s.entry = *entry_slot(art);
        s.valid = true;
    }

    /** 当前进程的包名(版本伪装只认这个包) */
    static char g_selfPkg[160] = "";

    static const char *self_package(JNIEnv *env) {
        if (g_selfPkg[0] != '\0') return g_selfPkg;

        jclass at = env->FindClass("android/app/ActivityThread");
        if (at != nullptr) {
            jmethodID cur = env->GetStaticMethodID(at, "currentPackageName",
                                                   "()Ljava/lang/String;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (cur != nullptr) {
                auto s = (jstring) env->CallStaticObjectMethod(at, cur);
                if (env->ExceptionCheck()) env->ExceptionClear();
                if (s != nullptr) {
                    const char *c = env->GetStringUTFChars(s, nullptr);
                    if (c != nullptr) {
                        snprintf(g_selfPkg, sizeof(g_selfPkg), "%s", c);
                        env->ReleaseStringUTFChars(s, c);
                    }
                    env->DeleteLocalRef(s);
                }
            }
            env->DeleteLocalRef(at);
        }
        if (g_selfPkg[0] == '\0') {
            FILE *f = fopen("/proc/self/cmdline", "r");
            if (f != nullptr) {
                char buf[256];
                size_t n = fread(buf, 1, sizeof(buf) - 1, f);
                fclose(f);
                if (n > 0) {
                    buf[n] = '\0';
                    for (size_t i = 0; i < n; i++) {
                        if (buf[i] == ':') {   // 子进程 com.xxx:push 这种,取主包名
                            buf[i] = '\0';
                            break;
                        }
                    }
                    snprintf(g_selfPkg, sizeof(g_selfPkg), "%s", buf);
                }
            }
        }
        return g_selfPkg;
    }

    /** 把 PackageInfo 里的版本字段抬高 */
    static void patch_version_fields(JNIEnv *env, jobject info) {
        jclass cls = env->GetObjectClass(info);
        if (cls == nullptr) {
            env->ExceptionClear();
            return;
        }
        jfieldID code = env->GetFieldID(cls, "versionCode", "I");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (code != nullptr) env->SetIntField(info, code, 999999999);

        jfieldID lcode = env->GetFieldID(cls, "longVersionCode", "J");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (lcode != nullptr) env->SetLongField(info, lcode, 999999999LL);

        jfieldID vname = env->GetFieldID(cls, "versionName", "Ljava/lang/String;");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (vname != nullptr) {
            jstring s = env->NewStringUTF("9.9.9");
            if (s != nullptr) {
                env->SetObjectField(info, vname, s);
                env->DeleteLocalRef(s);
            }
        }
        env->DeleteLocalRef(cls);
    }

    /** InetAddress.getAllByName(String) 的替换:命中更新域名 → 直接 UnknownHostException */
    extern "C" jobjectArray jh_dns_get_all(JNIEnv *env, jclass clazz, jstring host) {
        if (env == nullptr) return nullptr;

        const char *h = nullptr;
        if (host != nullptr) h = env->GetStringUTFChars(host, nullptr);
        bool blocked = host_should_block(h);
        if (h != nullptr) env->ReleaseStringUTFChars(host, h);

        if (blocked) {
            pthread_mutex_lock(&g_lock);
            g_dnsBlocked++;
            pthread_mutex_unlock(&g_lock);
            jclass ex = env->FindClass("java/net/UnknownHostException");
            if (ex != nullptr) {
                env->ThrowNew(ex, "update host blocked");
                env->DeleteLocalRef(ex);
            }
            return nullptr;
        }

        pthread_mutex_lock(&g_netLock);
        art_restore(g_dnsGetAll);
        // 用 A 版本:JNI 的可变参数路线在不同 ABI 上历史包袱多,A 版本参数表最稳
        jvalue dnsArg{};
        dnsArg.l = host;
        auto r = (jobjectArray) env->CallStaticObjectMethodA(
                clazz, (jmethodID) g_dnsGetAll.art, &dnsArg);
        bool pending = env->ExceptionCheck();
        art_as_native(g_dnsGetAll, (void *) jh_dns_get_all, g_genericEntry);
        pthread_mutex_unlock(&g_netLock);
        return pending ? nullptr : r;
    }

    /** PackageManager.getPackageInfo(String,int) 的替换:自己这个包的版本号读成大数 */
    extern "C" jobject jh_pkg_get_info(JNIEnv *env, jobject thiz, jstring pkg, jint flags) {
        if (env == nullptr) return nullptr;

        pthread_mutex_lock(&g_netLock);
        art_restore(g_pkgInfo);
        jvalue pkgArgs[2];
        pkgArgs[0].l = pkg;
        pkgArgs[1].i = flags;
        jobject info = env->CallObjectMethodA(thiz, (jmethodID) g_pkgInfo.art, pkgArgs);
        bool pending = env->ExceptionCheck();
        art_as_native(g_pkgInfo, (void *) jh_pkg_get_info, g_genericEntry);
        pthread_mutex_unlock(&g_netLock);

        if (pending || info == nullptr || pkg == nullptr) return info;

        const char *c = env->GetStringUTFChars(pkg, nullptr);
        bool target = c != nullptr && strcmp(c, self_package(env)) == 0;
        if (c != nullptr) env->ReleaseStringUTFChars(pkg, c);
        if (!target) return info;

        patch_version_fields(env, info);
        pthread_mutex_lock(&g_lock);
        g_verSpoof++;
        pthread_mutex_unlock(&g_lock);
        return info;
    }

    /** 类名像不像"更新页" */
    static const char *kNotUpdateActivityKeys[] = {
            "mainactivity", "unityplayeractivity", "launcher",
    };

    static bool activity_is_update_page(const char *name) {
        if (name == nullptr || name[0] == '\0') return false;
        // 主界面/游戏本体绝不误伤
        int notN = (int) (sizeof(kNotUpdateActivityKeys) / sizeof(kNotUpdateActivityKeys[0]));
        if (contains_any_ci(name, kNotUpdateActivityKeys, notN)) return false;
        int n = (int) (sizeof(kUpdateActivityKeys) / sizeof(kUpdateActivityKeys[0]));
        return contains_any_ci(name, kUpdateActivityKeys, n);
    }

    /** Activity.onCreate 的替换:更新页 finish 掉,并把游戏主界面拉回来 */
    extern "C" void jh_activity_on_create(JNIEnv *env, jobject thiz, jobject bundle) {
        if (env == nullptr) return;

        pthread_mutex_lock(&g_netLock);
        art_restore(g_actCreate);
        jvalue createArg{};
        createArg.l = bundle;
        env->CallVoidMethodA(thiz, (jmethodID) g_actCreate.art, &createArg);
        if (env->ExceptionCheck()) env->ExceptionClear();
        art_as_native(g_actCreate, (void *) jh_activity_on_create, g_genericEntry);
        pthread_mutex_unlock(&g_netLock);

        jclass cls = env->GetObjectClass(thiz);
        if (cls == nullptr) {
            env->ExceptionClear();
            return;
        }

        char name[256];
        name[0] = '\0';
        jclass cc = env->FindClass("java/lang/Class");
        if (cc != nullptr) {
            jmethodID getName = env->GetMethodID(cc, "getName", "()Ljava/lang/String;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (getName != nullptr) {
                auto s = (jstring) env->CallObjectMethod(cls, getName);
                if (env->ExceptionCheck()) env->ExceptionClear();
                if (s != nullptr) {
                    const char *c = env->GetStringUTFChars(s, nullptr);
                    if (c != nullptr) {
                        snprintf(name, sizeof(name), "%s", c);
                        env->ReleaseStringUTFChars(s, c);
                    }
                    env->DeleteLocalRef(s);
                }
            }
            env->DeleteLocalRef(cc);
        }

        if (!activity_is_update_page(name)) {
            env->DeleteLocalRef(cls);
            return;
        }

        pthread_mutex_lock(&g_lock);
        g_netRedirect++;
        bool first = (g_redirectedOnce == 0);
        if (first) g_redirectedOnce = 1;
        pthread_mutex_unlock(&g_lock);

        // 收掉更新页
        jmethodID finish = env->GetMethodID(cls, "finish", "()V");
        if (env->ExceptionCheck()) env->ExceptionClear();
        if (finish != nullptr) {
            env->CallVoidMethod(thiz, finish);
            if (env->ExceptionCheck()) env->ExceptionClear();
        }

        // 只主动拉一次主界面,防"拉起 → 又被推去更新页 → 再拉起"的死循环
        if (first) {
            jclass ctxCls = env->FindClass("android/content/Context");
            jclass pmCls = env->FindClass("android/content/pm/PackageManager");
            jclass inCls = env->FindClass("android/content/Intent");
            if (ctxCls != nullptr && pmCls != nullptr && inCls != nullptr) {
                jmethodID getApp = env->GetMethodID(
                        cls, "getApplicationContext", "()Landroid/content/Context;");
                if (env->ExceptionCheck()) env->ExceptionClear();
                jobject ctx = getApp != nullptr ? env->CallObjectMethod(thiz, getApp) : nullptr;
                if (env->ExceptionCheck()) env->ExceptionClear();

                if (ctx != nullptr) {
                    jmethodID getPm = env->GetMethodID(
                            ctxCls, "getPackageManager",
                            "()Landroid/content/pm/PackageManager;");
                    jmethodID getPkg = env->GetMethodID(
                            ctxCls, "getPackageName", "()Ljava/lang/String;");
                    jmethodID start = env->GetMethodID(
                            ctxCls, "startActivity", "(Landroid/content/Intent;)V");
                    jmethodID getLaunch = env->GetMethodID(
                            pmCls, "getLaunchIntentForPackage",
                            "(Ljava/lang/String;)Landroid/content/Intent;");
                    jmethodID addFlags = env->GetMethodID(
                            inCls, "addFlags", "(I)Landroid/content/Intent;");
                    if (env->ExceptionCheck()) env->ExceptionClear();

                    if (getPm != nullptr && getPkg != nullptr && start != nullptr &&
                        getLaunch != nullptr) {
                        jobject pm = env->CallObjectMethod(ctx, getPm);
                        auto pkgName = (jstring) env->CallObjectMethod(ctx, getPkg);
                        if (env->ExceptionCheck()) env->ExceptionClear();

                        jobject intent = nullptr;
                        if (pm != nullptr && pkgName != nullptr) {
                            intent = env->CallObjectMethod(pm, getLaunch, pkgName);
                            if (env->ExceptionCheck()) env->ExceptionClear();
                        }
                        if (intent != nullptr) {
                            if (addFlags != nullptr) {
                                // FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_SINGLE_TOP
                                env->CallObjectMethod(intent, addFlags, 0x10000000 | 0x20000000);
                                if (env->ExceptionCheck()) env->ExceptionClear();
                            }
                            env->CallVoidMethod(ctx, start, intent);
                            if (env->ExceptionCheck()) env->ExceptionClear();
                            env->DeleteLocalRef(intent);
                        }
                        if (pm != nullptr) env->DeleteLocalRef(pm);
                        if (pkgName != nullptr) env->DeleteLocalRef(pkgName);
                    }
                    env->DeleteLocalRef(ctx);
                }
            }
            if (ctxCls != nullptr) env->DeleteLocalRef(ctxCls);
            if (pmCls != nullptr) env->DeleteLocalRef(pmCls);
            if (inCls != nullptr) env->DeleteLocalRef(inCls);
        }
        env->DeleteLocalRef(cls);
    }

}  // namespace

// ================================================================ 对外接口

void jh_block_dialogs_tick() {
    if (g_dlgHooked) return;

    JNIEnv *env = env_or_null();
    if (env == nullptr) return;

    void *genericEntry = find_generic_jni_entry(env);
    if (genericEntry == nullptr) return;   // ART 布局没校验过,不动手

    jclass cls = env->FindClass("android/app/Dialog");
    if (cls == nullptr) {
        env->ExceptionClear();
        return;
    }
    jmethodID show = env->GetMethodID(cls, "show", "()V");
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (show == nullptr) {
        env->DeleteLocalRef(cls);
        return;
    }

    void *art = (void *) show;
    // 先原样备份,后面每次"调原方法"都靠它
    g_dialogShow.art = art;
    g_dialogShow.flags = *flags_slot(art);
    g_dialogShow.data = *data_slot(art);
    g_dialogShow.entry = *entry_slot(art);
    g_dialogShow.valid = true;

    if (patch_art_method(art, (void *) jh_dialog_show, genericEntry)) {
        g_dlgHooked = true;
    } else {
        g_dialogShow.valid = false;
    }
    env->DeleteLocalRef(cls);
}

int jh_blocked_count() {
    pthread_mutex_lock(&g_lock);
    int n = g_blocked;
    pthread_mutex_unlock(&g_lock);
    return n;
}

/**
 * 请求层那三刀的安装入口,扫描线程每轮都调,装上了就立刻返回。
 * 这一步不依赖证书 hook 是否成功 —— 就算 okhttp 那条没挂上,检查更新的请求照样会死。
 */
void jh_net_tick() {
    pthread_once(&g_netOnce, init_net_lock);

    JNIEnv *env = env_or_null();
    if (env == nullptr) return;

    void *genericEntry = find_generic_jni_entry(env);
    if (genericEntry == nullptr) return;

    // ① DNS 黑洞:只挂 getAllByName(String)。这是所有网络库的死穴 ——
    //    OkHttp / HttpURLConnection / Volley / UnityWebRequest 最后都走它,
    //    解析失败抛 UnknownHostException,和真断网一模一样。
    if (!g_dnsHooked) {
        jclass cls = env->FindClass("java/net/InetAddress");
        if (cls != nullptr) {
            jmethodID m = env->GetStaticMethodID(
                    cls, "getAllByName", "(Ljava/lang/String;)[Ljava/net/InetAddress;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (m != nullptr) {
                save_method(g_dnsGetAll, (void *) m);
                if (patch_art_method((void *) m, (void *) jh_dns_get_all, genericEntry)) {
                    g_dnsHooked = true;
                    // 不写进 g_hooked:那个计数是"证书校验放开几处",混进请求拦截会虚增;生效情况走 jh_net_state()
                } else {
                    g_dnsGetAll.valid = false;
                    remember_skipped("net:dns-patch-failed");
                }
            } else {
                remember_skipped("net:dns-nomethod");
            }
            env->DeleteLocalRef(cls);
        } else {
            env->ExceptionClear();
        }
    }

    // ② 版本号伪装:游戏拿自己 versionCode 跟服务器比,这里永远读成很大 = 已是最新。
    //    ApplicationPackageManager 是 PackageManager 的真实实现类,getPackageInfo 在这里。
    if (!g_pkgHooked) {
        jclass cls = env->FindClass("android/app/ApplicationPackageManager");
        if (cls != nullptr) {
            jmethodID m = env->GetMethodID(
                    cls, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (m != nullptr) {
                save_method(g_pkgInfo, (void *) m);
                if (patch_art_method((void *) m, (void *) jh_pkg_get_info, genericEntry)) {
                    g_pkgHooked = true;
                    // 不写进 g_hooked:那个计数是"证书校验放开几处",混进请求拦截会虚增;生效情况走 jh_net_state()
                } else {
                    g_pkgInfo.valid = false;
                    remember_skipped("net:ver-patch-failed");
                }
            } else {
                remember_skipped("net:ver-nomethod");
            }
            env->DeleteLocalRef(cls);
        } else {
            env->ExceptionClear();
        }
    }

    // ③ 更新页跳转:真开起了 UpdateActivity 这种页面,finish 掉并拉回游戏主界面。
    if (!g_actHooked) {
        jclass cls = env->FindClass("android/app/Activity");
        if (cls != nullptr) {
            jmethodID m = env->GetMethodID(cls, "onCreate", "(Landroid/os/Bundle;)V");
            if (env->ExceptionCheck()) env->ExceptionClear();
            if (m != nullptr) {
                save_method(g_actCreate, (void *) m);
                if (patch_art_method((void *) m, (void *) jh_activity_on_create, genericEntry)) {
                    g_actHooked = true;
                    // 不写进 g_hooked:那个计数是"证书校验放开几处",混进请求拦截会虚增;生效情况走 jh_net_state()
                } else {
                    g_actCreate.valid = false;
                    remember_skipped("net:page-patch-failed");
                }
            } else {
                remember_skipped("net:page-nomethod");
            }
            env->DeleteLocalRef(cls);
        } else {
            env->ExceptionClear();
        }
    }
}

int jh_net_blocked_count() {
    pthread_mutex_lock(&g_lock);
    int n = g_dnsBlocked;
    pthread_mutex_unlock(&g_lock);
    return n;
}

int jh_net_redirect_count() {
    pthread_mutex_lock(&g_lock);
    int n = g_netRedirect;
    pthread_mutex_unlock(&g_lock);
    return n;
}

int jh_net_version_count() {
    pthread_mutex_lock(&g_lock);
    int n = g_verSpoof;
    pthread_mutex_unlock(&g_lock);
    return n;
}

/** 三刀各自装上没,写进状态文件:ok 表示生效,none 表示没装 */
const char *jh_net_state() {
    static char buf[128];
    snprintf(buf, sizeof(buf), "dns=%s ver=%s page=%s",
             g_dnsHooked ? "ok" : "none",
             g_pkgHooked ? "ok" : "none",
             g_actHooked ? "ok" : "none");
    return buf;
}

int jh_tick() {
    JNIEnv *env = env_or_null();
    if (env == nullptr) {
        pthread_mutex_lock(&g_lock);
        snprintf(g_state, sizeof(g_state), "waiting(拿不到 JVM)");
        pthread_mutex_unlock(&g_lock);
        return 0;
    }

    void *genericEntry = find_generic_jni_entry(env);
    if (genericEntry == nullptr) {
        pthread_mutex_lock(&g_lock);
        snprintf(g_state, sizeof(g_state), "waiting(ART 布局自检没过,不动手)");
        pthread_mutex_unlock(&g_lock);
        return 0;
    }

    jobject appLoader = app_class_loader(env);

    int added = 0;
    for (const auto &t : kTargets) {
        if (already(t.label)) continue;
        jclass klass = t.appLoader ? load_class(env, appLoader, t.className)
                                   : env->FindClass(t.className);
        if (klass == nullptr) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            // 类还没加载(游戏还没用 okhttp)—— 正常,下一轮再试
            continue;
        }
        int got = hook_exact(env, klass, t, genericEntry);
        if (got == 0) note_miss(t.label, "no-signature-match");
        added += got;
        env->DeleteLocalRef(klass);
    }
    if (appLoader != nullptr) env->DeleteLocalRef(appLoader);

    pthread_mutex_lock(&g_lock);
    if (g_hits > 0) {
        char buf[520];
        size_t used = 0;
        buf[0] = '\0';
        for (int i = 0; i < g_hookedCount && used + 40 < sizeof(buf); i++) {
            used += (size_t) snprintf(buf + used, sizeof(buf) - used, "%s%s",
                                      i == 0 ? "" : ",", g_hooked[i]);
        }
        snprintf(g_state, sizeof(g_state), "ok(%d):%s", g_hits, buf);
    } else {
        snprintf(g_state, sizeof(g_state), "none(目标类还没加载或签名对不上)");
    }
    pthread_mutex_unlock(&g_lock);
    return added;
}

int jh_hit_count() {
    pthread_mutex_lock(&g_lock);
    int n = g_hits;
    pthread_mutex_unlock(&g_lock);
    return n;
}

const char *jh_state() {
    return g_state;
}

/** 被跳过的那些,状态文件里单独列一行,下次有问题一看就知道卡在哪条 */
const char *jh_skipped_state() {
    static char buf[420];
    pthread_mutex_lock(&g_lock);
    buf[0] = '\0';
    size_t used = 0;
    for (int i = 0; i < g_skippedCount; i++) {
        used += (size_t) snprintf(buf + used, sizeof(buf) - used, "%s%s",
                                  i == 0 ? "" : ";", g_skipped[i]);
    }
    pthread_mutex_unlock(&g_lock);
    return buf;
}

void jh_detach() {
    if (g_vm != nullptr && g_attached) {
        g_vm->DetachCurrentThread();
        g_attached = false;
    }
}
