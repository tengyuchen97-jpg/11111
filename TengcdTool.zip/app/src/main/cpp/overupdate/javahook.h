//
// javahook.h —— 免 root(进程注入)下的 Java 层补丁
//
// 没有 Xposed 框架,所以这里自己做最小的方法替换:
//   把目标方法标成 native、data_ 指向我们的 C 函数、入口指向 ART 的通用 JNI 跳板。
//   调用方照常按 Java 方法调,ART 把参数原样交给我们。
//
// 管两件事:
//   一、证书校验放行(OkHttp / Conscrypt / WebView),名单和 JustTrustMePP 一致;
//   二、更新弹窗拦截(Dialog.show 文字判定,没命中的照常弹)。
//
// 分寸:
//   只替换「返回 void / boolean」的校验方法,返回 List/数组的内部方法一律不碰
//   (上一版把 verifyChain 这种也换了,类型对不上,游戏一发起 HTTPS 就废)。
//   名字 + 返回类型 + 参数类型逐项比对,全中才动手。
//   ART 布局自检不过就一个字都不写。
//

#ifndef OVERUPDATE_JAVAHOOK_H
#define OVERUPDATE_JAVAHOOK_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 试一轮证书 hook。可以反复调(游戏懒加载 okhttp 时,后面几轮才 hook 得上)。
 * 返回:本轮新 hook 上的方法数。
 */
int jh_tick();

/** 挂上更新弹窗拦截(Dialog.show)。只需成功一次,后面调都直接返回。 */
void jh_block_dialogs_tick();

/**
 * 挂上"检查更新请求"那一层(DNS 黑洞 / 版本号伪装 / 更新页跳转)。
 * 扫描线程每轮调一次,装上了就立刻返回;不依赖证书 hook 成败。
 */
void jh_net_tick();

/** 被 DNS 黑洞掐掉的解析次数(每次 ≈ 一条打向更新域名的请求) */
int jh_net_blocked_count();

/** 被收掉并跳回主界面的更新页数量 */
int jh_net_redirect_count();

/** 版本号被伪装成最新版的查询次数 */
int jh_net_version_count();

/** 三刀各自生效情况(ok/none),写进状态文件的 net= 字段 */
const char *jh_net_state();

/** 已经 hook 上的证书方法总数 */
int jh_hit_count();

/** 已经拦掉的更新弹窗数 */
int jh_blocked_count();

/** 一行状态,写进 overupdate.status 的 java= 字段 */
const char *jh_state();

/** 匹配上但没动手的那些(签名对不上),写进 java_miss= 字段 */
const char *jh_skipped_state();

/** 线程用完就该 detach,别把 attach 过的线程直接扔了 */
void jh_detach();

#ifdef __cplusplus
}
#endif

#endif //OVERUPDATE_JAVAHOOK_H
