//
// liboverupdate.so —— 免 root 过更新补丁库 v4.0
//
// ============================ 这一版为什么重写 ============================
// 上一版(3.0)注入后直接把游戏崩掉,原因就两条,都在这里删干净了:
//
//   1) IL2CPP 全类扫描。遍历游戏所有 Il2CppClass → methods → MethodInfo,
//      按 il2cpp 内部结构体偏移直接读内存。只要游戏不是标准 il2cpp
//      (网易自研引擎、Unity mono、或者 il2cpp 版本对不上),那些指针全是野的,
//      一读就越界 → SIGSEGV,表现就是"注进去立刻闪退"。
//      → 这一版**整块删除**,不再碰任何引擎内部结构。
//
//   2) 直接改写函数体机器码(patch_code_ret0 / patch_entry)。
//      把 X509_verify_cert 之类的函数入口那几个字节改成跳转。
//      改的时候别的线程可能正在执行那几行指令,改完又没做指令缓存同步,
//      轻则 SIGILL,重则跳到半条指令上 → 闪退。
//      → 这一版改成**只改数据,不改代码**:
//        走 ELF 重定位表(.rela.plt / .rela.dyn),把调用方 GOT 槽里的函数指针
//        换成我们的实现。写的是可写数据段里的一个指针,不碰任何指令,
//        多线程下也不会出问题。
//
// ============================ 现在它干什么 ============================
//   一、证书校验放行(为"抓包 → 改更新接口响应 → 过更新"这条路铺路)
//       Java 层:OkHttp CertificatePinner / OkHostnameVerifier / Conscrypt
//                用 ArtMethod 替换实现,不需要 Xposed 框架(javahook.cpp)
//       原生层:BoringSSL / OpenSSL / mbedTLS 那批校验函数的 GOT 指针替换
//
//   二、更新弹窗拦截(javahook.cpp)
//       游戏如果弹的是 Java 层 Dialog(AlertDialog 这类),文字里带
//       "强制更新/版本过低/发现新版本"就直接不放出来。
//       判定前读不到文字、或者任何一步出异常,一律照常弹 —— 宁可漏拦,不能误伤。
//
//   全流程 best-effort:任何一步失败只写状态,绝不抛异常、绝不退出进程。
//

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "javahook.h"

#define TAG "overupdate"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

#define OD_VERSION "4.1"

// ================================================================ 一、证书校验放行的替身

static int rep_X509_verify_cert(void *ctx) {
    (void) ctx;
    return 1;                       // 1 = 校验通过
}

static int rep_SSL_get_verify_result(const void *ssl) {
    (void) ssl;
    return 0;                       // X509_V_OK
}

static int rep_X509_STORE_CTX_get_error(void *ctx) {
    (void) ctx;
    return 0;                       // X509_V_OK
}

static void rep_SSL_CTX_set_verify(void *ctx, int mode, void *cb) {
    (void) ctx; (void) mode; (void) cb;
}

static void rep_SSL_CTX_set_custom_verify(void *ctx, int mode, void *cb) {
    (void) ctx; (void) mode; (void) cb;
}

static void rep_SSL_CTX_set_verify_depth(void *ctx, int depth) {
    (void) ctx; (void) depth;
}

static void rep_SSL_CTX_set_cert_verify_callback(void *ctx, void *cb, void *arg) {
    (void) ctx; (void) cb; (void) arg;
}

static int rep_SSL_set1_host(void *ssl, const char *host) {
    (void) ssl; (void) host;
    return 1;
}

static int rep_X509_check_host(void *cert, const char *chk, size_t chklen,
                               unsigned int flags, char **peername) {
    (void) cert; (void) chk; (void) chklen; (void) flags;
    if (peername != nullptr) *peername = nullptr;
    return 1;
}

static int rep_X509_check_ip_asc(void *cert, const char *ipasc, unsigned int flags) {
    (void) cert; (void) ipasc; (void) flags;
    return 1;
}

static int rep_mbedtls_ssl_get_verify_result(const void *ssl) {
    (void) ssl;
    return 0;                       // 0 = 校验通过
}

static void rep_mbedtls_ssl_conf_authmode(void *conf, int authmode) {
    (void) conf; (void) authmode;
}

struct GotTarget {
    const char *name;
    void *replacement;
};

// 只放"返回值语义明确、被替换后不会让调用方拿到错误类型"的校验函数。
// SSL_read / SSL_write / 内存分配这类一概不碰 —— 换了就是整个 TLS 层报废。
static const GotTarget kGotTargets[] = {
        {"X509_verify_cert",                    (void *) rep_X509_verify_cert},
        {"SSL_get_verify_result",               (void *) rep_SSL_get_verify_result},
        {"X509_STORE_CTX_get_error",            (void *) rep_X509_STORE_CTX_get_error},
        {"SSL_CTX_set_verify",                  (void *) rep_SSL_CTX_set_verify},
        {"SSL_CTX_set_custom_verify",           (void *) rep_SSL_CTX_set_custom_verify},
        {"SSL_CTX_set_verify_depth",            (void *) rep_SSL_CTX_set_verify_depth},
        {"SSL_CTX_set_cert_verify_callback",    (void *) rep_SSL_CTX_set_cert_verify_callback},
        {"SSL_set1_host",                       (void *) rep_SSL_set1_host},
        {"X509_check_host",                     (void *) rep_X509_check_host},
        {"X509_check_ip_asc",                   (void *) rep_X509_check_ip_asc},
        {"mbedtls_ssl_get_verify_result",       (void *) rep_mbedtls_ssl_get_verify_result},
        {"mbedtls_ssl_conf_authmode",           (void *) rep_mbedtls_ssl_conf_authmode},
};

static const int kGotTargetCount =
        (int) (sizeof(kGotTargets) / sizeof(kGotTargets[0]));

// ---------------------------------------------------------------- 状态

static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

static int g_gotPatched = 0;            // 原生层改了多少个 GOT 槽
static char g_gotLibs[8][80];
static int g_gotLibCount = 0;
static uintptr_t g_gotDone[512];        // 已经改过的槽地址,防重复
static int g_gotDoneCount = 0;

static bool got_already(uintptr_t slot) {
    for (int i = 0; i < g_gotDoneCount; i++) {
        if (g_gotDone[i] == slot) return true;
    }
    return false;
}

static void got_remember(uintptr_t slot) {
    if (g_gotDoneCount < (int) (sizeof(g_gotDone) / sizeof(g_gotDone[0]))) {
        g_gotDone[g_gotDoneCount++] = slot;
    }
}

static void got_remember_lib(const char *name) {
    for (int i = 0; i < g_gotLibCount; i++) {
        if (strcmp(g_gotLibs[i], name) == 0) return;
    }
    if (g_gotLibCount < (int) (sizeof(g_gotLibs) / sizeof(g_gotLibs[0]))) {
        snprintf(g_gotLibs[g_gotLibCount], sizeof(g_gotLibs[0]), "%s", name);
        g_gotLibCount++;
    }
}

// ---------------------------------------------------------------- 写指针

/**
 * 往 GOT 槽里写一个新指针。
 *
 * 只写数据段:**绝不动代码段**,所以不存在"别的线程正在执行这条指令"的问题,
 * 也不需要清指令缓存。GOT 平时可能被 RELRO 保护成只读,写之前临时放开。
 */
static bool write_slot(void *slot, void *value) {
    if (slot == nullptr) return false;
    long pageSize = sysconf(_SC_PAGESIZE);
    if (pageSize <= 0) pageSize = 4096;
    uintptr_t page = ((uintptr_t) slot) & ~(uintptr_t) (pageSize - 1);

    if (mprotect((void *) page, (size_t) pageSize, PROT_READ | PROT_WRITE) != 0) {
        // 有些库的 GOT 在一个大段中间,单独 mprotect 这一页会失败,
        // 退一步带上执行位再试(仍然只是数据页,不改内容语义)
        if (mprotect((void *) page, (size_t) pageSize,
                     PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
            return false;
        }
    }
    *(void **) slot = value;
    return true;
}

// ---------------------------------------------------------------- 重定位表遍历

static const GotTarget *match_target(const char *symName) {
    if (symName == nullptr || symName[0] == '\0') return nullptr;
    for (int i = 0; i < kGotTargetCount; i++) {
        if (strcmp(symName, kGotTargets[i].name) == 0) return &kGotTargets[i];
    }
    return nullptr;
}

static void patch_one_rela(uintptr_t base, const ElfW(Rela) *rela, size_t count,
                           const ElfW(Sym) *symtab, const char *strtab,
                           const char *libName) {
    for (size_t i = 0; i < count; i++) {
        const ElfW(Rela) &r = rela[i];

#if defined(__LP64__)
        unsigned type = (unsigned) ELF64_R_TYPE(r.r_info);
        unsigned symIdx = (unsigned) ELF64_R_SYM(r.r_info);
        bool ok = (type == R_AARCH64_JUMP_SLOT) || (type == R_AARCH64_GLOB_DAT) ||
                  (type == R_AARCH64_ABS64);
#else
        unsigned type = (unsigned) ELF32_R_TYPE(r.r_info);
        unsigned symIdx = (unsigned) ELF32_R_SYM(r.r_info);
        bool ok = (type == R_ARM_JUMP_SLOT) || (type == R_ARM_GLOB_DAT) ||
                  (type == R_ARM_ABS32);
#endif
        if (!ok || symIdx == 0 || symtab == nullptr || strtab == nullptr) continue;

        const char *name = strtab + symtab[symIdx].st_name;
        const GotTarget *t = match_target(name);
        if (t == nullptr) continue;

        uintptr_t slot = base + (uintptr_t) r.r_offset;
        if (got_already(slot)) continue;
        if (write_slot((void *) slot, t->replacement)) {
            got_remember(slot);
            pthread_mutex_lock(&g_lock);
            g_gotPatched++;
            got_remember_lib(libName);
            pthread_mutex_unlock(&g_lock);
        }
    }
}

static void patch_one_rel(uintptr_t base, const ElfW(Rel) *rel, size_t count,
                          const ElfW(Sym) *symtab, const char *strtab,
                          const char *libName) {
    for (size_t i = 0; i < count; i++) {
        const ElfW(Rel) &r = rel[i];
#if defined(__LP64__)
        unsigned type = (unsigned) ELF64_R_TYPE(r.r_info);
        unsigned symIdx = (unsigned) ELF64_R_SYM(r.r_info);
        bool ok = (type == R_AARCH64_JUMP_SLOT) || (type == R_AARCH64_GLOB_DAT);
#else
        unsigned type = (unsigned) ELF32_R_TYPE(r.r_info);
        unsigned symIdx = (unsigned) ELF32_R_SYM(r.r_info);
        bool ok = (type == R_ARM_JUMP_SLOT) || (type == R_ARM_GLOB_DAT);
#endif
        if (!ok || symIdx == 0 || symtab == nullptr || strtab == nullptr) continue;
        const char *name = strtab + symtab[symIdx].st_name;
        const GotTarget *t = match_target(name);
        if (t == nullptr) continue;
        uintptr_t slot = base + (uintptr_t) r.r_offset;
        if (got_already(slot)) continue;
        if (write_slot((void *) slot, t->replacement)) {
            got_remember(slot);
            pthread_mutex_lock(&g_lock);
            g_gotPatched++;
            got_remember_lib(libName);
            pthread_mutex_unlock(&g_lock);
        }
    }
}

struct CallbackGuard {
    bool enabled = false;
};

static int got_scan_cb(struct dl_phdr_info *info, size_t, void *) {
    if (info == nullptr || info->dlpi_name == nullptr || info->dlpi_name[0] == '\0') {
        return 0;   // 主程序,一般不含我们要的符号,跳过
    }
    const char *libName = info->dlpi_name;
    // 自己别处理自己
    if (strstr(libName, "liboverupdate") != nullptr) return 0;

    const ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) {
            dyn = (const ElfW(Dyn) *) (info->dlpi_addr + info->dlpi_phdr[i].p_vaddr);
            break;
        }
    }
    if (dyn == nullptr) return 0;

    const ElfW(Sym) *symtab = nullptr;
    const char *strtab = nullptr;
    const void *jmprel = nullptr;
    size_t pltrelsz = 0;
    size_t pltrel = DT_RELA;
    const ElfW(Rela) *rela = nullptr;
    size_t relasz = 0;
    size_t relaent = sizeof(ElfW(Rela));
    const ElfW(Rel) *rel = nullptr;
    size_t relsz = 0;
    size_t relent = sizeof(ElfW(Rel));

    for (const ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB:
                symtab = (const ElfW(Sym) *) (info->dlpi_addr + d->d_un.d_ptr);
                break;
            case DT_STRTAB:
                strtab = (const char *) (info->dlpi_addr + d->d_un.d_ptr);
                break;
            case DT_JMPREL:
                jmprel = (const void *) (info->dlpi_addr + d->d_un.d_ptr);
                break;
            case DT_PLTRELSZ:
                pltrelsz = (size_t) d->d_un.d_val;
                break;
            case DT_PLTREL:
                pltrel = (size_t) d->d_un.d_val;
                break;
            case DT_RELA:
                rela = (const ElfW(Rela) *) (info->dlpi_addr + d->d_un.d_ptr);
                break;
            case DT_RELASZ:
                relasz = (size_t) d->d_un.d_val;
                break;
            case DT_RELAENT:
                relaent = (size_t) d->d_un.d_val;
                break;
            case DT_REL:
                rel = (const ElfW(Rel) *) (info->dlpi_addr + d->d_un.d_ptr);
                break;
            case DT_RELSZ:
                relsz = (size_t) d->d_un.d_val;
                break;
            case DT_RELENT:
                relent = (size_t) d->d_un.d_val;
                break;
            default:
                break;
        }
    }

    if (symtab == nullptr || strtab == nullptr) return 0;

    // .rela.plt(函数调用的懒绑定/直接绑定都在这)
    if (jmprel != nullptr && pltrelsz > 0) {
        if (pltrel == DT_RELA) {
            size_t n = relaent > 0 ? pltrelsz / relaent : 0;
            if (relaent == 0) n = pltrelsz / sizeof(ElfW(Rela));
            patch_one_rela(info->dlpi_addr, (const ElfW(Rela) *) jmprel, n,
                           symtab, strtab, libName);
        } else {
            size_t n = pltrelsz / sizeof(ElfW(Rel));
            patch_one_rel(info->dlpi_addr, (const ElfW(Rel) *) jmprel, n,
                          symtab, strtab, libName);
        }
    }
    // .rela.dyn(全局变量/函数指针)
    if (rela != nullptr && relasz > 0) {
        size_t n = relaent > 0 ? relasz / relaent : relasz / sizeof(ElfW(Rela));
        patch_one_rela(info->dlpi_addr, rela, n, symtab, strtab, libName);
    }
    if (rel != nullptr && relsz > 0) {
        size_t n = relent > 0 ? relsz / relent : relsz / sizeof(ElfW(Rel));
        patch_one_rel(info->dlpi_addr, rel, n, symtab, strtab, libName);
    }
    return 0;
}

/** 扫一轮所有已加载的库。后面新加载的库靠 bootstrap 线程的补扫追上。 */
static void scan_got_once() {
    dl_iterate_phdr(got_scan_cb, nullptr);
}

// ================================================================ 二、状态文件

static char g_statusPath[512];
static char g_statusPath2[512];

static void init_status_path() {
    g_statusPath[0] = '\0';
    g_statusPath2[0] = '\0';

    // ① 优先写本 so 所在目录(注入器把库放在目标可读的目录里,一定写得进去)
    Dl_info di{};
    if (dladdr((void *) init_status_path, &di) != 0 && di.dli_fname != nullptr) {
        const char *slash = strrchr(di.dli_fname, '/');
        if (slash != nullptr) {
            size_t n = (size_t) (slash - di.dli_fname);
            if (n + 40 < sizeof(g_statusPath)) {
                snprintf(g_statusPath, sizeof(g_statusPath), "%.*s/overupdate.status",
                         (int) n, di.dli_fname);
            }
        }
    }
    // ② 兜底:游戏进程自己的 files 目录
    char exe[512];
    ssize_t len = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
    if (len > 0) {
        exe[len] = '\0';
        const char *pkg = strstr(exe, "/lib/");
        if (pkg != nullptr) {
            size_t n = (size_t) (pkg - exe);
            if (n + 40 < sizeof(g_statusPath2)) {
                snprintf(g_statusPath2, sizeof(g_statusPath2), "%.*s/files/overupdate.status",
                         (int) n, exe);
            }
        }
    }
}

static char g_lastState[256] = "booting";
static int g_round = 0;

static void build_status(char *out, size_t cap) {
    if (out == nullptr || cap == 0) return;
    out[0] = '\0';

    pthread_mutex_lock(&g_lock);
    int got = g_gotPatched;
    char libs[8][80];
    int libCount = g_gotLibCount;
    for (int i = 0; i < libCount && i < 8; i++) snprintf(libs[i], sizeof(libs[i]), "%s", g_gotLibs[i]);
    char state[256];
    snprintf(state, sizeof(state), "%s", g_lastState);
    int round = g_round;
    pthread_mutex_unlock(&g_lock);

    int javaHits = jh_hit_count();
    int blocked = jh_blocked_count();
    const char *javaState = jh_state();
    const char *javaSkipped = jh_skipped_state();

    // 请求层(检查更新那一刀)的统计
    int netBlocked = jh_net_blocked_count();
    int netRedirect = jh_net_redirect_count();
    int netSpoof = jh_net_version_count();
    const char *netState = jh_net_state();

    int n = snprintf(out, cap,
                     "version=%s\n"
                     "state=%s\n"
                     "round=%d\n"
                     "code=0\n"          // 兼容旧界面:不再有 IL2CPP 方法改写
                     "meta=0\n"
                     "scanned=0\n"
                     "assemblies=0\n"
                     "il2cpp=none\n"
                     "total=%d\n"
                     "java=%s\n"
                     "java_miss=%s\n"
                     "dialog=%d\n"
                     "net_state=%s\n"
                     "net_hit=%d\n"
                     "redirect=%d\n"
                     "ver_spoof=%d\n"
                     "time=%ld\n",
                     OD_VERSION, state, round, got, javaState, javaSkipped, blocked,
                     netState, netBlocked, netRedirect, netSpoof,
                     (long) time(nullptr));
    if (n <= 0) return;
    size_t used = strlen(out);
    for (int i = 0; i < libCount && i < 8 && used + 100 < cap; i++) {
        used += (size_t) snprintf(out + used, cap - used, "hit=%s\n", libs[i]);
    }
}

static void write_status() {
    char buf[4096];
    build_status(buf, sizeof(buf));
    const char *paths[2] = {g_statusPath, g_statusPath2};
    for (int i = 0; i < 2; i++) {
        if (paths[i][0] == '\0') continue;
        FILE *f = fopen(paths[i], "w");
        if (f == nullptr) continue;
        fwrite(buf, 1, strlen(buf), f);
        fclose(f);
        chmod(paths[i], 0666);
    }
}

// ================================================================ 三、启动

static void set_state(const char *s) {
    pthread_mutex_lock(&g_lock);
    snprintf(g_lastState, sizeof(g_lastState), "%s", s == nullptr ? "" : s);
    pthread_mutex_unlock(&g_lock);
}

static void *bootstrap_thread(void *) {
    // 注入器是先把目标线程全冻住再 dlopen 的,给它留一点收尾时间,
    // 不然抢 linker 的锁会把注入卡死。
    struct timespec warm{};
    warm.tv_sec = 0;
    warm.tv_nsec = 250L * 1000 * 1000;
    nanosleep(&warm, nullptr);

    init_status_path();

    pthread_mutex_lock(&g_lock);
    snprintf(g_lastState, sizeof(g_lastState), "running");
    pthread_mutex_unlock(&g_lock);
    write_status();

    // 第一轮:能改的全改掉
    scan_got_once();
    jh_tick();
    jh_block_dialogs_tick();
    jh_net_tick();
    write_status();

    /**
     * 补扫节奏。
     *
     * 游戏的网络库 / okhttp 往往是懒加载的,第一轮扫的时候还不存在,
     * 所以要按时间补几轮。间隔逐步拉开,最后停在一分钟一次,不拖累游戏。
     * 全部跑完就退出线程,不在游戏进程里常驻。
     */
    static const int kAtMs[] = {0, 300, 800, 1600, 3000, 5000, 8000, 13000, 20000,
                                30000, 45000, 60000, 90000, 120000, 180000};
    struct timespec start{};
    clock_gettime(CLOCK_MONOTONIC, &start);
    long long startMs = (long long) start.tv_sec * 1000 + start.tv_nsec / 1000000;

    for (size_t i = 0; i < sizeof(kAtMs) / sizeof(kAtMs[0]); i++) {
        struct timespec now{};
        clock_gettime(CLOCK_MONOTONIC, &now);
        long long nowMs = (long long) now.tv_sec * 1000 + now.tv_nsec / 1000000;
        long long waitMs = startMs + kAtMs[i] - nowMs;
        if (waitMs > 0) {
            struct timespec ts{};
            ts.tv_sec = waitMs / 1000;
            ts.tv_nsec = (waitMs % 1000) * 1000000;
            nanosleep(&ts, nullptr);
        }

        int before = g_gotPatched;
        int javaBefore = jh_hit_count();
        int netBefore = jh_net_blocked_count() + jh_net_redirect_count() +
                        jh_net_version_count();
        scan_got_once();
        jh_tick();
        jh_block_dialogs_tick();
        jh_net_tick();

        pthread_mutex_lock(&g_lock);
        g_round = (int) i + 1;
        pthread_mutex_unlock(&g_lock);

        if (g_gotPatched != before || jh_hit_count() != javaBefore ||
            jh_net_blocked_count() + jh_net_redirect_count() + jh_net_version_count() !=
            netBefore) {
            write_status();
        }
    }

    /**
     * 静默巡检。
     *
     * 上面补扫完就退,但游戏"检查更新"往往发生在启动十几秒到几分钟之后
     * (等它自己登录完才查版本)。要是线程这会儿已经退了,拦是拦得住,
     * 可界面上永远显示 0,用户没法确认到底是没拦到还是压根没触发。
     *
     * 所以再多盯 30 分钟,只做一件事:计数变了就刷一遍状态文件。
     * 不扫描、不改任何东西,每 5 秒醒一次看一眼几个整数,开销可以忽略。
     */
    // 补扫到这里就完事了,状态先落成 done;后面只是盯着计数刷新,不再动任何 hook
    set_state("done");
    write_status();
    jh_detach();

    int netLast = jh_net_blocked_count() + jh_net_redirect_count() +
                  jh_net_version_count();
    for (int i = 0; i < 360; i++) {
        struct timespec ts{};
        ts.tv_sec = 5;
        nanosleep(&ts, nullptr);
        int now = jh_net_blocked_count() + jh_net_redirect_count() +
                  jh_net_version_count();
        if (now != netLast) {
            netLast = now;
            write_status();
        }
    }

    write_status();
    return nullptr;
}

static void start_once() {
    static pthread_mutex_t onceLock = PTHREAD_MUTEX_INITIALIZER;
    static bool started = false;

    pthread_mutex_lock(&onceLock);
    bool need = !started;
    started = true;
    pthread_mutex_unlock(&onceLock);
    if (!need) return;

    pthread_t th;
    if (pthread_create(&th, nullptr, bootstrap_thread, nullptr) == 0) {
        pthread_detach(th);
    }
}

/**
 * 构造函数里只点一个线程就返回。
 *
 * 注入器 dlopen 这个库的时候,目标进程的线程是被冻住的。谁在构造函数里
 * 干重活(遍历库、起 JNI、抢 linker 锁),dlopen 就永远不返回,
 * 注入器等到超时 —— 表现就是"注入没反应"或者干脆把游戏卡死。
 */
extern "C" __attribute__((constructor)) void overupdate_ctor() {
    start_once();
}

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void) vm;
    (void) reserved;
    start_once();
    return JNI_VERSION_1_6;
}

// ================================================================ 四、给 Java 层读状态

extern "C" JNIEXPORT jstring JNICALL
Java_com_tengcd_czr_xposed_OverUpdateNative_status(JNIEnv *env, jobject) {
    char buf[4096];
    build_status(buf, sizeof(buf));
    return env->NewStringUTF(buf);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_tengcd_czr_xposed_OverUpdateNative_scanNow(JNIEnv *, jobject) {
    int before = g_gotPatched;
    scan_got_once();
    jh_tick();
    jh_block_dialogs_tick();
    jh_net_tick();
    write_status();
    return g_gotPatched - before;
}
