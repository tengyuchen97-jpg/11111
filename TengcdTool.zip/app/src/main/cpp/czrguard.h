#ifndef CZR_GUARD_H
#define CZR_GUARD_H

#ifdef __cplusplus
extern "C" {
#endif

/** 原生门禁:apk 完整性 + 无调试器 才返回 1 */
int czr_guard_ok(void);

#ifdef __cplusplus
}
#endif

#endif  // CZR_GUARD_H
