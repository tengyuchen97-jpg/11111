//
// 卡密/完整性原生层。
//
// 这里只干两件 Java 侧做不到的事:
//
//  1. 算自己的 apk 里每个 classes*.dex 的 SHA-256,和编译时写死在这份 .so 里的
//     期望值相比。有人把包拆开改 smali(把验证判断改成 return true、把卡密写死、
//     去掉登录页),dex 的字节就变了,摘要必然对不上 —— 除非他连这份 .so 一起改,
//     而 .so 里只有一堆数字,改起来比改 smali 难得多。
//
//  2. 给进程注入加一道原生门禁:注入逻辑本来就在原生层,门禁放在这里,
//     光改 Java/Kotlin 是绕不过去的。
//
// 期望摘要由 tools/dexhash.py 在出包后写入(见 kDexDigest)。
//
#include "czrguard.h"

#include <jni.h>

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include <dlfcn.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <zlib.h>

#include <android/log.h>

#define GUARD_TAG "czr-guard"
#define GLOGI(...) __android_log_print(ANDROID_LOG_INFO, GUARD_TAG, __VA_ARGS__)

// ------------------------------------------------------------------ SHA-256

namespace {

struct Sha256 {
    uint32_t h[8];
    uint64_t len;
    unsigned char buf[64];
    size_t bufLen;

    Sha256() { reset(); }

    void reset() {
        h[0] = 0x6a09e667u; h[1] = 0xbb67ae85u; h[2] = 0x3c6ef372u; h[3] = 0xa54ff53au;
        h[4] = 0x510e527fu; h[5] = 0x9b05688cu; h[6] = 0x1f83d9abu; h[7] = 0x5be0cd19u;
        len = 0;
        bufLen = 0;
    }

    static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

    void block(const unsigned char* p) {
        static const uint32_t K[64] = {
            0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u, 0x3956c25bu, 0x59f111f1u,
            0x923f82a4u, 0xab1c5ed5u, 0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
            0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u, 0xe49b69c1u, 0xefbe4786u,
            0x0fc19dc6u, 0x240ca1ccu, 0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
            0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u, 0xc6e00bf3u, 0xd5a79147u,
            0x06ca6351u, 0x14292967u, 0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
            0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u, 0xa2bfe8a1u, 0xa81a664bu,
            0xc24b8b70u, 0xc76c51a3u, 0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
            0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u, 0x391c0cb3u, 0x4ed8aa4au,
            0x5b9cca4fu, 0x682e6ff3u, 0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
            0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
        };
        uint32_t w[64];
        for (int i = 0; i < 16; i++) {
            w[i] = (uint32_t(p[i * 4]) << 24) | (uint32_t(p[i * 4 + 1]) << 16) |
                   (uint32_t(p[i * 4 + 2]) << 8) | uint32_t(p[i * 4 + 3]);
        }
        for (int i = 16; i < 64; i++) {
            uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }
        uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
        uint32_t e = h[4], f = h[5], g = h[6], hh = h[7];
        for (int i = 0; i < 64; i++) {
            uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            uint32_t ch = (e & f) ^ ((~e) & g);
            uint32_t t1 = hh + S1 + ch + K[i] + w[i];
            uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            hh = g; g = f; f = e; e = d + t1;
            d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d;
        h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }

    void update(const void* data, size_t n) {
        const unsigned char* p = static_cast<const unsigned char*>(data);
        len += n;
        if (bufLen) {
            size_t need = 64 - bufLen;
            size_t take = n < need ? n : need;
            memcpy(buf + bufLen, p, take);
            bufLen += take;
            p += take;
            n -= take;
            if (bufLen == 64) {
                block(buf);
                bufLen = 0;
            }
        }
        while (n >= 64) {
            block(p);
            p += 64;
            n -= 64;
        }
        if (n) {
            memcpy(buf + bufLen, p, n);
            bufLen += n;
        }
    }

    void final(unsigned char out[32]) {
        uint64_t bits = len * 8ULL;
        unsigned char pad = 0x80;
        update(&pad, 1);
        unsigned char zero = 0;
        while (bufLen != 56) update(&zero, 1);
        unsigned char lenBuf[8];
        for (int i = 0; i < 8; i++) lenBuf[i] = static_cast<unsigned char>((bits >> (56 - i * 8)) & 0xFF);
        update(lenBuf, 8);
        for (int i = 0; i < 8; i++) {
            out[i * 4] = static_cast<unsigned char>((h[i] >> 24) & 0xFF);
            out[i * 4 + 1] = static_cast<unsigned char>((h[i] >> 16) & 0xFF);
            out[i * 4 + 2] = static_cast<unsigned char>((h[i] >> 8) & 0xFF);
            out[i * 4 + 3] = static_cast<unsigned char>(h[i] & 0xFF);
        }
    }
};

/// 出包后由 tools/dexhash.py 写入:所有 classes*.dex 合并摘要
static const unsigned char kDexDigest[32] = {
    0xE6, 0xD8, 0xA5, 0x3D, 0x1B, 0xCE, 0xD6, 0x72,
    0x8D, 0xF5, 0xEF, 0x80, 0x30, 0x1A, 0x1E, 0x9A,
    0xD6, 0xC2, 0x1A, 0x87, 0x24, 0x3F, 0x52, 0x12,
    0xFB, 0xAF, 0x5A, 0x0C, 0xFD, 0x6F, 0x23, 0xBC
};

static inline uint16_t le16(const unsigned char* p) {
    return static_cast<uint16_t>(p[0] | (p[1] << 8));
}
static inline uint32_t le32(const unsigned char* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

struct DexDigest {
    std::string name;
    unsigned char digest[32];
};

/// 从自己的 .so 路径反推 apk:/data/app/~~x/pkg-y/lib/arm64/libptrace_injector.so -> .../base.apk
static std::string selfApkPath() {
    Dl_info info;
    if (dladdr(reinterpret_cast<void*>(&selfApkPath), &info) == 0 || info.dli_fname == nullptr) {
        return std::string();
    }
    std::string soPath(info.dli_fname);
    size_t pos = soPath.rfind("/lib/");
    if (pos == std::string::npos) return std::string();
    return soPath.substr(0, pos) + "/base.apk";
}

static bool inflateToSha(const unsigned char* src, size_t srcLen, Sha256& sha) {
    z_stream zs;
    memset(&zs, 0, sizeof(zs));
    if (inflateInit2(&zs, -MAX_WBITS) != Z_OK) return false;
    unsigned char out[64 * 1024];
    size_t consumed = 0;
    int ret = Z_OK;
    while (ret != Z_STREAM_END) {
        if (zs.avail_in == 0 && consumed < srcLen) {
            size_t take = srcLen - consumed;
            if (take > (1u << 20)) take = (1u << 20);
            zs.next_in = const_cast<Bytef*>(src + consumed);
            zs.avail_in = static_cast<uInt>(take);
            consumed += take;
        }
        zs.next_out = out;
        zs.avail_out = sizeof(out);
        ret = inflate(&zs, Z_NO_FLUSH);
        if (ret != Z_OK && ret != Z_STREAM_END) {
            inflateEnd(&zs);
            return false;
        }
        size_t produced = sizeof(out) - zs.avail_out;
        if (produced) sha.update(out, produced);
        if (ret == Z_OK && zs.avail_in == 0 && consumed >= srcLen && produced == 0) {
            inflateEnd(&zs);
            return false;
        }
    }
    inflateEnd(&zs);
    return true;
}

/// 打开 apk,把每个 classes*.dex 的摘要算出来
static bool collectDex(const unsigned char* map, size_t size, std::vector<DexDigest>& out) {
    if (size < 22 + 4) return false;
    // 找 EOCD
    const size_t tail = size < 66000 ? size : 66000;
    const unsigned char* end = map + size;
    long eocd = -1;
    for (long i = static_cast<long>(tail) - 22; i >= 0; i--) {
        const unsigned char* p = end - tail + i;
        if (le32(p) == 0x06054b50u) {
            eocd = i;
            break;
        }
    }
    if (eocd < 0) return false;
    const unsigned char* e = end - tail + eocd;
    uint16_t count = le16(e + 10);
    uint32_t cdOffset = le32(e + 16);
    if (cdOffset >= size) return false;

    const unsigned char* p = map + cdOffset;
    for (uint16_t i = 0; i < count; i++) {
        if (p + 46 > end || le32(p) != 0x02014b50u) break;
        uint16_t method = le16(p + 10);
        uint32_t compSize = le32(p + 20);
        uint16_t nameLen = le16(p + 28);
        uint16_t extraLen = le16(p + 30);
        uint16_t cmtLen = le16(p + 32);
        uint32_t localOff = le32(p + 42);
        if (p + 46 + nameLen > end) break;
        std::string name(reinterpret_cast<const char*>(p + 46), nameLen);
        p += 46 + nameLen + extraLen + cmtLen;

        bool isDex = name.size() > 4 && name.compare(name.size() - 4, 4, ".dex") == 0 &&
                     name.find('/') == std::string::npos;
        if (!isDex) continue;

        if (localOff + 30 > size) continue;
        const unsigned char* lh = map + localOff;
        if (le32(lh) != 0x04034b50u) continue;
        uint16_t lNameLen = le16(lh + 26);
        uint16_t lExtraLen = le16(lh + 28);
        size_t dataOff = localOff + 30u + lNameLen + lExtraLen;
        if (dataOff + compSize > size) continue;

        Sha256 sha;
        bool ok;
        if (method == 0) {
            sha.update(map + dataOff, compSize);
            ok = true;
        } else if (method == 8) {
            ok = inflateToSha(map + dataOff, compSize, sha);
        } else {
            ok = false;
        }
        if (!ok) continue;
        DexDigest d;
        d.name = name;
        sha.final(d.digest);
        out.push_back(d);
    }
    return !out.empty();
}

static int computeDexState() {
    std::string apk = selfApkPath();
    if (apk.empty()) return -1;
    int fd = open(apk.c_str(), O_RDONLY);
    if (fd < 0) return -1;
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size <= 0) {
        close(fd);
        return -1;
    }
    size_t size = static_cast<size_t>(st.st_size);
    void* m = mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (m == MAP_FAILED) return -1;
    const unsigned char* map = static_cast<const unsigned char*>(m);

    std::vector<DexDigest> dexes;
    bool ok = collectDex(map, size, dexes);
    munmap(m, size);
    if (!ok) return -1;

    // 按名字排序,保证多次构建结果一致
    for (size_t i = 1; i < dexes.size(); i++) {
        for (size_t j = i; j > 0 && dexes[j].name < dexes[j - 1].name; j--) {
            DexDigest tmp = dexes[j];
            dexes[j] = dexes[j - 1];
            dexes[j - 1] = tmp;
        }
    }

    Sha256 all;
    for (auto& d : dexes) {
        all.update(d.name.c_str(), d.name.size());
        unsigned char zero = 0;
        all.update(&zero, 1);
        all.update(d.digest, 32);
    }
    unsigned char digest[32];
    all.final(digest);

    // 用 volatile 逐字节读:否则编译器会把 32 字节拆成两条 16 字节向量常量塞进
    // literal pool,虽然逻辑不错,但包里的期望值就不连续了,出包后没法静态核对。
    const volatile unsigned char* expected = kDexDigest;
    bool placeholder = true;
    bool match = true;
    for (int i = 0; i < 32; i++) {
        unsigned char e = expected[i];
        if (e != 0x00) placeholder = false;
        if (e != digest[i]) match = false;
    }
    // 还没写期望值的第一遍构建:不判死,免得出个全黑的包
    if (placeholder) return 1;
    return match ? 1 : 0;
}

static std::atomic<int> g_dex{-2};

static int dexState() {
    int v = g_dex.load();
    if (v != -2) return v;
    v = computeDexState();
    g_dex.store(v);
    return v;
}

static bool tracedSelf() {
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) return false;
    char buf[4096];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = 0;
    const char* p = strstr(buf, "TracerPid:");
    if (p == nullptr) return false;
    p += 10;
    while (*p == ' ' || *p == '\t') p++;
    return atoi(p) != 0;
}

}  // namespace

// ------------------------------------------------------------------ 对外接口

extern "C" int czr_guard_ok(void) {
    if (dexState() == 0) {
        GLOGI("guard: dex digest mismatch");
        return 0;
    }
    if (tracedSelf()) {
        GLOGI("guard: traced");
        return 0;
    }
    return 1;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_tengcd_czr_security_NativeGuard_selfIntegrity(JNIEnv*, jclass) {
    int v = dexState();
    GLOGI("selfIntegrity -> %d", v);
    return v;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_tengcd_czr_security_NativeGuard_injectAllowed(JNIEnv*, jclass, jobject) {
    return czr_guard_ok() ? JNI_TRUE : JNI_FALSE;
}
