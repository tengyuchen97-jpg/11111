package com.tengcd.czr.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * T3 网络验证客户端
 * 接口地址: http://w.t3yanzheng.com/{调用码}
 * 加密: Base64 自定义编码集 + RC4
 */
object T3Client {

    private const val BASE_URL = "http://w.t3yanzheng.com"
    private const val RC4_KEY = "7lo18aX1QialEA5"
    private const val APP_KEY = "f736fd5efeb7a9ab1b6bdfcc7b364a78"

    // Base64 自定义编码集
    private val CUSTOM_BASE64 = "kXcZ3OBKtPVsR5w1Fdmjl2GLg4SYfNhrUWopiI6+z/TnvbauQeCy9Aq8HMJ70DEx"
    private val STANDARD_BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /**
     * 单码卡密登录
     * 调用码: 47D4910970418F2E
     * @param kami 卡密
     * @param imei 设备码
     */
    suspend fun verifyCard(kami: String, imei: String): T3VerifyResult = withContext(Dispatchers.IO) {
        try {
            val callCode = "47D4910970418F2E"
            val url = "$BASE_URL/$callCode"
            val timestamp = System.currentTimeMillis() / 1000

            val formBody = FormBody.Builder()
                .add("appkey", APP_KEY)
                .add("kami", kami)
                .add("imei", imei)
                .add("t", timestamp.toString())
                .build()

            val request = Request.Builder()
                .url(url)
                .post(formBody)
                .header("User-Agent", "okhttp/4.9.0")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext T3VerifyResult(false, "HTTP ${response.code}", body)
                }

                // 解密返回值
                val decrypted = try {
                    decryptData(body)
                } catch (e: Exception) {
                    body
                }

                parseVerifyResponse(decrypted)
            }
        } catch (e: Exception) {
            T3VerifyResult(false, e.message ?: "network_error", "")
        }
    }

    /**
     * 获取程序公告
     * 调用码: 3C223920FC8D1028
     */
    suspend fun fetchNotice(): T3NoticeResult = withContext(Dispatchers.IO) {
        try {
            val callCode = "3C223920FC8D1028"
            val url = "$BASE_URL/$callCode?t=${System.currentTimeMillis() / 1000}"

            val request = Request.Builder()
                .url(url)
                .get()
                .header("User-Agent", "okhttp/4.9.0")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val decrypted = try {
                    decryptData(body)
                } catch (e: Exception) {
                    body
                }
                T3NoticeResult(true, decrypted)
            }
        } catch (e: Exception) {
            T3NoticeResult(false, e.message ?: "network_error")
        }
    }

    /**
     * RC4 加解密
     */
    private fun rc4(data: String, key: String): String {
        val s = IntArray(256) { it }
        var j = 0
        for (i in 0 until 256) {
            j = (j + s[i] + key[i % key.length].code) % 256
            val tmp = s[i]
            s[i] = s[j]
            s[j] = tmp
        }

        var i = 0
        j = 0
        val result = StringBuilder()
        for (char in data) {
            i = (i + 1) % 256
            j = (j + s[i]) % 256
            val tmp = s[i]
            s[i] = s[j]
            s[j] = tmp
            val k = s[(s[i] + s[j]) % 256]
            result.append((char.code xor k).toChar())
        }
        return result.toString()
    }

    /**
     * 自定义 Base64 解码
     */
    private fun customBase64Decode(input: String): String {
        val map = HashMap<Char, Char>()
        for (i in CUSTOM_BASE64.indices) {
            map[CUSTOM_BASE64[i]] = STANDARD_BASE64[i]
        }
        val standard = input.trim().map { map[it] ?: it }.joinToString("")
        return String(android.util.Base64.decode(standard, android.util.Base64.DEFAULT))
    }

    /**
     * 自定义 Base64 编码
     */
    private fun customBase64Encode(input: String): String {
        val standard = android.util.Base64.encodeToString(input.toByteArray(), android.util.Base64.NO_WRAP)
        val map = HashMap<Char, Char>()
        for (i in STANDARD_BASE64.indices) {
            map[STANDARD_BASE64[i]] = CUSTOM_BASE64[i]
        }
        return standard.map { map[it] ?: it }.joinToString("")
    }

    /**
     * 解密返回数据: Base64 自定义解码 → RC4 解密
     */
    private fun decryptData(data: String): String {
        return try {
            val base64Decoded = customBase64Decode(data)
            rc4(base64Decoded, RC4_KEY)
        } catch (e: Exception) {
            data
        }
    }

    /**
     * 加密请求数据: RC4 加密 → Base64 自定义编码
     */
    private fun encryptData(data: String): String {
        val rc4Encrypted = rc4(data, RC4_KEY)
        return customBase64Encode(rc4Encrypted)
    }

    /**
     * 解析验证返回
     * T3 返回格式: {"code": 1, "msg": "...", "expire": "...", "times": 100, "statecode": "..."}
     */
    private fun parseVerifyResponse(body: String): T3VerifyResult {
        return try {
            val json = JSONObject(body)
            val code = json.optInt("code", -1)
            val msg = json.optString("msg", json.optString("message", ""))
            val statecode = json.optString("statecode", "")
            val expire = json.optString("expire", json.optString("expire_time", ""))
            val times = json.optInt("times", json.optInt("remain", -1))

            when (code) {
                1 -> T3VerifyResult(
                    success = true,
                    message = msg,
                    statecode = statecode,
                    expireTime = expire,
                    remainCount = times
                )
                0, -1 -> T3VerifyResult(
                    success = false,
                    message = msg,
                    statecode = statecode
                )
                else -> T3VerifyResult(
                    success = false,
                    message = msg,
                    statecode = statecode
                )
            }
        } catch (e: Exception) {
            T3VerifyResult(false, "parse_error: $body", body)
        }
    }
}

data class T3VerifyResult(
    val success: Boolean,
    val message: String,
    val raw: String = "",
    val statecode: String = "",
    val expireTime: String = "",
    val remainCount: Int = -1
)

data class T3NoticeResult(
    val success: Boolean,
    val notice: String
)
