package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import com.tengcd.czr.util.ShellUtil
import java.io.File
import java.io.InputStream

/**
 * 模块 so 的存放 / 校验 / 分发。
 *
 * 现在一共有三种来源,注入时用哪一个看 InjectionPrefs.soSource:
 *  - builtin : 包里内置的变体。assets/so/v0.19.so ~ v0.24.so,
 *              首次启动全部铺到 files/module/libhonffx_<变体>.so,选择器切哪个就用哪个
 *  - local   : 用户从本机读进来的 so,落到 files/module/libhonffx_local.so
 *  - remote  : 从服务端下载的 so,落到 files/module/libhonffx.so
 *
 * 进程注入时还会再往目标应用自己的数据目录里放一份 —— 不给它放,
 * 目标进程的 linker 会因为路径权限拒绝加载。
 */
object ModuleStore {

    /** 远端下载件的老文件名 */
    const val MODULE_FILE_NAME = "libhonffx.so"

    /** 包里内置 so 的目录(assets/so/) */
    private const val ASSET_SO_DIR = "so"

    /** 老资产兼容:以前是 assets/injlib 单文件 */
    private const val LEGACY_ASSET = "injlib"

    /** 内置的四个变体,按这个顺序显示在模块概览下面的选择器里 */
    val BUILTIN_VARIANTS = listOf("v0.19", "v0.20", "v0.23", "v0.24", "v0.26","v0.27","塔菲")

    /** 一个 so 文件的实际状态 */
    data class SoInfo(
        val file: File,
        val exists: Boolean,
        val size: Long,
        val isElf: Boolean,
        val is64Bit: Boolean,
        /** 只有 Elf 头、没有内容 —— 就是包里自带的占位文件,还没被换成真 so */
        val placeholder: Boolean
    ) {
        val ready: Boolean get() = exists && isElf && size > MIN_SO_SIZE
    }

    /** 小于这个大小的一律当成占位文件(ELF 头 + 空段 = 320 字节) */
    const val MIN_SO_SIZE = 4096L

    /** 读文件头判断到底是不是能加载的 so */
    fun inspect(file: File): SoInfo {
        val size = if (file.isFile) file.length() else 0L
        var isElf = false
        var is64 = false
        if (size > 0L) {
            try {
                file.inputStream().use { input ->
                    val head = ByteArray(20)
                    val n = input.read(head)
                    if (n >= 20 &&
                        head[0] == 0x7F.toByte() && head[1] == 'E'.code.toByte() &&
                        head[2] == 'L'.code.toByte() && head[3] == 'F'.code.toByte()
                    ) {
                        isElf = true
                        is64 = head[4].toInt() == 2
                    }
                }
            } catch (t: Throwable) {
            }
        }
        return SoInfo(
            file = file,
            exists = size > 0L,
            size = size,
            isElf = isElf,
            is64Bit = is64,
            placeholder = size > 0L && size <= 4096L
        )
    }

    /** 当前选中的那份 so 的状态 */
    fun currentInfo(context: Context): SoInfo = inspect(effectiveFile(context))

    fun moduleDir(context: Context): File = File(context.filesDir, "module")

    /** 远端下载件落位 */
    fun remoteFile(context: Context): File = File(moduleDir(context), MODULE_FILE_NAME)

    /** 内置变体落位 */
    fun variantFile(context: Context, variant: String): File =
        File(moduleDir(context), "libhonffx_$variant.so")

    /** 本机读取进来的 so 落位 */
    fun localFile(context: Context): File = File(moduleDir(context), "libhonffx_local.so")

    /** 当前注入会用的那个文件(不一定存在) */
    fun effectiveFile(context: Context): File = when (InjectionPrefs.soSource) {
        InjectionPrefs.SO_SOURCE_LOCAL -> localFile(context)
        InjectionPrefs.SO_SOURCE_REMOTE -> remoteFile(context)
        else -> variantFile(context, InjectionPrefs.soVariant)
    }

    /** 当前生效的 so 路径,没就绪返回 null */
    fun effectivePath(context: Context): String? =
        effectiveFile(context).takeIf { it.isFile && it.length() > 0 }?.absolutePath

    /** 当前生效的 so(兼容老调用点) */
    fun moduleFile(context: Context): File = effectiveFile(context)

    /** 当前生效的 so 是否就绪 */
    fun isDownloaded(context: Context): Boolean = effectivePath(context) != null

    fun size(context: Context): Long = effectiveFile(context).length()

    /** 给界面用的一句话来源标签 */
    fun sourceLabel(): String = when (InjectionPrefs.soSource) {
        InjectionPrefs.SO_SOURCE_LOCAL -> "local"
        InjectionPrefs.SO_SOURCE_REMOTE -> "remote"
        else -> InjectionPrefs.soVariant
    }

    /**
     * 首次进来把四个内置变体都铺到私有目录,之后切哪个用哪个,不用再解包。
     *
     * ⚠️ 关键:换过安装包(assets 里的 so 被换成真的了)之后必须重新解包,
     * 否则一直用的是上一次留在私有目录里的旧文件 —— 之前"内置 SO 用不了"就是这个原因。
     */
    fun ensureBundled(context: Context): Boolean {
        val stamp = bundleStamp(context)
        val force = InjectionPrefs.soBundleStamp != stamp
        var any = false
        for (variant in BUILTIN_VARIANTS) {
            if (unpackVariant(context, variant, force)) any = true
        }
        if (!any) any = unpackLegacy(context)
        if (any && force) InjectionPrefs.soBundleStamp = stamp
        refreshPrefs(context)
        return any
    }

    /** 安装包指纹:版本号 + 安装时间,换了包就一定变 */
    private fun bundleStamp(context: Context): String = try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "${info.versionCode}@${info.lastUpdateTime}"
    } catch (t: Throwable) {
        "unknown"
    }

    fun hasVariant(context: Context, variant: String): Boolean {
        val f = variantFile(context, variant)
        return f.isFile && f.length() > 0
    }

    private fun unpackVariant(context: Context, variant: String, force: Boolean = false): Boolean {
        val dst = variantFile(context, variant)
        val usable = dst.isFile && dst.length() > MIN_SO_SIZE
        if (!force && usable) return true
        return try {
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            context.assets.open("$ASSET_SO_DIR/$variant.so").use { input ->
                tmp.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            if (tmp.length() <= 0L) {
                tmp.delete()
                dst.isFile && dst.length() > 0
            } else {
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    dst.isFile && dst.length() > 0
                } else {
                    true
                }
            }
        } catch (t: Throwable) {
            dst.isFile && dst.length() > 0
        }
    }

    private fun unpackLegacy(context: Context): Boolean {
        val dst = remoteFile(context)
        if (dst.isFile && dst.length() > 0) return true
        return try {
            dst.parentFile?.mkdirs()
            context.assets.open(LEGACY_ASSET).use { input ->
                dst.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            dst.length() > 0
        } catch (t: Throwable) {
            false
        }
    }

    /**
     * 把本机读进来的 so 落到私有目录。
     * 外部路径(比如 /sdcard/Download/xxx.so)目标进程未必打得开,所以统一先收进私有目录,
     * 再按进程注入的老路子往目标数据目录里搬。
     */
    fun importLocalSo(context: Context, input: InputStream, sourcePath: String?): File? {
        val dst = localFile(context)
        return try {
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            if (tmp.length() <= 0L) {
                tmp.delete()
                return null
            }
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) {
                tmp.delete()
                return null
            }
            InjectionPrefs.localSoSourcePath = sourcePath ?: dst.absolutePath
            InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_LOCAL
            InjectionPrefs.frameworkActive = false
            InjectionPrefs.frameworkError = null
            InjectionPrefs.frameworkPath = null
            refreshPrefs(context)
            dst
        } catch (t: Throwable) {
            null
        }
    }

    /** 切到内置变体 */
    fun useBuiltin(context: Context, variant: String) {
        InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
        InjectionPrefs.soVariant = variant
        // 换了 so,之前那次"已激活"就不算数了,得让目标重新加载
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null
        refreshPrefs(context)
    }

    /** 切到本机读进来的 so */
    fun useLocal(context: Context) {
        InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_LOCAL
        refreshPrefs(context)
    }

    fun clearLocal(context: Context) {
        try {
            localFile(context).delete()
        } catch (t: Throwable) {
        }
        InjectionPrefs.localSoSourcePath = null
        if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL) {
            InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
        }
        refreshPrefs(context)
    }

    /** 把"当前生效文件"的路径 / md5 / 版本名同步进偏好(注入链路都读这几个键) */
    fun refreshPrefs(context: Context) {
        val f = effectiveFile(context)
        InjectionPrefs.modulePath = f.absolutePath
        InjectionPrefs.moduleMd5 = if (f.isFile) Md5Util.md5(f) else null
        InjectionPrefs.moduleVersion = sourceLabel()
    }

    /** 把当前生效的 so 复制到目标自己的数据目录,进程注入靠它才能 dlopen 成功 */
    fun stageForTarget(context: Context, targetPkg: String): File? {
        val src = effectiveFile(context)
        if (!src.isFile || src.length() <= 0L) return null
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        val targetDir = File(dataDir, "files")
        if (!PermissionUtil.canWriteDir(targetDir)) return null
        val dst = File(targetDir, src.name)
        if (dst.isFile && Md5Util.md5(dst) == Md5Util.md5(src)) return dst
        return if (Md5Util.copyWithVerify(src, dst, Md5Util.md5(src))) dst else null
    }

    /**
     * 直接写不进目标目录时的兜底:先把自己的 so 放到 shell 能读到的地方,
     * 再用 root / Shizuku 的身份 cp 过去并改属主。两个特权通道都没有就返回 null。
     */
    fun stageForTargetPrivileged(context: Context, targetPkg: String): File? {
        val src = effectiveFile(context)
        if (!src.isFile || src.length() <= 0L) return null
        val dataDir = PackageUtil.dataDir(context, targetPkg) ?: return null
        val targetDir = File(dataDir, "files")
        val dst = File(targetDir, src.name)

        // shell 读不到我们的私有目录,先挪到外部目录
        val stagingDir = context.getExternalFilesDir(null) ?: context.cacheDir
        val staging = File(stagingDir, src.name)
        val copied = try {
            src.inputStream().use { i ->
                staging.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
            }
            true
        } catch (t: Throwable) {
            false
        }
        if (!copied) return null

        val uid = PackageUtil.uidOf(context, targetPkg)
        val command = buildString {
            append("mkdir -p ").append(shq(targetDir.absolutePath)).append(" && ")
            append("cp -f ").append(shq(staging.absolutePath)).append(' ')
            append(shq(dst.absolutePath)).append(" && ")
            append("chmod 0644 ").append(shq(dst.absolutePath))
            if (uid > 0) append(" && chown ").append(uid).append(':').append(uid)
                .append(' ').append(shq(dst.absolutePath))
            append(" && chcon u:object_r:app_data_file:s0 ").append(shq(dst.absolutePath))
            append(" 2>/dev/null; true")
        }
        val result = ShellUtil.execPrivileged(context, command, 20000L)
        return if (result != null && dst.isFile && dst.length() > 0L) dst else null
    }

    private fun shq(raw: String): String = "'" + raw.replace("'", "'\\''") + "'"

    /** 框架注入时,HookInit 从这里读 so 路径 */
    fun handoffFile(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "module_path.txt")

    data class Handoff(val path: String, val target: String, val variant: String)

    fun writeHandoff(context: Context, soPath: String, targetPkg: String) {
        val variant = sourceLabel()
        val body = buildString {
            appendLine(soPath)
            appendLine(targetPkg)
            appendLine(variant)
        }
        try {
            val f = handoffFile(context)
            f.parentFile?.mkdirs()
            f.writeText(body)
        } catch (t: Throwable) {
            // 外部目录不可写就退到私有目录,由 SoProvider 兜底
            try {
                File(context.filesDir, "module_path.txt").writeText(body)
            } catch (ignored: Throwable) {
            }
        }
    }

    fun readHandoff(context: Context): Handoff? {
        val candidates = listOf(
            handoffFile(context),
            File(context.filesDir, "module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val lines = f.readLines().filter { it.isNotBlank() }
                if (lines.isEmpty()) continue
                return Handoff(
                    path = lines[0].trim(),
                    target = (lines.getOrNull(1) ?: InjectionPrefs.targetPackage).trim(),
                    variant = (lines.getOrNull(2) ?: InjectionPrefs.soVariant).trim()
                )
            } catch (t: Throwable) {
            }
        }
        return null
    }
}
