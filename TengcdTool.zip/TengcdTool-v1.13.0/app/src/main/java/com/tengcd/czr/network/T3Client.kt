package com.tengcd.czr.network

import android.content.Context
import android.net.Uri
import android.os.Build
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * T3 网络验证的接入参数。
 */
data class T3Config(
    val baseUrl: String,
    val appId: String,
    val appKey: String,
    val aesKey: String,
    /** Base64 自定义编码集,必须 64 位 */
    val charset: String = T3Panel.B64_CHARSET,
    /** 请求体格式:官方只有 form,保留字段兼容老配置 */
    val format: String = "form"
) {
    /** 官方协议只要服务器地址;appid 是后台自己的标识,可留空 */
    val ready: Boolean
        get() = baseUrl.isNotBlank()

    companion object {
        /**
         * 正式接入参数:全部写死。
         * 界面上没有任何入口能改服务器 / appkey / 编码集,用户改不了,也不走本地卡密。
         */
        fun official(): T3Config = T3Config(
            baseUrl = T3Panel.SERVER,
            appId = "",
            appKey = T3Panel.APPKEY,
            aesKey = T3Panel.RC4_KEY,
            charset = T3Panel.B64_CHARSET,
            format = "form"
        )

        fun fromPrefs(): T3Config = T3Config(
            baseUrl = InjectionPrefs.t3BaseUrl,
            appId = InjectionPrefs.t3AppId,
            appKey = InjectionPrefs.t3AppKey,
            aesKey = InjectionPrefs.t3AesKey,
            charset = InjectionPrefs.t3Charset,
            format = InjectionPrefs.t3ReqFormat
        )
    }
}

/**
 * 一次验证请求的结果。登录 / 查询 / 解绑 / 心跳 / 公告 都用它。
 */
data class T3Result(
    val ok: Boolean,
    val message: String,
    val token: String = "",
    val expireAt: Long = 0L,
    val expireText: String = "",
    val remainCount: Int? = null,
    val unbindCount: Int? = null,
    /** 在线人数:后台没配在线统计接口时一直是 null */
    val onlineCount: Int? = null,
    /** 卡类型原文,后台 amount 字段,如 1年 / 30天 / 100次 */
    val cardType: String = "",
    /** 计次卡:后台给的是「次」而不是到期时间。计次卡不能随便重登,重登就扣次数。 */
    val isCountCard: Boolean = false,
    val boundDevice: String = "",
    val banned: Boolean = false,
    val expired: Boolean = false,
    val exhausted: Boolean = false,
    /** 服务端明确说这张卡不能用了(被踢/被封/过期),调用方应该退登 */
    val invalid: Boolean = false,
    val notice: String = "",
    /** 版本检测:服务端最新版本号 / 下载地址 / 更新日志 */
    val updateVersion: String = "",
    val updateUrl: String = "",
    val updateLog: String = "",
    /** 服务端确实给了业务响应(不是路径 404),探路时用来决定还要不要试下一个地址 */
    val reached: Boolean = false,
    val raw: String = ""
)

/**
 * T3 网络验证客户端:卡密登录、卡密查询、心跳保活、解绑设备、拉公告。
 *
 * 走的是 T3 官方协议:
 *   接口 = 验证服务器 + "/" + 调用码
 *   参数值 = HEX(自定义Base64(值)),签名 s = HEX(自定义Base64(md5(参数串 + appkey)))
 *   返回 = 自定义Base64 解码后是 JSON
 *
 * 验证服务器默认 w.t3yanzheng.com,官方还有 w2~w5 和 w.t3data.net 备用,
 * 一个连不上会自动换下一个。
 */
object T3Client {

    private const val ACTION_LOGIN = "login"
    private const val ACTION_QUERY = "query"
    private const val ACTION_QUERY_CARD = "querycard"
    private const val ACTION_ONLINE = "online"
    private const val ACTION_UNBIND = "unbind"
    private const val ACTION_HEARTBEAT = "heartbeat"
    private const val ACTION_NOTICE = "notice"
    private const val ACTION_LATEST = "latest"
    private const val ACTION_CHECKVER = "checkver"

    /** T3 官方验证服务器(全部是接口机,不是 www 官网) */
    private val OFFICIAL_SERVERS = listOf(
        "https://w.t3yanzheng.com",
        "https://w2.t3yanzheng.com",
        "https://w3.t3yanzheng.com",
        "https://w4.t3yanzheng.com",
        "https://w5.t3yanzheng.com",
        "https://w.t3data.net"
    )

    private const val UA = "TengcdTool/1.0 (Android)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    // ---------------- 对外接口 ----------------

    /** 卡密登录 */
    suspend fun login(
        context: Context,
        config: T3Config,
        card: String,
        deviceId: String
    ): T3Result {
        val direct = call(config, ACTION_LOGIN, card, deviceId, "")
        if (direct.ok) return direct

        // 登录接口不认这张卡时,再向「获取卡密状态信息」问一次。
        // 计次卡在部分 T3 后台不走登录接口(登录只对时间卡放行),
        // 后台自己都认为这张卡是有效的,就不能把用户挡在外面。
        val st = status(config, card)
        // 两边的结论拼一份:登录接口常给 token / 到期时间,状态接口才给次数和卡类型。
        // 计次卡最怕的就是「登录接口不认、状态接口认」时被丢掉次数信息,
        // 结果被当成时间卡,心跳一抖就重登、重登一次扣一次,几下次数就没了。
        val merged = mergeStatus(direct, st)
        if (st.ok) {
            return merged.copy(
                ok = true,
                invalid = false,
                message = "验证通过",
                token = direct.token.ifBlank { st.token }
            )
        }

        // 计次卡兜底:两个接口都没明确说「通过」,但返回里明确给了可用次数 > 0,
        // 说明后台认为这张卡是好的。别把用户挡在门外。
        if (merged.isCountCard && !merged.banned && !merged.expired && !merged.exhausted &&
            merged.remainCount != null && merged.remainCount > 0
        ) {
            return merged.copy(ok = true, invalid = false, message = "验证通过")
        }

        // 状态接口也只是「卡密不存在」这类硬失败时,把两个失败原因里更有信息量的给出来
        return if (st.reached && st.message.isNotBlank() && direct.message.isNotBlank()) {
            merged.copy(message = direct.message)
        } else {
            merged
        }
    }

    /**
     * 登录结果 + 卡密状态结果拼一份:成功与否以登录为准,
     * 次数 / 卡类型 / 到期时间各取第一个真正给了值的,别被空字段盖掉。
     */
    private fun mergeStatus(primary: T3Result, status: T3Result): T3Result {
        if (!status.reached && status.remainCount == null && status.cardType.isBlank()) {
            return primary
        }
        val countCard = primary.isCountCard || status.isCountCard ||
            status.cardType.contains("次") || primary.cardType.contains("次")
        return primary.copy(
            cardType = primary.cardType.ifBlank { status.cardType },
            isCountCard = countCard,
            remainCount = primary.remainCount ?: status.remainCount,
            unbindCount = primary.unbindCount ?: status.unbindCount,
            expireAt = if (primary.expireAt > 0L) primary.expireAt else status.expireAt,
            expireText = primary.expireText.ifBlank { status.expireText },
            boundDevice = primary.boundDevice.ifBlank { status.boundDevice },
            token = primary.token.ifBlank { status.token },
            banned = primary.banned || status.banned,
            expired = primary.expired || status.expired,
            exhausted = primary.exhausted || status.exhausted
        )
    }

    /**
     * 卡密状态(只读,不绑设备、不烧次数)。
     * 后台「获取卡密状态信息」接口,返回可用量 / 卡类型 / 到期时间。
     */
    suspend fun status(config: T3Config, card: String): T3Result =
        call(config, ACTION_QUERY_CARD, card, "", "")

    /** 卡密查询:到期时间 / 剩余次数 / 绑定设备 / 解绑次数 */
    suspend fun query(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result = withContext(Dispatchers.IO) {
        // 一次查询不是"发一个包就完事":后台不同接口返回的字段不一样,
        // 登录接口常带到期时间,查卡接口才带剩余次数 / 解绑次数。
        //
        // ⚠️ 但登录接口会绑设备、计次卡还会扣一次可用次数。
        // 以前这里每次都无脑打登录接口,计次卡点两下「查询」次数就白烧光,
        // 表现就是"计次卡用不了"。现在只在状态接口给不出结论时才走登录。
        val results = ArrayList<T3Result>()

        // ① 只读的状态接口:不绑设备、不烧次数
        val st = if (T3Panel.CODE_QUERY_CARD.isNotBlank()) {
            call(config, ACTION_QUERY_CARD, card, deviceId, token).also { results.add(it) }
        } else {
            null
        }

        // ② 状态接口没结论时,绝不再退回「登录」接口:
        //    登录接口会绑设备,计次卡还会实打实扣掉一次可用次数。
        //    以前这里一失败就打登录,用户点两下「查询」次数就没了,
        //    表现就是「次数卡用不了」。现在只用只读接口 + 心跳补数据。

        // ③ 在线人数单独问一次:它跟这张卡是否有效没关系,
        //    不能混进查询结果里,否则卡已经过期也会被它"带成有效"。
        val online = if (T3Panel.CODE_ONLINE.isNotBlank()) {
            runCatching { call(config, ACTION_ONLINE, card, "", "") }.getOrNull()
        } else {
            null
        }

        // ④ 前两个都没给出次数、手里又有 statecode 时,再走一次心跳把次数补全
        val gotCounts = results.any {
            it.ok && (it.remainCount != null || it.unbindCount != null)
        }
        if (!gotCounts && token.isNotBlank()) {
            results.add(call(config, ACTION_HEARTBEAT, card, deviceId, token))
        }

        val merged = mergeQueryResults(results)
        val onlineCount = online?.onlineCount ?: merged.onlineCount
        merged.copy(onlineCount = onlineCount)
    }

    /**
     * 把多次返回并成一份:状态以"成功的那个"为准,
     * 次数 / 到期 / 绑定设备各自取第一个真正给了值的,别被后一个空字段覆盖掉。
     */
    private fun mergeQueryResults(results: List<T3Result>): T3Result {
        if (results.isEmpty()) return T3Result(false, "查询失败", reached = false)

        val okResult = results.firstOrNull { it.ok }
        val base = okResult ?: results.first()
        if (okResult == null) {
            // 全都失败:优先把"服务端明确回了话"的那个原因带出来
            return results.firstOrNull { it.reached } ?: base
        }

        var remainCount: Int? = null
        var unbindCount: Int? = null
        var onlineCount: Int? = null
        var cardType = ""
        var expireAt = 0L
        var expireText = ""
        var boundDevice = ""
        var token = ""

        results.forEach { r ->
            if (remainCount == null && r.remainCount != null) remainCount = r.remainCount
            if (unbindCount == null && r.unbindCount != null) unbindCount = r.unbindCount
            if (onlineCount == null && r.onlineCount != null) onlineCount = r.onlineCount
            if (cardType.isBlank() && r.cardType.isNotBlank()) cardType = r.cardType
            if (expireAt == 0L && r.expireAt > 0L) expireAt = r.expireAt
            if (expireText.isBlank() && r.expireText.isNotBlank()) expireText = r.expireText
            if (boundDevice.isBlank() && r.boundDevice.isNotBlank()) boundDevice = r.boundDevice
            if (token.isBlank() && r.token.isNotBlank()) token = r.token
        }

        return base.copy(
            remainCount = remainCount,
            unbindCount = unbindCount,
            onlineCount = onlineCount,
            cardType = cardType,
            isCountCard = base.isCountCard ||
                results.any { it.isCountCard || it.cardType.contains("次") } ||
                // 没到期时间、只给了剩余次数,又不是「年/月/天/日」那种时长卡 —— 就是次数卡
                (expireText.isBlank() && remainCount != null &&
                    !cardType.contains("年") && !cardType.contains("月") &&
                    !cardType.contains("天") && !cardType.contains("日")),
            expireAt = expireAt,
            expireText = expireText,
            boundDevice = boundDevice,
            token = token.ifBlank { base.token }
        )
    }

    /** 解绑当前设备 */
    suspend fun unbind(
        config: T3Config,
        card: String,
        deviceId: String,
        token: String = ""
    ): T3Result = call(config, ACTION_UNBIND, card, deviceId, token)

    /** 心跳保活 */
    suspend fun heartbeat(
        config: T3Config,
        token: String,
        deviceId: String,
        card: String = ""
    ): T3Result = call(config, ACTION_HEARTBEAT, card, deviceId, token)

    /** 公告(不需要卡密,启动页也能拉) */
    suspend fun notice(config: T3Config, card: String = "", token: String = ""): T3Result =
        call(config, ACTION_NOTICE, card, "", token)

    /** 最新版序号 */
    suspend fun latestVersion(config: T3Config): T3Result =
        call(config, ACTION_LATEST, "", "", "")

    /** 检测版本是否最新版(ver = 客户端版本) */
    suspend fun checkVersion(config: T3Config, ver: String): T3Result =
        call(config, ACTION_CHECKVER, "", "", ver)

    /**
     * 检测更新:后台有新版就带回「版本号 / 下载地址 / 更新日志」。
     * 注意后台的返回码不能全信(它连本地版本比它还高也会回「有新版本」),
     * 到底是不是新版由调用方再按版本号比一遍。
     */
    suspend fun updateInfo(config: T3Config, localVersion: String): T3Result {
        // 本机版本为空时后台会直接回「版本号为不可空」,这里给个合法值兜住
        val local = localVersion.trim().ifBlank { "1" }

        // ① 检测版本是否最新版(FAE896FF9D204BEE):回 ver/version + upurl + uplog
        val checked = runCatching { call(config, ACTION_CHECKVER, "", "", local) }
            .getOrElse { T3Result(ok = false, message = "检测版本接口请求失败", reached = false) }

        var ver = pickVersion(checked.updateVersion, checked.message)
        var url = checked.updateUrl
        var log = checked.updateLog

        // ② 「获取最新版序号」(32BAF86A30D5CC25)无条件再打一次,不再"字段缺了才打":
        //    这个接口没有入参,版本号直接放在 msg 里(如 {"code":200,"msg":"1.1"}),
        //    老代码只从 ver/version 字段取,所以永远读不到版本号;
        //    而"字段缺了才补打"的写法一旦碰上接口抖动 / 超时,整次就什么都没了。
        //    现在两个接口每次都比一遍,谁有号用谁的,互相兜底。
        val latest = runCatching { call(config, ACTION_LATEST, "", "", "") }.getOrNull()
        if (latest != null) {
            if (ver.isBlank()) ver = pickVersion(latest.updateVersion, latest.message)
            if (url.isBlank()) url = latest.updateUrl
            if (log.isBlank()) log = latest.updateLog
        }

        return checked.copy(
            // 只要读到了版本号,这次检查就算有结果(否则调用方会以为整条请求失败)
            ok = checked.ok || ver.isNotBlank(),
            updateVersion = ver,
            updateUrl = url,
            updateLog = log,
            // 两个接口任意一个"服务器有业务响应",就说明网络是通的,
            // 调用方据此区分「网络没通」和「接口通了但后台没填版本号」
            reached = checked.reached || (latest?.reached ?: false)
        )
    }

    /**
     * 从若干候选里挑出「像版本号」的那个。
     * 后台的版本号可能出现在 ver / version 字段,也可能直接写在 msg 里,
     * 还可能写成「最新版本 1.11.1」「v1.11.1」这种话,所以统一按数字段捞。
     */
    private fun pickVersion(vararg candidates: String): String {
        for (raw in candidates) {
            val text = raw.trim().trim('"', '。', ' ')
            if (text.isBlank() || text.equals("ok", true) || text == "null") continue
            if (VERSION_RE.matches(text)) return text.removePrefix("v").removePrefix("V")
            // 「最新版本1.1」「版本号:1.1」这类话,捞出中间那段数字
            val hit = PLAIN_VERSION_RE.find(text)?.value ?: continue
            return hit
        }
        return ""
    }

    /** 纯版本号:v1.1 / 1.11.0 / 1 */
    private val VERSION_RE = Regex("^[vV]?\\d+(\\.\\d+){0,3}$")

    /** 长句里夹着的版本号,至少带一个小数点,免得把「返回码 200」当成版本号 */
    private val PLAIN_VERSION_RE = Regex("\\d+(\\.\\d+){1,3}")

    /**
     * 远端版本是不是比本地新。
     * 按数字段比,别用字符串比:字符串比的话 "1.9" < "1.10",会误判。
     * 段数不一样按 0 补齐(1.2 == 1.2.0)。
     */
    fun versionNewer(remote: String, local: String): Boolean {
        fun parts(v: String): List<Int> =
            Regex("\\d+").findAll(v.trim()).map { it.value.toIntOrNull() ?: 0 }.toList()

        val r = parts(remote)
        val l = parts(local)
        if (r.isEmpty() || l.isEmpty()) return false
        val size = maxOf(r.size, l.size)
        for (i in 0 until size) {
            val rv = r.getOrElse(i) { 0 }
            val lv = l.getOrElse(i) { 0 }
            if (rv != lv) return rv > lv
        }
        return false
    }

    /**
     * 后台版本号和本地版本号「对不上」。
     * 老板的要求是:后台把版本号一改,客户端认到版本号不符就直接弹公告框,
     * 所以这里比的是「是否一致」,不是「谁更新」——后台是几就得多几。
     * 段数不一样按 0 补齐(1.2 == 1.2.0),两边都解析不出数字时返回 false。
     */
    fun versionMismatch(remote: String, local: String): Boolean {
        fun parts(v: String): List<Int> =
            Regex("\\d+").findAll(v.trim()).map { it.value.toIntOrNull() ?: 0 }.toList()

        val r = parts(remote)
        val l = parts(local)
        if (r.isEmpty() || l.isEmpty()) return false
        val size = maxOf(r.size, l.size)
        for (i in 0 until size) {
            if (r.getOrElse(i) { 0 } != l.getOrElse(i) { 0 }) return true
        }
        return false
    }

    // ---------------- 请求调度 ----------------

    private suspend fun call(
        config: T3Config,
        action: String,
        card: String,
        deviceId: String,
        token: String
    ): T3Result = withContext(Dispatchers.IO) {
        val bases = serverCandidates(config.baseUrl)
        if (bases.isEmpty()) {
            return@withContext T3Result(false, "还没填验证服务器地址")
        }

        val code = T3Panel.codeOf(action)
        var last = T3Result(false, "连不上验证服务器", reached = false)

        for (base in bases) {
            val raw = post(
                url = join(base, code),
                params = buildParams(config, action, card, deviceId, token)
            )
            val parsed = parse(config, raw, action)
            if (parsed.ok) return@withContext parsed
            // 服务器已经给了业务响应(卡密不存在 / 过期 / 被封),不用再换服务器
            if (parsed.invalid || parsed.reached) return@withContext parsed
            last = parsed
        }
        last
    }

    /** 用户填的地址优先,填的是官方域名时把它后面几台备机也带上 */
    private fun serverCandidates(raw: String): List<String> {
        val list = ArrayList<String>()
        val base = raw.trim().trimEnd('/')
        if (base.isNotBlank()) list.add(base)
        if (base.isBlank() || base.contains("t3yanzheng.com") || base.contains("t3data.net")) {
            OFFICIAL_SERVERS.forEach { if (!list.contains(it)) list.add(it) }
        }
        return list
    }

    private fun join(base: String, code: String): String {
        val b = base.trim().trimEnd('/')
        return "$b/$code"
    }

    private fun buildParams(
        config: T3Config,
        action: String,
        card: String,
        deviceId: String,
        token: String
    ): Map<String, String> {
        val charset = config.charset
        val time = System.currentTimeMillis() / 1000L
        val params = LinkedHashMap<String, String>()

        // 各接口自己的参数(顺序要与签名串一致)
        when (action) {
            // 「获取卡密状态信息」只认 kami 一个参数,别把 imei 塞进去
            ACTION_QUERY_CARD -> {
                if (card.isNotBlank()) params[T3Panel.P_CARD] = card
            }
            ACTION_LOGIN, ACTION_QUERY -> {
                if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
            }
            // 在线数量接口没有入参
            ACTION_ONLINE -> Unit
            ACTION_UNBIND -> {
                if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
            }
            ACTION_HEARTBEAT -> {
                // T3 心跳接口的入参就是 statecode,多传反而可能被判参数错误
                if (token.isNotBlank()) {
                    params[T3Panel.P_STATE] = token
                } else {
                    if (card.isNotBlank()) params[T3Panel.P_CARD] = card
                    if (deviceId.isNotBlank()) params[T3Panel.P_DEVICE] = deviceId
                }
            }
            ACTION_CHECKVER -> params[T3Panel.P_VER] = token.ifBlank { "1" }
            else -> Unit
        }
        params["t"] = time.toString()

        // 值编码
        val encoded = LinkedHashMap<String, String>()
        params.forEach { (k, v) -> encoded[k] = T3Panel.encodeValue(v, charset) }

        // 签名:参数串 + &appkey
        val signSource = buildString {
            encoded.forEach { (k, v) -> append(k).append('=').append(v).append('&') }
            append(config.appKey.ifBlank { T3Panel.APPKEY })
        }
        val sign = T3Panel.encodeValue(Md5Util.md5(signSource), charset)

        val body = LinkedHashMap<String, String>()
        body.putAll(encoded)
        body["s"] = sign
        return body
    }

    private fun post(url: String, params: Map<String, String>): String {
        return try {
            val builder = FormBody.Builder()
            params.forEach { (k, v) -> builder.add(k, v) }
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "*/*")
                .post(builder.build() as RequestBody)
                .build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (text.isBlank()) "" else text
            }
        } catch (t: Throwable) {
            ""
        }
    }

    // ---------------- 返回解析 ----------------

    private fun parse(config: T3Config, raw: String, action: String): T3Result {
        val text = raw.trim()
        if (text.isEmpty()) {
            return T3Result(false, "服务器没有响应", reached = false)
        }

        var json = asJson(text)
        if (json == null) json = parseKv(text)
        if (json == null) json = decryptToJson(config, text)
        if (json == null) {
            if (text.contains("<html", true)) {
                return T3Result(false, "验证服务器地址不对(返回的是网页)", reached = false, raw = text.take(200))
            }
            if (T3Panel.usableCharset(config.charset)) {
                return T3Result(false, "返回内容解不开,检查后台 Base64 编码集(要 64 位)", reached = true, raw = text.take(200))
            }
            return T3Result(
                false,
                "返回内容解不开,检查后台 Base64 编码集(现在是 ${config.charset.trim().length} 位,要 64 位)",
                reached = true,
                raw = text.take(200)
            )
        }

        val flat = flatten(json)
        val code = firstInt(flat, "code", "status", "ret", "errcode", "err_no", "result")
        val msgRaw = firstString(flat, "msg", "message", "info", "errmsg", "tips", "error")
        // ⚠️ 这里绝不能认 "state":T3 的「获取卡密状态信息」接口会回 "state":"正常",
        // 老代码把它当会话凭证,心跳就把 "正常" 当 statecode 发出去,必然被判失效。
        val token = firstString(
            flat, "statecode", "state_code", "token", "access_token",
            "session", "sessionid", "sign_token"
        )
        val expireRaw = firstString(
            flat, "end_time", "expire_time", "expire", "expireTime", "endtime",
            "vip_time", "expiry", "expired_at", "due_time"
        )
        val expireAt = parseExpire(expireRaw)

        // 卡类型 / 可用量:后台真实返回是 amount="1年" / available=剩余次数(或剩余秒数)
        val amountText = firstString(
            flat, "amount", "card_type", "cardname", "type_name", "vip_name", "kami_type"
        )
        val availableRaw = firstInt(flat, "available", "available_count", "sy_count", "shengyu")

        // 次数卡判定:卡类型带「次」,提示语里写了次卡,或者后台压根没给有效到期时间、只给了可用量
        // (有些后台次数卡也会回 end_time=0 / 空,解析不出有效时间就按「没给」算)
        val countCard = amountText.contains("次") ||
            msgRaw.contains("次卡") ||
            msgRaw.contains("计次") ||
            (expireAt <= 0L && availableRaw != null)

        /** 服务端明确回了「成功」:计次卡登录成功时也会带「次」字,不能再被当成用完 */
        val successMsg = msgRaw.contains("成功") ||
            msgRaw.lowercase(Locale.US).contains("success")

        // 失败判定只认「明确的失败词」。
        // 老版本把「次数」+「用」当成次数用完了,次数卡登录成功时后台常回
        // 「登录成功,剩余可用次数 9」这种话,直接被误判成验证失败——这就是次数卡进不去的原因。
        val bannedMsg = flat.optBoolean("banned", false) ||
            flat.optInt("is_ban", 0) == 1 ||
            msgRaw.contains("封禁") ||
            msgRaw.contains("禁用", true) ||
            msgRaw.contains("冻结") ||
            msgRaw.lowercase(Locale.US).contains("banned")
        val expiredMsg = msgRaw.contains("已过期") ||
            msgRaw.contains("过期了") ||
            msgRaw.contains("卡密过期") ||
            msgRaw.contains("已到期") ||
            msgRaw.contains("卡已到期") ||
            msgRaw.lowercase(Locale.US).contains("expired")
        val exhaustedMsg = msgRaw.contains("次数不足") ||
            msgRaw.contains("次数已用完") ||
            msgRaw.contains("次数用完") ||
            msgRaw.contains("次数已耗尽") ||
            msgRaw.contains("次数耗尽") ||
            msgRaw.contains("次数用尽") ||
            msgRaw.contains("次数已用尽") ||
            msgRaw.contains("已用尽") ||
            msgRaw.contains("用完了") ||
            msgRaw.contains("已用完") ||
            msgRaw.contains("余额不足") ||
            msgRaw.lowercase(Locale.US).contains("no quota")

        val successFlag = when {
            flat.has("success") -> flat.optBoolean("success", false)
            flat.has("ok") -> flat.optBoolean("ok", false)
            else -> false
        }

        val noticeText = if (action == ACTION_NOTICE) extractNotice(flat) else ""

        // 剩余次数:不同后台字段名差得很远,常见的那几种都认
        val explicitCount = firstInt(
            flat,
            "remain", "remain_count", "remain_num", "remain_times", "remaining",
            "remaining_count", "surplus", "surplus_count", "left", "left_count",
            "balance", "count", "num", "times", "card_count", "use_count_left"
        )
        // 解绑次数(界面上已经不显示了,留着给内部判断)
        val unbindRaw = firstInt(
            flat,
            "change", "unbind_count", "unbind_times", "unbind_num", "unbind_remain",
            "unbind_remaining", "allow_unbind", "allow_unbind_times", "unbind",
            "rebind_count", "change_count"
        )
        // 只给了总次数 + 已用次数时,自己算剩余
        val computedCount = run {
            val total = firstInt(flat, "total", "total_times", "total_count")
            val used = firstInt(flat, "used", "used_count", "use_count", "used_times")
            if (total != null && used != null) (total - used).coerceAtLeast(0) else null
        }
        // 后台把次数写在提示语里(「剩余可用次数:9」)时兜一层
        val countFromMsg = Regex("剩余(?:可用)?次数[^0-9]{0,4}(\\d+)")
            .find(msgRaw)?.groupValues?.getOrNull(1)?.toIntOrNull()
            ?: Regex("剩余(\\d+)次").find(msgRaw)?.groupValues?.getOrNull(1)?.toIntOrNull()

        // 有的后台对计次卡不返回到期时间、也不给 amount,只把次数写在提示语里
        // (「登录成功,剩余可用次数 9」)。这种同样是次数卡,绝不能当时间卡处理——
        // 一旦当时间卡,心跳一抖就会自动重登,而计次卡每重登一次就扣一次可用次数。
        val isCountCard = countCard ||
            (expireAt <= 0L && (availableRaw != null || countFromMsg != null ||
                firstInt(flat, "remain", "remain_count", "remain_times", "surplus", "balance") != null))

        val remainCount = when {
            explicitCount != null -> explicitCount
            // available 是"次数"还是"秒数"要分开看:时间卡给的是剩余秒数(三十多年那种千万级大数),
            // 计次卡给的是几十/几百。小于 10 万的按次数算,别一律当成时间卡的"不限"。
            availableRaw != null && availableRaw in 0..100000 -> availableRaw
            isCountCard -> computedCount ?: countFromMsg
            // 时间卡没有次数概念:后台没给明确次数就是这段时间内不限
            expireAt > 0L -> -1
            else -> computedCount ?: countFromMsg
        }

        // 计次卡的剩余次数为 0 才算用完,而且服务端说「成功」或返回码 200 时一律不作数——
        // 计次卡登录成功后剩余次数可能就是 0(最后一次),这时候人还是能用的。
        val exhausted = exhaustedMsg ||
            (!successMsg && code != 200 && isCountCard && remainCount != null && remainCount <= 0)
        val expired = expiredMsg
        val banned = bannedMsg

        // T3 成功只认 code=200(或显式 success/ok)。
        // 卡密不存在是 201,机器码不符/过期是 202/203,这些绝对不能放进去。
        val ok = when {
            banned || expired || exhausted -> false
            successFlag -> true
            code == 200 -> true
            code == null -> token.isNotBlank() || noticeText.isNotBlank() ||
                flat.has("end_time") || flat.has("expire_time") || flat.has("remain") ||
                flat.has("available")
            // 计次卡:后台既然回了「还能用几次」并且次数 > 0,这张卡就是好的,
            // 别因为返回码不是 200、或者提示语措辞对不上就把它判死
            isCountCard && remainCount != null && remainCount > 0 &&
                (availableRaw != null || explicitCount != null || countFromMsg != null) -> true
            // 个别后台给计次卡回的是「登录成功」+ code 空/0,留一条保守的放行口
            successMsg && isCountCard && (token.isNotBlank() || availableRaw != null) -> true
            else -> false
        }

        val reached = flat.has("code") || flat.has("status") || flat.has("msg") ||
            flat.has("message") || successFlag || token.isNotBlank() || noticeText.isNotBlank()

        val message = msgRaw.trim().ifBlank {
            when {
                ok -> "ok"
                code != null -> "验证失败(返回码 $code)"
                else -> "验证失败"
            }
        }

        val invalid = !ok && (
            code == 401 || code == 402 || code == 403 || code == 404 || code == 410 ||
                code == 301 || code == 302 ||
                (code != null && code > 200 && code < 300) ||
                banned || expired || exhausted
            )

        // 在线人数:后台「获取在线卡密数量」直接返回 {"code":200,"msg":"7"},
        // 数字在 msg 里,所以字段取不到时再从 msg 兜一层。
        val onlineCount = if (action == ACTION_ONLINE) {
            firstInt(
                flat, "online", "online_count", "online_num", "onlinecount",
                "online_number", "num_online", "people_online", "people", "total_online",
                "count", "num", "total"
            ) ?: msgRaw.trim().let { m ->
                Regex("\\d+").find(m)?.value?.toIntOrNull()
            }
        } else {
            null
        }

        // 版本检测的返回:ver/version = 最新版本号,upurl = 下载地址,uplog = 更新日志
        val updateVer = firstString(
            flat, "ver", "version", "new_version", "newver", "latest_version", "latest"
        )
        val updateUrl = firstString(
            flat, "upurl", "downurl", "download_url", "download", "update_url", "apk_url", "url"
        )
        val updateLog = firstString(
            flat, "uplog", "update_log", "updatelog", "upgrade_log", "upgradelog", "describe", "changelog"
        )

        return T3Result(
            ok = ok,
            message = message,
            token = token,
            expireAt = expireAt,
            expireText = formatExpire(expireAt, expireRaw),
            remainCount = remainCount,
            unbindCount = unbindRaw,
            onlineCount = onlineCount,
            cardType = amountText,
            isCountCard = isCountCard,
            updateVersion = updateVer,
            updateUrl = updateUrl,
            updateLog = updateLog,
            boundDevice = firstString(
                flat, "imei", "device", "machine_code", "bound_device", "bind_device", "device_id"
            ),
            banned = banned,
            expired = expired,
            exhausted = exhausted,
            invalid = invalid,
            notice = noticeText,
            reached = reached,
            raw = text.take(400)
        )
    }

    private fun asJson(text: String): JSONObject? {
        if (!text.startsWith("{")) return null
        return try {
            JSONObject(text)
        } catch (t: Throwable) {
            null
        }
    }

    /** code=0&msg=ok&token=xxx 这种老式返回 */
    private fun parseKv(text: String): JSONObject? {
        if (!text.contains("=") || text.contains("<")) return null
        return try {
            val json = JSONObject()
            text.split("&").forEach { pair ->
                val idx = pair.indexOf('=')
                if (idx > 0) {
                    json.put(pair.substring(0, idx), pair.substring(idx + 1))
                }
            }
            if (json.length() == 0) null else json
        } catch (t: Throwable) {
            null
        }
    }

    /** 整体加密的返回:自定义 Base64 / RC4 都试一遍 */
    private fun decryptToJson(config: T3Config, raw: String): JSONObject? {
        val plain = T3Panel.decodePayload(raw, config.charset) ?: return null
        return asJson(plain) ?: parseKv(plain)
    }

    /** data 字段可能是对象也可能是字符串,统一摊平到一层 */
    private fun flatten(json: JSONObject): JSONObject {
        val out = JSONObject(json.toString())
        val data = json.optJSONObject("data")
        if (data != null) {
            val keys = data.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (!out.has(key)) out.put(key, data.get(key))
            }
        } else {
            val dataText = json.optString("data")
            if (dataText.startsWith("{")) {
                try {
                    val inner = JSONObject(dataText)
                    val keys = inner.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (!out.has(key)) out.put(key, inner.get(key))
                    }
                } catch (t: Throwable) {
                    // data 就是一串文本,不用管
                }
            }
        }
        return out
    }

    private fun firstString(json: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = json.optString(key)
            if (value.isNotBlank() && value != "null") return value.trim()
        }
        return ""
    }

    private fun firstInt(json: JSONObject, vararg keys: String): Int? {
        for (key in keys) {
            if (!json.has(key)) continue
            val value = json.opt(key)
            val num = when (value) {
                is Number -> value.toInt()
                is String -> value.trim().toIntOrNull()
                else -> null
            }
            if (num != null) return num
        }
        return null
    }

    private fun extractNotice(json: JSONObject): String {
        val direct = firstString(
            json, "notice", "announcement", "gonggao", "content", "text", "notice_content"
        )
        if (direct.isNotBlank()) return cleanNotice(direct)
        val data = json.optString("data")
        if (data.isNotBlank() && data != "null") return cleanNotice(data)
        val msg = firstString(json, "msg", "message", "info")
        return if (msg.isNotBlank() && msg != "ok") cleanNotice(msg) else ""
    }

    private fun cleanNotice(text: String): String = text
        .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
        .replace(Regex("</p>", RegexOption.IGNORE_CASE), "\n")
        .replace(Regex("<[^>]+>"), "")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .trim()

    private fun parseExpire(raw: String): Long {
        val value = raw.trim()
        if (value.isEmpty() || value == "0" || value.equals("null", true)) return 0L
        value.toLongOrNull()?.let { num ->
            return if (num > 10_000_000_000L) num else num * 1000L
        }
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd",
            "yyyy/MM/dd HH:mm:ss",
            "yyyy/MM/dd"
        )
        for (pattern in patterns) {
            try {
                val format = SimpleDateFormat(pattern, Locale.CHINA)
                format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
                val date = format.parse(value) ?: continue
                return date.time
            } catch (t: Throwable) {
                // 换下一个格式
            }
        }
        return 0L
    }

    private fun formatExpire(expireAt: Long, raw: String): String {
        if (expireAt <= 0L) return raw.trim()
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
            format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
            format.format(expireAt)
        } catch (t: Throwable) {
            raw.trim()
        }
    }

    /** 设备指纹:优先用系统给的 ANDROID_ID 派生的那个 */
    fun deviceId(context: Context): String = try {
        LocalCardGate.deviceId(context)
    } catch (t: Throwable) {
        val fallback = (Build.MODEL.orEmpty() + Build.BRAND.orEmpty() + Build.ID.orEmpty())
        Md5Util.md5(fallback).take(16).uppercase(Locale.US)
    }

    /** 展示用:把域名裁一裁,别在界面上撑爆一行 */
    fun prettyHost(url: String): String {
        if (url.isBlank()) return "-"
        return try {
            Uri.parse(url).host ?: url
        } catch (t: Throwable) {
            url
        }
    }
}

/** 把 T3 的返回换成卡密页要展示的那一份信息 */
fun T3Result.toCardInfo(card: String): CardQueryInfo = CardQueryInfo(
    card = card,
    expireTime = expireText,
    remainCount = remainCount,
    unbindCount = unbindCount,
    onlineCount = onlineCount,
    cardType = cardType,
    isCountCard = isCountCard,
    boundDevice = boundDevice,
    banned = banned,
    valid = ok,
    message = when {
        ok -> message
        banned -> "banned"
        expired -> "expired"
        exhausted -> "count_exhausted"
        else -> message
    }
)
