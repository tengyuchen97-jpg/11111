package com.tengcd.czr

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.i18n.Strings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.inject.PtraceInjectFailure
import com.tengcd.czr.network.AuthMode
import com.tengcd.czr.network.CardQueryInfo
import com.tengcd.czr.network.LocalCardGate
import com.tengcd.czr.network.T3Client
import com.tengcd.czr.network.T3Config
import com.tengcd.czr.network.T3Panel
import com.tengcd.czr.network.T3Result
import com.tengcd.czr.network.toCardInfo
import com.tengcd.czr.service.HandoffWakeReceiver
import com.tengcd.czr.service.InjectService
import com.tengcd.czr.ui.message
import com.tengcd.czr.util.ConfigFile
import com.tengcd.czr.util.FolderImporter
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Links
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.util.PermissionUtil
import com.tengcd.czr.util.ServiceState
import com.tengcd.czr.util.ShareCodec
import com.tengcd.czr.util.ShizukuShell
import com.tengcd.czr.util.ShellUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

private const val HEARTBEAT_INTERVAL_MS = 3 * 60 * 1000L

/** 目标应用运行状态轮询间隔 */
private const val RUNTIME_WATCH_INTERVAL_MS = 2000L

/** 公告接口挂了、本地又没缓存时的兜底文案,保证公告栏永远不是空白 */
private const val DEFAULT_NOTICE = "暂无公告内容,点右上角「刷新」重新拉取。"

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    /** 心跳任务 */
    private var heartbeatJob: Job? = null

    /** 目标应用运行状态轮询任务 */
    private var watchJob: Job? = null

    val strings: LocalizedStrings by lazy { Strings.of(Locale.getDefault().language) }

    init {
        val ctx = getApplication<Application>()
        InjectionPrefs.init(ctx)
        ModuleStore.ensureBundled(ctx)
        ServiceState.syncFromPrefs()

        _state.update {
            it.copy(
                darkTheme = InjectionPrefs.darkTheme,
                mode = InjectionMode.from(InjectionPrefs.injectionMode),
                cardKey = InjectionPrefs.cardKey,
                localCardMode = InjectionPrefs.localCardMode,
                targetPackage = InjectionPrefs.targetPackage,
                importTargetPath = InjectionPrefs.importTargetPath
                    .ifBlank { FolderImporter.DEFAULT_TARGET_PATH },
                importReplaceAll = InjectionPrefs.importReplaceAll,
                loginCard = InjectionPrefs.t3Card,
                loginToken = "",
                machineCode = runCatching { LocalCardGate.deviceId(ctx) }.getOrDefault(""),
                remainCount = InjectionPrefs.t3RemainCount,
                cardTypeText = InjectionPrefs.t3CardType,
                // 每次启动都停在验证页:卡密会带出来预填,但必须自己再点一次「登录」才放行,
                // 不再拿上次的会话直接进主界面。
                loggedIn = false
            )
        }

        restoreImportDirs()
        observeServiceState()
        InjectService.start(ctx)
        refreshRuntime()
        startRuntimeWatch()
        // 启动不再自动续会话(不静默登录、不自动心跳):
        // 要求每次进来都必须手输卡密 + 点登录才算验证通过。
        refreshNotice(silent = true)
        checkUpdate(silent = true)
    }

    // ---------------- 对外入口 ----------------

    fun onAction(action: UiAction) {
        when (action) {
            is UiAction.SelectTab -> _state.update { it.copy(tab = action.tab) }
            UiAction.ToggleTheme -> {
                val next = !_state.value.darkTheme
                InjectionPrefs.darkTheme = next
                _state.update { it.copy(darkTheme = next) }
            }
            UiAction.Inject -> inject()
            UiAction.InjectAndLaunch -> injectAndLaunch()
            UiAction.LaunchTarget -> launchTarget()
            UiAction.RefreshRuntime -> refreshRuntime()
            UiAction.StartService -> InjectService.start(getApplication())
            is UiAction.SetMode -> {
                InjectionPrefs.injectionMode = action.mode.value
                _state.update { it.copy(mode = action.mode) }
            }
            is UiAction.SelectSoVariant -> selectSoVariant(action.variant)
            UiAction.PickLocalSo -> emit(UiEvent.PickLocalSoFile)
            UiAction.UseBuiltinSo -> useBuiltinSo()
            UiAction.UseLocalSo -> useLocalSo()
            UiAction.ClearLocalSo -> clearLocalSo()
            is UiAction.CardKeyChanged -> _state.update { it.copy(cardKey = action.text) }
            UiAction.QueryCard -> queryCard()
            UiAction.UnbindCard -> unbindCard()
            UiAction.GenerateShareCode -> generateShareCode()
            UiAction.DismissDialog -> Unit
            UiAction.PickImportSource -> pickImportDir(forTarget = false)
            UiAction.PickImportTarget -> pickImportDir(forTarget = true)
            is UiAction.SetImportPath -> setImportPath(action.forTarget, action.path)
            UiAction.ClearImportSource -> clearImportSource()
            UiAction.ToggleImportReplaceAll -> {
                val next = !_state.value.importReplaceAll
                InjectionPrefs.importReplaceAll = next
                _state.update { it.copy(importReplaceAll = next) }
            }
            UiAction.RunImport -> runImport()
            is UiAction.SwitchImportPage -> switchImportPage(action.index)
            UiAction.ReadImportParams -> readImportParams()
            is UiAction.ImportParamsChanged -> _state.update {
                it.copy(importParamText = action.text, importParamMessage = null)
            }
            UiAction.SaveImportParams -> saveImportParams()
            UiAction.GrantShizuku -> grantShizuku()
            is UiAction.LoginCardChanged ->
                _state.update { it.copy(loginCard = action.text, loginError = null) }
            UiAction.Login -> login()
            UiAction.Logout -> logout()
            UiAction.RefreshNotice -> {
                refreshNotice()
                checkUpdate(silent = false)
            }
            UiAction.CheckUpdate -> checkUpdate(silent = false)
            UiAction.ShowUpdate -> showUpdateDialog()
        }
    }

    // ---------------- T3 网络验证 ----------------

    /** 上次的 token 还没过期就直接进首页 */
    private fun tokenStillValid(): Boolean {
        val token = InjectionPrefs.t3Token
        // 有的后台登录只回「验证通过」不给 statecode,登录态靠 t3Verified 记住
        if (token.isBlank() && !InjectionPrefs.t3Verified) return false
        val expire = InjectionPrefs.t3Expire
        return expire <= 0L || expire > System.currentTimeMillis()
    }

    /**
     * 会话还可用吗。
     * 现在这条只用于「登录之后」的内部判断:启动时一律回验证页,
     * 每次都要手输卡密点登录,不再自动放行。
     */
    private fun sessionUsable(): Boolean {
        if (InjectionPrefs.t3Card.isBlank()) return false
        return InjectionPrefs.t3Token.isNotBlank() || InjectionPrefs.t3Verified
    }

    /** 启动时静默续一次会话:能续上就续,网络不通就保持原样,不打扰用户 */
    private fun silentReLogin() {
        val config = T3Config.official()
        if (!config.ready) return
        val card = InjectionPrefs.t3Card
        if (card.isBlank()) return
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = runCatching {
                T3Client.login(ctx, config, card, T3Client.deviceId(ctx))
            }.getOrNull() ?: return@launch
            when {
                result.ok -> applyLoginState(result, card, silent = true)
                // 服务端明确说这张卡废了(封禁 / 过期 / 次数用完)才踢回验证页
                result.banned || result.expired || result.exhausted ->
                    forceLogout(result.message.ifBlank { strings.cardInvalid })
                // 其余(网络抖动、接口暂时不通)保持登录态,等心跳慢慢恢复
            }
        }
    }

    /** 登录成功后的统一落盘 + 界面更新(手动登录和静默续期共用) */
    private fun applyLoginState(result: T3Result, card: String, silent: Boolean) {
        InjectionPrefs.t3Token = result.token
        InjectionPrefs.t3Verified = true
        // 次数卡判定要落准:只要后台给了「剩余次数」而没给有效到期时间,
        // 就当次数卡存。存错了心跳一抖就会自动重登,重登一次扣一次,次数几下就没了。
        val countCard = result.isCountCard ||
            result.cardType.contains("次") ||
            (result.remainCount != null && result.expireAt <= 0L && result.expireText.isBlank())
        InjectionPrefs.t3CountCard = countCard
        // 服务端没返回到期时间时给个保守期限,免得一次登录就能永久离线使用。
        // 计次卡后台不给到期时间,而且每重登一次就扣一次可用次数:
        // 宽限给足 30 天,别让用户天天因为"重登"把次数烧光。
        val graceDays = if (countCard) 30L else 1L
        InjectionPrefs.t3Expire = if (result.expireAt > 0L) {
            result.expireAt
        } else {
            System.currentTimeMillis() + graceDays * 24L * 60L * 60L * 1000L
        }
        InjectionPrefs.t3Card = card
        InjectionPrefs.cardKey = card
        // 次数只在登录回包里出现(状态接口只给剩余秒数),所以这一份必须存下来,
        // 否则一点「查询」/一重启,界面上就变成"不限",用户以为卡没生效。
        if (result.remainCount != null && result.remainCount > 0) {
            InjectionPrefs.t3RemainCount = result.remainCount
            InjectionPrefs.t3RemainTime = nowText()
        }
        if (result.cardType.isNotBlank()) InjectionPrefs.t3CardType = result.cardType
        val machine = runCatching { LocalCardGate.deviceId(getApplication()) }.getOrDefault("")
        if (machine.isNotBlank()) InjectionPrefs.t3MachineCode = machine
        // 记住这张卡:下次打开直接进,不再弹验证页
        InjectionPrefs.t3AutoLogin = true
        InjectionPrefs.t3LoginAt = System.currentTimeMillis()
        _state.update {
            it.copy(
                loginBusy = false,
                loggedIn = true,
                loginError = null,
                loginToken = result.token,
                machineCode = machine,
                remainCount = if (result.remainCount != null && result.remainCount > 0)
                    result.remainCount else InjectionPrefs.t3RemainCount,
                cardTypeText = result.cardType.ifBlank { InjectionPrefs.t3CardType },
                // 计次卡没有到期时间:账号那行显示剩余次数,别显示个空白
                loginExpire = when {
                    countCard && result.remainCount != null ->
                        strings.remainCount + " " + result.remainCount
                    result.expireText.isNotBlank() -> result.expireText
                    countCard -> strings.expireByCount
                    else -> it.loginExpire
                },
                cardKey = card,
                cardInfo = result.toCardInfo(card),
                tab = AppTab.HOME
            )
        }
        startHeartbeat()
        if (!silent) {
            emit(UiEvent.Toast(strings.loginSuccess))
            refreshNotice(silent = true)
            refreshRuntime()
            // 登录后顺手查一次更新:一进主界面就能看到有没有新版
            checkUpdate(silent = true)
        }
    }



    /** 本地卡密版的登录:不走网络,LocalCardGate 比对通过就放行 */
    private fun localLogin(card: String) {
        val ctx = getApplication<Application>()
        _state.update { it.copy(loginBusy = true, loginError = null) }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { LocalCardGate.bind(ctx, card) }
            val info = withContext(Dispatchers.IO) { LocalCardGate.query(ctx, card) }
            if (ok) {
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loggedIn = true,
                        loginError = null,
                        loginToken = "local",
                        loginExpire = info.expireTime.ifBlank { "永久" },
                        cardKey = card,
                        cardInfo = info,
                        tab = AppTab.HOME
                    )
                }
                emit(UiEvent.Toast(strings.loginSuccess))
                refreshRuntime()
            } else {
                val msg = when (info.message) {
                    "empty" -> strings.loginEmpty
                    "expired" -> strings.expired
                    "count_exhausted" -> strings.countExhausted
                    else -> strings.cardInvalid
                }
                _state.update { it.copy(loginBusy = false, loginError = msg) }
            }
        }
    }

    private fun login() {
        val cur = _state.value
        if (cur.loginBusy) return
        val card = cur.loginCard.trim()
        if (card.isEmpty()) {
            _state.update { it.copy(loginError = strings.loginEmpty) }
            return
        }
        // 本地卡密版:不联网,直接在本地比对
        if (AuthMode.LOCAL_CARD) {
            localLogin(card)
            return
        }
        // 服务器地址 / appkey / 编码集全部写死,界面没有任何修改入口
        val config = T3Config.official()
        if (!config.ready) {
            _state.update { it.copy(loginError = strings.loginNeedServer) }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(loginBusy = true, loginError = null) }
            val ctx = getApplication<Application>()
            // 机器码要挨个试:老版本算机器码时拼了「目标包名」,后台那边绑的多半是
            // 「还没选目标」时算出来的那一串。升级后如果只拿新算的那串去登录,
            // 后台统一判「请在原设备登录」——这就是"卡密一直不行"的来源。
            // 这里按「已经验证过的那串 → 老算法(空目标) → 老算法(当前目标) → 新稳定算法」顺序试,
            // 谁通了就把那串记下来,以后心跳/查询/登录全用它,不再漂。
            val candidates = LocalCardGate.deviceCandidates(ctx)
            var result: T3Result? = null
            for (code in candidates) {
                if (!viewModelScope.isActive) break
                val r = T3Client.login(ctx, config, card, code)
                result = r
                if (r.ok) {
                    if (InjectionPrefs.t3MachineCode != code) InjectionPrefs.t3MachineCode = code
                    break
                }
                // 只有「设备不符 / 卡不存在」这类跟机器码有关的失败才继续换下一串;
                // 已经明确过期 / 封禁 / 次数用完就没必要再试了。
                if (r.expired || r.banned || r.exhausted) break
            }
            val done = result
            if (done != null && done.ok) {
                applyLoginState(done, card, silent = false)
            } else if (done == null) {
                _state.update { it.copy(loginBusy = false, loginError = strings.loginFailed) }
            } else {
                _state.update {
                    it.copy(
                        loginBusy = false,
                        loginError = done.message.ifBlank { strings.loginFailed }
                    )
                }
            }
        }
    }

    private fun logout(requestServer: Boolean = true) {
        stopHeartbeat()
        viewModelScope.launch {
            val config = T3Config.official()
            val token = InjectionPrefs.t3Token
            val ctx = getApplication<Application>()
            if (!AuthMode.LOCAL_CARD && requestServer && config.ready && token.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        T3Client.heartbeat(config, token, T3Client.deviceId(ctx), InjectionPrefs.t3Card)
                    }
                }
            }
            InjectionPrefs.t3Token = ""
            InjectionPrefs.t3Expire = 0L
            InjectionPrefs.t3Verified = false
            // 主动退出验证 = 不再自动进(卡密还留在输入框里,免得下次要重新找卡)
            InjectionPrefs.t3AutoLogin = false
            _state.update {
                it.copy(
                    loggedIn = false,
                    loginToken = "",
                    loginExpire = "",
                    loginError = null,
                    tab = AppTab.HOME,
                    cardInfo = null
                )
            }
        }
    }

    /** 服务端说卡不能用了:直接踢回验证页,别再让人以为还登着 */
    private fun forceLogout(reason: String) {
        stopHeartbeat()
        InjectionPrefs.t3Token = ""
        InjectionPrefs.t3Expire = 0L
        InjectionPrefs.t3Verified = false
        _state.update {
            it.copy(
                loggedIn = false,
                loginToken = "",
                loginExpire = "",
                cardInfo = null,
                tab = AppTab.HOME,
                loginError = reason.ifBlank { strings.loginFailed }
            )
        }
        emit(UiEvent.Toast(reason.ifBlank { strings.loginFailed }))
    }

    // ---------------- 心跳 / 公告 ----------------

    /** 心跳:每 3 分钟问一次,连不上 3 次才踢,被服务端明确判死立刻踢 */
    private fun startHeartbeat() {
        stopHeartbeat()
        if (AuthMode.LOCAL_CARD) return   // 本地版没有心跳,不联网
        heartbeatJob = viewModelScope.launch {
            var fails = 0
            while (isActive) {
                delay(HEARTBEAT_INTERVAL_MS)
                val config = T3Config.official()
                val token = InjectionPrefs.t3Token
                // 没 token 但有验证标记的(后台只回「验证通过」那种)用卡密当会话凭证继续心跳
                if (!config.ready) break
                if (token.isBlank() && !InjectionPrefs.t3Verified) break
                val ctx = getApplication<Application>()
                val result = runCatching {
                    T3Client.heartbeat(config, token, T3Client.deviceId(ctx), InjectionPrefs.t3Card)
                }.getOrNull()

                if (result == null) {
                    fails++
                    if (fails >= 3) {
                        forceLogout(strings.checkNetwork)
                        break
                    }
                    continue
                }
                if (result.ok) {
                    fails = 0
                    if (result.expireAt > 0L) InjectionPrefs.t3Expire = result.expireAt
                    // 心跳有时也会把剩余次数带回来(不同后台不一样),有就更新缓存,
                    // 这样次数卡的界面能跟上真实剩余量。
                    if (result.remainCount != null && result.remainCount > 0) {
                        InjectionPrefs.t3RemainCount = result.remainCount
                        InjectionPrefs.t3RemainTime = nowText()
                        if (result.isCountCard) InjectionPrefs.t3CountCard = true
                    }
                    _state.update { cur ->
                        val info = cur.cardInfo
                        cur.copy(
                            loginExpire = result.expireText.ifBlank { cur.loginExpire },
                            remainCount = result.remainCount?.takeIf { it > 0 } ?: cur.remainCount,
                            cardInfo = info?.copy(
                                expireTime = result.expireText.ifBlank { info.expireTime },
                                remainCount = result.remainCount?.takeIf { it > 0 } ?: info.remainCount,
                                unbindCount = result.unbindCount ?: info.unbindCount,
                                boundDevice = result.boundDevice.ifBlank { info.boundDevice }
                            )
                        )
                    }
                } else if (result.invalid) {
                    // 计次卡绝对不能在这里自动重登:每登一次就扣一次可用次数,
                    // 后台心血来潮把会话判失效一下,用户的次数就被后台和自己一起烧光。
                    // 次数卡只停心跳、保留登录态,下次手动点「验证」再说。
                    if (InjectionPrefs.t3CountCard || InjectionPrefs.t3Card.isBlank()) {
                        InjectionPrefs.t3Verified = true
                        break
                    }
                    // 时间卡:服务端说这次心跳不认了,先拿存着的卡密静默重登一次,
                    // 能续上就接着用,别直接把人踢回验证页。
                    val retry = runCatching {
                        T3Client.login(
                            ctx, config, InjectionPrefs.t3Card, T3Client.deviceId(ctx)
                        )
                    }.getOrNull()
                    if (retry != null && retry.ok) {
                        InjectionPrefs.t3Token = retry.token
                        if (retry.expireAt > 0L) InjectionPrefs.t3Expire = retry.expireAt
                        if (retry.isCountCard) InjectionPrefs.t3CountCard = true
                        fails = 0
                        _state.update { cur ->
                            val info = cur.cardInfo
                            cur.copy(
                                loginToken = retry.token,
                                cardInfo = info?.copy(
                                    remainCount = retry.remainCount ?: info.remainCount,
                                    boundDevice = retry.boundDevice.ifBlank { info.boundDevice }
                                )
                            )
                        }
                        continue
                    }
                    forceLogout(result.message)
                    break
                } else {
                    fails++
                    if (fails >= 3) {
                        // 次数卡:心跳连不上就停心跳,但绝不踢回验证页,更不自动重登
                        // (重登一次扣一次次数,网络抖一下就白烧几次)。
                        if (InjectionPrefs.t3CountCard) {
                            break
                        }
                        forceLogout(result.message)
                        break
                    }
                }
            }
        }
    }

    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    /** 公告:走 T3 的公告接口,拉不到就显示上次缓存的 */
    private fun refreshNotice(silent: Boolean = false) {
        if (AuthMode.LOCAL_CARD) {
            // 本地卡密版也要有公告:先把上次缓存的那份铺上(断网也有内容),
            // 再后台静默拉一次最新的。拉不到就保持缓存,不影响进 App。
            val cached = InjectionPrefs.t3NoticeCache
            _state.update {
                it.copy(
                    announcement = cached.ifBlank { AuthMode.LOCAL_NOTICE },
                    announcementUpdated = InjectionPrefs.t3NoticeTime,
                    announcementLoading = false,
                    announcementFailed = false
                )
            }
            viewModelScope.launch {
                val config = T3Config.official()
                if (!config.ready) return@launch
                val result = runCatching {
                    T3Client.notice(config, InjectionPrefs.t3Card, InjectionPrefs.t3Token)
                }.getOrNull()
                if (result != null && result.ok && result.notice.isNotBlank()) {
                    InjectionPrefs.t3NoticeCache = result.notice
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = result.notice,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
            }
            return
        }
        val config = T3Config.official()
        val cached = InjectionPrefs.t3NoticeCache
        _state.update {
            it.copy(
                announcement = it.announcement ?: cached.ifBlank { null },
                announcementUpdated = InjectionPrefs.t3NoticeTime,
                announcementLoading = true,
                announcementFailed = false
            )
        }
        viewModelScope.launch {
            if (!config.ready) {
                _state.update {
                    it.copy(
                        announcementLoading = false,
                        announcementFailed = cached.isBlank() && !silent
                    )
                }
                return@launch
            }
            val result = runCatching {
                T3Client.notice(config, InjectionPrefs.t3Card, InjectionPrefs.t3Token)
            }.getOrNull()

            when {
                result == null || !result.ok -> {
                    _state.update {
                        it.copy(
                            announcementLoading = false,
                            announcement = cached.ifBlank { it.announcement ?: DEFAULT_NOTICE },
                            announcementFailed = false
                        )
                    }
                }
                result.notice.isBlank() -> {
                    // 接口通了,后台没写公告
                    InjectionPrefs.t3NoticeCache = ""
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = null,
                            announcementLoading = false,
                            announcementFailed = false,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
                else -> {
                    InjectionPrefs.t3NoticeCache = result.notice
                    InjectionPrefs.t3NoticeTime = nowText()
                    _state.update {
                        it.copy(
                            announcement = result.notice,
                            announcementLoading = false,
                            announcementFailed = false,
                            announcementUpdated = InjectionPrefs.t3NoticeTime
                        )
                    }
                }
            }
        }
    }

    private fun nowText(): String =
        java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
            .format(java.util.Date())

    // ---------------- 运行态 ----------------

    private fun observeServiceState() {
        viewModelScope.launch {
            ServiceState.frameworkActive.collect { active ->
                _state.update { it.copy(frameworkActive = active) }
            }
        }
        viewModelScope.launch {
            ServiceState.serviceRunning.collect { running ->
                _state.update { it.copy(serviceRunning = running) }
            }
        }
    }

    fun refreshRuntime() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val target = InjectionPrefs.targetPackage
            val info = withContext(Dispatchers.IO) {
                // 进程状态按「/proc/<pid> 目录可不可访问」判:cmdline 读不到时用 status 的 Name+Uid 兜底
                val pids = if (target.isBlank()) emptyList()
                else PackageUtil.findPids(target, PackageUtil.uidOf(ctx, target))
                val dataDir = PackageUtil.dataDir(ctx, target)
                val label = try {
                    val pm = ctx.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(target, 0)).toString()
                } catch (t: Throwable) {
                    ""
                }
                RuntimeInfo(
                    installed = PackageUtil.isInstalled(ctx, target),
                    label = label,
                    pids = pids,
                    dirWritable = run {
                        val filesDir = File(dataDir ?: "", "files")
                        // 先按本进程权限判;本进程碰不到(安卓 12+ 的别的应用目录),
                        // 再看 root / Shizuku 能不能列出来——有特权就等于目录可访问。
                        PermissionUtil.canWriteDir(filesDir) ||
                            privilegedDirAccessible(ctx, filesDir.absolutePath)
                    },
                    sameUid = PackageUtil.sameUid(ctx, target),
                    rootAvailable = FolderImporter.hasRoot(),
                    channel = FolderImporter.channelState(
                        ctx,
                        InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH }
                    ),
                    importDirWritable = FolderImporter.canWrite(
                        File(InjectionPrefs.importTargetPath.ifBlank { FolderImporter.DEFAULT_TARGET_PATH })
                    )
                )
            }
            // 本地 so 没了的场景:自动退回内置,不然「本地」被隐藏后两个格子都不亮
            if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                !ModuleStore.localFile(ctx).isFile
            ) {
                InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
            }
            _state.update {
                it.copy(
                    targetPackage = target,
                    targetLabel = info.label,
                    targetInstalled = info.installed,
                    targetRunning = info.pids.isNotEmpty(),
                    targetPid = info.pids.firstOrNull() ?: -1,
                    targetDirAccessible = info.dirWritable,
                    sameUid = info.sameUid,
                    localModuleReady = ModuleStore.isDownloaded(ctx),
                    localModulePath = ModuleStore.effectiveFile(ctx).absolutePath,
                    moduleVersion = InjectionPrefs.moduleVersion,
                    moduleMd5 = InjectionPrefs.moduleMd5,
                    remoteVersion = InjectionPrefs.remoteVersion,
                    soVariants = ModuleStore.BUILTIN_VARIANTS,
                    soVariantReady = ModuleStore.BUILTIN_VARIANTS.associateWith { v ->
                        runCatching {
                            ModuleStore.inspect(ModuleStore.variantFile(ctx, v)).ready
                        }.getOrDefault(false)
                    },
                    selectedSo = InjectionPrefs.soVariant,
                    soSource = InjectionPrefs.soSource,
                    activeSoPath = InjectionPrefs.modulePath,
                    localSoSourcePath = readableSoPath(InjectionPrefs.localSoSourcePath),
                    localSoReady = ModuleStore.localFile(ctx).isFile,
                    soSize = ModuleStore.currentInfo(ctx).size,
                    soValid = ModuleStore.currentInfo(ctx).ready,
                    soPlaceholder = ModuleStore.currentInfo(ctx).placeholder,
                    frameworkError = InjectionPrefs.frameworkError,
                    frameworkLoadedPath = InjectionPrefs.frameworkPath,
                    writeChannel = info.channel.label,
                    writeChannelReady = info.channel.ready,
                    shizukuInstalled = info.channel.shizukuInstalled,
                    shizukuGranted = info.channel.shizukuGranted,
                    sdkInt = info.channel.sdkInt,
                    frameworkInstalled = XposedDetector.isFrameworkInstalled(ctx),
                    frameworkActive = InjectionPrefs.frameworkActive,
                    serviceRunning = ServiceState.serviceRunning.value,
                    rootAvailable = info.rootAvailable,
                    targetDirWritable = info.importDirWritable
                )
            }
        }
    }

    /**
     * 持续检测目标应用:每 2 秒看一次目标进程在不在,在就显示「正在运行 + PID」,
     * 不在就显示「未运行」。
     *
     * 以前只在特定动作后才刷新一次,用户开了游戏界面还挂着「未运行」,
     * 或者关了游戏还显示「正在运行」,完全得靠手动点刷新。
     * 现在轮到自己退出主界面 / ViewModel 销毁才停。
     */
    private fun startRuntimeWatch() {
        watchJob?.cancel()
        watchJob = viewModelScope.launch {
            while (isActive) {
                val target = InjectionPrefs.targetPackage
                val app = getApplication<Application>()
                if (target.isNotBlank() && _state.value.loggedIn) {
                    val info = withContext(Dispatchers.IO) {
                        runCatching {
                            val uid = PackageUtil.uidOf(app, target)
                            val pids = PackageUtil.findPids(target, uid)
                            pids to PackageUtil.isInstalled(app, target)
                        }.getOrNull()
                    }
                    if (info != null) {
                        val (pids, installed) = info
                        val running = pids.isNotEmpty()
                        val pid = pids.firstOrNull() ?: -1
                        val cur = _state.value
                        if (cur.targetRunning != running || cur.targetPid != pid ||
                            cur.targetInstalled != installed
                        ) {
                            _state.update { c ->
                                c.copy(
                                    targetRunning = running,
                                    targetPid = pid,
                                    targetInstalled = installed
                                )
                            }
                            // 游戏刚起来(或刚退)时重算一次「目标目录能不能访问」:
                            // 目录可访问 = 目标可注入,首页「进程状态」就会显示「已就绪」。
                            // 只在状态真的翻转时才刷,不跟着 2 秒轮询一起跑,不白耗电。
                            if (running != cur.targetRunning) refreshRuntime()
                        }
                    }
                }
                delay(RUNTIME_WATCH_INTERVAL_MS)
            }
        }
    }

    private data class RuntimeInfo(
        val installed: Boolean,
        val label: String,
        val pids: List<Int>,
        val dirWritable: Boolean,
        val sameUid: Boolean,
        val rootAvailable: Boolean,
        val importDirWritable: Boolean,
        val channel: FolderImporter.ChannelState
    )

    /** 目录在特权通道(root / Shizuku)下能不能访问:能 ls 出来就算可访问 */
    private fun privilegedDirAccessible(ctx: Application, path: String): Boolean {
        if (path.isBlank()) return false
        return runCatching {
            val quoted = "'" + path.replace("'", "'\\''") + "'"
            val r = ShellUtil.execPrivileged(ctx, "ls -d $quoted 2>/dev/null", 6000) ?: return false
            r.ok && r.output.contains(path)
        }.getOrDefault(false)
    }

    // ---------------- 导入参数(honffx.config) ----------------

    /** 切「导入旧数据 / 导入参数」两个界面;第一次进参数页自动把文件内容读出来 */
    private fun switchImportPage(index: Int) {
        val page = if (index == 1) 1 else 0
        val cur = _state.value
        _state.update {
            it.copy(
                importPage = page,
                importParamPath = ConfigFile.TARGET_PATH
            )
        }
        if (page == 1 && !cur.importParamLoading && !cur.importParamOk &&
            cur.importParamText.isBlank()
        ) {
            readImportParams()
        }
    }

    /** 读 honffx.config 现有内容,原样填进输入框 */
    private fun readImportParams() {
        if (_state.value.importParamLoading) return
        _state.update { it.copy(importParamLoading = true, importParamMessage = null) }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val text = withContext(Dispatchers.IO) { ConfigFile.read(ctx) }
            _state.update {
                it.copy(
                    importParamPath = ConfigFile.TARGET_PATH,
                    importParamLoading = false,
                    importParamText = text.orEmpty(),
                    importParamOk = text != null,
                    importParamMessage = if (text == null) strings.importParamReadFailed else null
                )
            }
        }
    }

    /** 把输入框内容整份覆盖写回 honffx.config */
    private fun saveImportParams() {
        if (_state.value.importParamLoading) return
        val text = _state.value.importParamText
        _state.update { it.copy(importParamLoading = true, importParamMessage = null) }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val ok = withContext(Dispatchers.IO) { ConfigFile.write(ctx, text) }
            _state.update {
                it.copy(
                    importParamLoading = false,
                    importParamOk = ok,
                    importParamMessage =
                        if (ok) strings.importParamSaved else strings.importParamSaveFailed
                )
            }
            emit(UiEvent.Toast(if (ok) strings.importParamSaved else strings.importParamSaveFailed))
        }
    }

    // ---------------- 写入通道 ----------------

    /** 申请 Shizuku 授权(界面收到事件后拉起授权框) */
    private fun grantShizuku() {
        val ctx = getApplication<Application>()
        if (!ShizukuShell.installed(ctx)) {
            emit(UiEvent.Toast(strings.shizukuNotInstalled))
            return
        }
        if (!ShizukuShell.alive()) {
            emit(UiEvent.Toast(strings.shizukuNotRunning))
            return
        }
        if (ShizukuShell.granted()) {
            emit(UiEvent.Toast(strings.shizukuGranted))
            refreshRuntime()
            return
        }
        emit(UiEvent.RequestShizukuPermission)
    }

    /** 授权结果回来 */
    fun onShizukuResult(granted: Boolean) {
        emit(UiEvent.Toast(if (granted) strings.shizukuGranted else strings.shizukuDenied))
        refreshRuntime()
    }

    // ---------------- 注入 ----------------

    private fun inject() {
        val current = _state.value
        if (current.injecting) return

        // 注入前不再弹任何"请更新 / 请先准备"的对话框,也不再拿"模块没就绪"拦人:
        // 直接用当前选中的那份 SO 往里打,缺的东西下面现补。
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }

        viewModelScope.launch {
            val ctx = getApplication<Application>()
            // 进程注入要求目标真在跑:现场查一次 pid,不依赖界面状态(一键注入刚拉起游戏时状态还没刷新)
            if (current.mode == InjectionMode.PROCESS) {
                val running = withContext(Dispatchers.IO) {
                    PackageUtil.findPids(
                        current.targetPackage,
                        PackageUtil.uidOf(ctx, current.targetPackage)
                    ).isNotEmpty()
                }
                if (!running) {
                    emit(UiEvent.Toast(strings.targetNotRunning))
                    return@launch
                }
            }
            withContext(Dispatchers.IO) {
                // 本机 SO 被删了就自动退回内置;内置变体没铺过的现铺一遍
                if (InjectionPrefs.soSource == InjectionPrefs.SO_SOURCE_LOCAL &&
                    !ModuleStore.localFile(ctx).isFile
                ) {
                    InjectionPrefs.soSource = InjectionPrefs.SO_SOURCE_BUILTIN
                }
                ModuleStore.ensureBundled(ctx)
                ModuleStore.refreshPrefs(ctx)
            }
            _state.update { it.copy(injecting = true) }
            emit(UiEvent.Toast(strings.injectRunning))
            ServiceState.lastInjectOk.value = null
            InjectService.inject(
                getApplication(),
                current.mode,
                current.targetPackage
            )
            val ok = awaitInjectResult()
            val raw = ServiceState.lastInjectDetail.value
            val kind = raw
                ?.let { runCatching { PtraceInjectFailure.valueOf(it.substringBefore(':')) }.getOrNull() }
                ?: PtraceInjectFailure.UNKNOWN
            val detail = raw?.substringAfter(':', "")?.trim()?.takeIf { it.isNotEmpty() }
            _state.update { it.copy(injecting = false, injectDetail = detail) }
            if (ok == true) {
                emit(UiEvent.Toast(strings.injectDone))
            } else {
                emit(UiEvent.Toast(kind.message(strings)))
            }
            refreshRuntime()
        }
    }

    private suspend fun awaitInjectResult(): Boolean? {
        repeat(25) {
            delay(300)
            ServiceState.lastInjectOk.value?.let { return it }
        }
        return ServiceState.lastInjectOk.value
    }

    /**
     * 一键:注入 + 启动游戏。
     *
     * 进程注入要求目标已经在跑,所以先起游戏、等它把进程拉起来再附加;
     * 框架注入是目标启动时由模块自己加载,那就先把 SO/模块准备好再起游戏。
     */
    private fun injectAndLaunch() {
        val current = _state.value
        if (current.injecting) return
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.targetNotInstalled))
            return
        }
        val ctx = getApplication<Application>()

        if (current.mode == InjectionMode.PROCESS) {
            if (!PackageUtil.launch(ctx, current.targetPackage)) {
                emit(UiEvent.Toast(strings.targetNotFound))
                return
            }
            viewModelScope.launch {
                // 等游戏进程真的起来,再去附加(最多等 8 秒)
                var up = false
                var waited = 0
                while (waited < 16) {
                    delay(500)
                    waited++
                    val pids = withContext(Dispatchers.IO) {
                        PackageUtil.findPids(
                            current.targetPackage,
                            PackageUtil.uidOf(getApplication(), current.targetPackage)
                        )
                    }
                    if (pids.isNotEmpty()) {
                        up = true
                        break
                    }
                }
                if (!up) {
                    emit(UiEvent.Toast(strings.targetNotRunning))
                    refreshRuntime()
                    return@launch
                }
                refreshRuntime()
                inject()
            }
        } else {
            inject()
            viewModelScope.launch {
                delay(1200)
                launchTarget()
            }
        }
    }

    private fun launchTarget() {
        val current = _state.value
        if (!current.targetInstalled) {
            emit(UiEvent.Toast(strings.installTargetFirst))
            return
        }
        val ctx = getApplication<Application>()
        val launched = PackageUtil.launch(ctx, current.targetPackage)
        if (!launched) {
            emit(UiEvent.Toast(strings.targetNotFound))
            return
        }
        if (current.mode == InjectionMode.PROCESS) {
            viewModelScope.launch {
                delay(3000)
                HandoffWakeReceiver.send(ctx, current.mode, current.targetPackage)
                refreshRuntime()
            }
        }
    }

    // ---------------- SO 选择 ----------------

    /** 选中哪个变体,注入就用哪个 */
    private fun selectSoVariant(variant: String) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, variant) }
            _state.update {
                it.copy(
                    selectedSo = variant,
                    soSource = InjectionPrefs.SO_SOURCE_BUILTIN,
                    activeSoPath = InjectionPrefs.modulePath
                )
            }
            emit(UiEvent.Toast(strings.soSwitchedTo + " " + variant))
            refreshRuntime()
        }
    }

    /** 从"本机 SO"切回内置变体 */
    private fun useBuiltinSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useBuiltin(ctx, _state.value.selectedSo) }
            emit(UiEvent.Toast(strings.soSwitchedBuiltin))
            refreshRuntime()
        }
    }

    /** 已经导入过本机 SO 的话,直接切过去用,不必再选一次文件 */
    private fun useLocalSo() {
        val ctx = getApplication<Application>()
        if (!ModuleStore.localFile(ctx).isFile) {
            emit(UiEvent.PickLocalSoFile)
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.useLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoSwitched))
            refreshRuntime()
        }
    }

    private fun clearLocalSo() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { ModuleStore.clearLocal(ctx) }
            emit(UiEvent.Toast(strings.localSoCleared))
            refreshRuntime()
        }
    }

    /**
     * 老版本把 content:// 原始串直接存进了偏好,界面上是一长串 %E6%87%82 的转义,
     * 看着跟加密数据一样。读出来的时候统一还原成人能读的路径。
     */
    private fun readableSoPath(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        if (!raw.startsWith("content://", ignoreCase = true)) return raw
        val ctx = getApplication<Application>()
        return runCatching {
            FolderImporter.fileDisplayPath(ctx, Uri.parse(raw))
        }.getOrDefault(Uri.decode(raw))
    }

    /** 界面把用户从本机挑中的那个 so 交过来(文件选择器回调) */
    fun onLocalSoPicked(uri: Uri?) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val input = ctx.contentResolver.openInputStream(uri)
                        ?: return@withContext null
                    // uri.toString() 是百分号转义串,界面上看着像乱码,先换成能读的路径
                    ModuleStore.importLocalSo(ctx, input, FolderImporter.fileDisplayPath(ctx, uri))
                } catch (t: Throwable) {
                    null
                }
            }
            if (saved == null) {
                emit(UiEvent.Toast(strings.localSoFailed))
            } else {
                emit(UiEvent.Toast(strings.localSoLoaded))
            }
            refreshRuntime()
        }
    }

    // ---------------- 卡密 ----------------

    private fun queryCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (AuthMode.LOCAL_CARD) {
                val raw = withContext(Dispatchers.IO) { LocalCardGate.query(ctx, card) }
                val info = if (raw.valid) raw else raw.copy(
                    message = when (raw.message) {
                        "empty" -> strings.loginEmpty
                        "invalid" -> strings.cardInvalid
                        "expired" -> strings.expired
                        "count_exhausted" -> strings.countExhausted
                        else -> raw.message.ifBlank { strings.cardInvalid }
                    }
                )
                _state.update { it.copy(cardQuerying = false, cardInfo = info) }
                if (info.valid) {
                    InjectionPrefs.cardKey = card
                    emit(UiEvent.Toast(strings.loginSuccess))
                } else {
                    emit(UiEvent.Toast(strings.cardInvalid))
                }
                return@launch
            }

            val config = T3Config.official()
            if (!config.ready) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.loginNeedServer))
                return@launch
            }

            // 兜一层:极端网络卡死时也要把「请求中」放下来。
            // 查询会依次打到登录 / 心跳几个接口(为了把次数凑全),给足时间,别中途掐断。
            val result = withTimeoutOrNull(45_000L) {
                T3Client.query(
                    config = config,
                    card = card,
                    deviceId = T3Client.deviceId(ctx),
                    token = InjectionPrefs.t3Token
                )
            }
            if (result == null) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.networkFailed))
                return@launch
            }
            // 状态接口不返回次数(它给的 available 是剩余秒数),
            // 次数只在登录回包里出现。所以这里用登录时缓存的那一份补上,
            // 不然查一下就变成「不限」,用户以为卡没生效、反复登录把次数烧光。
            val cachedCount = InjectionPrefs.t3RemainCount
            val cachedType = InjectionPrefs.t3CardType
            val isCount = result.isCountCard || cachedCount > 0 || cachedType.contains("次")
            val fixed = if (isCount && (result.remainCount == null || result.remainCount <= 0) &&
                cachedCount > 0
            ) {
                result.copy(
                    remainCount = cachedCount,
                    cardType = result.cardType.ifBlank { cachedType },
                    isCountCard = true
                )
            } else {
                result
            }
            if (fixed.remainCount != null && fixed.remainCount > 0) {
                InjectionPrefs.t3RemainCount = fixed.remainCount
                InjectionPrefs.t3RemainTime = nowText()
            }
            if (fixed.cardType.isNotBlank()) InjectionPrefs.t3CardType = fixed.cardType
            // 查询接口没探通时,别把登录时拿到的那份信息清掉
            val info = if (!fixed.ok && !fixed.reached) {
                _state.value.cardInfo?.takeIf { it.card == card } ?: fixed.toCardInfo(card)
            } else {
                fixed.toCardInfo(card)
            }
            _state.update {
                it.copy(
                    cardQuerying = false,
                    cardInfo = info,
                    remainCount = info.remainCount ?: it.remainCount,
                    cardTypeText = info.cardType.ifBlank { it.cardTypeText }
                )
            }
            if (info.valid) {
                InjectionPrefs.cardKey = card
                emit(UiEvent.Toast(strings.loginSuccess))
            } else if (info.banned) {
                emit(UiEvent.Toast(strings.banned))
            } else if (info.message == "expired") {
                emit(UiEvent.Toast(strings.expired))
            } else if (info.message == "count_exhausted") {
                emit(UiEvent.Toast(strings.countExhausted))
            } else {
                emit(UiEvent.Toast(result.message.ifBlank { strings.cardInvalid }))
            }
        }
    }

    private fun unbindCard() {
        val card = _state.value.cardKey.trim()
        if (card.isEmpty()) {
            emit(UiEvent.Toast(strings.cardHint))
            return
        }
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            _state.update { it.copy(cardQuerying = true) }

            if (AuthMode.LOCAL_CARD) {
                val ok = withContext(Dispatchers.IO) { LocalCardGate.unbind(ctx, card) }
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(if (ok) strings.unbindSuccess else strings.cardInvalid))
                if (ok) queryCard()
                return@launch
            }

            val config = T3Config.official()
            if (!config.ready) {
                _state.update { it.copy(cardQuerying = false) }
                emit(UiEvent.Toast(strings.loginNeedServer))
                return@launch
            }

            val result = T3Client.unbind(
                config = config,
                card = card,
                deviceId = T3Client.deviceId(ctx),
                token = InjectionPrefs.t3Token
            )
            _state.update { it.copy(cardQuerying = false) }
            if (result.ok) {
                emit(UiEvent.Toast(strings.unbindSuccess))
                queryCard()
            } else {
                emit(UiEvent.Toast(result.message.ifBlank { strings.requestFailed }))
            }
        }
    }

    private fun generateShareCode() {
        val payload = buildString {
            append("pkg=").append(InjectionPrefs.targetPackage).append(';')
            append("so=").append(_state.value.localModulePath ?: "").append(';')
            append("card=").append(_state.value.cardKey)
        }
        val code = ShareCodec.encode(payload)
        _state.update { it.copy(shareCode = code) }
        emit(UiEvent.Toast(strings.copied))
    }


    // ---------------- 资源导入(左源文件夹 -> 右目标文件夹 覆盖) ----------------

    private fun pickImportDir(forTarget: Boolean) = emit(UiEvent.PickFolderTree(forTarget))

    /** 界面把选中的源文件夹交过来(SAF 回调) */
    fun onImportSourcePicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (t: Throwable) {
                // 有些 ROM 的 DocumentsUI 不给持久权限,这一轮能读就行
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importSourceUri = uri.toString()
            _state.update {
                it.copy(
                    importSourceUri = uri.toString(),
                    importSourcePath = stat.path,
                    importSourceName = stat.name,
                    importSourceFiles = stat.files,
                    importSourceDirs = stat.dirs,
                    importSourceBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importSourcePicked + " · " + stat.files + " " + strings.importFileUnit))
            }
        }
    }

    /** 界面把选中的目标文件夹交过来(SAF 回调) */
    fun onImportTargetPicked(uri: Uri?, silent: Boolean = false) {
        if (uri == null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (t: Throwable) {
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statTree(ctx, uri) }
            if (stat == null) {
                if (!silent) emit(UiEvent.Toast(strings.importNoAccess))
                return@launch
            }
            InjectionPrefs.importTargetUri = uri.toString()
            InjectionPrefs.importTargetPath = ""
            _state.update {
                it.copy(
                    importTargetUri = uri.toString(),
                    importTargetPath = stat.path,
                    importTargetName = stat.name,
                    importTargetFiles = stat.files,
                    importTargetBytes = stat.bytes,
                    importFinished = false,
                    importFailed = false,
                    importMessage = null,
                    importChannelLabel = null
                )
            }
            if (!silent) {
                emit(UiEvent.Toast(strings.importTargetPicked))
            }
            refreshRuntime()
        }
    }

    /** 手输绝对路径(Android/data 这类 SAF 选不到的地方走这条) */
    private fun setImportPath(forTarget: Boolean, raw: String) {
        val path = raw.trim().trimEnd('/')
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            if (path.isBlank()) {
                if (forTarget) {
                    InjectionPrefs.importTargetUri = null
                    InjectionPrefs.importTargetPath = ""
                    _state.update {
                        it.copy(
                            importTargetUri = null, importTargetPath = "",
                            importTargetName = "", importTargetFiles = 0, importTargetBytes = 0
                        )
                    }
                }
                return@launch
            }
            val stat = withContext(Dispatchers.IO) { FolderImporter.statPath(File(path)) }
            if (forTarget) {
                InjectionPrefs.importTargetUri = null
                InjectionPrefs.importTargetPath = path
                _state.update {
                    it.copy(
                        importTargetUri = null,
                        importTargetPath = path,
                        importTargetName = stat.name,
                        importTargetFiles = stat.files,
                        importTargetBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(
                    UiEvent.Toast(
                        if (File(path).isDirectory) strings.importTargetSet
                        else strings.importTargetWillCreate
                    )
                )
            } else {
                // 源可以是文件夹,也可以是单个文件:文件就按原名整个写进目标文件夹
                if (!File(path).exists()) {
                    emit(UiEvent.Toast(strings.importNoAccess))
                    return@launch
                }
                InjectionPrefs.importSourceUri = null
                _state.update {
                    it.copy(
                        importSourceUri = null,
                        importSourcePath = path,
                        importSourceName = stat.name,
                        importSourceFiles = stat.files,
                        importSourceDirs = stat.dirs,
                        importSourceBytes = stat.bytes,
                        importFinished = false,
                        importFailed = false,
                        importMessage = null,
                        importChannelLabel = null
                    )
                }
                emit(UiEvent.Toast(strings.importSourcePicked))
            }
            refreshRuntime()
        }
    }

    private fun clearImportSource() {
        InjectionPrefs.importSourceUri = null
        _state.update {
            it.copy(
                importSourceUri = null,
                importSourcePath = "",
                importSourceName = "",
                importSourceFiles = 0,
                importSourceDirs = 0,
                importSourceBytes = 0L,
                importFinished = false,
                importFailed = false,
                importMessage = null
            )
        }
    }

    /** 冷启动把上次的源/目标找回来 */
    private fun restoreImportDirs() {
        InjectionPrefs.importSourceUri?.let { onImportSourcePicked(Uri.parse(it), silent = true) }
        val targetUri = InjectionPrefs.importTargetUri
        if (!targetUri.isNullOrBlank()) {
            onImportTargetPicked(Uri.parse(targetUri), silent = true)
        } else {
            _state.update { it.copy(importTargetPath = InjectionPrefs.importTargetPath) }
        }
    }

    private fun buildSource(cur: UiState): FolderImporter.Source? {
        val uri = cur.importSourceUri
        if (!uri.isNullOrBlank()) return FolderImporter.Source.Tree(Uri.parse(uri))
        val path = cur.importSourcePath
        if (path.isNotBlank() && File(path).exists()) return FolderImporter.Source.Path(File(path))
        return null
    }

    private fun buildTarget(cur: UiState): FolderImporter.Target? {
        val uri = cur.importTargetUri
        if (!uri.isNullOrBlank()) return FolderImporter.Target.Tree(Uri.parse(uri))
        val path = cur.importTargetPath
        if (path.isNotBlank()) return FolderImporter.Target.Path(File(path))
        return null
    }

    private fun runImport() {
        val cur = _state.value
        if (cur.importing) return
        val source = buildSource(cur)
        if (source == null) {
            emit(UiEvent.Toast(strings.importPickNone))
            return
        }
        val target = buildTarget(cur)
        if (target == null) {
            emit(UiEvent.Toast(strings.importTargetMissing))
            return
        }
        val ctx = getApplication<Application>()
        // 安卓 12 以上写别的应用目录要先有通道,没有就直说"尚未就绪",别跑了才报错
        val targetPath = (target as? FolderImporter.Target.Path)?.dir?.absolutePath
            ?: (target as? FolderImporter.Target.Tree)?.let { FolderImporter.displayPath(ctx, it.uri) }
        val channel = FolderImporter.channelState(ctx, targetPath)
        if (!channel.ready) {
            emit(UiEvent.Toast(strings.importNotReady))
            return
        }
        viewModelScope.launch {
            _state.update {
                it.copy(
                    importing = true,
                    importFinished = false,
                    importFailed = false,
                    importProgressFiles = 0,
                    importProgressTotal = cur.importSourceFiles,
                    importProgressBytes = 0L,
                    importChannelLabel = null,
                    importMessage = null
                )
            }
            val outcome = withContext(Dispatchers.IO) {
                FolderImporter.run(ctx, source, target, cur.importReplaceAll) { p ->
                    _state.update {
                        it.copy(
                            importProgressFiles = p.copied,
                            importProgressBytes = p.bytes,
                            importProgressTotal = if (p.total > 0) p.total else it.importProgressTotal
                        )
                    }
                }
            }
            val channelLabel = when (outcome.channel) {
                FolderImporter.CHANNEL_SAF -> strings.importChannelSaf
                FolderImporter.CHANNEL_DIRECT -> strings.importChannelDirect
                FolderImporter.CHANNEL_ROOT -> strings.importChannelRoot
                else -> "-"
            }
            _state.update {
                it.copy(
                    importing = false,
                    importFinished = true,
                    importFailed = !outcome.ok,
                    importProgressFiles = outcome.copied,
                    importProgressBytes = outcome.bytes,
                    importChannelLabel = channelLabel,
                    importMessage = if (outcome.ok) {
                        strings.importDone + " · " + outcome.copied + " " + strings.importFileUnit +
                            " · " + FolderImporter.formatSize(outcome.bytes)
                    } else {
                        strings.importFailedMsg + ": " +
                            (outcome.error ?: strings.importNoAccess)
                    }
                )
            }
            emit(UiEvent.Toast(if (outcome.ok) strings.importDone else strings.importFailedMsg))
            refreshRuntime()
        }
    }

    // ---------------- 更新 ----------------

    /**
     * 本机版本号(界面上和检测更新都用这个)。
     *
     * 以前直接读 BuildConfig.VERSION_NAME:AIDE 有时不重新生成 BuildConfig,
     * 明明改了 gradle 里的版本号,包里还是旧值 —— 后台改了号不弹更新,
     * 或者新包一直弹更新,来回折腾。现在以 T3Panel.APP_VERSION 为准,
     * 它没填才退回 BuildConfig。
     */
    private fun localVersion(): String =
        T3Panel.APP_VERSION.ifBlank {
            runCatching { BuildConfig.VERSION_NAME }.getOrDefault("")
        }

    /**
     * 检测更新。
     * 后台「检测更新」接口的返回码只能当参考(它连本地版本比它还高都会说"有新版本"),
     * 真正要不要弹,按版本号逐段比一遍才算数。
     */
    private fun checkUpdate(silent: Boolean = true) {
        // 本地卡密版也要能查更新:检测版本接口不需要卡密,断网时静默失败即可。
        val config = T3Config.official()
        if (!config.ready) return
        if (_state.value.updateChecking) return
        _state.update { it.copy(updateChecking = true) }
        viewModelScope.launch {
            var result: T3Result? = null
            try {
                val local = localVersion()

                // 一、三次机会。一次抖动就判"读不到"是最坑的:
                //    切网 / 地铁里 / 后台刚好重启,都会白报一次。
                for (attempt in 0 until 3) {
                    result = runCatching { T3Client.updateInfo(config, local) }.getOrNull()
                    if (!result?.updateVersion.orEmpty().trim().isBlank()) break
                    if (attempt < 2) delay(if (attempt == 0) 600L else 1500L)
                }

                val remoteFromServer = result?.updateVersion.orEmpty().trim()
                val cached = InjectionPrefs.t3RemoteVersion.trim()
                val fallback = T3Panel.FALLBACK_REMOTE_VERSION.trim()

                // 二、服务器读不到时按顺序兜底:上次读到的号 → 源码里写死的号
                val remote = when {
                    remoteFromServer.isNotBlank() -> remoteFromServer
                    cached.isNotBlank() -> cached
                    else -> fallback
                }
                val fromCache = remoteFromServer.isBlank() && remote.isNotBlank()
                if (remote.isNotBlank()) InjectionPrefs.t3RemoteVersion = remote

                val url = result?.updateUrl.orEmpty().trim()
                val log = result?.updateLog.orEmpty().trim()
                // 服务器到底有没有给业务响应:没给 = 网络没通;给了 = 通了但没版本号
                val reached = result?.reached == true

                // 老板的规则:后台版本号和客户端版本号「对不上」就让更新(后台填几,客户端就得是几)。
                // 唯一例外:后台填的是个比本地还老的号(比如后台还挂着 1.1、客户端已经 1.13.0),
                // 那不是"要更新",是后台没改——照旧弹框只会让所有人一开就卡在更新页,所以压掉。
                val mismatch = remote.isNotBlank() && T3Client.versionMismatch(remote, local)
                val remoteOlder = remote.isNotBlank() && T3Client.versionNewer(local, remote)
                val needUpdate = mismatch && !remoteOlder

                // 诊断文案:分清「网络没通」「接口通了但后台没填」「本次没读到、显示的是缓存」
                val diag = when {
                    remoteFromServer.isNotBlank() -> ""
                    remote.isBlank() ->
                        if (reached) strings.updateNoBackendVersion else strings.updateNetworkFailed
                    else -> strings.updateFromCacheHint
                }

                _state.update {
                    it.copy(
                        updateChecking = false,
                        backendVersion = remote,
                        updateDiag = diag,
                        updateAvailable = needUpdate,
                        updateVersion = if (needUpdate) remote else "",
                        updateUrl = if (needUpdate) url else "",
                        updateLog = if (needUpdate) log else ""
                    )
                }

                when {
                    needUpdate -> showUpdateDialog()
                    // 一次都没读到(接口没通 / 后台没填 / 也没有缓存)—— 如实说读到什么,别一句"检查网络"糊弄
                    remote.isBlank() -> if (!silent) emit(UiEvent.Toast(diag))
                    // 号是缓存里的:静默用着,不弹"已是最新"骗人
                    fromCache -> if (!silent) {
                        emit(UiEvent.Toast(strings.updateLatest + " (本机 v" + local + " / 后台 v" + remote + ")"))
                    }
                    // 读到了后台版本号,但它没本地新(后台那个号还没改)
                    remoteOlder -> if (!silent) {
                        emit(UiEvent.Toast(strings.updateLatest + " (本机 v" + local + " / 后台 v" + remote + ")"))
                    }
                    else -> if (!silent) {
                        emit(UiEvent.Toast(strings.updateLatest + " (v" + local + ")"))
                    }
                }
            } catch (e: Exception) {
                // 任何异常都不能把「正在检查更新…」永久挂在那儿
                _state.update {
                    it.copy(
                        updateChecking = false,
                        updateDiag = strings.updateNetworkFailed
                    )
                }
                if (!silent) emit(UiEvent.Toast(strings.updateNetworkFailed))
            } finally {
                if (_state.value.updateChecking) {
                    _state.update { it.copy(updateChecking = false) }
                }
            }
        }
    }

    /**
     * 公告式更新框(跟 T3 那个一样):
     * 标题固定「公告」,正文就是后台的公告内容,底下只有一个「立即下载」,
     * 点了直接跳更新链接,点外面 / 按返回都关不掉(强制更新)。
     */
    private fun showUpdateDialog() {
        val cur = _state.value
        if (!cur.updateAvailable) {
            checkUpdate(silent = false)
            return
        }
        // 后台没配下载地址时别再给个点了没反应的按钮:退回官方群,新版本都在群里发
        val url = cur.updateUrl.ifBlank { Links.QQ_GROUP }
        val hasOwnUrl = cur.updateUrl.isNotBlank()
        val notice = (cur.announcement ?: "").trim()
            .ifBlank { InjectionPrefs.t3NoticeCache.trim() }
        val log = cur.updateLog.trim()
        val body = buildString {
            // 正文 = 公告;后台没发公告就退回更新日志,再没有就给一句兜底
            val main = notice.ifBlank { log }
            if (main.isNotBlank()) append(main) else append(strings.updateDialogFallback)
            append("\n\n").append(strings.updateCurrentLabel).append(" v").append(localVersion())
            if (cur.updateVersion.isNotBlank()) {
                append("  →  ").append(strings.updateVersionLabel).append(" v").append(cur.updateVersion)
            }
            if (!hasOwnUrl) append("\n").append(strings.updateNoUrl)
            // 公告和更新日志不是同一份东西时,日志单独再列一段
            if (notice.isNotBlank() && log.isNotBlank() && log != notice) {
                append("\n\n").append(strings.updateLogTitle).append("\n").append(log)
            }
        }
        emit(
            UiEvent.Dialog(
                title = strings.updateTitle,
                message = body,
                confirmText = strings.updateNow,
                // 后台配了下载地址 → 强制更新(点外面关不掉);
                // 没配地址 → 让用户能关掉,只是跳群
                cancelText = if (hasOwnUrl) null else strings.updateLater,
                forced = hasOwnUrl,
                confirm = { openUrl(url) }
            )
        )
    }

    /** 用系统浏览器 / 下载器打开下载地址 */
    private fun openUrl(url: String) {
        val ctx = getApplication<Application>()
        val fixed = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        runCatching {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(fixed)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }.onFailure { emit(UiEvent.Toast(strings.updateNoUrl)) }
    }

    // ---------------- 小工具 ----------------

    private fun emit(event: UiEvent) {
        _events.trySend(event)
    }

    fun progressPercent(): Int = (_state.value.downloadProgress * 100f).roundToInt()
}
