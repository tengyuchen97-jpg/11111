@echo off
setlocal
cd /d "%~dp0"

if not exist "local.properties" (
  if exist "%LOCALAPPDATA%\Android\Sdk" (
    echo sdk.dir=%LOCALAPPDATA:\=/%/Android/Sdk> local.properties
    echo sdk.dir=%LOCALAPPDATA%\Android\Sdk
  ) else (
    echo 没找到 Android SDK,请手动在 local.properties 里写 sdk.dir=你的SDK路径 再跑
    exit /b 1
  )
)

call gradlew.bat assembleRelease
if exist "app\build\outputs\apk\release\app-release.apk" (
  echo 出包成功: app\build\outputs\apk\release\app-release.apk
) else (
  echo 没出包,看上面的日志
  exit /b 1
)
