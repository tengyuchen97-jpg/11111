#!/usr/bin/env bash
# 用 NDK 重新编 libdevid.so(改设备ID·进程注入通道的原生库)
#
# 用法:
#   bash tools/build_native.sh
#   或指定 NDK 路径:NDK=/path/to/ndk/26.1.10909125 bash tools/build_native.sh
#
# 编完直接覆盖 app/src/main/jniLibs/{arm64-v8a,armeabi-v7a}/libdevid.so,
# 再 ./gradlew assembleRelease 就会打进包里。
#
# 不重编也能编译出 APK —— Kotlin 侧的修复(patch 在 v1.22 说明里)照常生效,
# 只有「配置热更新」和「32 位 ArtMethod 偏移」这两处需要这份新 so。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/app/src/main/cpp/devid/devid.cpp"
[ -f "$SRC" ] || { echo "找不到 $SRC"; exit 1; }

# NDK 路径:优先环境变量,其次常见安装位置(Android Studio 默认目录)
if [ -z "${NDK:-}" ]; then
  for c in \
    "$HOME/Library/Android/sdk/ndk/26.1.10909125" \
    "$HOME/Android/Sdk/ndk/26.1.10909125" \
    "$LOCALAPPDATA/Android/Sdk/ndk/26.1.10909125" \
    /opt/android-ndk-r26d ; do
    if [ -d "$c" ]; then NDK="$c"; break; fi
  done
fi
[ -n "${NDK:-}" ] && [ -d "$NDK" ] || { echo "找不到 NDK:设置 NDK=<ndk 目录> 再跑"; exit 1; }

HOST=""
case "$(uname -s)" in
  Darwin) HOST="darwin-x86_64" ;;
  Linux)  HOST="linux-x86_64" ;;
  *)      HOST="windows-x86_64" ;;
esac
CLANG="$NDK/toolchains/llvm/prebuilt/$HOST/bin/clang++"
[ -x "$CLANG" ] || { echo "找不到编译器 $CLANG"; exit 1; }

# 跟 CMakeLists 一样:API 24 起,只链 log
build() {
  local abi="$1" triple="$2" api="$3"
  local out="$ROOT/app/src/main/jniLibs/$abi"
  mkdir -p "$out"
  "$CLANG" --target="$triple$api" -std=c++17 -O2 -fPIC -shared -fvisibility=hidden \
    -o "$out/libdevid.so" "$SRC" -llog -fuse-ld=lld
  echo "OK  $out/libdevid.so  ($(wc -c < "$out/libdevid.so") 字节)"
}

build arm64-v8a   aarch64-linux-android    24
build armeabi-v7a armv7a-linux-androideabi 24

echo "完事。接着 ./gradlew assembleRelease 出包。"
