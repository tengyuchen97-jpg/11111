package com.tengcd.czr.util

import android.content.Context
import java.io.File
import kotlin.random.Random

/**
 * 游戏设备ID(改ID)。
 *
 * 原理:游戏判断"这是哪台设备"靠的是一串设备标识(android_id、设备序列号这些)。
 * 把这串改成另一个值,游戏那边就等于换了一台机器 —— 原来绑在旧设备上的账号,
 * 在这台机器上就认不出来了(把值填回原来那个,又能认回来)。
 *
 * 两条注入通道读的都是这里写出来的配置:
 *  - 框架注入: xposed/DeviceIdHook 在目标进程里改(Java 层)
 *  - 进程注入: libdevid.so 在目标进程里改(原生层,免 root)
 *
 * 配置文件同时落一份纯文本到私有目录,原生层直接读文件,
 * 免得两边各存一套、改了一边另一边不生效。
 */
object DeviceIdPrefs {

    private const val FILE = "device_id"
    private const val KEY_ENABLED = "devid_enabled"
    private const val KEY_VALUE = "devid_value"
    private const val KEY_MODE = "devid_mode"

    /** 只换唯一标识(默认,最不容易把游戏搞崩) */
    const val MODE_ID_ONLY = "id"
    /** 连机型一起换(整套 Build 字段都伪装) */
    const val MODE_FULL = "full"

    /** 原生层读的纯文本配置(在 app 私有目录里,同 uid 的目标进程能读) */
    const val CFG_NAME = "devid.cfg"

    private var sp: android.content.SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) {
            sp = context.applicationContext
                .getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    private fun p(): android.content.SharedPreferences =
        sp ?: throw IllegalStateException("DeviceIdPrefs.init() 还没调用")

    var enabled: Boolean
        get() = p().getBoolean(KEY_ENABLED, false)
        set(v) {
            p().edit().putBoolean(KEY_ENABLED, v).apply()
        }

    /** 用户填的新设备ID;空 = 还没设置过 */
    var value: String
        get() = p().getString(KEY_VALUE, "") ?: ""
        set(v) {
            p().edit().putString(KEY_VALUE, v.trim()).apply()
        }

    var mode: String
        get() = p().getString(KEY_MODE, MODE_ID_ONLY) ?: MODE_ID_ONLY
        set(v) {
            p().edit().putString(KEY_MODE, v).apply()
        }

    /**
     * 生成一个新设备ID。
     *
     * android_id 在系统里就是 16 位十六进制,照这个格式生成,
     * 游戏拿去当 key 用不会因为格式奇怪被判异常。
     */
    fun randomId(): String {
        val hex = "0123456789abcdef"
        val sb = StringBuilder(16)
        repeat(16) { sb.append(hex[Random.nextInt(16)]) }
        return sb.toString()
    }

    /**
     * 归一化用户填的值。
     *
     * 16 位十六进制(系统 android_id 的标准格式)统一小写;
     * 其它内容**原样保留** —— 用户填什么,游戏里就该看到什么,
     * 不能再像老版本那样把值过一次 SHA-256 再给游戏
     * (老版本填 abc123,游戏里读到的是一串完全不相干的十六进制,
     *  看着就是「改了没生效」,而且想改回原值也回不去)。
     */
    fun normalize(raw: String): String {
        val v = raw.trim()
        if (v.isEmpty()) return ""
        var hex = true
        for (c in v) {
            if (!(c.isDigit() || c in 'a'..'f' || c in 'A'..'F')) {
                hex = false
                break
            }
        }
        return if (hex && v.length == 16) v.lowercase() else v
    }

    /** 现在真正生效的值:开关关了或者没填就返回空 */
    fun effectiveId(): String {
        if (!enabled) return ""
        return normalize(value)
    }

    /** 现在真正会让游戏看到的 android_id(开关关着 / 没填 = 空 = 不接管) */
    fun effectiveAndroidId(): String = effectiveId()

    /**
     * 把配置写成原生层能直接读的纯文本。
     *
     * 目标进程和本应用同 uid(进程注入本来就是靠这个免 root 的),
     * 所以 /data/data/<我们的包名>/files/devid.cfg 它读得到。
     */
    fun writeCfg(context: Context): File? {
        return try {
            val f = File(context.filesDir, CFG_NAME)
            val body = buildString {
                appendLine("enabled=" + if (enabled) "1" else "0")
                appendLine("id=" + normalize(value))
                appendLine("mode=" + mode)
            }
            f.writeText(body)
            // 同 uid 的另一进程要读,给个可读权限(只有同 uid 才拿得到)
            f.setReadable(true, false)
            f
        } catch (t: Throwable) {
            null
        }
    }

    /** 目标进程里读配置(框架模式用不到,原生层自己有读文件逻辑) */
    fun readCfg(context: Context): Pair<Boolean, String> = try {
        val f = File(context.filesDir, CFG_NAME)
        if (!f.isFile) enabled to value
        else {
            var on = false
            var id = ""
            f.readLines().forEach { line ->
                val k = line.substringBefore('=', "").trim()
                val v = line.substringAfter('=', "").trim()
                when (k) {
                    "enabled" -> on = v == "1"
                    "id" -> id = v
                }
            }
            on to id
        }
    } catch (t: Throwable) {
        enabled to value
    }
}
