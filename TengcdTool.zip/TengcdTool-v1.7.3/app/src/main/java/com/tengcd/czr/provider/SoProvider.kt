package com.tengcd.czr.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import android.os.ParcelFileDescriptor
import com.tengcd.czr.inject.ModuleStore
import com.tengcd.czr.util.Activation
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.Md5Util
import com.tengcd.czr.util.ServiceState
import java.io.File
import java.io.FileNotFoundException

/**
 * 对外的 so 分发口(内容提供者)。
 *
 *  - openFile(uri)         : 把模块 so 以文件流的形式给出去
 *  - query(uri)            : 版本 / md5 / 路径
 *  - call("get_module_path"): 直接拿路径
 *  - call("get_handoff")   : 拿 路径 + 目标包名
 *  - call("report_active") : 目标进程里的 HookInit 报告模块加载成功
 */
class SoProvider : ContentProvider() {

    override fun onCreate(): Boolean {
        context?.let {
            InjectionPrefs.init(it)
            com.tengcd.czr.util.DeviceIdPrefs.init(it)
        }
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val ctx = context
        val cursor = MatrixCursor(arrayOf("path", "version", "md5", "size", "target"))
        val file = ctx?.let { ModuleStore.moduleFile(it) } ?: File("")
        cursor.addRow(
            arrayOf(
                file.absolutePath,
                InjectionPrefs.moduleVersion ?: "",
                if (file.isFile) Md5Util.md5(file) else "",
                if (file.isFile) file.length() else 0L,
                InjectionPrefs.targetPackage
            )
        )
        return cursor
    }

    override fun getType(uri: Uri): String = "application/vnd.android.package-archive"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0

    @Throws(FileNotFoundException::class)
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException("no context")
        // content://<包名>.so/variant/<变体名>  -> 给指定变体
        // content://<包名>.so/module            -> 给当前选中的那份
        // 目标进程里选的是哪一版就得拿哪一版,不能永远只给「当前选中」那份,
        // 否则切换版本之后框架加载的其实还是老版本的 so。
        val segs = uri.pathSegments
        val variant = if (segs.size >= 2 && segs[0] == "variant") segs[1] else ""
        val file = if (variant.isNotBlank()) {
            val v = ModuleStore.variantFile(ctx, variant)
            if (v.isFile && v.length() > 0) v else ModuleStore.moduleFile(ctx)
        } else {
            ModuleStore.moduleFile(ctx)
        }
        if (!file.isFile) throw FileNotFoundException("module not ready")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val bundle = Bundle()
        when (method) {
            "get_module_path" -> {
                bundle.putString("path", InjectionPrefs.modulePath)
                bundle.putString("version", InjectionPrefs.moduleVersion)
                bundle.putString("target", InjectionPrefs.targetPackage)
                // 这里给的是「核对过」的激活状态:进程没了的旧记录不算
                bundle.putBoolean("framework_active", Activation.verify(context))
                ServiceState.syncFromPrefs(context)
            }
            "get_handoff" -> {
                val ctx = context
                if (ctx != null) {
                    ModuleStore.refreshPrefs(ctx)
                }
                val handoff = if (ctx != null) ModuleStore.readHandoff(ctx) else null
                val info = if (ctx != null) ModuleStore.currentInfo(ctx) else null
                bundle.putString("path", handoff?.path ?: InjectionPrefs.modulePath)
                bundle.putString(
                    "variant",
                    handoff?.variant ?: InjectionPrefs.soVariant
                )
                bundle.putString("target", handoff?.target ?: InjectionPrefs.targetPackage)
                bundle.putString("version", InjectionPrefs.moduleVersion)
                bundle.putString("md5", InjectionPrefs.moduleMd5)
                bundle.putLong("size", info?.size ?: 0L)
                bundle.putBoolean("ready", info?.ready ?: false)
            }
            "report_state" -> {
                val ok = arg == "ok"
                val detail = extras?.getString("detail")
                val process = extras?.getString("process").orEmpty()
                if (ok) {
                    // ⚠️ 不再「来一句 ok 就置 true」。
                    // pid / uid 取 Binder 对端的真实值:上报内容里自报的 pid 一律不认。
                    val callerPid = Binder.getCallingPid()
                    val callerUid = Binder.getCallingUid()
                    val reported = extras?.getString("context_package")
                        ?.takeIf { it.isNotBlank() }
                        ?: extras?.getString("package").orEmpty()
                    val path = extras?.getString("path")
                    ServiceState.onReportedActive(
                        context, callerPid, callerUid, reported, path, process
                    )
                } else {
                    // 目标进程明确报失败 -> 立刻把「已激活」撤掉,别让界面挂着假状态
                    InjectionPrefs.frameworkActive = false
                    InjectionPrefs.frameworkActiveAt = 0L
                    InjectionPrefs.frameworkError = detail ?: "目标进程里模块没加载起来"
                    InjectionPrefs.frameworkProcess = process
                    ServiceState.onReportedFailure(InjectionPrefs.frameworkError)
                }
                bundle.putBoolean("ok", true)
            }
            "report_active" -> {
                // 只有目标进程报上来的激活才算数,而且必须过 pid / uid 校验
                val reported = arg?.takeIf { it.isNotBlank() }?.trim().orEmpty()
                val okReport = ServiceState.onReportedActive(
                    context,
                    Binder.getCallingPid(),
                    Binder.getCallingUid(),
                    reported,
                    null,
                    null
                )
                bundle.putBoolean("ok", okReport)
            }
            "get_devid" -> {
                val ctx = context
                if (ctx != null) com.tengcd.czr.util.DeviceIdPrefs.init(ctx)
                bundle.putBoolean("enabled", com.tengcd.czr.util.DeviceIdPrefs.enabled)
                // 给目标进程的必须是「归一化之后、真正会生效」的那个值
                bundle.putString("id", com.tengcd.czr.util.DeviceIdPrefs.effectiveAndroidId())
                bundle.putString("mode", com.tengcd.czr.util.DeviceIdPrefs.mode)
            }
            // 目标进程自检回报:arg = "id=xxx&seen=xxx&pid=123&pkg=xxx"
            "report_devid" -> {
                val ctx = context
                var ok = false
                if (ctx != null && !arg.isNullOrBlank()) {
                    try {
                        val f = File(ctx.filesDir, "devid_report.txt")
                        f.writeText("at=" + System.currentTimeMillis() + "\n" + arg.replace('&', '\n'))
                        f.setReadable(true, false)
                        ok = true
                    } catch (t: Throwable) {
                    }
                }
                bundle.putBoolean("ok", ok)
            }
            "get_devid_report" -> {
                val ctx = context
                val f = if (ctx != null) File(ctx.filesDir, "devid_report.txt") else null
                if (f != null && f.isFile) {
                    try {
                        var at = ""
                        var id = ""
                        var seen = ""
                        var pid = ""
                        var pkg = ""
                        f.readLines().forEach { line ->
                            val k = line.substringBefore('=', "").trim()
                            val v = line.substringAfter('=', "").trim()
                            when (k) {
                                "at" -> at = v
                                "id" -> id = v
                                "seen" -> seen = v
                                "pid" -> pid = v
                                "pkg" -> pkg = v
                            }
                        }
                        bundle.putBoolean("has", seen.isNotBlank() || id.isNotBlank())
                        bundle.putString("at", at)
                        bundle.putString("id", id)
                        bundle.putString("seen", seen)
                        bundle.putString("pid", pid)
                        bundle.putString("pkg", pkg)
                    } catch (t: Throwable) {
                        bundle.putBoolean("has", false)
                    }
                } else {
                    bundle.putBoolean("has", false)
                }
            }
            "clear_active" -> {
                Activation.reset()
                ServiceState.frameworkActive.value = false
                bundle.putBoolean("ok", true)
            }
        }
        return bundle
    }
}
