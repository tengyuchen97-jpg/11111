package com.tengcd.czr.xposed

import android.app.Application
import android.app.Instrumentation
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process as AndroidProcess
import android.provider.Settings
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import com.tengcd.czr.util.SoVault
import com.tengcd.czr.util.ServiceState
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 目标包启动 -> 找到当前选中的那份 so -> System.load -> 回报结果。
 *
 * 这一版修的是「框架显示已注入、但游戏里什么都没有」:
 *
 *  1. 以前只在 Application.attach 的 after 里加载一次。虚拟空间框架(BlackBox/PINKBOX)
 *     注入模块的时机经常落在 attach 之后,那一下 hook 就永远不触发 —— 游戏里等于没注入。
 *     现在:注入当下先试一次,再把 attach / onCreate / callApplicationOnCreate 全挂上,
 *     最后还有主线程轮询兜底,哪条先到走哪条。
 *  2. 以前 so 只从「模块安装包 assets」和 prefs 里的路径找。so 是用户从本机导入的时候
 *     这两个地方都没有,于是必然加载失败。现在多一条:直接通过模块的 ContentProvider
 *     把 so 字节拉过来(跨 uid 唯一稳的路),再落到目标进程自己的目录加载。
 *  3. 模块自己被框架注入时不再上报「游戏已激活」——那个状态只认目标进程回报,
 *     免得界面一直挂着假的「已激活」。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    @Volatile
    private var loaded = false

    @Volatile
    private var hooksInstalled = false

    @Volatile
    private var polling = false

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return

        // 被注入的是我们自己的应用:这就是「框架认得模块」的证据。
        // 注意:这里只标记「框架识别到模块」,绝不等于游戏里注入成功。
        //
        // ⚠️ 这里只能按包名认,不能再用「classLoader 能不能加载出我们自己的类」认:
        //    虚拟空间(BlackBox / PINKBOX 这类)会把模块的 classloader 也带进游戏进程,
        //    那个判断会对游戏进程同样成立 —— 结果就是游戏进程一进来就 return,
        //    界面上看着「挂载成功」,游戏里其实什么都没加载。这就是「挂了却不生效」的主因。
        if (pkg == OUR_PACKAGE) {
            markSelfActive()
            return
        }
        if (pkg == "android" || pkg == "com.android.systemui") return
        // 框架/管理器自己的进程:模块也会被送进去,但那是拿来报「框架认得模块」的,
        // 绝不能在这些进程里加载游戏 so
        if (pkg in HOST_PACKAGES) {
            markSelfActive()
            return
        }

        // ⚠️ 不再拿偏好里存的目标包名去过滤 pkg。
        //    作用域是用户在 LSPosed 里自己勾的:勾了谁就是想对谁生效。
        //    旧逻辑是「pkg 必须等于缓存里的目标包(或写死的两个马甲包)」,
        //    于是换包名、多开分身、LSPosed 里手动勾别的应用,全都直接 return ——
        //    现象就是「框架显示挂载了,游戏里没反应」。
        //    现在只跳过系统和自己的进程,剩下的交给下面的加载逻辑。

        // ⓪ 改设备ID要抢在游戏读之前先挂上(比 so 加载更早,见 installEarlyDeviceId)
        installEarlyDeviceId(pkg)
        // ① 注入当下先试一次(有的框架到这一步 Application 已经建好了)
        tryLoadNow(pkg, "load")
        // ② 三个时机全挂上,谁先到谁干活
        installHooks(pkg)
        // ③ 最后兜底:主线程轮询一段时间,只要进程还在就一直等
        startPolling(pkg)
    }

    // ---------------------------------------------------------------- 改设备ID(抢跑)

    /**
     * 尽早挂改设备ID。
     *
     * 时机很关键:`Application.attach` / `Instrumentation.callApplicationOnCreate` 是
     * 游戏自己任何代码跑之前就能拿到的两个点。老版本要等 so 加载那套流程走完才装,
     * 那时候不少游戏已经在 Application.onCreate 里把旧 ID 读走、上报了 ——
     * 于是「改了 ID 还是老设备」。
     *
     * 这里只做一件事:拿到 Context 就立刻读配置 + 装 hook,不等 so、不等任何别的东西。
     */
    @Volatile
    private var earlyDeviceIdHooked = false

    private fun installEarlyDeviceId(pkg: String) {
        if (earlyDeviceIdHooked) return
        earlyDeviceIdHooked = true

        // 时机 A:Application.attach —— 绝大多数进程都有
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        bindDeviceId(context)
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] early devid attach hook failed: ${t.message}")
        }

        // 时机 B:callApplicationOnCreate —— 虚拟空间/壳进程里更可靠
        try {
            XposedHelpers.findAndHookMethod(
                Instrumentation::class.java,
                "callApplicationOnCreate",
                Application::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam?) {
                        val app = param?.args?.getOrNull(0) as? Application ?: return
                        bindDeviceId(app)
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] early devid onCreate hook failed: ${t.message}")
        }

        // 时机 C:注入当下 Application 已经在了,直接来一发
        try {
            val app = currentApplication()
            if (app != null) bindDeviceId(app)
        } catch (t: Throwable) {
        }
        XposedBridge.log("[Tengcd] early devid hooks armed: $pkg")
    }

    /** 读配置 + 装/更新 hook + 绑定 Context(之后值改动能热生效) */
    private fun bindDeviceId(context: Context) {
        try {
            DeviceIdHook.bindContext(context)
            val bundle = try {
                context.contentResolver.call(
                    Uri.parse("content://$OUR_PACKAGE.so"), "get_devid", null, null
                )
            } catch (t: Throwable) {
                null
            }
            var on = bundle?.getBoolean("enabled") ?: false
            var id = bundle?.getString("id").orEmpty()
            val mode = bundle?.getString("mode").orEmpty()
            if (id.isBlank()) {
                val cfg = readDeviceIdFile()
                if (cfg != null) {
                    if (!on) on = cfg.first
                    id = cfg.second
                }
            }
            // ⚠️ 就算这会儿开关是关的、或者值还没填,也要把 hook 装上。
            //    装上之后,目标进程里任何一次读设备ID都会顺带去模块要一次最新值,
            //    改完 2~4 秒内热生效;不装就永远是「进来那一刻没值 = 这辈子都没值」,
            //    用户看到的就是「开关打开了、游戏里还是老设备」。
            DeviceIdHook.install(if (on) id else "", mode == "full", OUR_PACKAGE)
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] bind devid failed: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- 触发

    /** 试一次:拿得到 Application 就加载 */
    private fun tryLoadNow(pkg: String, stage: String) {
        if (loaded) return
        val app = currentApplication() ?: return
        loadModule(app, pkg, stage)
    }

    /** 把能挂的时机全挂上。任何一个成功就够用,全失败还有轮询。 */
    private fun installHooks(pkg: String) {
        if (hooksInstalled) return
        hooksInstalled = true

        // 时机 1:Application.attach
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        Handler(Looper.getMainLooper()).post {
                            loadModule(context, pkg, "attach")
                        }
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked Application.attach: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook attach failed: ${t.message}")
        }

        // 时机 2:Application.onCreate(虚拟空间里这个一定还会被调到)
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "onCreate",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val app = param?.thisObject as? Application ?: return
                        loadModule(app, pkg, "onCreate")
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked Application.onCreate: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook onCreate failed: ${t.message}")
        }

        // 时机 3:Instrumentation.callApplicationOnCreate —— 虚拟空间框架就是从这里过
        try {
            XposedHelpers.findAndHookMethod(
                Instrumentation::class.java,
                "callApplicationOnCreate",
                Application::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val app = param?.args?.getOrNull(0) as? Application ?: return
                        loadModule(app, pkg, "callApplicationOnCreate")
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked callApplicationOnCreate: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook callApplicationOnCreate failed: ${t.message}")
        }
    }

    /** 主线程轮询兜底:400ms 一次,最多 90 次(约 36 秒) */
    private fun startPolling(pkg: String) {
        if (polling || loaded) return
        polling = true
        val handler = Handler(Looper.getMainLooper())
        var left = 90
        val runnable = object : Runnable {
            override fun run() {
                if (loaded) return
                val app = currentApplication()
                if (app != null) loadModule(app, pkg, "poll")
                if (loaded) return
                left -= 1
                if (left > 0) handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
        handler.postDelayed(runnable, POLL_INTERVAL_MS)
    }

    // ---------------------------------------------------------------- 自激活

    /** 反射拿当前进程的 Application,拿不到返回 null */
    private fun currentApplication(): Application? = try {
        val cls = Class.forName("android.app.ActivityThread")
        val current = cls.getMethod("currentActivityThread").invoke(null)
        val app = cls.getMethod("getApplication").invoke(current)
        app as? Application
    } catch (t: Throwable) {
        null
    }

    /** 这份 classLoader 能加载出我们自己的类 = 当前进程就是我们自己的进程 */
    private fun loadsOurApp(loader: ClassLoader?): Boolean {
        if (loader == null) return false
        val candidates = listOf(
            "$OUR_PACKAGE.MainActivity",
            "$OUR_PACKAGE.HonffxApplication",
            "$OUR_PACKAGE.xposed.HookInit"
        )
        for (name in candidates) {
            try {
                Class.forName(name, false, loader)
                return true
            } catch (t: Throwable) {
            }
        }
        return false
    }

    /**
     * 框架把本模块注入到我们自己的应用里 = 框架认得这个模块了。
     * 只置「框架识别到模块」这个标记,不写「游戏已注入」——那个只认目标进程回报。
     */
    private fun markSelfActive() {
        try {
            ActiveCheck.markSelfHooked()
        } catch (t: Throwable) {
        }
        try {
            val app = currentApplication()
            if (app != null) {
                ActiveCheck.writeMarker(app)
                ServiceState.onSelfLoaded()
            }
        } catch (t: Throwable) {
        }
        try {
            XposedBridge.log("[Tengcd] module injected into self (ver=" + ActiveCheck.xposedVersion() + ")")
        } catch (t: Throwable) {
        }
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val context = param?.args?.getOrNull(0) as? Context ?: return
                        if (context.packageName != OUR_PACKAGE && !ActiveCheck.boxHosted()) return
                        try {
                            ActiveCheck.markSelfHooked()
                            ActiveCheck.writeMarker(context)
                            ServiceState.onSelfLoaded()
                        } catch (t: Throwable) {
                            XposedBridge.log("[Tengcd] self marker failed: ${t.message}")
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] self hook failed: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- 改设备ID

    @Volatile
    private var deviceIdHooked = false

    /**
     * 在目标进程里装「改设备ID」的 hook。
     *
     * 值从模块的 ContentProvider 拿(跨 uid 唯一稳的一条),
     * Provider 拿不到再退回读模块私有目录里的配置文件。
     * 全都拿不到就什么都不做 —— 不能因为改ID没配置好就把游戏卡住。
     */
    private fun installDeviceIdHook(context: Context) {
        // 不再「装过一次就永远跳过」:以前这样写,用户在界面上改了新 ID,
        // 游戏进程里那个旧值就再也换不掉,看起来就是「改了等于没改」。
        // bindDeviceId 每次都重新读配置,DeviceIdHook.install 内部自己保证 hook 只装一次。
        bindDeviceId(context)
    }

    /** 读模块私有目录里的 devid.cfg(同 uid 时读得到) */
    private fun readDeviceIdFile(): Pair<Boolean, String>? {
        val files = listOf(
            "/data/data/$OUR_PACKAGE/files/devid.cfg",
            "/data/user/0/$OUR_PACKAGE/files/devid.cfg",
            "/data/user/10/$OUR_PACKAGE/files/devid.cfg"
        )
        for (path in files) {
            try {
                val f = File(path)
                if (!f.isFile) continue
                var on = false
                var id = ""
                f.readLines().forEach { line ->
                    val k = line.substringBefore('=', "").trim()
                    val v = line.substringAfter('=', "").trim()
                    when (k) {
                        "enabled" -> on = v == "1"
                        "id" -> id = v
                    }
                }
                if (id.isNotBlank()) return on to id
            } catch (t: Throwable) {
            }
        }
        return null
    }

    // ---------------------------------------------------------------- 加载

    @Synchronized
    private fun loadModule(context: Context, pkg: String, stage: String) {
        // 改设备ID先装:它不依赖 so,就算模块 so 没加载起来也能单独生效
        installDeviceIdHook(context)

        if (loaded) return

        // 目标包名以 Provider 给的为准,读不到再退回偏好里存的
        val handoff = queryHandoff(context)
        val configured = handoff?.target?.takeIf { it.isNotBlank() }
            ?: readTargetPackage()
            ?: DEFAULT_TARGET
        // ⚠️ pkg 跟配置里的目标名不一致时不再 return:
        //    框架只会把模块送进它被勾选的应用,送进来了就是用户要的目标。
        //    这里只在日志里留一句,方便看 LSPosed 里到底勾了谁。
        if (pkg != configured && pkg !in SAME_GAME_PACKAGES) {
            XposedBridge.log("[Tengcd] target name mismatch: pkg=$pkg configured=$configured (继续按目标处理)")
        }
        val target = pkg

        val variant = handoff?.variant?.takeIf { it.isNotBlank() }
            ?: readVariantFromPrefs()
            ?: ""

        val reasons = ArrayList<String>()

        // 1) 先用现成的路径试试(共用 uid / 有 root 的时候这条路能直接过)
        val candidates = listOfNotNull(
            handoff?.path,
            readPathFromPrefs(),
            readHandoffPathFile(context)
        ).filter { it.isNotBlank() }.distinct()
        for (path in candidates) {
            if (tryLoadPath(path, reasons)) return
        }

        // 2) 模块私有目录里的候选文件
        for (file in moduleDirCandidates(variant)) {
            if (tryLoadPath(file.absolutePath, reasons)) return
        }

        // 2.5) 变体名没拿到(或者名字对不上)时的兜底:
        //      私有目录里凡是 libhonffx_*.so 的都试一遍。
        //      以前这里直接放弃,于是「模块明明解包好了,框架就是说没版本」。
        for (file in anyModuleFiles()) {
            if (tryLoadPath(file.absolutePath, reasons)) return
        }

        // 3) 通过模块的 ContentProvider 把 so 拉过来(跨 uid 最稳的一条)
        val fetched = fetchFromProvider(context, variant, reasons)
        if (fetched != null && attemptLoad(context, fetched.absolutePath)) {
            report(context, pkg, true, fetched.absolutePath, null)
            return
        }

        // 4) 从模块安装包里把选中的变体抽到目标进程自己的目录
        val extracted = extractVariant(context, variant, reasons) { file ->
            attemptLoad(context, file.absolutePath)
        }
        if (extracted != null) {
            report(context, pkg, true, extracted.absolutePath, null)
            return
        }

        // 5) 上面都挂了,把原因回报给界面
        val detail = buildString {
            append(if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().joinToString(" / "))
            if (!canDrawOverlay(context)) {
                append(" / 框架没有「显示在其他应用上层」权限,so 就算加载了悬浮窗也弹不出来")
            }
        }
        XposedBridge.log("[Tengcd] load failed ($stage): $detail")
        report(context, pkg, false, null, detail)
    }

    /** 路径能读、是合法 so、位数对 -> 直接 load。返回 true 表示加载成功 */
    private fun tryLoadPath(path: String, reasons: MutableList<String>): Boolean {
        val f = File(path)
        if (!f.isFile) {
            reasons.add("文件不存在:${f.name}")
            return false
        }
        if (!f.canRead()) {
            reasons.add("目标进程读不到:${f.name}")
            return false
        }
        val why = validateSo(f)
        if (why != null) {
            reasons.add("${f.name}:$why")
            return false
        }
        if (attemptLoad(f)) {
            return true
        }
        reasons.add("${f.name}:System.load 被拒")
        return false
    }

    /** 模块私有目录里可能放着 so 的地方(真实目录 + 虚拟空间盒内的映射目录) */
    private fun moduleDirCandidates(variant: String): List<File> {
        val names = buildList {
            if (variant.isNotBlank()) add("libhonffx_$variant.so")
            add("libhonffx_local.so")
            add("libhonffx.so")
        }
        val dirs = listOf(
            "/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/10/$OUR_PACKAGE/files/module",
            "/data/user/999/$OUR_PACKAGE/files/module",
            // 虚拟空间盒子内的映射目录(模块也装进盒子时 so 会落在这里)
            "/data/data/$BOX_PACKAGE/virtual/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$BOX_PACKAGE/virtual/data/data/$OUR_PACKAGE/files/module",
            "/data/data/$BOX_PACKAGE/virtual/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/0/$BOX_PACKAGE/virtual/data/user/0/$OUR_PACKAGE/files/module"
        )
        val out = ArrayList<File>()
        for (dir in dirs) {
            for (name in names) {
                out.add(File(dir, name))
            }
        }
        return out
    }

    /** 模块私有目录里所有看起来能用的 libhonffx*.so(同 uid 才读得到) */
    private fun anyModuleFiles(): List<File> {
        val dirs = listOf(
            "/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/10/$OUR_PACKAGE/files/module",
            "/data/user/999/$OUR_PACKAGE/files/module",
            "/data/data/$BOX_PACKAGE/virtual/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$BOX_PACKAGE/virtual/data/user/0/$OUR_PACKAGE/files/module"
        )
        val out = ArrayList<File>()
        for (d in dirs) {
            val files = try {
                File(d).listFiles()
            } catch (t: Throwable) {
                null
            } ?: continue
            for (f in files) {
                if (!f.isFile) continue
                val n = f.name
                if (!n.startsWith("libhonffx") || !n.endsWith(".so")) continue
                if (f.length() <= 4096L) continue
                out.add(f)
            }
        }
        return out
    }

    /**
     * 从模块的 ContentProvider 拉 so。
     *
     * 模块 App 和游戏进程不是同一个 uid,直接读对方私有目录会被拒,
     * 但模块的 Provider 是导出的,openInputStream 能拿到字节流 —— 这是跨 uid 唯一稳的路。
     */
    private fun fetchFromProvider(context: Context, variant: String, reasons: MutableList<String>): File? {
        val dirs = listOfNotNull(
            File(context.codeCacheDir, "honffx"),
            File(context.filesDir, "honffx"),
            runCatching { File(context.createDeviceProtectedStorageContext().filesDir, "honffx") }.getOrNull()
        )
        val uris = buildList {
            if (variant.isNotBlank()) add(Uri.parse("content://$OUR_PACKAGE.so/variant/$variant"))
            add(Uri.parse("content://$OUR_PACKAGE.so/module"))
            add(Uri.parse("content://$OUR_PACKAGE.so"))
        }
        val tag = if (variant.isBlank()) "provider" else variant
        for (dir in dirs) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
            } catch (t: Throwable) {
                continue
            }
            for (uri in uris) {
                val tmp = File(dir, "libhonffx_$tag.so.tmp")
                try {
                    val input = context.contentResolver.openInputStream(uri) ?: continue
                    input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }
                } catch (t: Throwable) {
                    reasons.add("Provider 取不到:${t.javaClass.simpleName}")
                    tmp.delete()
                    continue
                }
                if (tmp.length() <= 4096L) {
                    reasons.add("Provider 给的 so 是空的/占位文件")
                    tmp.delete()
                    continue
                }
                val dst = File(dir, "libhonffx_$tag.so")
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add("Provider 的 so:$why")
                    continue
                }
                return dst
            }
        }
        return null
    }

    private fun attemptLoad(file: File): Boolean = attemptLoad(null, file.absolutePath)

    private fun attemptLoad(context: Context?, path: String): Boolean = try {
        System.load(path)
        loaded = true
        XposedBridge.log("[Tengcd] module loaded: $path")
        true
    } catch (t: Throwable) {
        XposedBridge.log("[Tengcd] System.load($path) failed: ${t.message}")
        false
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF 文件"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "这个 so 是 64 位,目标进程是 32 位" else "这个 so 是 32 位,目标进程是 64 位"
        }
        return null
    }

    // ---------------------------------------------------------------- 抽取

    /**
     * 从模块安装包里抽 assets/so/<variant>.so,写到目标进程自己的目录。
     * 写不进去就换下一个目录,全失败返回 null。
     */
    private fun extractVariant(
        context: Context,
        variant: String,
        reasons: MutableList<String>,
        attempt: (File) -> Boolean
    ): File? {
        val apk = resolveModuleApk(context)
        if (apk == null) {
            reasons.add("找不到模块安装包")
            return null
        }
        if (variant.isBlank()) {
            reasons.add("没拿到选中的 SO 版本")
            return null
        }

        val entryName = "assets/so/$variant.so${SoVault.ENC_SUFFIX}"
        val plainEntry = "assets/so/$variant.so"
        val targets = buildList {
            add(File(context.codeCacheDir, "honffx"))
            add(File(context.filesDir, "honffx"))
            try {
                add(File(context.createDeviceProtectedStorageContext().filesDir, "honffx"))
            } catch (t: Throwable) {
            }
        }

        if (!SoVault.signatureAllowed(context, OUR_PACKAGE)) {
            reasons.add("安装包签名校验失败,内置 so 拒绝解密")
            return null
        }

        for (dir in targets) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                val dst = File(dir, "libhonffx_$variant.so")
                if (!unzipEntry(apk, entryName, plainEntry, dst, reasons)) continue
                val why = validateSo(dst)
                if (why != null) {
                    reasons.add(why)
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (attempt(dst)) return dst
                reasons.add("解出来的 so 在 ${dir.name} 目录加载失败，换下一个目录")
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽一份 so 写到 dst。
     * 包里的资产是加密件(xxx.so.enc),这里读出来先解密再落盘;
     * 老包没有 .enc 的话退回读明文 .so。
     */
    private fun unzipEntry(
        apk: File,
        encEntry: String,
        plainEntry: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(encEntry)
                var encrypted = entry != null
                if (entry == null) {
                    entry = zip.getEntry(plainEntry)
                    encrypted = false
                }
                if (entry == null) {
                    reasons.add("安装包里没有 assets/so/$encEntry")
                    return false
                }
                val raw = zip.getInputStream(entry).use { it.readBytes() }
                if (raw.isEmpty()) {
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                var bytes: ByteArray? = if (encrypted) {
                    SoVault.decrypt(raw, entry.name.substringAfterLast('/'))
                } else {
                    raw
                }
                if (bytes == null || !SoVault.isElf(bytes) || bytes.size <= 4096) {
                    val alt = zip.getEntry(plainEntry)
                    if (alt != null && alt.name != entry.name) {
                        val altRaw = zip.getInputStream(alt).use { it.readBytes() }
                        if (SoVault.isElf(altRaw) && altRaw.size > 4096) bytes = altRaw
                    }
                }
                val plainBytes = bytes
                if (plainBytes == null) {
                    reasons.add("内置 so 解密失败(安装包被改过或签名不对)")
                    return false
                }
                if (!SoVault.isElf(plainBytes)) {
                    reasons.add("抽出来的东西不是 so(assets/so 里还是占位文件?)")
                    return false
                }
                val tmp = File(dst.parentFile, dst.name + ".tmp")
                tmp.outputStream().use { it.write(plainBytes) }
                if (tmp.length() <= 0L) {
                    tmp.delete()
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    reasons.add("落盘失败")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:${t.message}")
            return false
        }
    }

    /** 模块安装包路径:优先 initZygote 给的,拿不到就去问 PackageManager */
    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- 取配置

    private data class Handoff(val path: String, val variant: String, val target: String)

    /** 问我们自己的 ContentProvider 要交接信息(最可靠的一条路) */
    private fun queryHandoff(context: Context): Handoff? = try {
        val bundle: Bundle? = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", context.packageName, null
        )
        if (bundle == null) {
            null
        } else {
            Handoff(
                path = bundle.getString("path").orEmpty(),
                variant = bundle.getString("variant").orEmpty(),
                target = bundle.getString("target").orEmpty()
            )
        }
    } catch (t: Throwable) {
        null
    }

    /** 有没有「显示在其他应用上层」权限(so 的悬浮窗全靠它) */
    private fun canDrawOverlay(context: Context): Boolean = try {
        Settings.canDrawOverlays(context)
    } catch (t: Throwable) {
        true
    }

    private fun currentProcessName(): String = try {
        File("/proc/self/cmdline").readText().trim('\u0000', '\n', ' ')
    } catch (t: Throwable) {
        ""
    }

    private fun report(
        context: Context,
        pkg: String,
        ok: Boolean,
        path: String?,
        detail: String?
    ) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_state",
                if (ok) "ok" else "error",
                Bundle().apply {
                    putString("package", pkg)
                    putString("context_package", context.packageName)
                    putString("process", currentProcessName())
                    putInt("pid", AndroidProcess.myPid())
                    putString("path", path)
                    putString("detail", detail)
                    putBoolean("overlay", canDrawOverlay(context))
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report failed: ${t.message}")
        }
    }

    private fun readPrefs(): XSharedPreferences? = try {
        val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
        @Suppress("DEPRECATION")
        try {
            xsp.makeWorldReadable()
        } catch (t: Throwable) {
        }
        xsp.reload()
        xsp
    } catch (t: Throwable) {
        null
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)
    } catch (t: Throwable) {
        null
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = listOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"
        private const val POLL_INTERVAL_MS = 400L

        /** 虚拟空间框架的宿主包名(找盒内 so 映射目录用) */
        private const val BOX_PACKAGE = "top.niunaijun.blackbox"

        /** 框架自己 / 管理器的进程:只做「模块被认得」的标记,不加载游戏 so */
        private val HOST_PACKAGES = setOf(
            "com.tengcd.hx",
            "org.lsposed.manager",
            "org.lsposed.manager.debug",
            "de.robv.android.xposed.installer",
            "org.meowcat.edxposed.manager",
            "top.niunaijun.blackbox",
            "top.niunaijun.blackboxa",
            "com.pika.pinkbox",
            "com.haxsys.vbox"
        )

        /**
         * 同一个游戏的不同马甲包。
         *
         * 换包名重新分发是很常见的做法(只差一两个字母),但模块的作用域和这里的
         * 目标判断都是写死包名的 —— 名字对不上,框架压根不会把模块送进游戏,
         * 界面上就会一直显示"没生效"。这里把知道的马甲都列上。
         */
        private val SAME_GAME_PACKAGES = setOf(
            "com.pi.czrxdfirst",
            "com.pi.ezrxdfirst",
        )
    }
}
