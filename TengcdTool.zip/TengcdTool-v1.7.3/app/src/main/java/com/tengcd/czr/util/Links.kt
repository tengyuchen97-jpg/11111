package com.tengcd.czr.util

/**
 * 内置跳转链接集中放一处,页面里不再散写字面量。
 * 换群换地址只改这里。
 */
object Links {
    /** 官方 QQ 群(卡密验证页 / 卡密页都用这一个) */
    const val QQ_GROUP = "https://qm.qq.com/q/RJvQktX6gg"

    /**
     * 卡密购买入口(卡密页「购买卡密」那张卡跳这里)。
     *
     * 换发卡地址只改这一行;先填的还是 QQ 群,等你有发卡站了把链接贴进来就行。
     */
    const val BUY_CARD = QQ_GROUP
}
