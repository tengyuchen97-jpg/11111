package com.tengcd.czr.xposed

import android.bluetooth.BluetoothAdapter
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.media.MediaDrm
import android.net.Uri
import android.net.wifi.WifiInfo
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.telephony.TelephonyManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import java.lang.reflect.Field
import java.lang.reflect.Modifier
import java.net.NetworkInterface
import java.security.MessageDigest

/**
 * 改游戏读到的设备ID(框架注入通道)。
 *
 * 老版本为什么「改了跟没改一样」,原因有四条,现在逐条修掉:
 *
 *  1. `if (installed) return` —— 装过一次之后,用户在界面上改的新值根本传不进去,
 *     只有重启游戏才可能生效。
 *     → 现在 hook 只装一次,但「用哪个值」是每次调用时现取的,改完马上生效;
 *       另外每 2 秒会从模块那边重新读一次配置,不用重启游戏。
 *
 *  2. 只盖了 android_id。游戏的设备指纹是多源合并算出来的:
 *     android_id + Build.SERIAL/ro.serialno + IMEI/MEID/IMSI/ICCID + MediaDrm deviceUniqueId
 *     + MAC(WiFi/蓝牙/网卡) + 机型字段。
 *     → 现在这一整套全部按同一个值派生,值稳定(同一个 ID 永远算出同一套),
 *       不是每次随机,也不会跳来跳去。
 *
 *  3. 值格式不对(以前 IMEI 直接返回那串十六进制)。
 *     → IMEI 15 位带 Luhn 校验位、MEID 14 位十六进制、IMSI 460 开头 15 位、
 *       ICCID 8986 开头 20 位、MAC 合法本地管理地址、序列号 16 位字母数字。
 *
 *  4. 安装时机在 loadModule 里,有些游戏的 ContentProvider 在更早的时候就取了 ID。
 *     → HookInit 在 handleLoadPackage 阶段就先调一次 installEarly(),
 *       那时候还没跑游戏自己的任何代码。
 *
 * 所有 hook 都包在 try 里:某台机器上某个 API 不存在就跳过那一条,
 * 不影响别的,更不会把游戏搞挂。
 */
object DeviceIdHook {

    @Volatile
    private var installed = false

    /** 当前生效的假 ID */
    @Volatile
    private var currentId: String = ""

    @Volatile
    private var fullMask: Boolean = false

    /** 模块自己的包名,用来问 Provider 要最新配置 */
    @Volatile
    private var modulePackage: String = "com.tengcd.czr"

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var refreshing: Boolean = false

    @Volatile
    private var lastRefreshAt: Long = 0L

    // ------------------------------------------------------------ 对外入口

    /**
     * 装 hook / 更新值。可以反复调:
     *  - 第一次:真装 hook
     *  - 之后每次:只更新「用哪个值」,以及(全伪装模式下)重刷机型字段
     */
    fun install(fakeId: String, fullMask: Boolean, modulePkg: String? = null) {
        val id = fakeId.trim()
        if (!modulePkg.isNullOrBlank()) modulePackage = modulePkg
        this.fullMask = fullMask
        val idChanged = id != currentId
        currentId = id
        if (installed) {
            if (idChanged) {
                if (id.isBlank()) {
                    log("device id cleared -> real value")
                } else {
                    applySerialFields()
                    if (fullMask) maskBuildFields()
                }
                log("device id updated -> id=$id full=$fullMask")
                reportAsync()
            }
            return
        }
        installed = true

        hookAndroidId()
        hookSettingsQuery()
        hookSettingsCall()
        hookSerial()
        hookSystemProperties()
        hookTelephony()
        hookWifiAndNetwork()
        hookBluetooth()
        hookMediaDrm()
        if (id.isNotBlank()) {
            applySerialFields()
            if (fullMask) maskBuildFields()
        }

        log("device id hook installed, id=$id full=$fullMask")
        reportAsync()
    }

    /** 拿到目标进程的 Context 后绑一下:之后才能定时去问模块要最新配置 */
    fun bindContext(context: Context?) {
        if (context != null) appContext = context.applicationContext ?: context
    }

    /** 手动触发一次重新取值(比如刚注入完) */
    fun refreshNow() {
        lastRefreshAt = 0L
        live()
    }

    // ------------------------------------------------------------ 取值

    /**
     * 每次 hook 调用都走这里。
     *
     * ⚠️ 老版本第一行就是「值是空的就直接 return」——于是「先注入、后开开关」,
     * 或者配置比进程晚一步写好的情况下,hook 装完一次都没刷过值,
     * 表现就是「打开改ID、进游戏,还是老设备」。
     * 现在:值空也去问一次,值到了立刻就热生效。
     */
    private fun live(): String? {
        if (Thread.currentThread() === reportThread) return currentId.ifBlank { null }
        maybeRefresh()
        return currentId.ifBlank { null }
    }

    private fun maybeRefresh() {
        if (refreshing) return
        val ctx = appContext ?: return
        val now = SystemClock.elapsedRealtime()
        if (now - lastRefreshAt < 2000L) return
        lastRefreshAt = now
        refreshing = true
        try {
            val b = ctx.contentResolver.call(
                Uri.parse("content://$modulePackage.so"), "get_devid", null, null
            ) ?: return
            val on = b.getBoolean("enabled")
            val id = b.getString("id").orEmpty().trim()
            val mode = b.getString("mode").orEmpty()
            if (!on) {
                // 开关被关掉:之后的读取立刻回到系统真实值
                if (currentId.isNotEmpty()) {
                    currentId = ""
                    log("device id switch off -> real value")
                    reportAsync()
                }
                return
            }
            if (id.isBlank()) return
            val full = mode == "full"
            if (full && !fullMask) {
                fullMask = true
                maskBuildFields()
            }
            val changed = id != currentId
            currentId = id
            if (changed) {
                applySerialFields()
                log("device id refreshed -> id=$id full=$full")
                reportAsync()
            }
        } catch (t: Throwable) {
        } finally {
            refreshing = false
        }
    }

    // ------------------------------------------------------------ 自检回报

    /** 正在跑自检的那个线程(它自己读 android_id 时不要再去刷新配置,免得绕回来) */
    @Volatile
    private var reportThread: Thread? = null

    @Volatile
    private var lastReportAt: Long = 0L

    /**
     * 把「本进程里现在真正读到的 android_id」回报给模块。
     *
     * 以前改ID完全没法验证:用户只能进游戏看,看不出来就只能说「还是不生效」。
     * 现在注入完(以及每次改值之后)会把本进程读到的那串报回去,
     * 界面上直接显示「目标进程读到 android_id = xxxx」——
     * 读到的是我们填的 → 说明 hook 生效了;读到的是别的 → 一眼就知道卡在哪。
     */
    private fun reportAsync() {
        val ctx = appContext ?: return
        val now = SystemClock.elapsedRealtime()
        if (now - lastReportAt < 1500L) return
        lastReportAt = now
        val wanted = currentId
        try {
            val th = Thread {
                reportThread = Thread.currentThread()
                try {
                    Thread.sleep(350)
                    val seen = try {
                        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
                            .orEmpty()
                    } catch (t: Throwable) {
                        ""
                    }
                    val arg = "id=$wanted&seen=$seen&pid=" + android.os.Process.myPid() +
                        "&pkg=" + ctx.packageName
                    ctx.contentResolver.call(
                        Uri.parse("content://$modulePackage.so"), "report_devid", arg, null
                    )
                } catch (t: Throwable) {
                } finally {
                    reportThread = null
                }
            }
            th.isDaemon = true
            th.start()
        } catch (t: Throwable) {
        }
    }

    // ------------------------------------------------------------ android_id

    private fun hookAndroidId() {
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam?) {
                val p = param ?: return
                val key = param?.args?.getOrNull(1) as? String ?: return
                if (key != Settings.Secure.ANDROID_ID) return
                val id = live() ?: return
                p.result = androidIdOf(id)
            }
        }
        // getString(ContentResolver, String) / getStringForUser(ContentResolver, String, int)
        // 两个重载参数顺序一样,args[1] 都是 key
        hookSafe(Settings.Secure::class.java, "getString", hook)
        hookSafe(Settings.Secure::class.java, "getStringForUser", hook)
        hookSafe(Settings.System::class.java, "getString", hook)
        hookSafe(Settings.System::class.java, "getStringForUser", hook)

        // 新一点的 SDK 直接用 Settings.Secure.getAndroidId(ContentResolver)(API 26+,隐藏 API)
        try {
            XposedBridge.hookAllMethods(
                Settings.Secure::class.java,
                "getAndroidId",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val id = live() ?: return
                        param?.result = androidIdOf(id)
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook Settings.Secure.getAndroidId failed: ${t.message}")
        }
    }

    /**
     * 还有一批 SDK 不走 Settings.Secure 的 Java 方法,直接
     * ContentResolver.call(content://settings/secure, "GET_secure", "android_id")
     * 从 SettingsProvider 拿。这里把返回 Bundle 里的 value 换掉。
     */
    private fun hookSettingsCall() {
        try {
            XposedBridge.hookAllMethods(
                ContentResolver::class.java,
                "call",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val method = p.args.getOrNull(1) as? String ?: return
                        if (method != "GET_secure" && method != "GET_system") return
                        val key = p.args.getOrNull(2) as? String ?: return
                        if (key != Settings.Secure.ANDROID_ID) return
                        val id = live() ?: return
                        val bundle = p.result as? android.os.Bundle ?: return
                        bundle.putString("value", androidIdOf(id))
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook ContentResolver.call failed: ${t.message}")
        }
    }

    /**
     * 有些 SDK 不调 Settings.Secure.getString,直接 query 设置数据库。
     * 这里把结果里 name=android_id 的那一行换掉;别的行原样保留,绝不整表乱改。
     */
    private fun hookSettingsQuery() {
        try {
            XposedBridge.hookAllMethods(
                ContentResolver::class.java,
                "query",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val id = live() ?: return
                        val uri = param?.args?.getOrNull(0) as? Uri ?: return
                        val s = uri.toString()
                        if (!s.contains("settings/secure") && !s.contains("settings/system")) return
                        val selection = p.args.getOrNull(2) as? String
                        val cursor = p.result as? Cursor ?: return
                        p.result = rewriteCursor(cursor, selection, androidIdOf(id))
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook ContentResolver.query failed: ${t.message}")
        }
    }

    private fun rewriteCursor(cursor: Cursor, selection: String?, newValue: String): Cursor {
        return try {
            val cols = cursor.columnNames
            val nameIdx = cols.indexOfFirst { it.equals("name", true) }
            val valueIdx = cols.indexOfFirst { it.equals("value", true) }
            if (valueIdx < 0) return cursor
            // 没有 name 列时,只有选择条件里明确点名 android_id 才敢替换
            val blind = nameIdx < 0 && selection?.contains(Settings.Secure.ANDROID_ID) == true
            if (nameIdx < 0 && !blind) return cursor

            val out = MatrixCursor(cols)
            cursor.moveToPosition(-1)
            while (cursor.moveToNext()) {
                val row = arrayOfNulls<Any?>(cols.size)
                for (i in cols.indices) {
                    row[i] = when (cursor.getType(i)) {
                        Cursor.FIELD_TYPE_NULL -> null
                        Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(i)
                        Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(i)
                        Cursor.FIELD_TYPE_BLOB -> cursor.getBlob(i)
                        else -> cursor.getString(i)
                    }
                }
                val isTarget = blind ||
                    (nameIdx >= 0 && Settings.Secure.ANDROID_ID.equals(
                        row[nameIdx]?.toString(), ignoreCase = true
                    ))
                if (isTarget) row[valueIdx] = newValue
                out.addRow(row)
            }
            cursor.close()
            out
        } catch (t: Throwable) {
            cursor
        }
    }

    // ------------------------------------------------------------ 序列号

    private fun hookSerial() {
        try {
            XposedBridge.hookAllMethods(
                Build::class.java,
                "getSerial",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val id = live() ?: return
                        p.result = serialOf(id)
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook Build.getSerial failed: ${t.message}")
        }
    }

    /** Build.SERIAL 是 static final 字段(Android 10 以后基本拿不到值,但还是要盖) */
    private fun applySerialFields() {
        val id = currentId
        if (id.isBlank()) return
        setStaticString("android.os.Build", "SERIAL", serialOf(id))
    }

    /** ro.serialno 这类属性:有的 SDK 直接读 SystemProperties,不认 Build */
    private fun hookSystemProperties() {
        try {
            val cls = Class.forName("android.os.SystemProperties")
            XposedBridge.hookAllMethods(
                cls,
                "get",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val key = param?.args?.getOrNull(0) as? String ?: return
                        val id = live() ?: return
                        if (isSerialKey(key)) p.result = serialOf(id)
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook SystemProperties failed: ${t.message}")
        }
    }

    private fun isSerialKey(key: String): Boolean {
        val k = key.lowercase()
        return k == "ro.serialno" || k == "ro.boot.serialno" ||
            k == "ro.serial" || k == "persist.sys.serialno" ||
            k == "sys.serialno" || k == "ril.serialnumber"
    }

    // ------------------------------------------------------------ IMEI 那一套

    private fun hookTelephony() {
        // 每条都按「应该返回什么格式」分开挂,不再一律返回同一串十六进制
        hookTelephonyValues(
            listOf("getDeviceId", "getImei", "getDeviceIdForSubscriber", "getDeviceIdForPhone"),
            TelephonyKind.IMEI
        )
        hookTelephonyValues(
            listOf("getMeid", "getMeidForSubscriber"),
            TelephonyKind.MEID
        )
        hookTelephonyValues(
            listOf("getSubscriberId", "getSubscriberIdForSubscriber"),
            TelephonyKind.IMSI
        )
        hookTelephonyValues(
            listOf("getSimSerialNumber", "getSimSerialNumberForSubscriber"),
            TelephonyKind.ICCID
        )
        hookTelephonyValues(
            listOf("getLine1Number", "getLine1NumberForSubscriber"),
            TelephonyKind.PHONE
        )
        hookTelephonyValues(
            listOf("getNai", "getNaiForSubscriber"),
            TelephonyKind.NAI
        )
    }

    private enum class TelephonyKind { IMEI, MEID, IMSI, ICCID, PHONE, NAI }

    private fun hookTelephonyValues(names: List<String>, kind: TelephonyKind) {
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam?) {
                val p = param ?: return
                val id = live() ?: return
                p.result = when (kind) {
                    TelephonyKind.IMEI -> imeiOf(id)
                    TelephonyKind.MEID -> meidOf(id)
                    TelephonyKind.IMSI -> imsiOf(id)
                    TelephonyKind.ICCID -> iccidOf(id)
                    TelephonyKind.PHONE -> phoneOf(id)
                    TelephonyKind.NAI -> naiOf(id)
                }
            }
        }
        for (n in names) {
            try {
                XposedBridge.hookAllMethods(TelephonyManager::class.java, n, hook)
            } catch (t: Throwable) {
                log("hook Telephony.$n failed: ${t.message}")
            }
        }
    }

    // ------------------------------------------------------------ MAC

    private fun hookWifiAndNetwork() {
        val macHook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam?) {
                val p = param ?: return
                val id = live() ?: return
                p.result = macOf(id)
            }
        }
        hookSafe(WifiInfo::class.java, "getMacAddress", macHook)

        try {
            XposedBridge.hookAllMethods(
                NetworkInterface::class.java,
                "getHardwareAddress",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val id = live() ?: return
                        p.result = macBytesOf(id)
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook NetworkInterface failed: ${t.message}")
        }
    }

    private fun hookBluetooth() {
        try {
            XposedBridge.hookAllMethods(
                BluetoothAdapter::class.java,
                "getAddress",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val id = live() ?: return
                        p.result = macOf(id)
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook BluetoothAdapter failed: ${t.message}")
        }
    }

    // ------------------------------------------------------------ MediaDrm

    /**
     * Widevine 的 deviceUniqueId:有些游戏拿它当「这台设备」的硬标识。
     * 这里按 ID 派生 32 字节,值稳定,能正常解密(布局不校验内容)。
     */
    private fun hookMediaDrm() {
        try {
            XposedBridge.hookAllMethods(
                MediaDrm::class.java,
                "getPropertyByteArray",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        val p = param ?: return
                        val name = param?.args?.getOrNull(0) as? String ?: return
                        val id = live() ?: return
                        if (name == "deviceUniqueId") {
                            p.result = deviceUniqueIdOf(id)
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            log("hook MediaDrm failed: ${t.message}")
        }
    }

    // ------------------------------------------------------------ 机型字段(可选)

    private fun maskBuildFields() {
        // 只改跟"这台机器"相关的,而且改成一个固定但合理的值,
        // 不跟着假ID乱变 —— 机型字段跳来跳去反而容易被判异常
        val pairs = listOf(
            "MODEL" to "PEGM00",
            "BRAND" to "OnePlus",
            "MANUFACTURER" to "OnePlus",
            "DEVICE" to "OP4E5D",
            "PRODUCT" to "PEGM00",
            "HARDWARE" to "qcom",
            "BOARD" to "kona",
            "HOST" to "localhost",
            "USER" to "builder",
            "DISPLAY" to "OP4E5D.20240101",
            "FINGERPRINT" to "OnePlus/PEGM00/OP4E5D:13/TP1A.220905.001/1:user/release-keys",
            "BOOTLOADER" to "unknown",
            "SOC_MANUFACTURER" to "Qualcomm",
            "SOC_MODEL" to "SM8250"
        )
        for ((k, v) in pairs) {
            setStaticString("android.os.Build", k, v)
        }
        log("build fields masked for $currentId")
    }

    // ------------------------------------------------------------ 值派生

    private fun digest(id: String, salt: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest((id + "|" + salt).toByteArray())

    private fun hexOf(id: String, salt: String, len: Int): String {
        val b = digest(id, salt)
        val sb = StringBuilder()
        var i = 0
        while (sb.length < len) {
            sb.append(String.format("%02x", b[i % b.size].toInt() and 0xFF))
            i++
        }
        return sb.substring(0, len)
    }

    private fun digitsOf(id: String, salt: String, len: Int): String {
        val b = digest(id, salt)
        val sb = StringBuilder()
        var i = 0
        while (sb.length < len) {
            sb.append((b[i % b.size].toInt() and 0xFF) % 10)
            i++
        }
        return sb.substring(0, len)
    }

    /**
     * android_id:**原样返回用户填的那串**。
     *
     * ⚠️ 老版本这里做了一次 SHA-256 派生(hexOf(id, "android_id", 16)),
     * 于是用户填 abc123,游戏里读到的是另一串完全不相干的十六进制;
     * 而原生通道(libdevid.so)返回的是原值 —— 两条通道对同一个输入给出两个不同的 ID,
     * 用户看到的就是「改了ID不生效」「把原来的值填回去也认不回来」。
     * 现在两条通道统一:填什么,游戏就读到什么(16 位十六进制统一小写)。
     */
    private fun androidIdOf(id: String): String = normalizeId(id)

    private fun normalizeId(id: String): String {
        val v = id.trim()
        if (v.isEmpty()) return v
        var hex = true
        for (c in v) {
            if (!(c.isDigit() || c in 'a'..'f' || c in 'A'..'F')) {
                hex = false
                break
            }
        }
        return if (hex && v.length == 16) v.lowercase() else v
    }

    /**
     * 序列号:跟原生通道对齐 —— 直接用用户填的那串(字母数字部分,最多 16 位)。
     * 老版本这里是派生出来的 16 位,框架注入和进程注入读到的序列号就不是同一个。
     */
    private fun serialOf(id: String): String {
        val clean = id.trim().filter { it.isLetterOrDigit() }
        if (clean.isNotEmpty() && clean.length <= 16) return clean.uppercase()
        return hexOf(id, "serial", 16).uppercase()
    }

    /** IMEI 15 位:前 14 位派生 + 最后一位 Luhn 校验 */
    private fun imeiOf(id: String): String = luhn(digitsOf(id, "imei", 14))

    /** MEID 14 位十六进制大写 */
    private fun meidOf(id: String): String = hexOf(id, "meid", 14).uppercase()

    /** IMSI 15 位,460 开头(中国 MCC) */
    private fun imsiOf(id: String): String = "460" + digitsOf(id, "imsi", 12)

    /** ICCID 20 位,8986 开头 */
    private fun iccidOf(id: String): String = "8986" + digitsOf(id, "iccid", 16)

    /** 本机号码 11 位(1 开头) */
    private fun phoneOf(id: String): String = "1" + digitsOf(id, "line1", 10)

    /** NAI 16 位十六进制 */
    private fun naiOf(id: String): String = hexOf(id, "nai", 16)

    private fun macOf(id: String): String {
        val b = digest(id, "mac")
        val buf = ByteArray(6) { i -> b[i] }
        buf[0] = ((buf[0].toInt() and 0xFC) or 0x02).toByte() // 本地管理地址位
        return buf.joinToString(":") { String.format("%02X", it.toInt() and 0xFF) }
    }

    private fun macBytesOf(id: String): ByteArray {
        val b = digest(id, "mac")
        val buf = ByteArray(6) { i -> b[i] }
        buf[0] = ((buf[0].toInt() and 0xFC) or 0x02).toByte()
        return buf
    }

    private fun deviceUniqueIdOf(id: String): ByteArray {
        val a = digest(id, "drm1")
        val b = digest(id, "drm2")
        return a + b // 32 字节
    }

    /** 给 14 位数字补一位 Luhn 校验位 */
    private fun luhn(payload: String): String {
        var sum = 0
        var dbl = true
        for (i in payload.indices.reversed()) {
            var d = payload[i] - '0'
            if (dbl) {
                d *= 2
                if (d > 9) d -= 9
            }
            sum += d
            dbl = !dbl
        }
        return payload + ((10 - sum % 10) % 10)
    }

    // ------------------------------------------------------------ 工具

    private fun hookSafe(cls: Class<*>, method: String, hook: XC_MethodHook) {
        try {
            XposedBridge.hookAllMethods(cls, method, hook)
        } catch (t: Throwable) {
            log("hook $method failed: ${t.message}")
        }
    }

    /**
     * 改 static final String 字段。
     *
     * 直接 Field.set 会被 final 拦掉,所以先把 accessFlags 里的 FINAL 位清掉。
     * 拿不到 accessFlags 的话就退回 XposedHelpers,再不行就算了 —— 少改一个字段
     * 不影响 android_id 那条主路。
     */
    private fun setStaticString(clsName: String, fieldName: String, value: String) {
        if (value.isBlank()) return
        try {
            val cls = Class.forName(clsName)
            val f: Field = cls.getDeclaredField(fieldName)
            f.isAccessible = true
            try {
                val flags = Field::class.java.getDeclaredField("accessFlags")
                flags.isAccessible = true
                val cur = flags.getInt(f)
                flags.setInt(f, cur and Modifier.FINAL.inv())
            } catch (t: Throwable) {
                // 拿不到就算了,下面 set 会自己再试一次
            }
            f.set(null, value)
        } catch (t: Throwable) {
            try {
                XposedHelpers.setStaticObjectField(Class.forName(clsName), fieldName, value)
            } catch (t2: Throwable) {
                log("set $clsName.$fieldName failed: ${t2.message}")
            }
        }
    }

    private fun log(msg: String) {
        try {
            XposedBridge.log("[Tengcd] $msg")
        } catch (t: Throwable) {
        }
    }
}
