package com.tengcd.czr.inject

import android.content.Context
import android.net.Uri
import com.tengcd.czr.util.Activation
import com.tengcd.czr.util.DeviceIdPrefs
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 */
object InjectorRouter {

    /** 本应用包名(改ID的配置是放在我们自己的 ContentProvider 上的) */
    private const val OUR_PACKAGE = "com.tengcd.czr"

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        // 换过安装包也要先把内置 so 重新解包一遍,别拿旧的占位文件去加载
        ModuleStore.ensureBundled(context)

        // ⚠️ 改ID 是**独立的一条路**:游戏模块有没有准备好、注入成没成功,都不该影响它。
        //    老版本把它挂在「游戏模块注入成功」之后,于是模块一旦没就绪/注入失败,
        //    改ID 连试都没试 —— 用户那边看到的就是「改ID不生效」。
        val devId = if (mode == InjectionMode.PROCESS) {
            injectDeviceId(context, targetPkg)
        } else {
            frameworkDevIdNote(context)
        }

        if (!ModuleStore.isDownloaded(context)) {
            // 选中的这一版本机没有真 so、只有空文件占位时说清楚是哪一版,
            // 不再偷偷换成别的版本去注入(以前就是这么被换回 v0.24 的)。
            val f = ModuleStore.effectiveFile(context)
            val why = if (f.isFile) {
                "选中的 " + ModuleStore.sourceLabel() + " 本机还没有 so 文件(空文件占位)," +
                    "把这个版本的 so 放进私有目录或导入本机 SO 后再注入"
            } else {
                "选中的 " + ModuleStore.sourceLabel() + " 还没解包出文件"
            }
            return@withContext PtraceInjectResult.Failure(
                PtraceInjectFailure.MODULE_NOT_READY,
                join(why, devId)
            )
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg, devId)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry, devId)
        }
    }

    /**
     * 框架注入:我们不需要自己动手,只要把"用哪个 so"写进交接文件,
     * 目标进程起来时由 HookInit 自己从安装包里抽出来加载。
     */
    private suspend fun frameworkInject(
        context: Context,
        targetPkg: String,
        devId: String?
    ): PtraceInjectResult {
        // 框架探测只当提示用,不当门槛。
        // 以前探测不到就直接失败,于是「框架明明装着、只是管理器包名/目录认不出来」
        // 的机器上,连把 so 准备好这一步都做不了 —— 用户看到的就是「框架不能用」。
        // 现在照常把交接信息写好(不写才真的什么都不可能发生),界面上把原因说清楚。
        val noFramework = !XposedDetector.isFrameworkInstalled(context)
        val info = ModuleStore.currentInfo(context)
        if (!info.ready) {
            val why = when {
                !info.exists -> "还没解包出内置 SO"
                info.placeholder -> "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
                !info.isElf -> "内置 SO 不是有效的 ELF 文件"
                else -> "内置 SO 不完整"
            }
            return PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, join(why, devId))
        }

        // 每次重新注入都先把上次的状态抹掉,免得界面一直显示"已激活"
        Activation.reset()
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null

        val soPath = info.file.absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        val noFwHint = if (noFramework) " / 没探测到框架:确认框架已装并把本模块勾到游戏上" else ""
        if (pids.isEmpty()) {
            // 目标还没跑:这不叫失败,下次它启动时模块会自己载入
            return PtraceInjectResult.Success(
                pid = -1,
                soPath = soPath,
                detail = "已准备好(" + ModuleStore.sourceLabel() + "),启动目标后自动加载" + noFwHint
            )
        }

        // 目标在跑:等目标进程回报(它下次启动才会重新加载)
        delay(2500)
        // 只认「目标进程真的报上来、而且那个 pid 现在还活着」这一种结论
        val activated = Activation.verify(context)
        // 目标进程自己读到的 android_id(改ID到底有没有生效,看这一行)
        val devIdSeen = devIdReportNote(context) ?: devId
        if (activated) {
            return PtraceInjectResult.Success(pids.first(), soPath, join("已生效", devIdSeen))
        }
        val error = InjectionPrefs.frameworkError
        return PtraceInjectResult.Success(
            pid = pids.first(),
            soPath = soPath,
            detail = join(
                if (error.isNullOrBlank()) {
                    "已准备好(" + ModuleStore.sourceLabel() + "),重启目标后生效" + noFwHint
                } else {
                    "已准备好,但目标加载失败:" + error
                },
                devIdSeen
            )
        )
    }

    /**
     * 进程注入:目标在跑 -> 把 so 挪到目标数据目录 -> ptrace 附加 -> 远程 dlopen。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?,
        devId: String?
    ): PtraceInjectResult {
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.SAME_UID_REQUIRED,
                join("本应用与目标应用的 uid 不一致(需要 sharedUserId 相同)", devId)
            )
        }
        val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_NOT_FOUND, join("目标没在跑", devId)
            )
        }
        val staged = ModuleStore.stageForTarget(context, targetPkg)
            ?: ModuleStore.stageForTargetPrivileged(context, targetPkg)
            ?: return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE,
                join("复制不进目标数据目录(权限不足)", devId)
            )

        var last: PtraceInjectResult? = null
        for (pid in pids) {
            val r = PtraceInjector.inject(pid, staged.absolutePath, entry)
            if (r is PtraceInjectResult.Success) {
                return PtraceInjectResult.Success(pid, staged.absolutePath, join(r.detail, devId))
            }
            last = r
        }

        // 把原生侧的具体原因带出去,界面上直接看得到卡在哪一步
        PtraceInjector.lastDetail?.let { detail ->
            val all = last
            if (all is PtraceInjectResult.Failure) {
                return PtraceInjectResult.Failure(all.kind, join(detail, devId))
            }
        }
        val all = last
        return if (all is PtraceInjectResult.Failure) {
            PtraceInjectResult.Failure(all.kind, join(all.detail, devId))
        } else {
            PtraceInjectResult.Failure(PtraceInjectFailure.UNKNOWN, devId)
        }
    }

    // ------------------------------------------------------------ 改设备ID

    /**
     * 把改设备ID的原生模块送进目标进程。
     *
     * 跟游戏模块完全解耦:
     *  - 游戏模块没就绪 / 注入失败,照样把改ID模块送进去;
     *  - 目标有几个进程就送几个(游戏经常把读设备ID这一步放在子进程里);
     *  - 每次注入都重写一遍 devid.cfg,不会拿上次的旧值;
     *  - 返回一句人话状态,界面上直接看得到成没成、值是多少。
     */
    private fun injectDeviceId(context: Context, targetPkg: String): String {
        return try {
            if (!DeviceIdPrefs.enabled) return ""
            val id = DeviceIdPrefs.effectiveAndroidId()
            if (id.isBlank()) return "改ID:开关开着,但ID是空的"
            // 先把配置落成文件:原生层读的就是这份
            DeviceIdPrefs.writeCfg(context)

            val pids = PackageUtil.findPids(targetPkg, PackageUtil.uidOf(context, targetPkg))
            if (pids.isEmpty()) {
                return "改ID:目标没在跑,启动游戏后再点一次注入(游戏启动那一刻读到的就是新ID)"
            }
            val so = ModuleStore.stageDeviceId(context, targetPkg)
                ?: return "改ID:改ID模块复制不进目标目录(权限不足)"
            var ok = 0
            var why = ""
            for (pid in pids) {
                val r = PtraceInjector.inject(pid, so.absolutePath, null)
                if (r is PtraceInjectResult.Success) {
                    ok++
                } else if (r is PtraceInjectResult.Failure) {
                    why = r.detail ?: r.kind.name
                }
            }
            if (ok > 0) {
                "改ID:已注入 " + ok + "/" + pids.size + " 个进程,值 " + id +
                    "(注入后要把游戏完全杀掉再启动,它启动那一刻读到的才是新值)"
            } else {
                "改ID:注入失败(" + why + ")"
            }
        } catch (t: Throwable) {
            "改ID:失败(" + (t.message ?: t.javaClass.simpleName) + ")"
        }
    }

    /** 框架注入下:确认配置已写好,并告诉用户值在哪一步生效 */
    private fun frameworkDevIdNote(context: Context): String {
        return try {
            if (!DeviceIdPrefs.enabled) return ""
            val id = DeviceIdPrefs.effectiveAndroidId()
            if (id.isBlank()) return "改ID:开关开着,但ID是空的"
            DeviceIdPrefs.writeCfg(context)
            "改ID:已打开,值 " + id + "(框架模块在游戏进程里接管;改了值要重启游戏)"
        } catch (t: Throwable) {
            ""
        }
    }

    /** 问模块要「目标进程自己读到的 android_id」:这是 hook 到底有没有生效的唯一硬证据 */
    private fun devIdReportNote(context: Context): String? = try {
        val b = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_devid_report", null, null
        )
        if (b == null || !b.getBoolean("has")) {
            null
        } else {
            val seen = b.getString("seen").orEmpty()
            val pid = b.getString("pid").orEmpty()
            val id = b.getString("id").orEmpty()
            when {
                seen.isBlank() -> "改ID:目标进程回报了,但没读到 android_id"
                id.isBlank() -> "改ID:目标进程读到 android_id = " + seen + "(没填值/开关是关的)"
                seen == id -> "改ID:已生效,目标进程(pid " + pid + ")读到 android_id = " + seen
                else -> "改ID:目标进程(pid " + pid + ")读到 android_id = " + seen +
                    ",跟设置里的 " + id + " 不一致(游戏可能缓存了,强停+清数据再启动)"
            }
        }
    } catch (t: Throwable) {
        null
    }

    /** 两段人话拼一起,空的自动忽略 */
    private fun join(a: String?, b: String?): String? {
        val x = a?.trim().orEmpty()
        val y = b?.trim().orEmpty()
        return when {
            x.isEmpty() && y.isEmpty() -> null
            x.isEmpty() -> y
            y.isEmpty() -> x
            else -> x + " · " + y
        }
    }
}
