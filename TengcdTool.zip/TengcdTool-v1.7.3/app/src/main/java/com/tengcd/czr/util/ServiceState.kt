package com.tengcd.czr.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * 跨组件共享的运行态:注入服务在跑没有、框架模块在目标里激活没有。
 * Provider(被目标进程调用)、Service、ViewModel 都读写这里。
 *
 * ⚠️ 两个状态必须分清楚,别再混:
 *  - selfLoaded      :框架把模块注入到了「模块自己」的进程。只说明框架认得这个模块。
 *  - frameworkActive :**目标游戏进程**里真的把 so 加载起来了。界面上那个「已激活」只能看它。
 *
 * frameworkActive 只有一个来源:Activation 校验通过的上报。这里不再直接把它置 true。
 */
object ServiceState {

    val serviceRunning = MutableStateFlow(false)

    /** 目标游戏进程回报的注入状态(唯一可以显示成「已激活」的依据) */
    val frameworkActive = MutableStateFlow(false)

    /** 框架识别到模块(模块自己被注入),不等于游戏里注入成功 */
    val frameworkSelfLoaded = MutableStateFlow(false)

    val lastInjectOk = MutableStateFlow<Boolean?>(null)
    val lastInjectDetail = MutableStateFlow<String?>(null)

    /**
     * 目标进程报上来了。pid / uid 必须由调用方从 Binder 或 socket 对端取真实值,
     * 校验不过就当没报(以前谁发一句都算激活,就是界面假状态的主因)。
     */
    fun onReportedActive(
        context: Context?,
        pid: Int,
        uid: Int,
        pkg: String,
        path: String? = null,
        process: String? = null
    ): Boolean {
        val ok = Activation.report(context, pid, uid, pkg, path, process)
        if (ok) {
            frameworkActive.value = true
            lastInjectOk.value = true
            lastInjectDetail.value = null
        } else {
            // 报上来了但对不上:记下来,界面显示「未激活」并给出原因
            val why = "收到进程上报,但和目标进程对不上(pid=$pid),已忽略"
            InjectionPrefs.frameworkError = why
            frameworkActive.value = false
            lastInjectDetail.value = why
        }
        return ok
    }

    /** 模块自己被框架注入(框架认得模块了) */
    fun onSelfLoaded() {
        frameworkSelfLoaded.value = true
        InjectionPrefs.frameworkSelfLoaded = true
    }

    /** 目标进程报了失败:把「已激活」撤掉,别再挂着骗人 */
    fun onReportedFailure(detail: String?) {
        frameworkActive.value = false
        Activation.markFailure(detail)
        lastInjectOk.value = false
        lastInjectDetail.value = detail
    }

    /** 从偏好恢复界面状态:激活与否一律重新核对,不直接信以前存的 true */
    fun syncFromPrefs(context: Context? = null) {
        frameworkActive.value = Activation.verify(context)
        frameworkSelfLoaded.value = InjectionPrefs.frameworkSelfLoaded
        lastInjectDetail.value = InjectionPrefs.frameworkError
    }
}
