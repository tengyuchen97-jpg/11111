package com.tengcd.czr.util

import android.content.Context
import android.os.Process
import java.io.File

/**
 * 「游戏里到底激活了没有」的唯一判定入口。
 *
 * 老版本为什么会出现「根本没激活,界面却显示已激活」:
 *  - 目标进程只要发一句 REPORT_ACTIVE 就算数,不认 pid —— 谁发的、有没有真的加载,一概不问
 *  - 注入服务只要把 so 准备好也记成成功
 *  - 状态存成偏好里的一个 true,进程死了、游戏退了、包名换了,也没人把它改回来
 *
 * 现在只有一条规矩:
 *   目标进程真的回报过 + 那个 pid 现在仍然活着 + 仍然是目标应用 + 包名没换 + 记录没过期
 * 五条全满足才叫激活;任何一条不满足,立刻判未激活,并把旧记录清掉。
 *
 * 另外,上报时里的 pid / uid 一律由调用方从 Binder / socket 对端取,
 * 绝不信任上报内容里自报的 pid(那是可以被随便填的)。
 */
object Activation {

    /** 记录最多认 12 小时:防 pid 被系统回收后复用给别的进程,把旧的激活记录撞成新的 */
    private const val MAX_AGE_MS = 12 * 60 * 60 * 1000L

    /**
     * 目标进程上报成功。
     *
     * @param callerPid 上报进程的真实 pid(Binder.getCallingPid / socket 对端),必须 > 0
     * @param callerUid 上报进程的真实 uid,<= 0 表示拿不到,跳过这一项校验
     * @param pkg       上报进程自己报的包名
     * @return 通过校验并记录下来才是 true
     */
    fun report(
        context: Context?,
        callerPid: Int,
        callerUid: Int,
        pkg: String,
        path: String?,
        process: String?
    ): Boolean {
        val reported = pkg.trim()
        val target = InjectionPrefs.targetPackage.trim()

        if (callerPid <= 0) return false
        if (reported.isBlank()) return false
        // 上报的包名必须是当前选定的目标(没选目标时,只接受真实存在的包名)
        if (target.isNotBlank() && reported != target) return false

        // ① 进程真的在
        if (!pidAlive(callerPid)) return false

        // ② 那个 pid 的命令行确实是这个包(读不到就退到 uid 判断,不要凭这一条否掉)
        val cmd = cmdlineOf(callerPid)
        if (!cmd.isNullOrBlank()) {
            val okName = cmd == reported || cmd.startsWith("$reported:")
            if (!okName) return false
        }

        // ③ uid 对得上(拿得到才算)
        val expectedUid = uidOf(context, reported)
        val realUid = if (callerUid > 0) callerUid else -1
        if (expectedUid > 0 && realUid > 0 && expectedUid != realUid) return false

        // 全都对得上:记下来,连 pid / uid / 包名一起记
        InjectionPrefs.activePid = callerPid
        InjectionPrefs.activeUid = if (realUid > 0) realUid else expectedUid
        InjectionPrefs.activePkg = reported
        InjectionPrefs.frameworkActiveAt = System.currentTimeMillis()
        InjectionPrefs.frameworkActive = true
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkProcess = process
        if (!path.isNullOrBlank()) InjectionPrefs.frameworkPath = path
        return true
    }

    /**
     * 现在还算不算「已激活」。界面每次显示前都必须过这一遍。
     *
     * 只要记录对不上(进程没了 / 包名换了 / 过期了 / 根本不是目标应用),就把状态清掉。
     */
    fun verify(context: Context?): Boolean {
        if (!InjectionPrefs.frameworkActive) {
            clearStale()
            return false
        }
        val pid = InjectionPrefs.activePid
        val pkg = InjectionPrefs.activePkg.orEmpty()
        val at = InjectionPrefs.frameworkActiveAt
        val target = InjectionPrefs.targetPackage.trim()

        if (pid <= 0 || pkg.isBlank() || at <= 0L) {
            clearStale()
            return false
        }
        if (target.isNotBlank() && pkg != target) {
            clearStale()
            return false
        }
        if (System.currentTimeMillis() - at > MAX_AGE_MS) {
            clearStale()
            return false
        }
        if (!pidAlive(pid)) {
            clearStale()
            return false
        }
        val cmd = cmdlineOf(pid)
        if (!cmd.isNullOrBlank() && cmd != pkg && !cmd.startsWith("$pkg:")) {
            // pid 被系统回收给了别的进程
            clearStale()
            return false
        }
        val expectedUid = uidOf(context, pkg)
        val recordedUid = InjectionPrefs.activeUid
        if (expectedUid > 0 && recordedUid > 0 && expectedUid != recordedUid) {
            clearStale()
            return false
        }
        // 最后再确认一遍:目标应用还装着(卸载了就谈不上激活)
        if (context != null && expectedUid <= 0 && !installed(context, pkg)) {
            clearStale()
            return false
        }
        return true
    }

    /** 目标进程报了失败:立刻撤掉「已激活」 */
    fun markFailure(detail: String?) {
        InjectionPrefs.frameworkError = detail
        clearStale()
    }

    /** 注入前先把旧记录抹掉,免得新的一次还没结果界面就亮着 */
    fun reset() {
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.activePid = 0
        InjectionPrefs.activeUid = -1
        InjectionPrefs.activePkg = null
        InjectionPrefs.frameworkActiveAt = 0L
    }

    private fun clearStale() {
        if (InjectionPrefs.frameworkActive) InjectionPrefs.frameworkActive = false
        if (InjectionPrefs.activePid != 0) InjectionPrefs.activePid = 0
        if (!InjectionPrefs.activePkg.isNullOrEmpty()) InjectionPrefs.activePkg = null
        if (InjectionPrefs.frameworkActiveAt != 0L) InjectionPrefs.frameworkActiveAt = 0L
    }

    private fun pidAlive(pid: Int): Boolean = try {
        File("/proc/$pid").exists()
    } catch (t: Throwable) {
        false
    }

    private fun cmdlineOf(pid: Int): String? = try {
        if (pid <= 0) null
        else File("/proc/$pid/cmdline").readText().trim('\u0000', '\n', ' ')
    } catch (t: Throwable) {
        null
    }

    private fun uidOf(context: Context?, pkg: String): Int {
        if (context == null || pkg.isBlank()) return -1
        return try {
            context.packageManager.getApplicationInfo(pkg, 0).uid
        } catch (t: Throwable) {
            -1
        }
    }

    private fun installed(context: Context, pkg: String): Boolean = try {
        context.packageManager.getApplicationInfo(pkg, 0)
        true
    } catch (t: Throwable) {
        false
    }

    /** 给界面用:未激活时说明原因(不再只给一句「未激活」) */
    fun inactiveReason(context: Context?): String? {
        if (InjectionPrefs.frameworkActive) return null
        val pid = InjectionPrefs.activePid
        val at = InjectionPrefs.frameworkActiveAt
        return when {
            at > 0L && pid > 0 && !pidAlive(pid) -> "上次注入的进程已经退出"
            at > 0L && System.currentTimeMillis() - at > MAX_AGE_MS -> "激活记录已过期"
            else -> InjectionPrefs.frameworkError
        }
    }

    /** 当前进程是不是目标进程(给上报前自检用,防止自己忽悠自己) */
    fun isTargetProcess(context: Context): Boolean {
        val target = InjectionPrefs.targetPackage.trim()
        return target.isNotBlank() && context.packageName == target
    }

    @Suppress("unused")
    private fun myTid(): Int = Process.myPid()
}
