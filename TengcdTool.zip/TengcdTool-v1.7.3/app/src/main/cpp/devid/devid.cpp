/*
 * libdevid.so —— 免 root 改设备ID(进程注入通道)
 *
 * 被 ptrace 注入到游戏进程后:
 *   1. 改 Build 里那几个"这台机器是谁"的字段(序列号等)
 *   2. 把 Settings.Secure.getString / getStringForUser 换成我们的实现,
 *      android_id 直接返回用户设的新值,别的 key 照原样从 SettingsProvider 取
 *   3. 把 SystemProperties.native_get 的 JNI 入口换掉,
 *      ro.serialno / ro.boot.serialno 这类也一起换(部分 SDK 在 native 层读)
 *
 * 两条原则:
 *   - 任何一步失败都只跳过这一步,绝不能把游戏搞挂
 *   - 配置读不到就整个什么都不做
 */

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define LOG_TAG "TengcdDevId"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

#define ACC_NATIVE 0x0100u
#define ACC_FAST_NATIVE 0x00080000u

static JavaVM *g_vm = NULL;
static char g_id[128] = {0};
static int g_full = 0;
/* 配置会被 watch 线程改、被游戏线程读,加把锁,别读到写了一半的值 */
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

/* ArtMethod 里 data_ / quick-entry 的字节偏移,运行时自己探出来 */
static int g_data_off = -1;
static int g_entry_off = -1;
static void *g_trampoline = NULL;

static uintptr_t g_art_lo = 0, g_art_hi = 0;
static uintptr_t g_rt_lo = 0, g_rt_hi = 0;

/* ------------------------------------------------------------------ 配置 */

/* 读一次配置。开关开着且有值 -> 返回 1 并带出 id / mode */
static int load_cfg(char *id_out, size_t n, int *full_out) {
    const char *paths[] = {
        "/data/data/com.tengcd.czr/files/devid.cfg",
        "/data/user/0/com.tengcd.czr/files/devid.cfg",
        "/data/user/10/com.tengcd.czr/files/devid.cfg",
        "/data/user/999/com.tengcd.czr/files/devid.cfg",
    };
    for (unsigned i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        FILE *f = fopen(paths[i], "r");
        if (!f) continue;
        char line[256];
        int enabled = 0;
        int full = 0;
        char id[128] = {0};
        while (fgets(line, sizeof(line), f)) {
            char *eq = strchr(line, '=');
            if (!eq) continue;
            *eq = 0;
            char *k = line;
            char *v = eq + 1;
            while (*v == ' ') v++;
            char *nl = strpbrk(v, "\r\n");
            if (nl) *nl = 0;
            if (strcmp(k, "enabled") == 0) enabled = (v[0] == '1');
            else if (strcmp(k, "id") == 0) snprintf(id, sizeof(id), "%s", v);
            else if (strcmp(k, "mode") == 0) full = (strcmp(v, "full") == 0);
        }
        fclose(f);
        if (enabled && id[0]) {
            snprintf(id_out, n, "%s", id);
            if (full_out) *full_out = full;
            return 1;
        }
    }
    return 0;
}

/* 当前生效的假 ID(线程安全) */
static void current_id(char *out, size_t n) {
    pthread_mutex_lock(&g_lock);
    snprintf(out, n, "%s", g_id);
    pthread_mutex_unlock(&g_lock);
}

/* 写入新的假 ID;id 为空 = 交回系统真实值 */
static void store_id(const char *id, int full) {
    pthread_mutex_lock(&g_lock);
    if (id && id[0]) snprintf(g_id, sizeof(g_id), "%s", id);
    else g_id[0] = 0;
    g_full = full;
    pthread_mutex_unlock(&g_lock);
}

/* ------------------------------------------------------------------ maps */

static int maps_cb(struct dl_phdr_info *info, size_t size, void *data) {
    (void) size;
    (void) data;
    if (!info->dlpi_name) return 0;
    uintptr_t lo = 0, hi = 0;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr) *ph = &info->dlpi_phdr[i];
        if (ph->p_type != PT_LOAD) continue;
        uintptr_t s = info->dlpi_addr + ph->p_vaddr;
        uintptr_t e = s + ph->p_memsz;
        if (!lo || s < lo) lo = s;
        if (e > hi) hi = e;
    }
    if (strstr(info->dlpi_name, "libart.so")) {
        g_art_lo = lo;
        g_art_hi = hi;
    } else if (strstr(info->dlpi_name, "libandroid_runtime.so")) {
        g_rt_lo = lo;
        g_rt_hi = hi;
    }
    return 0;
}

static int in_range(uintptr_t p, uintptr_t lo, uintptr_t hi) {
    return lo && hi && p >= lo && p < hi;
}

/* ------------------------------------------------------------------ 探测 ArtMethod 布局 */

/*
 * 拿 android.os.SystemProperties.native_get(String) 当参照:
 * 它本来就是个 JNI 方法,data_ 里一定是指向 libandroid_runtime.so 的函数指针,
 * quick-entry 一定在 libart.so 里(通用 JNI 跳板)。
 * 顺着这个特征把偏移试出来,不同安卓版本改布局也不用改代码。
 */
static void probe_art_method(JNIEnv *env) {
    dl_iterate_phdr(maps_cb, NULL);
    if (!g_art_lo || !g_rt_lo) {
        LOGI("probe: libart/libandroid_runtime not found");
        return;
    }
    jclass cls = env->FindClass("android/os/SystemProperties");
    if (!cls) return;
    jmethodID mid = env->GetStaticMethodID(
            cls, "native_get", "(Ljava/lang/String;)Ljava/lang/String;");
    if (!mid) {
        env->ExceptionClear();
        LOGI("probe: native_get not found");
        return;
    }
    uintptr_t m = (uintptr_t) mid;
    int psz = (int) sizeof(void *);
    /*
     * 必须**同时**满足两个条件才算找到:
     *   a(=data_) 指向 libandroid_runtime.so 里的那个 native 函数,
     *   b(=quick-entry)指向 libart.so 里的通用 JNI 跳板。
     * 老版本只看 b,于是 32 位机器上会在错位(off=12)上误判成 data_,
     * 接着把 access_flags/method_index 写坏 —— 结果就是「注入完没反应」或者游戏直接崩。
     */
    for (int off = psz; off <= 48; off += 4) {
        void *a = *(void **) (m + off);
        void *b = *(void **) (m + off + psz);
        uintptr_t ua = (uintptr_t) a, ub = (uintptr_t) b;
        if (in_range(ua, g_rt_lo, g_rt_hi) && in_range(ub, g_art_lo, g_art_hi)) {
            g_data_off = off;
            g_entry_off = off + psz;
            g_trampoline = b;
            LOGI("probe ok: data_off=%d entry_off=%d tramp=%p", g_data_off, g_entry_off, g_trampoline);
            return;
        }
    }
    /*
     * 探不出来就按已知布局兜底:
     *   64 位:declaring_class_(4) access_flags(4) dex_method_index(4) method_index(4) data_(8) entry(8)
     *   32 位:同上,data_(4) entry(4)
     */
    if (psz == 8) {
        g_data_off = 16;
        g_entry_off = 24;
    } else {
        g_data_off = 16;
        g_entry_off = 20;
    }
    if (g_trampoline == NULL) {
        /* 退一步:entry 只要落在 libart 里就能当跳板用 */
        void *cand = *(void **) (m + g_entry_off);
        if (in_range((uintptr_t) cand, g_art_lo, g_art_hi)) g_trampoline = cand;
    }
    LOGI("probe failed, fallback data_off=%d entry_off=%d tramp=%p",
         g_data_off, g_entry_off, g_trampoline);
    if (g_trampoline == NULL) {
        LOGI("probe: no trampoline, give up");
        g_data_off = -1;
        g_entry_off = -1;
    }
}

/* ------------------------------------------------------------------ 改 Build 字段 */

static void set_build_str(JNIEnv *env, const char *name, const char *value) {
    jclass build = env->FindClass("android/os/Build");
    if (!build) {
        env->ExceptionClear();
        return;
    }
    jfieldID fid = env->GetStaticFieldID(build, name, "Ljava/lang/String;");
    if (!fid) {
        env->ExceptionClear();
        return;
    }
    jstring js = env->NewStringUTF(value);
    env->SetStaticObjectField(build, fid, js);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(js);
}

static void patch_build(JNIEnv *env) {
    char cur[128] = {0};
    current_id(cur, sizeof(cur));
    if (!cur[0]) return;
    char serial[64] = {0};
    snprintf(serial, sizeof(serial), "%s", cur);
    for (char *c = serial; *c; c++) {
        if (*c >= 'a' && *c <= 'z') *c = (char) (*c - 'a' + 'A');
    }
    set_build_str(env, "SERIAL", serial);
    if (g_full) {
        set_build_str(env, "MODEL", "PEGM00");
        set_build_str(env, "BRAND", "OnePlus");
        set_build_str(env, "MANUFACTURER", "OnePlus");
        set_build_str(env, "DEVICE", "OP4E5D");
        set_build_str(env, "PRODUCT", "PEGM00");
        set_build_str(env, "HARDWARE", "qcom");
        set_build_str(env, "BOARD", "kona");
        set_build_str(env, "DISPLAY", "OP4E5D.20240101");
        set_build_str(env, "FINGERPRINT",
                      "OnePlus/PEGM00/OP4E5D:13/TP1A.220905.001/1:user/release-keys");
    }
    LOGI("build patched");
}

/* ------------------------------------------------------------------ hook 工具 */

static int patch_method(void *method, void *fn, int force_native) {
    if (g_data_off < 0 || !g_trampoline || !method) return 0;
    uintptr_t page = (uintptr_t) method & ~(uintptr_t) 0xFFF;
    size_t len = 0x1000;
    if (mprotect((void *) page, len, PROT_READ | PROT_WRITE) != 0) {
        LOGI("mprotect failed for %p", method);
        return 0;
    }
    *(void **) ((char *) method + g_data_off) = fn;
    if (force_native) {
        uint32_t *flags = (uint32_t *) ((char *) method + 4);
        uint32_t f = *flags;
        f &= ~ACC_FAST_NATIVE;
        f |= ACC_NATIVE;
        *flags = f;
        *(void **) ((char *) method + g_entry_off) = g_trampoline;
    }
    __builtin___clear_cache((char *) method, (char *) method + 64);
    return 1;
}

/* ------------------------------------------------------------------ 原来的值 */

static char g_secure_uri[] = "content://settings/secure";
static char g_system_uri[] = "content://settings/system";

static jstring call_settings(JNIEnv *env, jobject resolver, const char *uriStr,
                             const char *cmd, jstring key) {
    if (!resolver) return NULL;
    jclass uriCls = env->FindClass("android/net/Uri");
    jclass crCls = env->FindClass("android/content/ContentResolver");
    jclass bundleCls = env->FindClass("android/os/Bundle");
    if (!uriCls || !crCls || !bundleCls) {
        env->ExceptionClear();
        return NULL;
    }
    jmethodID parse = env->GetStaticMethodID(uriCls, "parse",
                                             "(Ljava/lang/String;)Landroid/net/Uri;");
    jmethodID call = env->GetMethodID(crCls, "call",
                                      "(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;");
    jmethodID getString = env->GetMethodID(bundleCls, "getString",
                                           "(Ljava/lang/String;)Ljava/lang/String;");
    if (!parse || !call || !getString) {
        env->ExceptionClear();
        return NULL;
    }
    jstring juri = env->NewStringUTF(uriStr);
    jstring jcmd = env->NewStringUTF(cmd);
    jobject uri = env->CallStaticObjectMethod(uriCls, parse, juri);
    jobject bundle = env->CallObjectMethod(resolver, call, uri, jcmd, key, NULL);
    jstring out = NULL;
    if (bundle && !env->ExceptionCheck()) {
        jstring jvalue = env->NewStringUTF("value");
        out = (jstring) env->CallObjectMethod(bundle, getString, jvalue);
        env->DeleteLocalRef(jvalue);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    return out;
}

/* ------------------------------------------------------------------ hook 实现 */

static jstring JNICALL hook_secure_get_string(JNIEnv *env, jclass clazz,
                                              jobject resolver, jstring name) {
    if (!name) return NULL;
    const char *key = env->GetStringUTFChars(name, NULL);
    jstring ret = NULL;
    if (key && strcmp(key, "android_id") == 0) {
        /* 原样返回用户填的值(不派生、不改格式),跟框架通道保持一致 */
        char cur[128] = {0};
        current_id(cur, sizeof(cur));
        ret = env->NewStringUTF(cur);
    } else {
        /* 别的 key 照原样给,不能让游戏读别的设置读崩 */
        ret = call_settings(env, resolver, g_secure_uri, "GET_secure", name);
    }
    if (key) env->ReleaseStringUTFChars(name, key);
    return ret;
}

static jstring JNICALL hook_system_get_string(JNIEnv *env, jclass clazz,
                                              jobject resolver, jstring name) {
    if (!name) return NULL;
    return call_settings(env, resolver, g_system_uri, "GET_system", name);
}


/* ------------------------------------------------------------------ 安装 */

static void install_hooks(JNIEnv *env) {
    patch_build(env);

    /* android_id: Settings.Secure.getString(ContentResolver, String) */
    jclass sec = env->FindClass("android/provider/Settings$Secure");
    if (sec) {
        jmethodID m1 = env->GetStaticMethodID(
                sec, "getString",
                "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
        if (m1) {
            int ok = patch_method((void *) m1, (void *) hook_secure_get_string, 1);
            LOGI("hook Settings.Secure.getString -> %d", ok);
        } else {
            env->ExceptionClear();
        }
        jmethodID m2 = env->GetStaticMethodID(
                sec, "getStringForUser",
                "(Landroid/content/ContentResolver;Ljava/lang/String;I)Ljava/lang/String;");
        if (m2) {
            /* 参数多了个 int,单独一个入口 */
            int ok = patch_method((void *) m2, (void *) hook_secure_get_string, 1);
            LOGI("hook Settings.Secure.getStringForUser -> %d", ok);
        } else {
            env->ExceptionClear();
        }
    } else {
        env->ExceptionClear();
    }

    /*
     * SystemProperties.native_get 在 AOSP 里带 @FastNative,把它的入口换掉
     * 会因为调用约定不同直接把游戏带崩,所以这里只把它当"探针"用(在 probe 里),
     * 不改它。属性那条路交给 Build 字段去覆盖。
     */
}

/* ------------------------------------------------------------------ 线程 */

/*
 * 配置变了就重新把 Build 字段刷一遍(android_id 那条是实时读的,不用管)。
 * 需要 JNIEnv,所以临时 attach 一次。
 */
static void refresh_build_fields(void) {
    if (!g_vm) return;
    JNIEnv *env = NULL;
    JavaVMAttachArgs args;
    args.version = JNI_VERSION_1_6;
    args.name = (char *) "tcd-devid-cfg";
    args.group = NULL;
    if (g_vm->AttachCurrentThread(&env, &args) != JNI_OK || !env) return;
    patch_build(env);
    g_vm->DetachCurrentThread();
}

/*
 * 配置热更新。
 *
 * 老版本只在注入那一刻读一次 devid.cfg,于是「注入完再改ID」永远不生效,
 * 必须在界面上重新点一次注入、甚至重启游戏 —— 用户看到的就是「改了没用」。
 * 现在每 2 秒看一次配置,值一变立刻跟上。
 */
static void *cfg_watcher(void *arg) {
    (void) arg;
    char last[128] = {0};
    int last_full = -1;
    for (;;) {
        sleep(2);
        char id[128] = {0};
        int full = 0;
        if (!load_cfg(id, sizeof(id), &full)) {
            if (last[0]) {
                store_id("", 0);
                last[0] = 0;
                last_full = -1;
                LOGI("cfg off -> real value");
            }
            continue;
        }
        if (strcmp(id, last) == 0 && full == last_full) continue;
        snprintf(last, sizeof(last), "%s", id);
        last_full = full;
        store_id(id, full);
        LOGI("cfg changed -> %s (full=%d)", id, full);
        refresh_build_fields();
    }
    return NULL;
}

static void *worker(void *arg) {
    (void) arg;
    /* 等注入器把目标进程放行,别在构造函数里做重活 */
    usleep(800 * 1000);

    char id[128] = {0};
    int full = 0;
    if (!load_cfg(id, sizeof(id), &full)) {
        LOGI("no cfg, nothing to do");
        return NULL;
    }
    store_id(id, full);
    LOGI("device id = %s (full=%d)", id, full);

    JNIEnv *env = NULL;
    JavaVMAttachArgs args;
    args.version = JNI_VERSION_1_6;
    args.name = (char *) "tcd-devid";
    args.group = NULL;
    if (g_vm->AttachCurrentThread(&env, &args) != JNI_OK || !env) {
        LOGI("attach failed");
        return NULL;
    }

    probe_art_method(env);
    install_hooks(env);

    g_vm->DetachCurrentThread();

    /* 挂上配置热更新线程:改完值 2 秒内生效,不用重新注入 */
    pthread_t wt;
    pthread_attr_t wa;
    pthread_attr_init(&wa);
    pthread_attr_setdetachstate(&wa, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&wt, &wa, cfg_watcher, NULL) != 0) {
        LOGI("cfg watcher thread failed");
    }
    pthread_attr_destroy(&wa);
    return NULL;
}

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void) reserved;
    g_vm = vm;
    LOGI("loaded");
    pthread_t th;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&th, &attr, worker, NULL) != 0) {
        LOGI("pthread_create failed");
    }
    pthread_attr_destroy(&attr);
    return JNI_VERSION_1_6;
}
