plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.tengcd.czr"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.tengcd.czr"
        minSdk = 24
        targetSdk = 35
        versionCode = 173
        versionName = "1.7.3"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }

    }

    // 本机没装这个版本 NDK 时,Android Studio 会自动下载;也可以改成你已装的版本
    ndkVersion = "26.1.10909125"
    // native 库用 NDK clang 预编译好放在 src/main/jniLibs 下(tools/build_native.sh),
    // 不依赖本机 CMake;Android Studio 打开也不会因为缺 CMake 报错。

    signingConfigs {
        create("release") {
            // 签名文件和密码都放在 app/ 下,别丢:换了签名就没法覆盖安装旧版本
            storeFile = file("tengcd.jks")
            storePassword = "tengcd123"
            keyAlias = "tengcd"
            keyPassword = "tengcd123"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    /**
     * 「内置 so」打包开关。
     *
     * 默认(不加参数):assets 用 src/main/assets,里面那份 so 全部打进包里 —— 装上去就能直接选。
     * 出**不内置**的小包:加 -PnoBundledSo,assets 换成 src/main/assets_noso,
     * 那个目录里只有 xposed_init 和一个空的 so/,打出来的 APK 一个 so 都不带,
     * 界面上的变体按钮全部是空白占位,靠「从本机读取」那份 so 用。
     *
     *   ./gradlew assembleRelease -PnoBundledSo
     */
    val noBundledSo = project.hasProperty("noBundledSo")
    sourceSets {
        getByName("main") {
            assets.setSrcDirs(
                listOf(
                    if (noBundledSo) "src/main/assets_noso" else "src/main/assets"
                )
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.documentfile:documentfile:1.0.1")

    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Shizuku:安卓 12 以上借 shell 身份写别的应用目录用
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:aidl:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    // Xposed / LSPosed 模块编译期依赖(只在编译期用,不打进包里)
    compileOnly("de.robv.android.xposed:api:82")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
