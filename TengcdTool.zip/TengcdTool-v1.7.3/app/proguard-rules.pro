# 本工程 isMinifyEnabled = false,这个文件只是给 AGP 一个存在的路径,不用加规则。
# 以后要开混淆,再把 -keep 规则写进来。
-keep class com.tengcd.czr.xposed.** { *; }
-keep class de.robv.android.xposed.** { *; }
