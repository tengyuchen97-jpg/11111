#!/usr/bin/env bash
# 一条命令出 APK(macOS / Linux)
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f local.properties ]; then
  if   [ -d "$HOME/Library/Android/sdk" ]; then SDK="$HOME/Library/Android/sdk"
  elif [ -d "$HOME/Android/Sdk" ];        then SDK="$HOME/Android/Sdk"
  elif [ -n "${ANDROID_HOME:-}" ];        then SDK="$ANDROID_HOME"
  elif [ -n "${ANDROID_SDK_ROOT:-}" ];    then SDK="$ANDROID_SDK_ROOT"
  else echo "没找到 Android SDK:手动在 local.properties 里写 sdk.dir=<你的SDK路径> 再跑"; exit 1; fi
  printf 'sdk.dir=%s\n' "$SDK" > local.properties
  echo "sdk.dir=$SDK"
fi

chmod +x gradlew
./gradlew --no-daemon assembleRelease

APK="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK" ]; then
  echo "出包成功:$APK"
else
  echo "没出包,看上面的日志"
  exit 1
fi
