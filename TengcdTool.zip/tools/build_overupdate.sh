#!/usr/bin/env bash
#
# build_overupdate.sh —— 重编 liboverupdate.so(过更新补丁库)
#
# 什么时候需要跑这个:
#   · 你改了 app/src/main/cpp/overupdate/ 下的任何 .cpp / .h
#   · 只想改拦截规则、不动 C 代码 → 不用跑,直接改 Kotlin/偏好就行
#
# 不需要 Android Studio,装个 NDK 就能一键出两个 ABI 的 so。
# 出来的文件会直接覆盖 app/src/main/jniLibs/ 下对应位置,下次打 APK 就带上了。
#
# 用法:
#   export ANDROID_NDK=/path/to/android-ndk-r26c
#   ./tools/build_overupdate.sh
#
# 产物:
#   app/src/main/jniLibs/arm64-v8a/liboverupdate.so
#   app/src/main/jniLibs/armeabi-v7a/liboverupdate.so
#
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"

SRC_DIR="$ROOT/app/src/main/cpp/overupdate"
OUT_ARM64="$ROOT/app/src/main/jniLibs/arm64-v8a"
OUT_ARM32="$ROOT/app/src/main/jniLibs/armeabi-v7a"

# ---------------------------------------------------------------- 找 NDK

if [ -z "${ANDROID_NDK:-}" ]; then
  for guess in \
    "$HOME/Android/Sdk/ndk/26.1.10909125" \
    "$HOME/Android/Sdk/ndk/26.3.11579264" \
    "$HOME/Library/Android/sdk/ndk/26.1.10909125" \
    "/usr/lib/android-sdk/ndk/26.1.10909125" \
    "$ANDROID_HOME/ndk/26.1.10909125"; do
    if [ -d "$guess" ]; then ANDROID_NDK="$guess"; break; fi
  done
fi

if [ -z "${ANDROID_NDK:-}" ] || [ ! -d "$ANDROID_NDK" ]; then
  echo "找不到 NDK。先装一个(26.x 就行),然后:"
  echo "  export ANDROID_NDK=/你的/ndk/路径"
  echo "  ./tools/build_overupdate.sh"
  exit 1
fi

HOST=""
case "$(uname -s)" in
  Linux)  HOST="linux-x86_64" ;;
  Darwin) HOST="darwin-x86_64" ;;
  *) echo "这台系统不在支持范围:$(uname -s)"; exit 1 ;;
esac

TOOLCHAIN="$ANDROID_NDK/toolchains/llvm/prebuilt/$HOST"
if [ ! -d "$TOOLCHAIN" ]; then
  echo "NDK 里没找到 prebuilt 工具链:$TOOLCHAIN"
  exit 1
fi

# ---------------------------------------------------------------- 编译参数

# API 21 起步,和老设备兼容;要更高可以改这个数字(比如 24)
API=21
CXXFLAGS=(
  -shared -fPIC -O2 -std=c++17 -fvisibility=hidden
  -ffunction-sections -fdata-sections
  -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable
  -Wl,--gc-sections -Wl,-z,max-page-size=16384
  -static-libstdc++
)
LIBS=(-llog -ldl)

SOURCES=(
  "$SRC_DIR/overupdate.cpp"
  "$SRC_DIR/javahook.cpp"
)

# 头文件都在同目录,include 路径给上
INCLUDES=(-I"$SRC_DIR")

build_one() {
  local abi="$1" target="$2" outdir="$3"

  local cxx="$TOOLCHAIN/bin/${target}-clang++"
  if [ ! -x "$cxx" ]; then
    echo "缺编译器:$cxx"
    return 1
  fi

  mkdir -p "$outdir"
  local out="$outdir/liboverupdate.so"

  echo ">>> 编 $abi"
  "$cxx" "${CXXFLAGS[@]}" "${INCLUDES[@]}" \
    -o "$out" "${SOURCES[@]}" "${LIBS[@]}"

  if [ -s "$out" ]; then
    echo "    ok  $out  ($(wc -c < "$out") 字节)"
  else
    echo "    编出来是空的,没成功"
    return 1
  fi
}

build_one arm64-v8a   "aarch64-linux-android$API"   "$OUT_ARM64"
build_one armeabi-v7a "armv7a-linux-androideabi$API" "$OUT_ARM32"

echo
echo "两个 ABI 都编好了。现在可以打 APK(Android Studio 直接 Build,或 ./gradlew assembleDebug)。"
echo
echo "提醒:liboverupdate.so 是打进 APK 的 assets/jniLibs,重装模块后要让游戏重启一次"
echo "      才会加载新的库 —— 已经开着的游戏进程还在跑旧的那份。"
