#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
出包后一步搞定:重算 dex 摘要 → 写进两份 libptrace_injector.so → 重新对齐 → 重新签名。

为什么需要它
------------
czrguard.cpp 里写死了一份「所有 classes*.dex 的合并摘要」(kDexDigest),
运行时算一遍对不上就拒绝注入(界面提示「卡密验证已失效或安装包被修改」)。

只要你改过任何 Kotlin/Java 代码重新编译,dex 就变了,而 .so 里还是旧摘要,
装上去自己就被自己拦住。这个脚本按 tools/dexhash.py 同一套算法重算,
把新摘要直接改到 APK 里那两份 .so 的字节里(不用 NDK,不用重编 cpp),
然后 zipalign + apksigner 重签,出来就能装、能跑。

用法
----
    python3 tools/fix_apk.py app/build/outputs/apk/release/app-release.apk
    python3 tools/fix_apk.py app/build/outputs/apk/release/app-release.apk --out 出包.apk
    python3 tools/fix_apk.py xxx.apk --build-tools /path/to/build-tools/35.0.0

可选参数:
    --ks        签名文件,默认 app/tengcd.jks
    --ks-pass   证书库密码,默认 tengcd123
    --key-pass  key 密码,默认同证书库密码
    --alias     key 别名,默认 tengcd
    --out       输出文件名,默认 <原名>-signed.apk
    --no-sign   只改 so,不重签(一般不需要,改完字节原签名必然失效)

依赖:Python 3 + zipalign / apksigner(Android SDK build-tools 里有)
"""

import argparse
import hashlib
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CPP = os.path.join(ROOT, "app", "src", "main", "cpp", "czrguard.cpp")
SO_ENTRIES = [
    "lib/arm64-v8a/libptrace_injector.so",
    "lib/armeabi-v7a/libptrace_injector.so",
]


# --------------------------------------------------------------- dex 摘要
def combined_digest(apk_path):
    """必须和 czrguard.cpp 的 computeDexState() 逐字节一致。"""
    parts = []
    with zipfile.ZipFile(apk_path) as zf:
        names = sorted(n for n in zf.namelist() if n.endswith(".dex") and "/" not in n)
        if not names:
            raise SystemExit("APK 里没有 classes*.dex,确认这是不是一个 APK")
        for n in names:
            d = hashlib.sha256(zf.read(n)).digest()
            parts.append(n.encode("utf-8") + b"\x00" + d)
            print("  %-18s %s" % (n, d.hex()))
    return hashlib.sha256(b"".join(parts)).digest()


def old_digest_from_cpp():
    """从 czrguard.cpp 里读出当前写死的期望值,用来在 .so 里定位那 32 个字节。"""
    if not os.path.isfile(CPP):
        return None
    src = io.open(CPP, encoding="utf-8").read()
    m = re.search(r"kDexDigest\[32\]\s*=\s*\{(.*?)\}", src, re.S)
    if not m:
        return None
    vals = re.findall(r"0x([0-9A-Fa-f]{1,2})", m.group(1))
    if len(vals) != 32:
        return None
    return bytes(int(v, 16) for v in vals)


# --------------------------------------------------------------- ELF 定位
ELF_MAGIC = b"\x7fELF"
DIGEST_SYMBOLS = (
    "_ZN12_GLOBAL__N_110kDexDigestE",  # 匿名命名空间里的 kDexDigest
    "kDexDigest",
)


def _u(b, off, size, endian):
    return int.from_bytes(b[off:off + size], endian)


def find_digest_offset(blob):
    """
    在 .so 里定位 kDexDigest 这个 32 字节常量,返回文件偏移。

    为什么不按「已知值」去搜索:.so 里的期望值是出包后直接改进二进制的,
    源码 czrguard.cpp 里那份往往是上一版的旧值,按值搜命中率是 0(实测)。
    符号表里它还留着(local OBJECT / 32 字节),按符号定位才是稳的。
    """
    if len(blob) < 64 or blob[:4] != ELF_MAGIC:
        return None
    is64 = blob[4] == 2
    endian = "little" if blob[5] == 1 else "big"
    if is64:
        shoff = _u(blob, 0x28, 8, endian)
        shentsize = _u(blob, 0x3A, 2, endian)
        shnum = _u(blob, 0x3C, 2, endian)
    else:
        shoff = _u(blob, 0x20, 4, endian)
        shentsize = _u(blob, 0x2E, 2, endian)
        shnum = _u(blob, 0x30, 2, endian)
    if not shoff or not shnum or shentsize < 40:
        return None

    secs = []
    for i in range(shnum):
        base = shoff + i * shentsize
        if base + shentsize > len(blob):
            break
        if is64:
            secs.append({
                "type": _u(blob, base + 4, 4, endian),
                "addr": _u(blob, base + 16, 8, endian),
                "off": _u(blob, base + 24, 8, endian),
                "size": _u(blob, base + 32, 8, endian),
                "link": _u(blob, base + 40, 4, endian),
                "entsize": _u(blob, base + 56, 8, endian),
            })
        else:
            secs.append({
                "type": _u(blob, base + 4, 4, endian),
                "addr": _u(blob, base + 12, 4, endian),
                "off": _u(blob, base + 16, 4, endian),
                "size": _u(blob, base + 20, 4, endian),
                "link": _u(blob, base + 24, 4, endian),
                "entsize": _u(blob, base + 36, 4, endian),
            })

    for sec in secs:
        if sec["type"] != 2 or sec["link"] >= len(secs):  # SHT_SYMTAB
            continue
        strtab = secs[sec["link"]]
        ent = sec["entsize"] or (24 if is64 else 16)
        count = sec["size"] // ent
        for i in range(count):
            base = sec["off"] + i * ent
            if is64:
                name_off = _u(blob, base, 4, endian)
                shndx = _u(blob, base + 6, 2, endian)
                value = _u(blob, base + 8, 8, endian)
                size = _u(blob, base + 16, 8, endian)
            else:
                name_off = _u(blob, base, 4, endian)
                value = _u(blob, base + 4, 4, endian)
                size = _u(blob, base + 8, 4, endian)
                shndx = _u(blob, base + 14, 2, endian)
            if name_off >= strtab["size"]:
                continue
            start = strtab["off"] + name_off
            end = blob.find(b"\x00", start)
            if end < 0:
                continue
            name = blob[start:end].decode("ascii", "ignore")
            if name not in DIGEST_SYMBOLS:
                continue
            if size != 32 or shndx == 0 or shndx >= len(secs):
                continue
            target = secs[shndx]
            off = target["off"] + (value - target["addr"])
            if 0 <= off <= len(blob) - 32:
                return off
    return None


def old_digest_from_cpp():
    """源码里那份期望值:只作为兜底(符号表被 strip 掉时按值搜)。"""
    if not os.path.isfile(CPP):
        return None
    src = io.open(CPP, encoding="utf-8").read()
    m = re.search(r"kDexDigest\[32\]\s*=\s*\{(.*?)\}", src, re.S)
    if not m:
        return None
    vals = re.findall(r"0x([0-9A-Fa-f]{1,2})", m.group(1))
    if len(vals) != 32:
        return None
    return bytes(int(v, 16) for v in vals)


# --------------------------------------------------------------- 改 so
def patch_so(blob, new):
    """把 .so 里 kDexDigest 的 32 字节换成 new。返回 (新字节, 说明)。"""
    off = find_digest_offset(blob)
    if off is not None:
        cur = blob[off:off + 32]
        if cur == new:
            return blob, "已经是新摘要(偏移 0x%x)" % off
        return blob[:off] + new + blob[off + 32:], "偏移 0x%x 已替换" % off
    # 兜底:符号表被 strip 掉,退化成按源码里的旧值搜
    old = old_digest_from_cpp()
    if old and blob.count(old) == 1:
        return blob.replace(old, new), "按旧值命中(符号表已 strip)"
    return blob, "定位不到 kDexDigest(符号表被 strip 且旧值也对不上)"


def rewrite_apk(src, dst, new_digest):
    patched = 0
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in SO_ENTRIES:
                data, note = patch_so(data, new_digest)
                if "已" in note:
                    patched += 1
                    print("  [ok] %s  %s" % (item.filename, note))
                else:
                    print("  [!!] %s  %s —— 用 NDK 重编 native 才能改(tools/build_native.sh)" %
                          (item.filename, note))
            zout.writestr(item, data)
    return patched


# --------------------------------------------------------------- 工具链
def find_build_tools(explicit=None):
    if explicit:
        return explicit
    sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if not sdk:
        lp = os.path.join(ROOT, "local.properties")
        if os.path.isfile(lp):
            for line in io.open(lp, encoding="utf-8"):
                if line.startswith("sdk.dir"):
                    sdk = line.split("=", 1)[1].strip()
    cands = []
    if sdk:
        bt = os.path.join(sdk, "build-tools")
        if os.path.isdir(bt):
            cands = [os.path.join(bt, d) for d in sorted(os.listdir(bt), reverse=True)]
    for c in cands:
        if os.path.isfile(os.path.join(c, "apksigner")) and \
           os.path.isfile(os.path.join(c, "zipalign")):
            return c
    return None


def run(cmd):
    print("  $", " ".join(cmd))
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = r.stdout.decode("utf-8", "replace").strip()
    if out:
        print("   ", out.replace("\n", "\n    "))
    if r.returncode != 0:
        raise SystemExit("命令失败(%d):%s" % (r.returncode, " ".join(cmd)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("apk")
    ap.add_argument("--out")
    ap.add_argument("--ks", default=os.path.join(ROOT, "app", "tengcd.jks"))
    ap.add_argument("--ks-pass", default="tengcd123")
    ap.add_argument("--key-pass", default=None)
    ap.add_argument("--alias", default="tengcd")
    ap.add_argument("--build-tools")
    ap.add_argument("--no-sign", action="store_true")
    args = ap.parse_args()

    src = os.path.abspath(args.apk)
    if not os.path.isfile(src):
        raise SystemExit("找不到 APK: %s" % src)
    out = os.path.abspath(args.out) if args.out else \
        os.path.join(os.path.dirname(src), os.path.splitext(os.path.basename(src))[0] + "-signed.apk")

    print("== APK:", src)
    print("== dex 摘要")
    new_digest = combined_digest(src)
    print("  combined =", new_digest.hex())

    old_digest = old_digest_from_cpp()
    if old_digest is not None:
        print("  源码 cpp 里那份(可能已过期) =", old_digest.hex())

    tmpdir = tempfile.mkdtemp(prefix="fixapk-")
    mid = os.path.join(tmpdir, "patched.apk")
    print("== 改 .so(按 ELF 符号定位 kDexDigest)")
    patched = rewrite_apk(src, mid, new_digest)
    if patched == 0:
        print("== 注意:两份 .so 都没改成 —— 装上可能还会被原生自校验拦")

    if args.no_sign:
        shutil.move(mid, out)
        print("== 已输出(未签名):", out)
        shutil.rmtree(tmpdir, ignore_errors=True)
        return

    bt = find_build_tools(args.build_tools)
    if not bt:
        raise SystemExit("没找到 build-tools(zipalign/apksigner)。用 --build-tools 指定,"
                         "或设 ANDROID_HOME")
    print("== build-tools:", bt)

    aligned = os.path.join(tmpdir, "aligned.apk")
    print("== zipalign")
    run([os.path.join(bt, "zipalign"), "-p", "-f", "4", mid, aligned])

    print("== apksigner 签名")
    cmd = [os.path.join(bt, "apksigner"), "sign",
           "--ks", args.ks,
           "--ks-pass", "pass:" + args.ks_pass,
           "--key-pass", "pass:" + (args.key_pass or args.ks_pass),
           "--ks-key-alias", args.alias,
           "--out", out, aligned]
    run(cmd)

    print("== 验签")
    run([os.path.join(bt, "apksigner"), "verify", "--print-certs", out])

    shutil.rmtree(tmpdir, ignore_errors=True)
    print("\n== 完成:", out, "(%.1f MB)" % (os.path.getsize(out) / 1048576.0))
    print("   装这个包就行了:卡密不再看签名,dex 摘要也已经同步到 .so 里。")


if __name__ == "__main__":
    main()
