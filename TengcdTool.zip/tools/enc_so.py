#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools/enc_so.py —— 内置 so 加密 / 解密 / 校验工具（与 SoVault.kt 完全一致）

用法：
    # 1) 加密：把明文 so 压成 assets 里能用的密文（自动生成 xxx.so.enc）
    python3 tools/enc_so.py enc app/src/main/assets/so/v0.31.so

    # 2) 解密：把 .enc 还原成明文 so（自己检查内容用）
    python3 tools/enc_so.py dec app/src/main/assets/so/v0.30.so.enc -o /tmp/v0.30.so

    # 3) 校验：只验 HMAC + ELF 头，不落盘
    python3 tools/enc_so.py verify app/src/main/assets/so/v0.30.so.enc

    # 改过包名就要一起改：
    python3 tools/enc_so.py enc xxx.so --app-id com.your.newid

注意：
  * 密钥、包名、文件名三者都参与派生。**改包名 / 改 assets 里的文件名，都必须重新加密一遍**，
    否则 HMAC 对不上，App 里解不出来，界面上就会显示那个变体是空白占位。
  * 本脚本的密钥必须和 util/SoVault.kt 里的 K1~K4 / MASK / APP_ID 一字不差。
    要换密钥，两边一起换，然后把所有 .enc 全部重新加密。
"""

import argparse
import hashlib
import hmac as hmac_mod
import os
import secrets
import struct
import sys

# ---------------- 与 SoVault.kt 保持一致的常量 ----------------
K1 = "6044c62328c79f79"
K2 = "d7a0c6228ef309d4"
K3 = "ff9eab9352589e8e"
K4 = "ba18db2d308aca80"
MASK = "337d501fc4e9085bc02931bbedec9218fbc6eb0e251b983c61641dfa3557a103"

DEFAULT_APP_ID = "com.tengcd.czr"      # = SoVault.APP_ID

MAGIC = b"TCD2"
VERSION = 1
IV_LEN = 16
TAG_LEN = 32
HEADER_LEN = 4 + 1 + IV_LEN + 4        # 25
ENC_SUFFIX = ".enc"
MIN_SO_SIZE = 4096                     # 小于这个数一律当占位文件，App 不认


# ---------------- AES-CTR（优先 cryptography，其次 pycryptodome） ----------------
def _make_ctr(key, iv):
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        c = Cipher(algorithms.AES(key), modes.CTR(iv))
        return c.decryptor(), c.encryptor()
    except ImportError:
        pass
    try:
        from Crypto.Cipher import AES
        from Crypto.Util import Counter
        ctr = Counter.new(128, initial_value=int.from_bytes(iv, "big"))
        c = AES.new(key, AES.MODE_CTR, counter=ctr)
        return c, c       # pycryptodome 同一个对象加解密都行
    except ImportError:
        sys.exit("缺加密库：pip install cryptography   （或 pip install pycryptodome）")


def aes_ctr(key, iv, data, encrypt):
    if encrypt:
        _, enc = _make_ctr(key, iv)
        return enc.update(data)
    dec, _ = _make_ctr(key, iv)
    return dec.update(data)


# ---------------- 密钥链 ----------------
def master_key():
    mixed = bytes.fromhex(K1 + K2 + K3 + K4)
    mask = bytes.fromhex(MASK)
    secret = bytes(mixed[i] ^ mask[i % len(mask)] for i in range(len(mixed)))
    return hashlib.sha256(secret + b"|TCD-SO-V2").digest()


def _hmac(key, data):
    return hmac_mod.new(key, data, hashlib.sha256).digest()


def file_key(master, app_id, entry_name):
    return _hmac(master, ("k|%s|%s" % (app_id, entry_name)).encode())


def mac_key(master, app_id, entry_name):
    return _hmac(master, ("m|%s|%s" % (app_id, entry_name)).encode())


# ---------------- 核心 ----------------
def encrypt_bytes(plain, entry_name, app_id=DEFAULT_APP_ID):
    if plain[:4] != b"\x7fELF":
        raise SystemExit("这不是 ELF（前面不是 7f 45 4c 46），八成选错文件了")
    master = master_key()
    iv = secrets.token_bytes(IV_LEN)
    ct = aes_ctr(file_key(master, app_id, entry_name), iv, plain, encrypt=True)
    head = MAGIC + bytes([VERSION]) + iv + struct.pack(">i", len(ct))
    body = head + ct
    tag = _hmac(mac_key(master, app_id, entry_name), body)
    return body + tag


def decrypt_bytes(raw, entry_name, app_id=DEFAULT_APP_ID):
    if len(raw) < HEADER_LEN + TAG_LEN:
        return None, "文件太短，不是 TCD2 密文"
    if raw[:4] == b"\x7fELF":
        return None, "这是明文 so，本来就是能直接用的，不需要解密"
    if raw[:4] != MAGIC:
        return None, "magic 不对（%r），不是 TCD2 密文" % raw[:4]
    if raw[4] != VERSION:
        return None, "版本号 %d 不认识" % raw[4]
    iv = raw[5:5 + IV_LEN]
    body_len = struct.unpack(">i", raw[21:25])[0]
    if body_len <= 0 or len(raw) != HEADER_LEN + body_len + TAG_LEN:
        return None, "长度对不上（文件 %d，头里写 %d）" % (len(raw), body_len)
    body_end = HEADER_LEN + body_len
    ct, tag = raw[HEADER_LEN:body_end], raw[body_end:body_end + TAG_LEN]
    master = master_key()
    expect = _hmac(mac_key(master, app_id, entry_name), raw[:body_end])
    if not hmac_mod.compare_digest(expect, tag):
        return None, ("HMAC 校验失败：密钥 / 包名 / 文件名三者之一对不上"
                      "（当前 app-id=%s，文件名=%s）" % (app_id, entry_name))
    return aes_ctr(file_key(master, app_id, entry_name), iv, ct, encrypt=False), None


def describe(data):
    arch = {0xB7: "aarch64/arm64", 0x28: "arm32", 0x3E: "x86_64"}.get(
        int.from_bytes(data[18:20], "little"), "未知")
    return "%s，%.1f MB" % (arch, len(data) / 1048576.0)


# ---------------- 命令行 ----------------
def cmd_enc(args):
    src = args.file
    plain = open(src, "rb").read()
    if len(plain) <= MIN_SO_SIZE:
        print("⚠️  文件只有 %d 字节，App 会当成占位文件拒掉" % len(plain))
    out = args.out or (src if src.endswith(ENC_SUFFIX) else src + ENC_SUFFIX)
    # ⚠️ SoVault 派生用的文件名是 assets 里的完整名（含 .enc），不是去掉后缀的
    entry = os.path.basename(out)
    if not entry.endswith(ENC_SUFFIX):
        entry += ENC_SUFFIX
    blob = encrypt_bytes(plain, entry, args.app_id)
    open(out, "wb").write(blob)
    print("✅ 加密完成：%s" % out)
    print("   源文件     : %s（%s）" % (entry, describe(plain)))
    print("   密文大小   : %.1f MB" % (len(blob) / 1048576.0))
    print("   包名(APP_ID): %s" % args.app_id)
    # 立刻回环验证，确保 App 那边一定解得开
    back, err = decrypt_bytes(blob, entry, args.app_id)
    if err or back != plain:
        sys.exit("❌ 回环校验失败：%s" % (err or "内容不一致"))
    print("   回环校验   : PASS（解密结果与源文件逐字节一致）")


def cmd_dec(args):
    src = args.file
    entry = os.path.basename(src)          # 完整名，含 .enc
    raw = open(src, "rb").read()
    data, err = decrypt_bytes(raw, entry, args.app_id)
    if err:
        sys.exit("❌ " + err)
    out = args.out
    if out:
        open(out, "wb").write(data)
        print("✅ 已解出：%s（%s）" % (out, describe(data)))
    else:
        print("✅ 解密成功（%s），没给 -o 所以没落盘" % describe(data))


def cmd_verify(args):
    exit_code = 0
    for src in args.file:
        entry = os.path.basename(src)      # 完整名，含 .enc
        raw = open(src, "rb").read()
        data, err = decrypt_bytes(raw, entry, args.app_id)
        if err:
            print("❌ %s —— %s" % (entry, err))
            exit_code = 1
            continue
        elf = data[:4] == b"\x7fELF"
        print("%s %s —— HMAC PASS，解密后 %s%s" % (
            "✅" if elf else "⚠️", entry,
            "是 ELF" if elf else "不是 ELF",
            "，" + describe(data) if elf else ""))
        if not elf:
            exit_code = 1
    return exit_code


def main():
    p = argparse.ArgumentParser(description="内置 so 加密 / 解密 / 校验（与 SoVault.kt 同算法）")
    sub = p.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("enc", help="明文 so → xxx.so.enc")
    e.add_argument("file")
    e.add_argument("-o", "--out", help="输出路径（默认 <输入>.enc）")
    e.add_argument("--app-id", default=DEFAULT_APP_ID, help="应用包名（= SoVault.APP_ID）")
    e.set_defaults(func=cmd_enc)

    d = sub.add_parser("dec", help="xxx.so.enc → 明文 so")
    d.add_argument("file")
    d.add_argument("-o", "--out")
    d.add_argument("--app-id", default=DEFAULT_APP_ID)
    d.set_defaults(func=cmd_dec)

    v = sub.add_parser("verify", help="只校验，不落盘")
    v.add_argument("file", nargs="+")
    v.add_argument("--app-id", default=DEFAULT_APP_ID)
    v.set_defaults(func=cmd_verify)

    args = p.parse_args()
    r = args.func(args)
    sys.exit(r or 0)


if __name__ == "__main__":
    main()
