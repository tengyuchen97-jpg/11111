#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
算 apk 里所有 classes*.dex 的合并摘要,写进 czrguard.cpp 的 kDexDigest。

算法必须跟 czrguard.cpp 里一模一样:

    H = SHA256( 对每个 dex(按文件名升序):
                  name + b"\\x00" + SHA256(dex 内容) )

用法:
    python3 tools/dexhash.py app/build/outputs/apk/release/app-release.apk            # 只打印
    python3 tools/dexhash.py app/build/outputs/apk/release/app-release.apk --write    # 写进 cpp
"""
import hashlib
import io
import re
import sys
import zipfile

CPP = "app/src/main/cpp/czrguard.cpp"


def combined_digest(apk_path):
    parts = []
    with zipfile.ZipFile(apk_path) as zf:
        names = sorted(
            n for n in zf.namelist()
            if n.endswith(".dex") and "/" not in n
        )
        if not names:
            raise SystemExit("apk 里没有 classes*.dex")
        for n in names:
            content = zf.read(n)
            d = hashlib.sha256(content).digest()
            parts.append(n.encode("utf-8") + b"\x00" + d)
            print("  %-16s %s" % (n, d.hex()))
    return hashlib.sha256(b"".join(parts)).digest()


def cpp_array(digest):
    rows = []
    for i in range(0, 32, 8):
        rows.append("    " + ", ".join("0x%02X" % b for b in digest[i:i + 8]))
    return ",\n".join(rows)


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    apk = sys.argv[1]
    write = "--write" in sys.argv
    digest = combined_digest(apk)
    print("combined =", digest.hex())
    if not write:
        print("\n(加 --write 写进 %s)" % CPP)
        return
    src = io.open(CPP, encoding="utf-8").read()
    new = re.sub(
        r"static const unsigned char kDexDigest\[32\] = \{.*?\n\};",
        "static const unsigned char kDexDigest[32] = {\n" + cpp_array(digest) + "\n};",
        src,
        flags=re.S,
    )
    if new == src:
        raise SystemExit("没找到 kDexDigest 定义")
    io.open(CPP, "w", encoding="utf-8").write(new)
    print("已写入", CPP)


if __name__ == "__main__":
    main()
