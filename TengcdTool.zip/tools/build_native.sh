#!/usr/bin/env bash
# 重新编译原生层(注入器 + 卡密/完整性守卫),产物直接覆盖 src/main/jniLibs 下的 .so。
#
# 什么时候要跑:
#   1. 改了 app/src/main/cpp 下任何 .cpp/.h
#   2. 用 tools/dexhash.py 把新的 dex 摘要写进 czrguard.cpp 之后(必须重编,否则守卫还是旧摘要)
#
# 用法:
#   ANDROID_NDK_HOME=/path/to/ndk bash tools/build_native.sh
#
# 找不到 NDK 时的默认值见下面 DEFAULT_NDK,改一下就行。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK="${ANDROID_NDK_HOME:-${ROOT}/build_env/sdk/ndk/26.1.10909125}"
TC="${NDK}/toolchains/llvm/prebuilt/linux-x86_64/bin"
SRC="${ROOT}/app/src/main/cpp"
OUTA="${ROOT}/app/src/main/jniLibs/arm64-v8a"
OUTV="${ROOT}/app/src/main/jniLibs/armeabi-v7a"

if [ ! -x "${TC}/aarch64-linux-android24-clang++" ]; then
    echo "找不到 NDK 工具链: ${TC}" >&2
    echo "请把 ANDROID_NDK_HOME 指到 NDK r26b 目录再跑" >&2
    exit 1
fi

FLAGS=(-shared -fPIC -O2 -std=c++17 -fvisibility=hidden -ffunction-sections -fdata-sections)
LIBS=(-llog -lz -Wl,--gc-sections)

echo "==> arm64-v8a"
"${TC}/aarch64-linux-android24-clang++" "${FLAGS[@]}" \
    -o "${OUTA}/libptrace_injector.so" \
    "${SRC}/injector.cpp" "${SRC}/jni_bridge.cpp" "${SRC}/czrguard.cpp" \
    "${LIBS[@]}"

echo "==> armeabi-v7a"
"${TC}/armv7a-linux-androideabi24-clang++" "${FLAGS[@]}" \
    -o "${OUTV}/libptrace_injector.so" \
    "${SRC}/injector.cpp" "${SRC}/jni_bridge.cpp" "${SRC}/czrguard.cpp" \
    "${LIBS[@]}"

echo "==> 完成:"
ls -l "${OUTA}/libptrace_injector.so" "${OUTV}/libptrace_injector.so"
