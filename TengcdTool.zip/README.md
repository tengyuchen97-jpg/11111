# 遄懂（TengcdTool）—— 完整源码

Kotlin + Jetpack Compose 全套工程，两条注入通道（框架注入 / 进程注入）+ ptrace native 注入器源码 + Xposed 模块入口 + 卡密页 + 更新分发。

> 这是**源码工程**，用 Android Studio 打开直接能编。

---

## 〇、v1.3（versionCode 130）—— 修「LSPosed 勾选了但用不了」

| # | 改动 | 在哪 |
|---|---|---|
| 1 | **框架注入新增「Provider 送 so」这条路**：so 以文件流经模块自己的 ContentProvider 送进目标进程，目标进程写到自己的 codeCacheDir 再 load。以前只写私有目录路径，目标 uid 根本读不到，所以勾选了也必失败 | `xposed/HookInit.kt` `fetchViaProvider()` |
| 2 | **状态拆三档**：`已注入目标进程` / `so 已加载` / `so 加载失败(+原因)`，界面「注入阶段」一行直出，不再只有一个「未激活」 | `ServiceState` / `UiState` / `InjectScreen` |
| 3 | **只走目标主进程**：包的每个进程都塞 so 会让主进程空手；现在只认主进程，重试 0.3s/1.2s/3s/6s，attach 挂不上改挂 `Instrumentation.callApplicationOnCreate` | `xposed/HookInit.kt` |
| 4 | **抽变体不再「拿最大的顶包」**：包里没有该变体就明确报错并列出实际有的，避免假成功 | `xposed/HookInit.kt` `extractVariant()` |
| 5 | **框架检测多路判定**：已知包名 → 包名关键词 → /data/adb 模块目录 → 系统属性 → 目标进程回报，隐藏/寄生管理器也能认；且检测结果不再当注入门槛 | `xposed/XposedDetector.kt` |
| 6 | 版本号 `120 → 130`、`1.2 → 1.3`，界面/远端版本号同步 | `app/build.gradle.kts` `network/T3Panel.kt` |

详细说明见 `改动说明-v1.3-框架修复.txt`。

---

## 一、这一版改了什么

| # | 改动 | 在哪 |
|---|---|---|
| 1 | **模块概览下面加了 SO 选择器**：`v0.19 / v0.20 / v0.23 / v0.24` 四个变体，点哪个就用哪个注入（包里先放的是空白占位 so） | `ModuleStore.BUILTIN_VARIANTS` + `ui/screens/UpdateScreen.kt` |
| 2 | **注入时不再弹任何阻止性对话框**（不再拦「请先更新模块 / 请先在框架里启用」），直接按当前选中的 SO 往里打 | `MainViewModel.inject()` |
| 3 | 标题 `Honffx Tool` → **遄懂**（字体不变，仍是手写体标题档） | `i18n/Strings.kt` `appTitle`、`res/values/strings.xml` |
| 4 | **配色**：未激活 / 未就绪 → 黄色；已激活 / 可访问 / 已就绪 → 绿色 | `ui/components/LiquidGlass.kt` `StatusRow`、两个屏幕 |
| 5 | **目标应用名标红**，下面一个框单独放它的包名 | `ui/components/LiquidGlass.kt` `TargetAppBadge` |
| 6 | 包名 → **`com.tengcd.czr`**（含 Kotlin 目录、JNI 符号名、provider authority、action 全量同步） | 全局 |
| 7 | **公告下面加了「本机 SO」卡**：从本机读一个 so 文件，读完注入就用它 | `ModuleStore.importLocalSo` + `UpdateScreen` |

## 一·二、v0.4 这一版改了什么(相对 v0.3)

| # | 改动 | 在哪 |
|---|---|---|
| 1 | **底部导航改成截图那种悬浮胶囊**:整条是一个浮起来的玻璃胶囊(62dp,两头全圆、半透明白、细描边),选中项自己在胶囊里再垫一块浅色药丸,图标+文字一起变蓝,未选中接近黑色;内容是浮在页面上方,不是压平贴在底边 | `ui/components/BottomNavBar.kt` + `MainActivity.kt`(`NavBarBlock` 留白) |
| 2 | **导入页重做成 MT 管理器那种左右双栏**:**左=源文件夹(本机选)**,**右=目标文件夹(本机选 或 手输绝对路径)**,把左边整棵树覆盖到右边 | `ui/screens/ImportScreen.kt` |
| 3 | **修「选完文件夹没反应」**:原来源和目标共用同一个选择器回调,选完只改了内部字段、界面不刷新。现在两条独立的 `rememberLauncherForActivityResult`,选完立刻回填路径、递归统计(文件数/子目录数/总大小)、弹 Toast 提示,不再静默 | `MainActivity.kt` + `MainViewModel.onImportSourcePicked / onImportTargetPicked` |
| 4 | **覆盖方式两档**:默认「合并覆盖」(同名文件被源的替换,目标多出来的保留);切「清空后覆盖」则先清空目标目录再整份写入 | `FolderImporter.run(replaceAll)` |
| 5 | **不再要求同 uid 才能用导入**:目标可以走 ① SAF 文件夹授权 ② 手输路径直写 ③ root,三条路自动挑,页面显示当前走哪条 | `util/FolderImporter.kt` |
| 6 | **大目录直写快路径**:源和目标都是绝对路径时边读边写,不再先整份拷进应用缓存(资源文件夹几百 MB 也不会把缓存撑爆) | `FolderImporter.writeDirectTree` |
| 7 | 导入进度实时刷新(已写入文件数 / 总文件数 / 已写字节),结束给出通道名和成功/失败原因 | `UiState.importProgress*` |
| 8 | 保留 v0.3 的 UID 注入修复(附加线程 / mmap / dlopen / memfd 分步报错) | `cpp/injector.cpp`、`PtraceInjector.lastDetail` |

---|---|---|
| 1 | **底部导航栏改成全透明**：去掉那层玻璃底和描边，只剩图标+文字+选中块；排列还是原来的等分，间距没动，不会变挤 | `ui/components/BottomNavBar.kt` |
| 2 | **底部留白改成按实际高度算**：内容区底部 = 导航栏本体(78dp) + 上下留白(12dp×2) + 系统手势条 inset，滚到底时最后一块正好贴着导航栏上沿，既不被盖住也不会空出一大块 | `MainActivity.kt`（`BottomNavBarHeight` / `NavBarGap`） |
| 3 | **新增「导入」页**：选本机一个文件夹 → 整个覆盖到 `/storage/emulated/0/Android/data/com.pi.czrxdfirst/files`；导入前先把目标目录里的文件全部删掉，再写入 | `ui/screens/ImportScreen.kt` + `util/FolderImporter.kt` |
| 4 | **修 UID 注入闪退**（三个真实原因见下面第五节） | `cpp/injector.cpp` |
| 5 | 注入失败时界面上直接显示**原生侧卡在哪一步**（附加线程 / mmap / dlopen / memfd），不再只有一句「注入失败」 | `PtraceInjector.lastDetail` + `InjectScreen` |

---

## 二、怎么编

1. Android Studio（Koala 或更新）→ Open → 选本目录
2. 首次打开会自动拉 Gradle 8.9 / AGP 8.7.3 / Compose 依赖
3. **native 部分需要 NDK**：默认写的是 `ndkVersion = "26.1.10909125"`（`app/build.gradle.kts` 里）。
   本机没这个版本就改成你已装的版本号（Android Studio 也会自动下）。
4. Run ▶ 装到真机（arm64 / armv7 都编了）

命令行编：

```bash
./gradlew :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

工程里带了 gradle wrapper 配置；缺 `gradlew` 脚本和 `gradle-wrapper.jar` 的话，
在项目根目录跑一次 `gradle wrapper --gradle-version 8.9` 生成即可。

---

## 三、把你的真 SO 塞进去（重要）

`app/src/main/assets/so/` 下面那四个 `v0.19.so ~ v0.24.so` 现在是**空白占位件**
（最小可 dlopen 的 arm64 空壳，注入进去不会崩、但也不做任何事）。

换成真的：**直接用你的真 so 覆盖同名文件即可**，文件名不要改。

```
app/src/main/assets/so/v0.19.so   ← 覆盖成真的 v0.19
app/src/main/assets/so/v0.20.so
app/src/main/assets/so/v0.23.so
app/src/main/assets/so/v0.24.so
```

换完之后：
- 首次启动会把四个变体解到私有目录 `files/module/libhonffx_<变体>.so`
- 界面上点哪个变体，注入用的就是那个文件
- 想加/减变体：改 `ModuleStore.BUILTIN_VARIANTS`（顺序就是界面上显示的顺序），
  然后往 `assets/so/` 放同名文件

> 已经装过旧版的话，装新版前先清一下数据（老的四份落位件还在私有目录里，同名会被复用）。

「本机 SO」那条路不走内置资产：用户在界面上挑一个手机里的 so，
文件会被收进私有目录 `files/module/libhonffx_local.so`，之后注入就用它；
点「清除」自动退回内置变体。

---

## 四、目录结构

```
app/src/main/
├─ AndroidManifest.xml                 清单（sharedUserId / Xposed 声明 / Provider / 服务 / 广播）
├─ assets/
│   ├─ xposed_init                     框架模块入口：com.tengcd.czr.xposed.HookInit
│   └─ so/v0.19.so … v0.24.so          ← 内置 SO 变体（现在是占位件，换成你的真 so）
├─ res/                                图标 / 主题 / xposed 作用域 / 文案
├─ cpp/
│   ├─ CMakeLists.txt
│   ├─ injector.h
│   ├─ injector.cpp                    ptrace 注入器（arm64 + arm32）
│   └─ jni_bridge.cpp                  JNI 桥：PtraceInjector.nativeInject
└─ java/com/tengcd/czr/
    ├─ HonffxApplication.kt            启动：配置初始化 + 内置 SO 落位 + 本地 socket 常驻
    ├─ MainActivity.kt                 界面外壳：标题栏 / 底部四页签 / 文件+文件夹选择器 / 弹窗调度
    ├─ MainViewModel.kt                全部业务逻辑（更新 / 下载 / 注入 / SO 切换 / 本机 SO / 卡密）
    ├─ UiState.kt  UiAction.kt  UiEvent.kt  ErrorKind.kt
    ├─ i18n/                           中英文案（LocalizedStrings + Strings）
    ├─ inject/
    │   ├─ InjectionMode.kt            FRAMEWORK / PROCESS
    │   ├─ InjectorRouter.kt           按模式选通道，统一出入口
    │   ├─ PtraceInjector.kt           进程注入（加载 native 库 + 找 pid）
    │   ├─ PtraceInjectFailure.kt      失败码（和 native 一一对应）
    │   ├─ PtraceInjectResult.kt
    │   └─ ModuleStore.kt              so 的多来源落位（内置变体 / 本机 / 远端）+ 交接文件
    ├─ ipc/SoSocketServer.kt           本地 socket：目标进程来问模块路径
    ├─ network/                        配置拉取 / 模块下载校验 / 卡密接口 / 本地卡密
    ├─ provider/SoProvider.kt          content:// 把 so 供出去 + 回报激活状态
    ├─ service/                        InjectService / 交接唤醒 / 开机自启
    ├─ ui/                             主题、玻璃组件、四个页面（更新/注入/导入/卡密）
    ├─ util/                           偏好、md5、包工具、权限、分享码、shell、文件夹导入(FolderImporter)
    └─ xposed/
        ├─ HookInit.kt                 框架注入入口
        └─ XposedDetector.kt           检测设备上有没有 Xposed 系框架
```

---

## 五、两条注入通道怎么走

### 1. 框架注入（`InjectionMode.FRAMEWORK`）
1. 装 LSPosed → 模块里勾上本应用 → 作用域勾目标游戏
2. 「一键注入」把当前选中的 so 路径写进交接文件 / 偏好（`ModuleStore.writeHandoff`）
3. 目标游戏启动 → `HookInit` 拿到路径 → `System.load()` → 回 `content://com.tengcd.czr.so` 报激活
4. 路径来源顺序：XSharedPreferences → ContentProvider → 外部交接文件 → 私有 module 目录里的 so

### 2. 进程注入（`InjectionMode.PROCESS`）
1. 目标应用先跑起来（「启动游戏」按钮，起来后自动触发一次交接广播）
2. 校验两件事：**两个应用同一个 sharedUserId**（清单里写的是 `ts.al.al`）、目标数据目录可写
3. 把当前选中的 so 复制到 `/data/data/<目标包>/files/`（`ModuleStore.stageForTarget`）
4. native 侧 `injector.cpp`（这一版重写）：
   1. **挑线程**：遍历 `/proc/<pid>/task`，优先挑睡眠态的线程、主线程排最后 —— 避免怼在持锁的线程上远程调 dlopen 把自己锁死
   2. `PTRACE_ATTACH`（失败再退 `PTRACE_SEIZE` + `INTERRUPT`）
   3. **远程 syscall**：在目标 libc 里找一条现成的 `svc #0`，把 PC 指过去单步执行，用它调 `mmap` 拿一块内存
      —— 老版本这里是拿 `LR=0` 去调 mmap，函数一返回就跳地址 0，**这就是闪退的根**
   4. 写 so 路径 + `brk #0` 断点 → `PC=dlopen`、`LR=断点` → `PTRACE_CONT` → 断点停下 → 取返回值
   5. 路径加载失败时自动改走 **memfd**：目标进程里 `memfd_create` + `pwrite64` 把 so 写进去，再 `dlopen("/proc/self/fd/<fd>")`（不依赖目标数据目录能不能写）
   6. **无论成败都先还原寄存器再 detach** —— 老版本失败路径直接 detach，PC 还停在蹦掉的地址上，等于亲手把目标送走

失败原因全都有对应人话提示（`ui/InjectFailureMessage.kt` + 界面上那张「注入详情」卡）：
未装目标 / 没跑起来 / uid 不一致 / 附加被拒 / 目标是 32 位 / mmap 失败 / 链接器拒绝该路径 / 加载器忙 ……

---

## 六、上线前要改的地方

| 改什么 | 在哪 |
|---|---|
| 目标游戏包名 | `InjectionPrefs.DEFAULT_TARGET_PACKAGE` + `res/xml/xposed_scope.xml` + 清单里的 `<queries>` |
| sharedUserId | `AndroidManifest.xml` 的 `android:sharedUserId`（必须和目标应用一致才能进程注入） |
| 服务端地址 | `InjectionPrefs.DEFAULT_CONFIG_URL`（配置 JSON 字段见 `network/ConfigParser.kt`） |
| 内置 SO | `app/src/main/assets/so/v*.so` 覆盖同名文件 + `ModuleStore.BUILTIN_VARIANTS` |
| 卡密本地校验 | 卡密页开关，或 `/sdcard/Download/honffx_card.txt`，格式：`卡密\|到期时间\|剩余次数\|解绑次数` |
| 加语言 | `i18n/Strings.kt` 再补一份 `LocalizedStrings` 实例 |

服务端配置 JSON 长这样：

```json
{
  "version": "0.24",
  "so_url": "https://你的域名/module/libhonffx.so",
  "md5": "模块文件的md5",
  "announcement": "公告文字",
  "target_package": "com.pi.czrxdfirst",
  "force_update": false,
  "update_log": "更新说明"
}
```

---

## 六·五、导入页怎么用(MT 管理器那种覆盖)

1. 底部点「导入」
2. **左边**:「选择文件夹」→ 系统文件夹选择器里挑本机那个源目录(整棵子树都会读)
3. **右边**:「选择文件夹」→ 挑目标目录;`Android/data` 这类系统选择器进不去的地方,点「输入路径」手输,
   例如 `/storage/emulated/0/Android/data/com.pi.czrxdfirst/files`
4. 两侧一选好,页面立刻显示:文件夹名 / 文件数 / 子目录数 / 总大小,并弹一句 Toast 确认
5. 选覆盖方式:「合并覆盖」(默认,同名覆盖其余保留)或「清空后覆盖」(先清空目标)
6. 点「开始导入(覆盖)」→ 进度条按文件数走 → 结束显示写入通道 + 写入文件数 + 总字节

覆盖语义(和 MT 的「移动/覆盖」一致):**源目录里的每一个文件,按相对路径写到目标目录的同名位置**;
源里没有的文件不会被删(除非你选「清空后覆盖」)。

写入通道(`util/FolderImporter.kt`),自动挑:

| 通道 | 什么时候用 |
|---|---|
| 直写 | 源和目标都是绝对路径、目标可写(本应用私有目录 / `Android/data` 同 uid / 有 `MANAGE_EXTERNAL_STORAGE` 的公共目录)→ 边读边写,不占缓存 |
| 文件夹通道(SAF) | 目标是用系统选择器授权的目录树:走 `DocumentFile`,不需要 root,也不需要同 uid |
| root | 上面两条都写不进去且设备有 root:`su` 跑 `cp -rf`,再 `chown` 回目标 uid、`restorecon` 修 SELinux 标签 |
| 都不通 | 页面提示「目标目录写不进去」+ 当前尝试过哪条通道,不会写一半留残缺文件 |

> 走 SAF / root 时源内容会先落到应用缓存再写目标(失败不留半截文件);纯路径直写是边读边写。

## 七、真机上的几个实话

- **进程注入在无 root 的设备上限制很大**：Android 7+ 的 SELinux 默认不允许跨进程 ptrace。
  能走通的前提是「同 sharedUserId + 目标允许调试/转储」，走不通就换框架注入那条路。
  这一版把失败原因分得比较细（附加被拒 / 目标是 32 位 / mmap / dlopen / memfd），
  界面上那张「注入详情」卡会直接告诉你卡在哪一步，对着它判断就行。
- 模块 so 得是**目标进程能 dlopen 的纯 native 库**（不要依赖 JNI 环境，除非你自己调 `JNI_OnLoad`）。
- 目标 so 的路径权限很关键，所以默认优先放目标私有目录，再退到外部目录。
- 「本机 SO」挑进来的文件会先收进本应用私有目录再注入 —— 外部路径（比如 Downloads 里）
  目标进程多半没权限打开。

---

## 八、免责

代码只做技术演示，注入的目标应用请确保是你自己有权调试的。
