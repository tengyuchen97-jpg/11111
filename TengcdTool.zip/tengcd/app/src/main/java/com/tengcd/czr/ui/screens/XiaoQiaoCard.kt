package com.tengcd.czr.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.StatusRow
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.xq.XqBinary
import com.tengcd.czr.xq.XqFloatService
import com.tengcd.czr.xq.XqPrefs
import com.tengcd.czr.xq.XqRunner
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 首页最下面这张卡:小乔的入口。
 *
 * 本体是内置在包里的(assets/xq/xiaoqiao_arm64),装在手机上第一次点启动会
 * 自动解包到私有目录;要换版本不用重新打包,这里「导入本体」直接选一份覆盖。
 */
private data class CardSnap(
    val running: Boolean,
    val pid: Int,
    val hasBinary: Boolean,
    val sizeMb: Long,
    val floatOn: Boolean,
    val overlayOk: Boolean
)

@Composable
fun XiaoQiaoCard(dark: Boolean) {
    val ctx = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var pid by remember { mutableStateOf(-1) }
    var hasBinary by remember { mutableStateOf(false) }
    var sizeMb by remember { mutableStateOf(0L) }
    var floatOn by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }

    val scope = rememberCoroutineScope()

    val importer = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val (ok, msg) = withContext(Dispatchers.IO) { XqBinary.importFrom(ctx, uri) }
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                if (ok) {
                    hasBinary = XqBinary.exists(ctx)
                    sizeMb = XqBinary.size(ctx) / 1024 / 1024
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            // 扫 /proc、读 Shizuku 都是阻塞活,放到 IO 线程,别卡首页
            val snap = withContext(Dispatchers.IO) {
                val st = XqRunner.status(ctx)
                CardSnap(
                    st.running,
                    st.pid,
                    XqBinary.exists(ctx),
                    XqBinary.size(ctx) / 1024 / 1024,
                    XqPrefs.floatEnabled(ctx),
                    Settings.canDrawOverlays(ctx)
                )
            }
            running = snap.running
            pid = snap.pid
            hasBinary = snap.hasBinary
            sizeMb = snap.sizeMb
            floatOn = snap.floatOn
            overlayOk = snap.overlayOk
            delay(1000L)
        }
    }

    GlassCard(dark = dark) {
        SectionHeader(Icons.Filled.Bolt, "小乔", dark)
        Spacer(Modifier.height(8.dp))

        StatusRow(
            label = "小乔状态",
            value = if (running) "运行中 · PID $pid" else "未运行",
            dark = dark,
            dot = true,
            ok = running,
            warn = !running
        )
        StatusRow(
            label = "悬浮窗",
            value = if (floatOn) "已开启" else "未开启",
            dark = dark,
            dot = true,
            ok = floatOn,
            warn = !floatOn
        )
        KeyValueRow(
            label = "内置本体",
            value = if (hasBinary) "$sizeMb MB · arm64" else "未解包(第一次启动会自动解)",
            dark = dark,
            valueColor = if (hasBinary) OkGreen else ErrRed
        )
        KeyValueRow(
            label = "运行通道",
            value = when (XqPrefs.mode(ctx)) {
                XqPrefs.MODE_SHIZUKU -> "Shizuku(免root)"
                XqPrefs.MODE_ROOT -> "root"
                else -> "应用内(免root)"
            },
            dark = dark
        )

        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            SecondaryActionButton(
                text = if (floatOn) "悬浮窗已开" else "开启悬浮窗",
                icon = Icons.Filled.Bolt,
                dark = dark,
                modifier = Modifier.weight(1f)
            ) {
                if (!overlayOk) {
                    Toast.makeText(ctx, "先给一下「显示在其他应用上层」权限", Toast.LENGTH_SHORT).show()
                    try {
                        ctx.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + ctx.packageName)
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (t: Throwable) {
                    }
                } else {
                    XqFloatService.start(ctx)
                    Toast.makeText(ctx, "悬浮球已放出,拖到顺手的位置", Toast.LENGTH_SHORT).show()
                }
            }
            Spacer(Modifier.height(0.dp))
            SecondaryActionButton(
                text = "导入本体",
                icon = Icons.Filled.Bolt,
                dark = dark,
                modifier = Modifier.weight(1f)
            ) {
                try {
                    importer.launch(arrayOf("*/*"))
                } catch (t: Throwable) {
                    Toast.makeText(ctx, "打不开文件选择器", Toast.LENGTH_SHORT).show()
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        SecondaryActionButton(
            text = if (running) "停止小乔" else "启动小乔",
            icon = Icons.Filled.Bolt,
            dark = dark
        ) {
            if (running) {
                scope.launch {
                    withContext(Dispatchers.IO) { XqRunner.stop(ctx) }
                    Toast.makeText(ctx, "已停止", Toast.LENGTH_SHORT).show()
                }
            } else {
                val mode = XqPrefs.mode(ctx)
                scope.launch {
                    val (ok, msg) = withContext(Dispatchers.IO) { XqRunner.start(ctx, mode) }
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            text = "小乔跑在本应用自己的 uid 上(和目标共用 sharedUserId),所以不用 root;" +
                "要是本机 SELinux 拦了,面板里切到 Shizuku 通道再启动。",
            color = if (dark) TextSecondaryDark else TextSecondaryLight,
            fontSize = 11.sp
        )
        Spacer(Modifier.height(10.dp))
    }
}
