package com.tengcd.czr.xposed

import android.content.Context
import android.os.Process
import java.io.File

/**
 * 「模块到底激活了没有」的真实判定。
 *
 * 老逻辑只看设备上装没装框架管理器(包名比对 org.lsposed.manager 那一套)。
 * 可 LSPosed 新版管理器是寄生式的,包名根本不叫这个,
 * 结果就是:框架勾了、目标也注入了,界面还一直挂着「未激活」。
 *
 * 现在改成按「硬证据」判,从最硬往软退:
 *  1. 本进程里能不能找到框架的类(de.robv.android.xposed.XposedBridge)
 *     —— 只要本应用被勾进作用域,这个类就一定在本进程里,骗不了人
 *  2. 本进程加载的 native 里有没有框架痕迹(/proc/self/maps 里的 lspd / xposed)
 *  3. 模块自己被注入时写下的激活标记(带 pid,换进程自动失效)
 */
object ActiveCheck {

    private const val FRAMEWORK_CLASS = "de.robv.android.xposed.XposedBridge"
    private const val HOOK_CLASS = "de.robv.android.xposed.XC_MethodHook"
    private const val MARKER_NAME = "lsp_active.marker"

    /** HookInit 在「自己这个进程」被注入时置位,同一进程内立即可见 */
    @Volatile
    var selfHooked: Boolean = false
        private set

    fun markSelfHooked() {
        selfHooked = true
    }

    /** 框架的类在不在本进程里(最硬的证据) */
    fun frameworkClassLoaded(): Boolean = try {
        val cl = ActiveCheck::class.java.classLoader
        Class.forName(FRAMEWORK_CLASS, false, cl) != null
    } catch (t: Throwable) {
        false
    }

    /** 框架的 hook 基类在不在本进程里(二重确认,防某些加固把桥类藏起来) */
    fun hookClassLoaded(): Boolean = try {
        val cl = ActiveCheck::class.java.classLoader
        Class.forName(HOOK_CLASS, false, cl) != null
    } catch (t: Throwable) {
        false
    }

    /** 框架自报的版本号,0 = 拿不到 */
    fun xposedVersion(): Int = try {
        val cls = Class.forName(FRAMEWORK_CLASS, false, ActiveCheck::class.java.classLoader)
        (cls.getMethod("getXposedVersion").invoke(null) as? Int) ?: 0
    } catch (t: Throwable) {
        0
    }

    /** 本进程加载的 native 里有没有框架的影子(不用 root 也能看) */
    fun nativeTrace(): Boolean = try {
        val maps = File("/proc/self/maps")
        if (!maps.canRead()) {
            false
        } else {
            maps.useLines { lines ->
                lines.any { line ->
                    val l = line.lowercase()
                    l.contains("lspd") || l.contains("xposed") || l.contains("libriru")
                }
            }
        }
    } catch (t: Throwable) {
        false
    }

    /** 模块自己写的激活标记,pid 对得上才算数 */
    fun markerActive(context: Context): Boolean = try {
        val f = File(context.filesDir, MARKER_NAME)
        if (!f.isFile) {
            false
        } else {
            val pid = f.readText().trim().substringBefore(':').toIntOrNull()
            pid != null && pid == Process.myPid()
        }
    } catch (t: Throwable) {
        false
    }

    fun writeMarker(context: Context) {
        try {
            File(context.filesDir, MARKER_NAME)
                .writeText(Process.myPid().toString() + ":" + System.currentTimeMillis())
        } catch (t: Throwable) {
        }
    }

    /** 本进程此刻有没有真的被框架注入 */
    fun activeInSelf(context: Context): Boolean =
        selfHooked || frameworkClassLoaded() || nativeTrace() || markerActive(context)

    /** 一句话说明是靠哪条判据认出来的,给日志用 */
    fun evidence(context: Context): String {
        val list = ArrayList<String>()
        if (selfHooked) list.add("hook-self")
        if (frameworkClassLoaded()) list.add("class")
        if (hookClassLoaded()) list.add("hook-class")
        if (nativeTrace()) list.add("maps")
        if (markerActive(context)) list.add("marker")
        return if (list.isEmpty()) "none" else list.joinToString("+")
    }
}
