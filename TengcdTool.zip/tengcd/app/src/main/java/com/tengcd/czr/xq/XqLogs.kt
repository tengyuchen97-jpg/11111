package com.tengcd.czr.xq

import android.content.Context
import com.tengcd.czr.util.ShizukuShell

/**
 * 面板上要显示的日志。
 *
 * 应用内通道的日志就在 files/xq/xiaoqiao.log,直接读;
 * Shizuku 通道的进程是 shell 身份起的,它的日志落在 /data/local/tmp/xq/xiaoqiao.log,
 * 我们读不到那个目录,于是让 Shizuku 帮我们把 tail 吐回来(1.5 秒才问一次,别一直 binder)。
 */
object XqLogs {

    private const val TTL = 1500L

    @Volatile
    private var extCache = ""

    @Volatile
    private var extAt = 0L

    fun tail(c: Context, lines: Int = 16): String {
        val app = XqPrefs.tailLog(c, lines)
        if (XqPrefs.mode(c) != XqPrefs.MODE_SHIZUKU) return app

        val now = System.currentTimeMillis()
        if (extAt == 0L || now - extAt > TTL) {
            extAt = now
            extCache = try {
                ShizukuShell.exec("tail -n " + lines + " " + XqRunner.EXT_LOG + " 2>/dev/null", 2500L)
                    ?.output?.trim().orEmpty()
            } catch (t: Throwable) {
                ""
            }
        }
        return if (extCache.isBlank()) app else app + "\n— Shizuku 通道日志 —\n" + extCache
    }

    /** 清日志:自己的清掉,Shizuku 那边也顺手清一下 */
    fun clear(c: Context): Boolean {
        val ok = XqPrefs.clearLog(c)
        extCache = ""
        extAt = 0L
        if (XqPrefs.mode(c) == XqPrefs.MODE_SHIZUKU && ShizukuShell.granted()) {
            try {
                ShizukuShell.exec(": > " + XqRunner.EXT_LOG + " 2>/dev/null; rm -f " + XqRunner.EXT_LOG, 3000L)
            } catch (t: Throwable) {
            }
        }
        return ok
    }
}
