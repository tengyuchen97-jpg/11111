package com.tengcd.czr.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.ParcelFileDescriptor
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import java.io.File

/**
 * Shizuku 通道。
 *
 * 安卓 12 起,普通应用碰不到别的应用的 /Android/data/<包名> 目录,
 * 这时候要么 root,要么借 Shizuku 的 shell 身份去写。
 *
 * 这里只用 Shizuku 的两件事:
 *  - 授权(用户在 Shizuku 里点允许)
 *  - 以 shell 身份起一个 sh 进程跑命令
 *
 * v1.6 修复:加 pushFile()。
 * shell 身份(uid 2000)进不去应用私有目录 /data/user/0/<包名>/files,
 * 所以「小乔在 Shizuku 通道启动」必须先把本体推到 /data/local/tmp 再跑,
 * 推的方式是把文件内容直接灌进 sh 进程的 stdin(`cat > 目标路径`),
 * 不用绕道任何外部存储、也不用先给谁写权限。
 */
object ShizukuShell {

    /** 请求授权的 requestCode,Activity 侧要一致 */
    const val REQUEST_CODE = 4201

    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    /** 手机装没装 Shizuku */
    fun installed(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (t: Throwable) {
        false
    }

    /** Shizuku 服务活着没有(装是装了,可能没启动) */
    fun alive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    /** 我们有没有拿到授权 */
    fun granted(): Boolean = try {
        alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /** 弹授权框。已经授权过就直接返回 true */
    fun requestPermission(code: Int = REQUEST_CODE): Boolean = try {
        if (!alive()) {
            false
        } else if (granted()) {
            true
        } else {
            Shizuku.requestPermission(code)
            true
        }
    } catch (t: Throwable) {
        false
    }

    fun addResultListener(listener: (Int, Boolean) -> Unit): Boolean = try {
        Shizuku.addRequestPermissionResultListener { requestCode, grantResult ->
            listener(requestCode, grantResult == PackageManager.PERMISSION_GRANTED)
        }
        true
    } catch (t: Throwable) {
        false
    }

    private fun service(): IShizukuService? = try {
        val binder = Shizuku.getBinder() ?: return null
        IShizukuService.Stub.asInterface(ShizukuBinderWrapper(binder))
    } catch (t: Throwable) {
        null
    }

    /**
     * 以 shell 身份跑一条命令。拿不到授权 / 服务没起来 -> null
     */
    fun exec(command: String, timeoutMs: Long = 15000L): ShellUtil.Result? {
        if (!granted()) return null
        return try {
            val svc = service() ?: return null
            val process = svc.newProcess(arrayOf("sh", "-c", command), null, null) ?: return null

            val output = StringBuilder()
            val reader = Thread {
                try {
                    ParcelFileDescriptor.AutoCloseInputStream(process.inputStream).use { stream ->
                        stream.bufferedReader().forEachLine { line ->
                            output.append(line).append('\n')
                        }
                    }
                } catch (t: Throwable) {
                }
            }
            reader.isDaemon = true
            reader.start()

            val finished = try {
                process.waitForTimeout(timeoutMs, "MILLISECONDS")
            } catch (t: Throwable) {
                false
            }
            if (!finished) {
                try {
                    process.destroy()
                } catch (t: Throwable) {
                }
            }
            try {
                reader.join(1200L)
            } catch (t: Throwable) {
            }
            val code = try {
                process.exitValue()
            } catch (t: Throwable) {
                -1
            }
            ShellUtil.Result(code, output.toString())
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * 把本地文件的内容灌进 shell 进程的 stdin,由命令自己决定写到哪。
     *
     * 典型用法:
     *   pushFile("mkdir -p /data/local/tmp/xq && cat > /data/local/tmp/xq/xiaoqiao && chmod 700 ...", bin)
     *
     * 成功后返回值里会带上命令自己 echo 出来的内容。
     */
    fun pushFile(command: String, file: File, timeoutMs: Long = 60000L): ShellUtil.Result? {
        if (!granted()) return null
        if (!file.isFile) return null
        return try {
            val svc = service() ?: return null
            val process = svc.newProcess(arrayOf("sh", "-c", command), null, null) ?: return null

            val output = StringBuilder()
            val reader = Thread {
                try {
                    ParcelFileDescriptor.AutoCloseInputStream(process.inputStream).use { stream ->
                        stream.bufferedReader().forEachLine { line ->
                            output.append(line).append('\n')
                        }
                    }
                } catch (t: Throwable) {
                }
            }
            reader.isDaemon = true
            reader.start()

            var written = 0L
            var writeError: String? = null
            val writer = Thread {
                try {
                    ParcelFileDescriptor.AutoCloseOutputStream(process.outputStream).use { out ->
                        file.inputStream().use { input ->
                            val buf = ByteArray(128 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                out.write(buf, 0, n)
                                written += n
                            }
                        }
                        out.flush()
                    }
                } catch (t: Throwable) {
                    writeError = t.message ?: t.javaClass.simpleName
                }
            }
            writer.isDaemon = true
            writer.start()

            try {
                writer.join(timeoutMs)
            } catch (t: Throwable) {
            }
            val finished = try {
                process.waitForTimeout(timeoutMs, "MILLISECONDS")
            } catch (t: Throwable) {
                false
            }
            if (!finished) {
                try {
                    process.destroy()
                } catch (t: Throwable) {
                }
            }
            try {
                reader.join(1200L)
            } catch (t: Throwable) {
            }
            val code = try {
                process.exitValue()
            } catch (t: Throwable) {
                -1
            }
            val text = output.toString()
            ShellUtil.Result(
                code,
                if (writeError != null) text + "\n[write " + written + "B err=" + writeError + "]" else text
            )
        } catch (t: Throwable) {
            null
        }
    }
}
