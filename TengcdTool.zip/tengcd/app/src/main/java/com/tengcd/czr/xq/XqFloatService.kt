package com.tengcd.czr.xq

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.tengcd.czr.MainActivity
import com.tengcd.czr.R
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * 小乔悬浮窗。
 *
 * 一个可拖动的球,点开是控制面板:启停、通道切换、目标进程、实时日志。
 * 面板里所有东西都走 [XqRunner],不碰原来那套 so 注入逻辑。
 */
class XqFloatService : Service() {

    companion object {
        const val ACTION_SHOW = "com.tengcd.czr.xq.SHOW"
        const val ACTION_HIDE = "com.tengcd.czr.xq.HIDE"
        private const val CHANNEL_ID = "xq_float"
        private const val NOTIFICATION_ID = 4202

        fun start(c: Context) {
            val i = Intent(c, XqFloatService::class.java).setAction(ACTION_SHOW)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.startService(Intent(c, XqFloatService::class.java).setAction(ACTION_HIDE))
        }
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var statusText: TextView? = null
    private var targetText: TextView? = null
    private var modeText: TextView? = null
    private var logText: TextView? = null
    private var dotView: View? = null

    private var expanded = false

    /**
     * 起停 / 扫 /proc / 问 Shizuku 全是阻塞活,一律丢这个线程里做,
     * 结果再 post 回主线程刷 UI。原来面板按钮是在主线程直接调 XqRunner.start(),
     * 里面 sleep 最多 2 秒多(Shizuku 通道更久),点一下就像卡死。
     */
    private val io: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var refreshing = false

    private data class Snapshot(
        val running: Boolean,
        val pid: Int,
        val mode: String,
        val targetPkg: String,
        val targetInstalled: Boolean,
        val targetPid: Int,
        val log: String
    )

    private val ticker = object : Runnable {
        override fun run() {
            refreshAsync()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        InjectionPrefs.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        startAsForeground()
        showBubble()
        handler.post(ticker)
        XqPrefs.setFloatEnabled(this, true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                teardown()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> showBubble()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            io.shutdownNow()
        } catch (t: Throwable) {
        }
        teardown()
        XqPrefs.setFloatEnabled(this, false)
        super.onDestroy()
    }

    // ---------------- 通知 ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "小乔悬浮窗", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun startAsForeground() {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("小乔悬浮窗")
            .setContentText("点悬浮球打开控制面板")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notif)
        }
    }

    // ---------------- 悬浮球 ----------------

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        if (bubble != null) return
        hidePanel()
        val size = dp(52)
        val ball = TextView(this).apply {
            text = "乔"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFFF3B6B.toInt(), 0xFF7C4DFF.toInt())
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0x66FFFFFF)
            }
            elevation = dp(8).toFloat()
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = resources.displayMetrics.widthPixels - size - dp(8)
        lp.y = resources.displayMetrics.heightPixels / 3
        bubbleParams = lp

        attachDrag(ball, lp) {
            togglePanel()
        }
        try {
            wm.addView(ball, lp)
            bubble = ball
        } catch (t: Throwable) {
            // 没有悬浮窗权限(或系统拒了)时别把服务搞崩:提示一下,停掉自己
            XqPrefs.append(this, "悬浮球添加失败:" + (t.message ?: t.javaClass.simpleName))
            stopSelf()
        }
    }

    private fun removeBubble() {
        val b = bubble ?: return
        try {
            wm.removeView(b)
        } catch (t: Throwable) {
        }
        bubble = null
    }

    /** 拖动 + 松手判定点击 */
    private fun attachDrag(v: View, lp: WindowManager.LayoutParams, onClick: () -> Unit) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    try {
                        wm.updateViewLayout(v, lp)
                    } catch (t: Throwable) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick()
                    true
                }
                else -> false
            }
        }
    }

    // ---------------- 控制面板 ----------------

    private fun glassBackground(radius: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(0xF20D0A16.toInt())
        setStroke(dp(1), 0x33FF7AA8)
    }

    private fun togglePanel() {
        if (expanded) hidePanel() else openPanel()
    }

    private fun openPanel() {
        if (panel != null) return
        expanded = true
        removeBubble()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glassBackground(20)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(12).toFloat()
        }

        // 标题栏(可拖动)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dotView = View(this).apply {
            setBackgroundColor(0xFF8A8A9A.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply {
                rightMargin = dp(8)
            }
        }
        header.addView(dotView)
        header.addView(TextView(this).apply {
            text = "小乔"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(TextView(this).apply {
            text = "—"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 18f
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { hidePanel() }
        })
        header.addView(TextView(this).apply {
            text = "✕"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 15f
            setPadding(dp(6), 0, dp(2), 0)
            setOnClickListener {
                teardown()
                stopSelf()
            }
        })
        root.addView(header)

        statusText = TextView(this).apply {
            setTextColor(0xFFFF8FB0.toInt())
            textSize = 13f
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(statusText)

        targetText = TextView(this).apply {
            setTextColor(0xAAFFFFFF.toInt())
            textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }
        root.addView(targetText)

        // 按钮区
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        row1.addView(button("启动", 0xFFFF3B6B.toInt()) {
            toastish("正在启动…")
            runInBackground {
                val (_, msg) = XqRunner.start(this@XqFloatService)
                postToast(msg)
            }
        }, weightParams())
        row1.addView(button("停止", 0x33FFFFFF) {
            runInBackground {
                val killed = XqRunner.stop(this@XqFloatService)
                postToast(if (killed) "已停止" else "本来就没在跑")
            }
        }, weightParams())
        row1.addView(button("游戏", 0xFF7C4DFF.toInt()) {
            val pkg = InjectionPrefs.targetPackage
            if (!XqRunner.launchTarget(this@XqFloatService, pkg)) toastish("拉不起目标:" + pkg)
        }, weightParams())
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        modeText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0x22FFFFFF)
                setStroke(dp(1), 0x44FFFFFF)
            }
            setOnClickListener {
                val next = when (XqPrefs.mode(this@XqFloatService)) {
                    XqPrefs.MODE_APP -> XqPrefs.MODE_SHIZUKU
                    XqPrefs.MODE_SHIZUKU -> XqPrefs.MODE_ROOT
                    else -> XqPrefs.MODE_APP
                }
                XqPrefs.setMode(this@XqFloatService, next)
                toastish("通道切到 " + modeName(next))
                refreshAsync()
            }
        }
        row2.addView(modeText, weightParams())
        row2.addView(button("日志清空", 0x33FFFFFF) {
            runInBackground {
                XqLogs.clear(this@XqFloatService)
                postToast("日志已清空")
            }
        }, weightParams())
        root.addView(row2)

        // 日志
        val scroll = ScrollView(this).apply {
            setPadding(0, dp(10), 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132)
            )
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(0x66000000)
            }
        }
        logText = TextView(this).apply {
            setTextColor(0xFF9CE8C0.toInt())
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setPadding(dp(8), dp(6), dp(8), dp(6))
            text = "等待日志…"
        }
        scroll.addView(logText)
        root.addView(scroll)

        val lp = WindowManager.LayoutParams(
            Math.min(dp(320), (resources.displayMetrics.widthPixels * 0.86f).toInt()),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(120)

        attachDrag(header, lp) { }
        try {
            wm.addView(root, lp)
            panel = root
            refreshAsync()
        } catch (t: Throwable) {
            XqPrefs.append(this, "面板添加失败:" + (t.message ?: t.javaClass.simpleName))
            panel = null
            showBubble()
        }
    }

    private fun weightParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(6)
        }

    private fun button(text: String, color: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(9), 0, dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(color)
                setStroke(dp(1), 0x33FFFFFF)
            }
            setOnClickListener { onClick() }
        }

    private fun toastish(msg: String) {
        val t = TextView(this).apply {
            text = msg
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xEE1A1424.toInt())
                setStroke(dp(1), 0x55FF7AA8)
            }
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = dp(140)
        try {
            wm.addView(t, lp)
            handler.postDelayed({
                try {
                    wm.removeView(t)
                } catch (e: Throwable) {
                }
            }, 1800L)
        } catch (e: Throwable) {
        }
    }

    private fun hidePanel(reAddBubble: Boolean = true) {
        val p = panel ?: return
        try {
            wm.removeView(p)
        } catch (t: Throwable) {
        }
        panel = null
        expanded = false
        if (reAddBubble) showBubble()
    }

    private fun runInBackground(block: () -> Unit) {
        try {
            io.execute {
                try {
                    block()
                } catch (t: Throwable) {
                    postToast("操作失败:" + (t.message ?: t.javaClass.simpleName))
                }
            }
        } catch (t: Throwable) {
        }
    }

    private fun postToast(msg: String) {
        handler.post { toastish(msg) }
    }

    /**
     * 刷新面板:扫 /proc、问 Shizuku、读日志都是阻塞活,
     * 全程在 io 线程做,做完把快照丢回主线程。
     */
    private fun refreshAsync() {
        if (refreshing) return
        refreshing = true
        try {
            io.execute {
                val snap = try {
                    buildSnapshot()
                } catch (t: Throwable) {
                    null
                }
                handler.post {
                    refreshing = false
                    if (snap != null) applySnapshot(snap)
                }
            }
        } catch (t: Throwable) {
            refreshing = false
        }
    }

    private fun buildSnapshot(): Snapshot {
        val st = XqRunner.status(this)
        val pkg = InjectionPrefs.targetPackage
        val installed = try {
            PackageUtil.isInstalled(this, pkg)
        } catch (t: Throwable) {
            false
        }
        val pids = if (installed) {
            try {
                PackageUtil.findPids(pkg)
            } catch (t: Throwable) {
                emptyList<Int>()
            }
        } else {
            emptyList<Int>()
        }
        val pid = try {
            pids.firstOrNull() ?: -1
        } catch (t: Throwable) {
            -1
        }
        val log = try {
            XqLogs.tail(this, 16)
        } catch (t: Throwable) {
            ""
        }
        return Snapshot(st.running, st.pid, st.mode, pkg, installed, pid, log)
    }

    private fun applySnapshot(s: Snapshot) {
        dotView?.setBackgroundColor(if (s.running) 0xFF35D07F.toInt() else 0xFF8A8A9A.toInt())
        statusText?.text = if (s.running) {
            "运行中 · PID " + s.pid + " · " + modeName(s.mode)
        } else {
            "未运行 · 当前通道 " + modeName(XqPrefs.mode(this))
        }
        modeText?.text = "通道:" + modeName(XqPrefs.mode(this))

        targetText?.text = if (!s.targetInstalled) {
            "目标:" + s.targetPkg + " 未安装"
        } else if (s.targetPid <= 0) {
            "目标:" + s.targetPkg + " 已安装 · 未运行"
        } else {
            "目标:" + s.targetPkg + " 运行中 · PID " + s.targetPid
        }

        logText?.text = if (s.log.isBlank()) "等待日志…" else s.log
        logText?.let { tv ->
            val parent = tv.parent as? ScrollView
            parent?.post { parent.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun modeName(mode: String): String = when (mode) {
        XqPrefs.MODE_SHIZUKU -> "Shizuku"
        XqPrefs.MODE_ROOT -> "root"
        else -> "应用内"
    }

    private fun teardown() {
        hidePanel(false)
        removeBubble()
        try {
            wm.removeViewImmediate(bubble)
        } catch (t: Throwable) {
        }
    }
}
