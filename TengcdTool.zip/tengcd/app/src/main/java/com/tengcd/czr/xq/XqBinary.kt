package com.tengcd.czr.xq

import android.content.Context
import android.net.Uri
import android.os.Build
import com.tengcd.czr.util.Md5Util
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * 内置小乔本体。
 *
 * 打包时把 ARM64 的 ELF 放进 assets/xq/xiaoqiao_arm64,
 * 首次启动解包到 files/xq/xiaoqiao 并加可执行权限。
 * 之后要换版本,不用重新打包 —— 面板里「从本机导入」直接选一份覆盖就行。
 *
 * v1.6 修复:
 *  1) 解包不再用 AssetManager.openFd()。assets 里的文件没有扩展名,aapt2 默认会压缩它,
 *     对压缩过的 asset 调 openFd() 必然抛
 *     "This file can not be opened as a file descriptor; it is probably compressed",
 *     这就是之前「内置本体解包失败」的真正原因。现在只走 assets.open() 流式拷贝。
 *  2) 导入本体时先认 ELF 头;如果用户选的是那份自解压 .sh(外面包着 3 层 gzip),
 *     这里自己把层剥掉、取出里面的真 ELF,不再把 .sh 当成本体去执行
 *     (执行 .sh 就会看到 "find: /data/: Permission denied" 和 "RANDOM % 0: zero divisor")。
 *  3) 写入一律先落 .part 再改名,解到一半被打断也不会留下一个坏掉的本体。
 */
object XqBinary {

    private const val ASSET = "xq/xiaoqiao_arm64"
    private const val BIN_NAME = "xiaoqiao"

    /** 小于这个体积肯定不是本体 */
    const val MIN_SIZE = 1024L * 1024L

    /** 剥自解压包时的内存上限,超过就放弃(本体 12MB,留足余量) */
    private const val MAX_PEEL_BYTES = 64L * 1024L * 1024L
    private const val MAX_PEEL_ROUNDS = 8

    fun isArm64(): Boolean {
        val abis = if (Build.VERSION.SDK_INT >= 21) Build.SUPPORTED_ABIS else arrayOf(Build.CPU_ABI)
        return abis.any { it.equals("arm64-v8a", true) }
    }

    fun binFile(c: Context): File = File(XqPrefs.workDir(c), BIN_NAME)

    /** 本体在不在、能不能跑(必须是真的 ELF) */
    fun exists(c: Context): Boolean = try {
        val f = binFile(c)
        f.isFile && f.length() >= MIN_SIZE && isElf(f)
    } catch (t: Throwable) {
        false
    }

    fun size(c: Context): Long = try {
        binFile(c).length()
    } catch (t: Throwable) {
        0L
    }

    fun md5(c: Context): String = try {
        if (exists(c)) (Md5Util.md5(binFile(c)) ?: "") else ""
    } catch (t: Throwable) {
        ""
    }

    /**
     * 确保本体已经在私有目录里、并且可执行。
     *
     * 已有且是真 ELF 就直接用(尊重用户导入的版本);
     * 没有、或者被导入成了别的东西(.sh / 压缩包 / 半截文件)就用内置的那份重新解。
     */
    fun ensure(c: Context): File? {
        val target = binFile(c)
        if (exists(c)) {
            if (target.canExecute() || target.setExecutable(true, false)) return target
            XqPrefs.append(c, "本体在,但没有执行权限,重解一次内置")
        } else if (target.isFile && target.length() > 0L) {
            XqPrefs.append(c, "现有本体不是可执行 ELF(" + (target.length() / 1024 / 1024) + "MB),用内置的覆盖")
        }
        return extractBundled(c)
    }

    /** 把 assets 里那份解到 files/xq/xiaoqiao */
    fun extractBundled(c: Context): File? {
        val target = binFile(c)
        val tmp = File(target.parentFile, BIN_NAME + ".part")
        return try {
            target.parentFile?.mkdirs()
            if (tmp.exists()) tmp.delete()
            var total = 0L
            c.applicationContext.assets.open(ASSET).use { input: InputStream ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        total += n
                    }
                    out.flush()
                }
            }
            if (total < MIN_SIZE || !isElf(tmp)) {
                tmp.delete()
                XqPrefs.append(c, "内置本体不完整(解出 " + (total / 1024 / 1024) + "MB,或不是 ELF)")
                return null
            }
            tmp.setReadable(true, true)
            tmp.setExecutable(true, false)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                // 极少数机器上 rename 会失败,退回复制
                tmp.inputStream().use { input ->
                    target.outputStream().use { out -> input.copyTo(out, 128 * 1024) }
                }
                tmp.delete()
            }
            target.setReadable(true, true)
            target.setExecutable(true, false)
            XqPrefs.append(c, "内置本体已解包:" + (target.length() / 1024 / 1024) + "MB")
            return target
        } catch (t: Throwable) {
            try {
                if (tmp.exists()) tmp.delete()
            } catch (e: Throwable) {
            }
            XqPrefs.append(c, "解包失败:" + (t.message ?: t.javaClass.simpleName))
            null
        }
    }

    /**
     * 从本机选的文件导入(换版本用)。
     * 支持三种输入:① 已经解出来的 ELF ② 超孜然那种自解压 .sh ③ 里面包着 ELF 的 gz/压缩流。
     */
    fun importFrom(c: Context, uri: Uri): Pair<Boolean, String> {
        return try {
            val raw = c.contentResolver.openInputStream(uri)?.use { readCapped(it, MAX_PEEL_BYTES) }
                ?: return false to "选的文件读不出来"
            if (raw.size < 4096) return false to "文件太小,不像本体"

            var peeled = 0
            var data = raw
            if (!isElf(data)) {
                val out = peel(data)
                if (out == null) {
                    XqPrefs.append(c, "导入失败:剥完不是 ELF(" + (raw.size / 1024 / 1024) + "MB)")
                    return false to "这个文件里没有小乔本体(不是 ELF)"
                }
                peeled = 1
                data = out
            }
            if (data.size < MIN_SIZE) return false to "取出来的本体太小,不对"

            val target = binFile(c)
            val tmp = File(target.parentFile, BIN_NAME + ".part")
            target.parentFile?.mkdirs()
            tmp.outputStream().use { it.write(data) }
            if (!isElf(tmp)) {
                tmp.delete()
                return false to "写进去的不是 ELF"
            }
            tmp.setReadable(true, true)
            tmp.setExecutable(true, false)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.inputStream().use { input ->
                    target.outputStream().use { out -> input.copyTo(out, 128 * 1024) }
                }
                tmp.delete()
            }
            target.setReadable(true, true)
            target.setExecutable(true, false)

            val mb = target.length() / 1024 / 1024
            if (peeled > 0) {
                XqPrefs.append(c, "已从自解压包里剥出本体:" + mb + "MB")
                true to ("已从包里剥出本体 " + mb + "MB")
            } else {
                XqPrefs.append(c, "已导入本机小乔:" + mb + "MB")
                true to ("已导入小乔本体 " + mb + "MB")
            }
        } catch (t: Throwable) {
            XqPrefs.append(c, "导入失败:" + (t.message ?: t.javaClass.simpleName))
            false to ("导入失败:" + (t.message ?: t.javaClass.simpleName))
        }
    }

    /** 是否是能跑的 ELF(读头四个字节) */
    fun isElf(f: File): Boolean = try {
        f.inputStream().use { s ->
            val b = ByteArray(4)
            s.read(b) == 4 && b[0] == 0x7F.toByte() && b[1] == 'E'.code.toByte() &&
                b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte()
        }
    } catch (t: Throwable) {
        false
    }

    fun isElf(b: ByteArray): Boolean =
        b.size >= 4 && b[0] == 0x7F.toByte() && b[1] == 'E'.code.toByte() &&
            b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte()

    // ---------------- 内部:剥自解压包 ----------------

    /** 一层层剥 gzip,剥到 ELF 为止;剥不出来返回 null */
    private fun peel(raw: ByteArray): ByteArray? {
        var data = raw
        var round = 0
        while (round < MAX_PEEL_ROUNDS) {
            if (isElf(data)) return data
            val at = indexOfGzip(data)
            if (at < 0) return null
            data = gunzip(data, at) ?: return null
            round++
        }
        return if (isElf(data)) data else null
    }

    private fun indexOfGzip(b: ByteArray): Int {
        val end = b.size - 3
        var i = 0
        while (i < end) {
            if (b[i] == 0x1F.toByte() && b[i + 1] == 0x8B.toByte() && b[i + 2] == 0x08.toByte()) return i
            i++
        }
        return -1
    }

    private fun gunzip(b: ByteArray, from: Int): ByteArray? = try {
        GZIPInputStream(ByteArrayInputStream(b, from, b.size - from)).use { g ->
            val out = ByteArrayOutputStream(4 * 1024 * 1024)
            val buf = ByteArray(128 * 1024)
            var total = 0L
            var over = false
            while (true) {
                val n = g.read(buf)
                if (n <= 0) break
                total += n
                if (total > MAX_PEEL_BYTES) {
                    over = true
                    break
                }
                out.write(buf, 0, n)
            }
            if (over) null else out.toByteArray()
        }
    } catch (t: Throwable) {
        null
    }

    private fun readCapped(input: InputStream, cap: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(128 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            total += n
            if (total > cap) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
