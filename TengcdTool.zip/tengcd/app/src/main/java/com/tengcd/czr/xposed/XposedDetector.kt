package com.tengcd.czr.xposed

import android.content.Context
import com.tengcd.czr.util.ShellUtil

/**
 * 判断设备上有没有 Xposed 系框架(原版 / EdXposed / LSPosed 都算),
 * 以及框架是不是真的在本应用里生效了。
 *
 * 注意:LSPosed 新版管理器是寄生式的(包名不固定),光靠包名比对会一路判「未激活」。
 * 所以这里先走 [ActiveCheck] 的真实注入判定,包名 / 目录只作为兜底。
 */
object XposedDetector {

    private val FRAMEWORK_PACKAGES = listOf(
        "de.robv.android.xposed.installer",
        "org.lsposed.manager",
        "org.lsposed.manager.debug",
        "com.lsposed.manager",
        "org.meowcat.edxposed.manager",
        "com.solohsu.android.edxp.manager",
        "io.github.lsposed.manager",
        "io.github.lsposed.manager.debug"
    )

    @Volatile
    private var cachedAt: Long = 0L

    @Volatile
    private var cachedResult: Boolean = false

    /** 框架存在(装了、或者已经注入到本进程) */
    fun isFrameworkInstalled(context: Context): Boolean {
        // 1. 最硬:本进程里有没有框架的类 / 标记(这个永远是实时判,不吃缓存)
        if (ActiveCheck.activeInSelf(context)) return true
        // 后面的探测要拉 su / 翻目录,界面每 30 秒会刷一次,缓存一下别把机器拖死
        val now = System.currentTimeMillis()
        if (cachedAt != 0L && now - cachedAt < 30000L) return cachedResult
        val result = detectInstalled(context)
        cachedResult = result
        cachedAt = now
        return result
    }

    private fun detectInstalled(context: Context): Boolean {
        // 2. 管理器包名
        val pm = context.packageManager
        for (pkg in FRAMEWORK_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return true
            } catch (t: Throwable) {
            }
        }

        // 3. 有 root 就直接去 /data/adb 里翻,比 ls 一次靠谱得多
        val rootHit = ShellUtil.execAsRoot(
            "ls -d /data/adb/lspd /data/adb/modules/*lsposed* /data/adb/modules/*riru* " +
                "/data/adb/modules/*zygisk* /data/adb/lspatch 2>/dev/null"
        )
        if (rootHit != null && rootHit.output.isNotBlank()) return true
        val rootProp = ShellUtil.execAsRoot("getprop | grep -i -E 'lsposed|xposed'")
        if (rootProp != null && rootProp.output.isNotBlank()) return true

        // 4. 没 root 的老路子兜一下
        if (ShellUtil.exec("ls /data/adb/lspd 2>/dev/null").output.isNotBlank()) return true
        if (ShellUtil.exec("ls /data/adb/modules 2>/dev/null | grep -i -E 'xposed|riru|lsposed'").output.isNotBlank()) return true
        return false
    }

    /** 模块在本应用里真的生效了没有(界面「模块已激活」看这个) */
    fun isModuleActive(context: Context): Boolean = ActiveCheck.activeInSelf(context)

    fun frameworkName(context: Context): String? {
        val pm = context.packageManager
        for (pkg in FRAMEWORK_PACKAGES) {
            try {
                val info = pm.getPackageInfo(pkg, 0)
                return info.applicationInfo?.loadLabel(pm)?.toString() ?: pkg
            } catch (t: Throwable) {
            }
        }
        return null
    }
}
