package com.tengcd.czr.xq

import android.content.Context
import android.content.SharedPreferences
import java.io.File

/**
 * 小乔的运行参数 + 日志文件的落地位置。
 *
 * 全部放在应用私有目录里(/data/data/<包名>/files/xq),
 * 不碰 /data 根目录,所以整条链路不需要 root。
 */
object XqPrefs {

    private const val NAME = "xq_prefs"
    const val MODE_APP = "app"          // 应用内直跑(同 uid,免 root 的主通道)
    const val MODE_SHIZUKU = "shizuku"  // 借 Shizuku 的 shell 身份(免 root 备用)
    const val MODE_ROOT = "root"        // 有 root 时兜底

    const val LOG_MAX_BYTES = 512L * 1024L

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun mode(c: Context): String = sp(c).getString("mode", MODE_APP) ?: MODE_APP

    fun setMode(c: Context, v: String) = sp(c).edit().putString("mode", v).apply()

    fun autoStart(c: Context): Boolean = sp(c).getBoolean("auto_start", false)

    fun setAutoStart(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_start", v).apply()

    fun floatEnabled(c: Context): Boolean = sp(c).getBoolean("float_enabled", false)

    fun setFloatEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("float_enabled", v).apply()

    fun pid(c: Context): Int = sp(c).getInt("pid", -1)

    fun setPid(c: Context, v: Int) = sp(c).edit().putInt("pid", v).apply()

    fun startedAt(c: Context): Long = sp(c).getLong("started_at", 0L)

    fun setStartedAt(c: Context, v: Long) = sp(c).edit().putLong("started_at", v).apply()

    /** 小乔的工作目录:二进制、日志、它自己写出来的配置都在这里 */
    fun workDir(c: Context): File {
        val d = File(c.applicationContext.filesDir, "xq")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun logFile(c: Context): File {
        val f = File(workDir(c), "xiaoqiao.log")
        if (!f.exists()) {
            try {
                f.createNewFile()
            } catch (t: Throwable) {
            }
        }
        return f
    }

    fun clearLog(c: Context): Boolean = try {
        val f = logFile(c)
        f.writeText("")
        true
    } catch (t: Throwable) {
        false
    }

    /** 取日志尾部若干行(日志有可能被小乔自己刷得很大,读之前先截断) */
    fun tailLog(c: Context, maxLines: Int = 14): String {
        return try {
            val f = logFile(c)
            if (!f.exists() || f.length() == 0L) return ""
            val len = f.length()
            val start = if (len > 96 * 1024) len - 96 * 1024 else 0L
            val bytes = java.io.RandomAccessFile(f, "r")
            bytes.seek(start)
            val buf = ByteArray((len - start).toInt())
            bytes.readFully(buf)
            bytes.close()
            val all = String(buf, Charsets.UTF_8).split('\n')
                .filter { it.isNotBlank() }
            all.takeLast(maxLines).joinToString("\n")
        } catch (t: Throwable) {
            ""
        }
    }

    /** 日志超过上限就砍一半,免得越滚越大 */
    fun trimLog(c: Context) {
        try {
            val f = logFile(c)
            if (f.length() <= LOG_MAX_BYTES) return
            val text = f.readText()
            val keep = text.takeLast((LOG_MAX_BYTES / 2).toInt())
            f.writeText(keep)
        } catch (t: Throwable) {
        }
    }

    /** 日志文件里追加一行(我们自己打的进度也写进去,面板上能一起看到) */
    fun append(c: Context, line: String) {
        try {
            val f = logFile(c)
            val text = "[" + android.text.format.DateFormat.format("HH:mm:ss", System.currentTimeMillis()) + "] " + line + "\n"
            f.appendText(text)
            trimLog(c)
        } catch (t: Throwable) {
        }
    }
}
