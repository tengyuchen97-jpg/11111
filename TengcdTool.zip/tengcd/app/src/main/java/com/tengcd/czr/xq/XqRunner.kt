package com.tengcd.czr.xq

import android.content.Context
import android.content.Intent
import com.tengcd.czr.util.ShizukuShell
import com.tengcd.czr.util.ShellUtil
import java.io.File
import java.io.RandomAccessFile

/**
 * 小乔的启动 / 停止 / 存活判定。
 *
 * 三条通道:
 *  - app     : 直接在本应用进程里 fork 出小乔。因为本应用和目标游戏共用同一个
 *              sharedUserId,uid 一致,小乔不需要 root 就能读目标进程内存。
 *  - shizuku : 借 Shizuku 的 shell 身份起(免 root 备用)
 *  - root    : 有 root 时的兜底
 *
 * v1.6 修复要点:
 *  1) Shizuku 通道原来是把应用私有目录里的本体直接拿去跑,shell(uid 2000)
 *     进不去 /data/user/0/<包名>/files(700),命令第一步就失败,
 *     于是面板上只有一句「外部通道没拿到 pid」。现在改成先把本体推送到
 *     /data/local/tmp/xq/,在那边起,日志也落那边,面板再从那边读回来。
 *  2) 进程起不来说明原因:带上 exit code + 这一段日志的最后几行,
 *     不再只给一句「进程没起来」。
 *  3) 存活判定对外部通道加了 kill -0 兜底(有些系统不让普通应用读别的 uid 的 /proc)。
 */
object XqRunner {

    private const val TAG_BIN = "xiaoqiao"

    /** Shizuku / root 通道用的中立目录(shell 也能读能写) */
    const val EXT_DIR = "/data/local/tmp/xq"
    const val EXT_BIN = EXT_DIR + "/xiaoqiao"
    const val EXT_LOG = EXT_DIR + "/xiaoqiao.log"

    data class Status(
        val running: Boolean,
        val pid: Int,
        val mode: String,
        val startedAt: Long
    )

    @Volatile
    private var proc: Process? = null

    fun status(c: Context): Status {
        var pid = XqPrefs.pid(c)
        if (pid > 0 && !aliveFor(c, pid)) pid = -1
        if (pid <= 0) {
            pid = findPid()
            if (pid > 0) XqPrefs.setPid(c, pid)
        }
        val running = pid > 0
        if (!running) {
            XqPrefs.setStartedAt(c, 0L)
            if (XqPrefs.pid(c) != -1) XqPrefs.setPid(c, -1)
        }
        return Status(running, if (running) pid else -1, XqPrefs.mode(c), XqPrefs.startedAt(c))
    }

    fun alive(pid: Int): Boolean {
        if (pid <= 0) return false
        if (!File("/proc/$pid").exists()) return false
        return try {
            val cmd = File("/proc/$pid/cmdline").readText().replace("\u0000", " ")
            cmd.contains(TAG_BIN)
        } catch (t: Throwable) {
            // 读不到 cmdline(权限/内核限制)时只按目录存在判定
            File("/proc/$pid").exists()
        }
    }

    @Volatile
    private var extCheckAt = 0L

    @Volatile
    private var extCheckPid = -1

    @Volatile
    private var extCheckAlive = false

    /** 外部通道起的进程,普通应用可能看不到它的 /proc,用 Shizuku 的 kill -0 兜一下 */
    private fun aliveExternal(pid: Int): Boolean {
        if (pid <= 0) return false
        val now = System.currentTimeMillis()
        if (pid == extCheckPid && now - extCheckAt < 3000L) return extCheckAlive
        val ok = try {
            ShizukuShell.exec("kill -0 " + pid + " 2>/dev/null && echo XQALIVE", 2500L)
                ?.output?.contains("XQALIVE") == true
        } catch (t: Throwable) {
            false
        }
        extCheckPid = pid
        extCheckAt = now
        extCheckAlive = ok
        return ok
    }

    private fun aliveFor(c: Context, pid: Int): Boolean {
        if (alive(pid)) return true
        return XqPrefs.mode(c) == XqPrefs.MODE_SHIZUKU && aliveExternal(pid)
    }

    @Volatile
    private var lastScanAt = 0L

    @Volatile
    private var lastScanPid = -1

    /**
     * 同 uid 下扫 /proc 找小乔;找不到就 -1。
     * 面板每秒刷一次,这个扫描 2 秒内只做一次,别一直薅内核。
     */
    fun findPid(): Int {
        val now = System.currentTimeMillis()
        if (lastScanAt != 0L && now - lastScanAt < 2000L && lastScanPid > 0 && alive(lastScanPid)) {
            return lastScanPid
        }
        val found = scanProc()
        lastScanAt = now
        lastScanPid = found
        return found
    }

    private fun scanProc(): Int {
        val dirs = File("/proc").listFiles() ?: return -1
        for (d in dirs) {
            if (!d.isDirectory) continue
            val name = d.name
            if (name.isEmpty() || name[0] < '0' || name[0] > '9') continue
            try {
                val cmd = File(d, "cmdline").readText().replace("\u0000", " ")
                if (cmd.contains(TAG_BIN)) {
                    return name.toIntOrNull() ?: -1
                }
            } catch (t: Throwable) {
            }
        }
        return -1
    }

    /** 启动。返回 (成功, 说明) */
    fun start(c: Context, mode: String = XqPrefs.mode(c)): Pair<Boolean, String> {
        if (!XqBinary.isArm64()) {
            return false to "本机不是 arm64,小乔这份是 arm64 本体,跑不了"
        }
        stop(c)

        val bin = XqBinary.ensure(c) ?: return false to "内置本体解包失败,看日志最后一行"
        if (!bin.canExecute()) {
            bin.setExecutable(true, false)
            if (!bin.canExecute()) return false to "本体没有执行权限"
        }
        val dir = XqPrefs.workDir(c)
        val log = XqPrefs.logFile(c)
        XqPrefs.append(c, "启动小乔 · 通道=" + modeLabel(mode) + " · 本体 " + (bin.length() / 1024 / 1024) + "MB")

        return when (mode) {
            XqPrefs.MODE_SHIZUKU -> startExternal(c, bin, dir, log, true)
            XqPrefs.MODE_ROOT -> startExternal(c, bin, dir, log, false)
            else -> startInApp(c, bin, dir, log)
        }
    }

    private fun modeLabel(mode: String): String = when (mode) {
        XqPrefs.MODE_SHIZUKU -> "Shizuku(免root)"
        XqPrefs.MODE_ROOT -> "root"
        else -> "应用内(免root)"
    }

    /**
     * 应用内直跑:小乔继承本应用的 uid,和目标游戏同一个 uid,
     * 所以它 attach 游戏进程这一步不需要任何提权。
     */
    private fun startInApp(c: Context, bin: File, dir: File, log: File): Pair<Boolean, String> {
        return try {
            val before = if (log.exists()) log.length() else 0L
            val pb = ProcessBuilder(bin.absolutePath)
            pb.directory(dir)
            pb.redirectErrorStream(true)
            pb.redirectOutput(ProcessBuilder.Redirect.appendTo(log))
            val env = pb.environment()
            env["HOME"] = dir.absolutePath
            env["TMPDIR"] = c.cacheDir.absolutePath
            env["TMP"] = c.cacheDir.absolutePath
            env["LD_LIBRARY_PATH"] = dir.absolutePath + ":/system/lib64:/system/lib64/hw:/vendor/lib64"
            env["PATH"] = "/sbin:/system/sbin:/system/bin:/system/xbin"
            val p = pb.start()
            proc = p

            // 等它起来一点再认 pid,太早扫 /proc 会扫空
            var pid = -1
            for (i in 0 until 20) {
                Thread.sleep(120)
                pid = findPid()
                if (pid > 0) break
                if (!p.isAlive && i > 4) break
            }
            if (pid <= 0) pid = findPid()
            XqPrefs.setPid(c, pid)
            XqPrefs.setStartedAt(c, System.currentTimeMillis())

            if (pid > 0) {
                XqPrefs.append(c, "小乔已启动 · pid=" + pid)
                true to ("已启动 pid=" + pid)
            } else {
                val exit = try {
                    p.exitValue()
                } catch (t: Throwable) {
                    -1
                }
                val tail = lastLines(log, before, 4)
                XqPrefs.append(
                    c,
                    "进程没起来(exit=" + exit + ")" + if (tail.isBlank()) "" else " · " + tail.replace("\n", " / ")
                )
                false to ("进程没起来(exit=" + exit + "),日志里有原因")
            }
        } catch (t: Throwable) {
            XqPrefs.append(c, "启动失败:" + (t.message ?: t.javaClass.simpleName))
            false to ("启动失败:" + (t.message ?: t.javaClass.simpleName))
        }
    }

    /** Shizuku / root:交给外部 shell 起,回来从输出里认 pid */
    private fun startExternal(
        c: Context,
        bin: File,
        dir: File,
        log: File,
        shizuku: Boolean
    ): Pair<Boolean, String> {
        val binPath: String
        val logPath: String

        if (shizuku) {
            if (!ShizukuShell.granted()) return false to "Shizuku 没授权,先在主界面里授权一次"

            // shell 身份进不去应用私有目录 → 先把本体推送到 /data/local/tmp/xq
            val push = ShizukuShell.pushFile(
                "mkdir -p " + EXT_DIR + " && cat > " + EXT_BIN +
                    " && chmod 700 " + EXT_BIN + " && echo PUSHED:$(wc -c < " + EXT_BIN + ")",
                bin,
                60000L
            ) ?: return false to "Shizuku 通道推本体失败(服务断了)"

            if (!push.output.contains("PUSHED:")) {
                XqPrefs.append(c, "Shizuku 推本体失败:" + push.output.trim().take(160))
                return false to "Shizuku 通道推本体失败,看日志"
            }
            binPath = EXT_BIN
            logPath = EXT_LOG
            XqPrefs.append(c, "本体已推送:" + push.output.trim())
        } else {
            binPath = bin.absolutePath
            logPath = log.absolutePath
        }

        // 修复：去掉了显式的 : ShellUtil.Result? 声明，交由编译器推断，避免空安全报错
        val out = if (shizuku) {
            ShizukuShell.exec(buildStartCmd(binPath, logPath), 12000L)
        } else {
            try {
                val p = ProcessBuilder("su", "-c", buildStartCmd(binPath, logPath))
                    .redirectErrorStream(true).start()
                val text = p.inputStream.bufferedReader().readText()
                p.waitFor()
                ShellUtil.Result(p.exitValue(), text)
            } catch (t: Throwable) {
                null
            }
        } ?: return false to "外部通道不可用(Shizuku/root 没就绪)"

        val text = out.output
        var pid = -1
        for (line in text.split('\n')) {
            if (line.contains("XQPID:")) {
                pid = line.substringAfter("XQPID:").trim().toIntOrNull() ?: -1
            }
        }

        // 起来 0.8 秒再确认一次,有的机器 setsid 之后会立刻退出
        if (pid > 0) {
            try {
                Thread.sleep(800)
            } catch (t: Throwable) {
            }
        }

        val stillAlive = if (pid > 0) {
            if (shizuku) {
                ShizukuShell.exec("kill -0 " + pid + " 2>/dev/null && echo XQALIVE", 3000L)
                    ?.output?.contains("XQALIVE") == true
            } else {
                alive(pid)
            }
        } else {
            false
        }

        if (pid <= 0 || !stillAlive) {
            val tail = readExternalTail(c, shizuku, logPath, 4)
            XqPrefs.append(
                c,
                "外部通道没拿到 pid:" + text.trim().take(160) +
                    if (tail.isBlank()) "" else " · " + tail.replace("\n", " / ")
            )
            return false to "没起来,换应用内通道试试(日志里有原因)"
        }

        XqPrefs.setPid(c, pid)
        XqPrefs.setStartedAt(c, System.currentTimeMillis())
        extCheckPid = pid
        extCheckAt = System.currentTimeMillis()
        extCheckAlive = true
        XqPrefs.append(c, "小乔已启动(外部通道) · pid=" + pid)
        return true to ("已启动 pid=" + pid)
    }

    private fun buildStartCmd(binPath: String, logPath: String): String {
        val q = "'"
        return "cd " + q + File(binPath).parent + q +
            " && (setsid " + q + binPath + q + " >> " + q + logPath + q +
            " 2>&1 & echo XQPID:\$!)"
    }

    /** root 通道读应用私有日志;Shizuku 通道让它把 tail 吐回来 */
    private fun readExternalTail(c: Context, shizuku: Boolean, logPath: String, lines: Int): String {
        return try {
            if (shizuku) {
                ShizukuShell.exec("tail -n " + lines + " " + logPath + " 2>/dev/null", 3000L)
                    ?.output?.trim().orEmpty()
            } else {
                val p = ProcessBuilder("su", "-c", "tail -n " + lines + " " + logPath)
                    .redirectErrorStream(true).start()
                val text = p.inputStream.bufferedReader().readText()
                p.waitFor()
                text.trim()
            }
        } catch (t: Throwable) {
            ""
        }
    }

    fun stop(c: Context): Boolean {
        var killed = false
        try {
            proc?.destroy()
            proc = null
            killed = true
        } catch (t: Throwable) {
        }
        val pids = ArrayList<Int>()
        val known = XqPrefs.pid(c)
        if (known > 0) pids.add(known)
        val scanned = findPid()
        if (scanned > 0 && !pids.contains(scanned)) pids.add(scanned)

        val shizuku = XqPrefs.mode(c) == XqPrefs.MODE_SHIZUKU && ShizukuShell.granted()

        for (pid in pids) {
            if (shizuku) {
                try {
                    ShizukuShell.exec("kill -9 " + pid, 4000L)
                } catch (t: Throwable) {
                }
            }
            try {
                android.os.Process.killProcess(pid)
            } catch (t: Throwable) {
            }
            try {
                Runtime.getRuntime().exec(arrayOf("kill", "-9", pid.toString())).waitFor()
            } catch (t: Throwable) {
            }
            killed = true
        }
        XqPrefs.setPid(c, -1)
        XqPrefs.setStartedAt(c, 0L)
        extCheckPid = -1
        if (killed) XqPrefs.append(c, "小乔已停止")
        return killed
    }

    /** 把小乔拉起来的那个游戏也一并拉起(选了目标包名才有用) */
    fun launchTarget(c: Context, pkg: String): Boolean {
        return try {
            val intent = c.packageManager.getLaunchIntentForPackage(pkg)
                ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(intent)
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** 取日志文件从 from 开始新增的最后 n 行 */
    fun lastLines(f: File, from: Long, n: Int): String {
        return try {
            if (!f.exists()) return ""
            val len = f.length()
            val start = if (from in 0 until len) from else (if (len > 8192) len - 8192 else 0L)
            val raf = RandomAccessFile(f, "r")
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            raf.close()
            String(buf, Charsets.UTF_8).split('\n').filter { it.isNotBlank() }.takeLast(n).joinToString("\n")
        } catch (t: Throwable) {
            ""
        }
    }
}