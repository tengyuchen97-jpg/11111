package com.tengcd.czr

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tengcd.czr.i18n.LocalStrings
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.ui.components.BottomNavBar
import com.tengcd.czr.ui.components.GlassIconButton
import com.tengcd.czr.ui.components.LiquidGlassDialog
import com.tengcd.czr.ui.components.NavEntry
import com.tengcd.czr.ui.screens.CardKeyScreen
import com.tengcd.czr.ui.screens.StartGate
import com.tengcd.czr.ui.screens.ImportScreen
import com.tengcd.czr.ui.screens.HomeScreen
import com.tengcd.czr.ui.screens.InjectScreen
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.HonffxTheme
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.util.ShizukuShell
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.appBackgroundBrush

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            HonffxTheme(darkTheme = state.darkTheme) {
                CompositionLocalProvider(LocalStrings provides viewModel.strings) {
                    HonffxApp(viewModel, state)
                }
            }
        }
    }
}

/** 导航栏本体高度,和 BottomNavBar 里的 62.dp 保持一致 */
private val BottomNavBarHeight = 62.dp

/** 导航栏上下留白 */
private val NavBarGap = 12.dp

@Composable
private fun HonffxApp(vm: MainViewModel, state: UiState) {
    val s = LocalStrings.current
    val context = LocalContext.current
    var dialog by remember { mutableStateOf<UiEvent.Dialog?>(null) }

    // Shizuku 授权结果(授权框由 Shizuku 自己弹,结果走监听回来)
    LaunchedEffect(Unit) {
        ShizukuShell.addResultListener { _, granted -> vm.onShizukuResult(granted) }
    }

    val soPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> vm.onLocalSoPicked(uri) }

    // 源文件夹选择器
    val sourcePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri -> vm.onImportSourcePicked(uri) }

    // 目标文件夹选择器
    val targetPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri -> vm.onImportTargetPicked(uri) }

    LaunchedEffect(Unit) {
        vm.events.collect { event ->
            when (event) {
                is UiEvent.Toast ->
                    Toast.makeText(context, event.text, Toast.LENGTH_SHORT).show()
                is UiEvent.Dialog ->
                    dialog = event
                UiEvent.PickLocalSoFile -> {
                    try {
                        soPicker.launch(arrayOf("*/*"))
                    } catch (t: Throwable) {
                        Toast.makeText(context, s.localSoFailed, Toast.LENGTH_SHORT).show()
                    }
                }
                UiEvent.RequestShizukuPermission -> {
                    if (!ShizukuShell.requestPermission()) {
                        Toast.makeText(context, s.shizukuNotRunning, Toast.LENGTH_SHORT).show()
                    }
                }
                is UiEvent.PickFolderTree -> {
                    try {
                        if (event.forTarget) targetPicker.launch(null)
                        else sourcePicker.launch(null)
                    } catch (t: Throwable) {
                        Toast.makeText(context, s.importNoAccess, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    LaunchedEffect(state.tab) {
        vm.refreshRuntime()
    }

    // 导航栏本体高度 + 上下留白,底部内容就卡在这条线上,既不被盖住也不会拉开一大截
    val navBarBlock = BottomNavBarHeight + NavBarGap * 2
    val density = LocalDensity.current
    val navInsetDp = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }
    val neededBottom = navInsetDp + navBarBlock

    // 没验证通过卡密之前,只给登录界面,别的什么都不给看
    if (!state.loggedIn) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(appBackgroundBrush(state.darkTheme))
        ) {
            StartGate(state, s) { vm.onAction(it) }
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(appBackgroundBrush(state.darkTheme))
    ) {
        // 1. 底层内容：使用 Scaffold 保证结构，但把 bottomBar 去掉，改成手写留白
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = { TopBar(state, s) { vm.onAction(it) } }
        ) { padding ->
            // Scaffold 已经吃掉了一部分(状态栏/导航条)的 inset,这里只补差额,
            // 免得算两遍导致底部空出一大块
            val extraBottom = (neededBottom - padding.calculateBottomPadding())
                .coerceAtLeast(0.dp)
            Box(
                modifier = Modifier
                    .padding(padding)
                    .padding(bottom = extraBottom)
            ) {
                when (state.tab) {
                    AppTab.HOME -> HomeScreen(state, s, vm::onAction)
                    AppTab.INJECT -> InjectScreen(state, s, vm::onAction)
                    AppTab.IMPORT -> ImportScreen(state, s, vm::onAction)
                    AppTab.CARD -> CardKeyScreen(state, s, vm::onAction)
                }
            }
        }

        // 2. 顶层悬浮窗
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding() // 避开手机底部的系统手势条
                .padding(horizontal = 18.dp, vertical = NavBarGap)
        ) {
            BottomBar(state, s) { vm.onAction(it) }
        }

        dialog?.let { dlg ->
            LiquidGlassDialog(
                dark = state.darkTheme,
                title = dlg.title,
                message = dlg.message,
                confirmText = dlg.confirmText,
                cancelText = dlg.cancelText,
                onConfirm = {
                    dialog = null
                    dlg.confirm?.invoke()
                },
                onDismiss = { dialog = null }
            )
        }
    }
}

@Composable
private fun TopBar(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            // 保持了你代码里原来的 50.dp
            .padding(start = 16.dp, end = 16.dp, top = 50.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = s.appTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = TitleFontFamily,
            color = if (dark) TextPrimaryDark else TextPrimaryLight
        )
        Spacer(Modifier.weight(1f))
        // 有新版就在顶栏挂一颗「更新 vX.Y」的胶囊,点开就是更新弹窗。
        // 之前只有后台在查版本,界面上一个入口都没有,用户根本不知道有新版本。
        if (state.updateAvailable) {
            UpdatePill(
                text = if (state.updateVersion.isBlank()) s.updatePill
                else s.updatePill + " v" + state.updateVersion,
                dark = state.darkTheme
            ) { onAction(UiAction.ShowUpdate) }
            Spacer(Modifier.width(10.dp))
        }
        GlassIconButton(
            icon = Icons.Filled.Refresh,
            contentDescription = s.refresh,
            dark = dark
        ) { onAction(UiAction.RefreshRuntime) }
        Spacer(Modifier.width(10.dp))
        GlassIconButton(
            icon = if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
            contentDescription = if (dark) s.themeLight else s.themeDark,
            dark = dark
        ) { onAction(UiAction.ToggleTheme) }
    }
}

/** 顶栏那颗更新胶囊:实底蓝,一眼看得见 */
@Composable
private fun UpdatePill(text: String, dark: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .height(38.dp)
            .clip(shape)
            .background(AccentBlue)
            .clickable { onClick() }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = Color.White
        )
    }
}

@Composable
private fun BottomBar(state: UiState, s: LocalizedStrings, onAction: (UiAction) -> Unit) {
    val dark = state.darkTheme
    BottomNavBar(
        dark = dark,
        entries = listOf(
            NavEntry(
                label = s.tabHome,
                icon = Icons.Filled.Home,
                selected = state.tab == AppTab.HOME,
                onClick = { onAction(UiAction.SelectTab(AppTab.HOME)) }
            ),
            NavEntry(
                label = s.tabInject,
                icon = Icons.Filled.Layers,
                selected = state.tab == AppTab.INJECT,
                onClick = { onAction(UiAction.SelectTab(AppTab.INJECT)) }
            ),
            NavEntry(
                label = s.tabImport,
                icon = Icons.Filled.FolderZip,
                selected = state.tab == AppTab.IMPORT,
                onClick = { onAction(UiAction.SelectTab(AppTab.IMPORT)) }
            ),
            NavEntry(
                label = s.tabCard,
                icon = Icons.Filled.CreditCard,
                selected = state.tab == AppTab.CARD,
                onClick = { onAction(UiAction.SelectTab(AppTab.CARD)) }
            )
        )
    )
}
