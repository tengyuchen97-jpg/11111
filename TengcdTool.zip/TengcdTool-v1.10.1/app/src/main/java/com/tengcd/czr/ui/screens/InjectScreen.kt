package com.tengcd.czr.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tengcd.czr.UiAction
import com.tengcd.czr.UiState
import com.tengcd.czr.i18n.LocalizedStrings
import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.ui.components.EmptyHint
import com.tengcd.czr.ui.components.GlassCard
import com.tengcd.czr.ui.components.KeyValueRow
import com.tengcd.czr.ui.components.PathBox
import com.tengcd.czr.ui.components.PrimaryActionButton
import com.tengcd.czr.ui.components.SecondaryActionButton
import com.tengcd.czr.ui.components.SectionHeader
import com.tengcd.czr.ui.components.SoSourceChips
import com.tengcd.czr.ui.components.SoVariantChips
import com.tengcd.czr.ui.components.SegmentedControl
import com.tengcd.czr.ui.components.TargetAppBadge
import com.tengcd.czr.ui.theme.AccentBlue
import com.tengcd.czr.ui.theme.ErrRed
import com.tengcd.czr.ui.theme.OkGreen
import com.tengcd.czr.ui.theme.TextPrimaryDark
import com.tengcd.czr.ui.theme.TextPrimaryLight
import com.tengcd.czr.ui.theme.TextSecondaryDark
import com.tengcd.czr.ui.theme.TextSecondaryLight
import com.tengcd.czr.ui.theme.TitleFontFamily
import com.tengcd.czr.ui.theme.WarnOrange

@Composable
fun InjectScreen(
    state: UiState,
    s: LocalizedStrings,
    onAction: (UiAction) -> Unit
) {
    val dark = state.darkTheme

    // 每次进到这一页都重新核一遍:本地 so 还在不在、目标进程活没活
    // (不然删掉本地 so 之后,「本地」那个按钮会挂在那儿不走)
    LaunchedEffect(Unit) { onAction(UiAction.RefreshRuntime) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // 删除了原本的大标题 Text 和它上面的 Spacer
        // 直接留出一点点顶部间距即可
        Spacer(Modifier.height(16.dp)) 

        SegmentedControl(
            options = listOf(s.frameworkInject, s.processInject),
            selectedIndex = if (state.mode == InjectionMode.FRAMEWORK) 0 else 1,
            dark = dark
        ) { index ->
            onAction(
                UiAction.SetMode(
                    if (index == 0) InjectionMode.FRAMEWORK else InjectionMode.PROCESS
                )
            )
        }

        Spacer(Modifier.height(14.dp))

        if (state.mode == InjectionMode.FRAMEWORK) {
            GlassCard(dark = dark) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionHeader(Icons.Filled.Extension, s.frameworkPrepare, dark)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (state.frameworkActive && state.frameworkInstalled) {
                        s.frameworkModuleActive
                    } else {
                        s.frameworkModuleInactive
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = if (state.frameworkActive && state.frameworkInstalled) OkGreen else WarnOrange
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.frameworkPrepareDesc,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(10.dp))
                KeyValueRow(
                    label = s.frameworkStatus,
                    value = if (state.frameworkInstalled) s.statusActivated else s.statusNotActivated,
                    dark = dark,
                    valueColor = if (state.frameworkInstalled) OkGreen else WarnOrange
                )
            }
        } else {
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.Storage, s.processPrepare, dark)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = s.checkRuntimeCondition,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = AccentBlue
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.processPrepareDesc,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(10.dp))
                KeyValueRow(
                    label = s.targetProcess,
                    value = if (state.targetRunning) "PID ${state.targetPid}" else s.targetNotRunning,
                    dark = dark,
                    valueColor = if (state.targetRunning) OkGreen else WarnOrange
                )
                KeyValueRow(
                    label = s.targetDir,
                    value = if (state.targetDirAccessible) s.targetDirOk else s.targetDirNo,
                    dark = dark,
                    valueColor = if (state.targetDirAccessible) OkGreen else WarnOrange
                )
                KeyValueRow(
                    label = s.injectMode,
                    value = s.processInject,
                    dark = dark
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionHeader(Icons.Filled.Storage, s.localModule, dark)
                Spacer(Modifier.weight(1f))
                if (state.soValid) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = OkGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (state.soValid) s.moduleReady else s.moduleNotReady,
                style = MaterialTheme.typography.bodyMedium,
                color = if (state.soValid) OkGreen else WarnOrange
            )
            Spacer(Modifier.height(4.dp))
            KeyValueRow(
                label = s.soSelect,
                value = when (state.soSource) {
                    "local" -> s.soLocal
                    "remote" -> s.soRemote
                    else -> s.soBuiltin + " " + state.selectedSo
                },
                dark = dark,
                valueColor = if (state.soSource == "local") OkGreen else null
            )
            KeyValueRow(
                label = s.soSizeLabel,
                value = formatSoSize(state.soSize),
                dark = dark,
                valueColor = if (state.soValid) OkGreen else WarnOrange
            )
            if (state.soPlaceholder) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.soPlaceholderHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            } else if (state.soSize > 0 && !state.soValid) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.soInvalidHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
            Spacer(Modifier.height(10.dp))
            SoVariantChips(
                options = state.soVariants.ifEmpty { listOf(state.selectedSo) },
                selected = state.selectedSo,
                active = state.soSource == "builtin",
                dark = dark,
                ready = state.soVariantReady
            ) { onAction(UiAction.SelectSoVariant(it)) }
            Spacer(Modifier.height(10.dp))
            KeyValueRow(
                label = s.localSoTitle,
                value = if (state.localSoReady) s.soReady else s.localSoNone,
                dark = dark,
                valueColor = if (state.localSoReady) OkGreen else null
            )
            state.localSoSourcePath?.let { path ->
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.localSoSourcePathLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
                Spacer(Modifier.height(4.dp))
                // 整条路径单独占一行(等宽字体,长路径自动折行,不再挤成半截)
                PathBox(text = path, dark = dark)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = s.soSourceTitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (dark) TextSecondaryDark else TextSecondaryLight
            )
            Spacer(Modifier.height(6.dp))
            SoSourceChips(
                dark = dark,
                builtinActive = state.soSource != "local",
                localReady = state.localSoReady,
                onBuiltin = { onAction(UiAction.UseBuiltinSo) },
                onLocal = {
                    if (state.localSoReady) {
                        onAction(UiAction.UseLocalSo)
                    } else {
                        onAction(UiAction.PickLocalSo)
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryActionButton(
                    text = s.localSoPick,
                    icon = Icons.Filled.Storage,
                    dark = dark,
                    modifier = Modifier.weight(1f)
                ) { onAction(UiAction.PickLocalSo) }
                if (state.localSoReady) {
                    SecondaryActionButton(
                        text = s.localSoClear,
                        icon = Icons.Filled.Extension,
                        dark = dark,
                        modifier = Modifier.weight(1f)
                    ) { onAction(UiAction.ClearLocalSo) }
                }
            }
            state.frameworkError?.takeIf { it.isNotBlank() }?.let { err ->
                Spacer(Modifier.height(6.dp))
                Text(
                    text = s.injectDetailLabel + ": " + err,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard(dark = dark) {
            if (!state.targetInstalled) {
                EmptyHint(s.targetNotInstalled, dark)
            } else {
                TargetAppBadge(
                    label = state.targetLabel.ifBlank { state.targetPackage },
                    pkg = state.targetPackage,
                    dark = dark,
                    running = state.targetRunning
                )
                Spacer(Modifier.height(6.dp))
                KeyValueRow(
                    label = s.injectMode,
                    value = if (state.mode == InjectionMode.FRAMEWORK) s.frameworkInject else s.processInject,
                    dark = dark
                )
                KeyValueRow(
                    label = s.targetDir,
                    value = if (state.targetDirAccessible) s.targetDirOk else s.targetDirNo,
                    dark = dark,
                    valueColor = if (state.targetDirAccessible) OkGreen else WarnOrange
                )
                if (!state.sameUid && state.mode == InjectionMode.PROCESS) {
                    Spacer(Modifier.height(4.dp))
                    EmptyHint(s.notSameUid, dark)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        PrimaryActionButton(
            text = if (state.injecting) s.injectRunning else s.oneKeyInject,
            icon = Icons.Filled.Bolt,
            enabled = !state.injecting,
            dark = dark
        ) { onAction(UiAction.Inject) }

        state.injectDetail?.takeIf { it.isNotBlank() }?.let { detail ->
            Spacer(Modifier.height(12.dp))
            GlassCard(dark = dark) {
                SectionHeader(Icons.Filled.BugReport, s.injectDetailLabel, dark)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrRed
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(horizontalArrangement = Arrangement.Center) {
                Text(
                    text = if (state.serviceRunning) s.serviceRunning else s.serviceStopped,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.serviceRunning) OkGreen else WarnOrange
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = state.targetRunning.takeIf { it }?.let { "PID ${state.targetPid}" } ?: s.targetNotRunning,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (dark) TextSecondaryDark else TextSecondaryLight
                )
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

/** so 大小:没文件就显示 "-" */
private fun formatSoSize(bytes: Long): String {
    if (bytes <= 0L) return "-"
    return when {
        bytes >= 1024L * 1024L -> String.format("%.2f MB", bytes / 1024.0 / 1024.0)
        bytes >= 1024L -> String.format("%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}
