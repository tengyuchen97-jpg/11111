package com.tengcd.czr

import com.tengcd.czr.inject.InjectionMode
import com.tengcd.czr.network.CardQueryInfo

enum class AppTab { HOME, INJECT, IMPORT, CARD }

data class UiState(
    val tab: AppTab = AppTab.HOME,
    val darkTheme: Boolean = false,

    // 公告
    val announcement: String? = null,
    val announcementLoading: Boolean = false,
    val announcementFailed: Boolean = false,
    /** 公告更新时间,显示在公告标题右上角 */
    val announcementUpdated: String = "",

    // 模块
    val localModuleReady: Boolean = false,
    val localModulePath: String? = null,
    val moduleVersion: String? = null,
    val remoteVersion: String? = null,
    val moduleMd5: String? = null,

    // SO 选择(模块概览下面那个)
    val soVariants: List<String> = emptyList(),
    val selectedSo: String = "v0.24",
    val soSource: String = "builtin",
    val activeSoPath: String? = null,
    val localSoSourcePath: String? = null,
    val localSoReady: Boolean = false,

    /** 当前 SO 的实际状态(大小 / 是不是有效 ELF / 是不是占位文件) */
    val soSize: Long = 0L,
    val soValid: Boolean = false,
    val soPlaceholder: Boolean = false,

    /**
     * 每个内置版本能不能加载:true = 能(界面标绿),false = 不能(标黄)。
     * 包里塞的是占位 so 时全是黄,换成真 so 之后自己就变绿。
     */
    val soVariantReady: Map<String, Boolean> = emptyMap(),

    /** 框架注入:目标进程回报的状态 */
    val frameworkError: String? = null,
    val frameworkLoadedPath: String? = null,

    /** 落盘通道:root / shizuku / direct / none */
    val writeChannel: String = "none",
    val writeChannelReady: Boolean = false,
    val shizukuInstalled: Boolean = false,
    val shizukuGranted: Boolean = false,
    val sdkInt: Int = 0,

    // 框架
    val frameworkInstalled: Boolean = false,

    /** 目标游戏进程里真的把 so 加载起来了(唯一能显示「已激活」的依据) */
    val frameworkActive: Boolean = false,

    /** 目标进程回报成功的时间;0 = 从来没有成功过 */
    val frameworkActiveAt: Long = 0L,

    /** 目标进程回报时用的进程名 */
    val frameworkProcess: String? = null,

    /** 框架认得这个模块(模块自己被注入),不等于游戏里注入成功 */
    val frameworkSelfLoaded: Boolean = false,

    /**
     * 当前跑在虚拟空间/框架里(BlackBox、PINKBOX 那一系)。
     * 这种环境下游戏跑在框架自己的虚拟进程里,进程名是宿主包名,
     * 按游戏包名扫 /proc 永远扫不到 —— 所以「运行中」不能只按 pid 判。
     */
    val virtualHosted: Boolean = false,

    val serviceRunning: Boolean = false,

    // 目标
    val targetPackage: String = "",
    val targetLabel: String = "",
    val targetInstalled: Boolean = false,
    val targetRunning: Boolean = false,
    val targetPid: Int = -1,
    val targetDirAccessible: Boolean = false,
    val sameUid: Boolean = false,
    /** 目标应用的 uid 能不能被我们访问(共用 uid 或特权通道能进它的私有目录) */
    val uidAccessible: Boolean = false,

    // 注入
    val mode: InjectionMode = InjectionMode.FRAMEWORK,
    val injecting: Boolean = false,
    val lastInjectDetail: String? = null,

    // 更新
    val checking: Boolean = false,
    /** 检测到有新版本:顶栏会出现「更新」按钮,进 App 也会自动弹一次 */
    val updateAvailable: Boolean = false,
    val updateVersion: String = "",
    val updateUrl: String = "",
    val updateLog: String = "",
    val updateChecking: Boolean = false,
    /** 最近一次读到的后台版本号:界面直接显示出来,空 = 这次确实没读到 */
    val backendVersion: String = "",
    /** 检查更新的诊断结果(网络没通 / 后台没填版本号),只给界面显示,不猜 */
    val updateDiag: String = "",
    val downloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,

    // 资源导入(把左边源文件夹整个覆盖到右边目标文件夹)
    val importSourceUri: String? = null,
    val importSourcePath: String = "",
    val importSourceName: String = "",
    val importSourceFiles: Int = 0,
    val importSourceDirs: Int = 0,
    val importSourceBytes: Long = 0L,

    val importTargetUri: String? = null,
    val importTargetPath: String = "",
    val importTargetName: String = "",
    val importTargetFiles: Int = 0,
    val importTargetBytes: Long = 0L,

    /** false = 合并覆盖(同名替换),true = 先清空目标再写 */
    val importReplaceAll: Boolean = false,

    val importing: Boolean = false,
    val importProgressFiles: Int = 0,
    val importProgressTotal: Int = 0,
    val importProgressBytes: Long = 0L,
    val importFinished: Boolean = false,
    val importFailed: Boolean = false,
    val importChannelLabel: String? = null,
    val importMessage: String? = null,
    val rootAvailable: Boolean = false,

    // ---------------- 保存旧数据(整目录打 zip 到 /storage/emulated/0/遄懂/) ----------------
    /** 输入框里的 zip 名称(不带 .zip) */
    val oldDataZipName: String = "",
    val oldDataBackingUp: Boolean = false,
    val oldDataBackupDone: Boolean = false,
    val oldDataBackupFailed: Boolean = false,
    val oldDataBackupFiles: Int = 0,
    val oldDataBackupTotal: Int = 0,
    val oldDataBackupBytes: Long = 0L,
    /** 结果/失败原因,直接显示在按钮下面 */
    val oldDataBackupMessage: String? = null,

    /** 导入页当前界面:0 = 导入旧数据,1 = 导入参数 */
    val importPage: Int = 0,
    /** 导入参数:目标配置文件路径 */
    val importParamPath: String = com.tengcd.czr.util.ConfigFile.TARGET_PATH,
    /** 导入参数:输入框里的内容(进页面时自动填成文件现有内容) */
    val importParamText: String = "",
    val importParamLoading: Boolean = false,
    val importParamOk: Boolean = false,
    /** 这次读写实际走的通道:direct / root / shizuku / none(界面直接显示) */
    val importParamChannel: String = "",
    val importParamMessage: String? = null,
    val targetDirWritable: Boolean = false,

    // 注入失败时 native 侧的详细原因(界面上直接显示)
    val injectDetail: String? = null,

    // 卡密
    val cardKey: String = "",
    val localCardMode: Boolean = false,
    val cardQuerying: Boolean = false,
    val cardInfo: CardQueryInfo? = null,
    val shareCode: String? = null,

    // ---------------- T3 网络验证(启动先验卡密,过了才进首页) ----------------
    val loggedIn: Boolean = false,
    val loginCard: String = "",
    val loginBusy: Boolean = false,
    val loginError: String? = null,
    val loginToken: String = "",
    val loginExpire: String = "",
    /** 机器码:卡密绑定的就是这串,换手机/换目标应用都不该变 */
    val machineCode: String = "",
    /** 剩余次数:-1 = 不是次数卡 / 还不知道。次数卡登录后由后台回包写入,平时读缓存 */
    val remainCount: Int = -1,
    /** 卡类型原文:后台 amount 字段,如 1年 / 30天 / 99次 */
    val cardTypeText: String = "",
)
