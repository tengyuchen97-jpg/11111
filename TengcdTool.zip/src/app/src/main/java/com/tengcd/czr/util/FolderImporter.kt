package com.tengcd.czr.util

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * 文件夹 -> 文件夹 的对拷引擎(MT 管理器那种:左边源文件夹整个盖到右边目标文件夹)。
 *
 * 两边的文件夹都可以来自两处:
 *   1) 系统文件夹选择器(SAF)→ 走 DocumentFile / content:// 通道
 *   2) 手输绝对路径 → 走文件直读直写;写不进去(比如 /Android/data 下的应用私有目录)再用 root
 *
 * 覆盖方式两种:
 *   replaceAll = false  合并覆盖:同名文件被源里的替换掉,目标里多出来的文件保留
 *   replaceAll = true   整目录替换:先清空目标目录,再把源整个写进去
 *
 * 流程统一是"先暂存再落盘":源内容先拷进自己的缓存目录,落盘时一次性写目标,
 * 这样中途失败不会在目标目录里留下半截文件。
 */
object FolderImporter {

    /** 默认目标目录(只是给输入框预填一个常用值,用户可以随便改) */
    const val DEFAULT_TARGET_PATH = "/storage/emulated/0/Android/data/com.pi.czrxdfirst/files"

    /** 按目标包名算默认目录:切到 czr 组时导入页也跟着指到 czr 的目录 */
    fun defaultTargetPath(pkg: String = "com.pi.czrxdfirst"): String {
        val p = pkg.ifBlank { "com.pi.czrxdfirst" }
        return "/storage/emulated/0/Android/data/$p/files"
    }

    /** 目标应用包名(只在 root 通道里用来 chown,不是硬依赖) */
    const val TARGET_PACKAGE = "com.pi.czrxdfirst"

    /** 老代码里的名字,保留兼容 */
    const val TARGET_PATH = DEFAULT_TARGET_PATH

    const val CHANNEL_SAF = "saf"
    const val CHANNEL_DIRECT = "direct"
    const val CHANNEL_ROOT = "root"
    const val CHANNEL_SHIZUKU = "shizuku"
    const val CHANNEL_NONE = "none"

    /** 当前设备/目标目录下,到底能不能把文件写进去 */
    data class ChannelState(
        val sdkInt: Int,
        val rootAvailable: Boolean,
        val shizukuInstalled: Boolean,
        val shizukuGranted: Boolean,
        val directAllowed: Boolean,
        /** root / shizuku / direct / none */
        val label: String,
        val ready: Boolean
    )

    private const val MAX_DEPTH = 32

    data class DirStat(
        val name: String,
        val path: String,
        val files: Int,
        val dirs: Int,
        val bytes: Long
    )

    data class Progress(val copied: Int, val total: Int, val bytes: Long)

    data class Outcome(
        val ok: Boolean,
        val copied: Int,
        val bytes: Long,
        val channel: String,
        val error: String? = null
    )

    /** 源文件夹:SAF 或绝对路径 */
    sealed class Source {
        data class Tree(val uri: Uri) : Source()
        data class Path(val dir: File) : Source()
    }

    /** 目标文件夹:SAF 或绝对路径 */
    sealed class Target {
        data class Tree(val uri: Uri) : Target()
        data class Path(val dir: File) : Target()
    }

    fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
        bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
        bytes >= 1024L -> String.format("%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    fun hasRoot(): Boolean = ShellUtil.hasRoot()

    /**
     * 落盘通道判定:
     *  - 有 root -> 直接可用
     *  - 安卓 11 及以下 -> 有「所有文件访问」就能直写
     *  - 安卓 12 起 -> 必须 Shizuku(或 root),都没有就是"尚未就绪"
     */
    fun channelState(context: Context, targetPath: String? = null): ChannelState {
        val sdk = PermissionUtil.sdkInt()
        val root = ShellUtil.hasRoot()
        val shizukuInstalled = ShizukuShell.installed(context)
        val shizukuGranted = ShizukuShell.granted()
        val ownDir = targetPath != null && (
            targetPath.contains(context.packageName) || targetPath.startsWith(context.filesDir.path)
            )
        val direct = ownDir || !PermissionUtil.needsSpecialChannelForOtherAppDir()
        val label = when {
            root -> CHANNEL_ROOT
            shizukuGranted -> CHANNEL_SHIZUKU
            direct -> CHANNEL_DIRECT
            else -> CHANNEL_NONE
        }
        val ready = root || shizukuGranted || direct
        return ChannelState(
            sdkInt = sdk,
            rootAvailable = root,
            shizukuInstalled = shizukuInstalled,
            shizukuGranted = shizukuGranted,
            directAllowed = direct,
            label = label,
            ready = ready
        )
    }

    /** 这个目录现在能不能直接读写(有 root 的话其实不用管这个) */
    fun canWrite(dir: File): Boolean = try {
        if (dir.exists()) {
            dir.isDirectory && dir.canWrite()
        } else {
            var p: File? = dir.parentFile
            while (p != null && !p.exists()) p = p.parentFile
            p != null && p.canWrite()
        }
    } catch (t: Throwable) {
        false
    }

    // ---------------------------------------------------------------- 统计

    /** SAF 文件夹:文件数 / 子目录数 / 总字节 */
    fun statTree(context: Context, uri: Uri): DirStat? {
        val root = DocumentFile.fromTreeUri(context, uri) ?: return null
        var files = 0
        var dirs = 0
        var bytes = 0L
        walkTree(root) { _, doc ->
            if (doc.isDirectory) {
                dirs++
            } else if (doc.isFile) {
                files++
                bytes += doc.length()
            }
        }
        return DirStat(root.name ?: "已选文件夹", displayPath(context, uri), files, dirs, bytes)
    }

    /** 绝对路径:文件数 / 子目录数 / 总字节。目录不存在时返回全 0(目标目录常常还没建) */
    fun statPath(dir: File): DirStat {
        var files = 0
        var dirs = 0
        var bytes = 0L
        if (dir.isFile) {
            // 选中的就是一个文件:算 1 个文件,大小照实给
            return DirStat(dir.name.ifBlank { dir.path }, dir.absolutePath, 1, 0, dir.length())
        }
        if (dir.isDirectory) {
            walkFile(dir) { f ->
                if (f.isDirectory) {
                    dirs++
                } else {
                    files++
                    bytes += f.length()
                }
            }
        }
        return DirStat(dir.name.ifBlank { dir.path }, dir.absolutePath, files, dirs, bytes)
    }

    /** 把 content:// 的 tree uri 换成能看懂的绝对路径,选完文件夹给用户看 */
    fun displayPath(context: Context, uri: Uri): String {
        val docId = try {
            DocumentsContract.getTreeDocumentId(uri)
        } catch (t: Throwable) {
            null
        } ?: return uri.toString()
        val parts = docId.split(":", limit = 2)
        return when {
            parts.size == 2 && parts[0] == "primary" ->
                "/storage/emulated/0/" + parts[1].trimStart('/')
            parts.size == 2 -> "/storage/" + parts[0] + "/" + parts[1].trimStart('/')
            else -> docId
        }.trimEnd('/').ifBlank { "/" }
    }

    /**
     * 单选文件的 content:// uri 换成能看懂的绝对路径。
     * 以前直接把 uri.toString() 塞进界面,显示成
     * content://com.android.externalstorage.documents/document/primary%3A%E6%87%82...%2Fxxx.so
     * 一长串百分号转义,看着跟加密串一样 —— 这里统一还原成人能读的路径。
     */
    fun fileDisplayPath(context: Context, uri: Uri): String {
        if (uri.scheme == "file") return uri.path.orEmpty()
        val docId = try {
            DocumentsContract.getDocumentId(uri)
        } catch (t: Throwable) {
            null
        }
        if (!docId.isNullOrBlank()) {
            val parts = docId.split(":", limit = 2)
            val path = when {
                parts.size == 2 && parts[0].equals("primary", true) ->
                    "/storage/emulated/0/" + parts[1].trimStart('/')
                parts.size == 2 -> "/storage/" + parts[0] + "/" + parts[1].trimStart('/')
                else -> docId
            }
            return Uri.decode(path).trimEnd('/')
        }
        // 别的 provider(网盘/第三方文件管理器)拿不到真实路径,至少给个干净的文件名
        val name = try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (t: Throwable) {
            null
        }
        if (!name.isNullOrBlank()) return name
        return Uri.decode(uri.toString())
    }

    private fun walkTree(
        dir: DocumentFile,
        depth: Int = 0,
        prefix: String = "",
        visit: (String, DocumentFile) -> Unit
    ) {
        if (depth > MAX_DEPTH) return
        val children = try {
            dir.listFiles()
        } catch (t: Throwable) {
            emptyArray()
        }
        for (child in children) {
            val name = child.name ?: continue
            val path = if (prefix.isEmpty()) name else "$prefix/$name"
            visit(path, child)
            if (child.isDirectory) walkTree(child, depth + 1, path, visit)
        }
    }

    private fun walkFile(dir: File, depth: Int = 0, visit: (File) -> Unit) {
        if (depth > MAX_DEPTH) return
        val children = try {
            dir.listFiles()
        } catch (t: Throwable) {
            null
        } ?: return
        for (child in children) {
            visit(child)
            if (child.isDirectory) walkFile(child, depth + 1, visit)
        }
    }

    // ---------------------------------------------------------------- 拷贝

    /**
     * 源是单个文件:把它整个写进目标文件夹,文件名不变。
     * 目标里同名的旧文件会被替换,其它文件保留。
     */
    private fun runSingleFile(
        context: Context,
        file: File,
        target: Target,
        onProgress: (Progress) -> Unit
    ): Outcome {
        val name = file.name
        val total = 1
        val size = file.length()

        when (target) {
            is Target.Path -> {
                val dir = target.dir
                if (!dir.exists() && !dir.mkdirs()) {
                    return Outcome(false, 0, 0, CHANNEL_NONE, "目标目录建不了")
                }
                if (!dir.isDirectory) {
                    return Outcome(false, 0, 0, CHANNEL_NONE, "目标不是目录")
                }
                val out = File(dir, name)
                // ① 直接写
                val direct = try {
                    file.inputStream().use { i ->
                        out.outputStream().use { o ->
                            val copied = i.copyTo(o, 256 * 1024)
                            if (copied != size) 0L else copied
                        }
                    }
                } catch (t: Throwable) {
                    -1L
                }
                if (direct >= 0L) {
                    onProgress(Progress(total, total, size))
                    return Outcome(true, 1, size, CHANNEL_DIRECT)
                }
                // ② 直写不行(目标在别的应用私有目录)就走 root cp
                if (hasRoot()) {
                    val src = shq(file.absolutePath)
                    val dst = shq(out.absolutePath)
                    val r = ShellUtil.exec(
                        "su -c 'mkdir -p " + shq(dir.absolutePath) + " && cp -f $src $dst'",
                        120_000
                    )
                    if (out.exists() && out.length() == size) {
                        // 属主必须写成数字 uid。以前这里拿包名当用户名传给 chown
                        // ("com.pi.czrxdfirst:com.pi.czrxdfirst"),系统里没这个用户,
                        // 命令静默失败,文件留在 root 名下,目标进程读不到 —— 看着就像"注进去了没生效"
                        val uid = ownerUidOf(context, dir)
                        if (uid > 0) {
                            ShellUtil.exec("su -c 'chown $uid:$uid $dst'", 15_000)
                        }
                        onProgress(Progress(total, total, size))
                        return Outcome(true, 1, size, CHANNEL_ROOT)
                    }
                    return Outcome(false, 0, 0, CHANNEL_ROOT, r.output.ifBlank { "root 写入失败" })
                }
                return Outcome(false, 0, 0, CHANNEL_NONE, "没有写权限(需要 root 或 Shizuku)")
            }

            is Target.Tree -> {
                val root = DocumentFile.fromTreeUri(context, target.uri)
                    ?: return Outcome(false, 0, 0, CHANNEL_NONE, "目标文件夹拿不到写权限,重新选一次")
                return try {
                    findChild(root, name, isDir = false)?.delete()
                    var doc = root.createFile(mimeOf(name), name)
                        ?: root.createFile("application/octet-stream", name)
                        ?: return Outcome(false, 0, 0, CHANNEL_NONE, "目标文件夹建不了文件")
                    if (doc.name != name) doc.renameTo(name)
                    val out = context.contentResolver.openOutputStream(doc.uri)
                        ?: return Outcome(false, 0, 0, CHANNEL_NONE, "目标文件打不开")
                    file.inputStream().use { i ->
                        out.use { o -> i.copyTo(o, 256 * 1024) }
                    }
                    onProgress(Progress(1, 1, size))
                    Outcome(true, 1, size, CHANNEL_SAF)
                } catch (t: Throwable) {
                    Outcome(false, 0, 0, CHANNEL_SAF, t.message ?: "写入失败")
                }
            }
        }
    }

    /**
     * 真正执行一次"源文件夹 -> 目标文件夹"的覆盖。
     *
     * @param replaceAll true = 先清空目标目录再写;false = 同名覆盖,其余保留
     */
    fun run(
        context: Context,
        source: Source,
        target: Target,
        replaceAll: Boolean,
        onProgress: (Progress) -> Unit = {}
    ): Outcome {
        // 源是一个文件时,按文件名整个写进目标文件夹(同名覆盖)
        val singleFile = (source as? Source.Path)?.dir
        if (singleFile != null && singleFile.isFile) {
            return runSingleFile(context, singleFile, target, onProgress)
        }

        val stat = when (source) {
            is Source.Tree -> statTree(context, source.uri)
            is Source.Path -> statPath(source.dir)
        } ?: return Outcome(false, 0, 0, "none", "源文件夹读不出来(权限或已失效)")

        if (stat.files == 0 && stat.dirs == 0) {
            return Outcome(false, 0, 0, "none", "源文件夹是空的")
        }

        // 快路径:源和目标都是绝对路径时直接对拷,不占缓存(资源文件夹动辄几百 MB,别先暂存一份)
        if (source is Source.Path && target is Target.Path) {
            val direct = writeDirectTree(source.dir, target.dir, replaceAll, stat.files, onProgress)
            if (direct != null) {
                cleanupStage(context)
                return direct
            }
        }

        val staged = stageSource(context, source, stat, onProgress)
            ?: return Outcome(false, 0, 0, "none", "源文件夹内容读不出来(权限不足)")

        val stageDir = staged.first
        val total = staged.second
        if (total <= 0) {
            cleanupStage(context)
            return Outcome(false, 0, 0, "none", "源文件夹里没有可写的文件")
        }

        val outcome = when (target) {
            is Target.Tree -> writeToTree(context, target.uri, stageDir, replaceAll, total, onProgress)
            is Target.Path ->
                writeToPathDirect(stageDir, target.dir, replaceAll, total, onProgress)
                    ?: writeToPathRoot(context, stageDir, target.dir, replaceAll, total)
                    ?: Outcome(false, 0, 0, CHANNEL_NONE, notReadyReason(context, target.dir))
        }

        cleanupStage(context)
        return outcome
    }

    /** 把源整个拷进缓存,返回 (暂存目录, 文件总数) */
    private fun stageSource(
        context: Context,
        source: Source,
        stat: DirStat,
        onProgress: (Progress) -> Unit
    ): Pair<File, Int>? {
        val work = stageDir(context)
        try {
            work.deleteRecursively()
        } catch (t: Throwable) {
        }
        if (!work.mkdirs() && !work.isDirectory) return null

        var copied = 0
        var bytes = 0L
        val total = stat.files

        when (source) {
            is Source.Tree -> {
                val root = DocumentFile.fromTreeUri(context, source.uri) ?: return null
                walkTree(root) { rel, doc ->
                    val out = File(work, rel)
                    try {
                        if (doc.isDirectory) {
                            out.mkdirs()
                        } else if (doc.isFile) {
                            out.parentFile?.mkdirs()
                            val input = context.contentResolver.openInputStream(doc.uri)
                            if (input != null) {
                                input.use { i ->
                                    out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                                }
                                copied++
                                bytes += out.length()
                                onProgress(Progress(copied, total, bytes))
                            }
                        }
                    } catch (t: Throwable) {
                        // 单个文件读不出来就跳过,最后按实际写入数报结果
                    }
                }
            }

            is Source.Path -> {
                var directOk = false
                try {
                    val r = copyFilesInto(source.dir, work, total, onProgress)
                    copied = r.first
                    bytes = r.second
                    directOk = r.first > 0
                } catch (t: Throwable) {
                    directOk = false
                }
                if (!directOk) {
                    // 直读不行(没有存储权限)就用 root 把源内容搬进暂存目录
                    if (hasRoot()) {
                        val src = shq(source.dir.absolutePath)
                        val dst = shq(work.absolutePath)
                        ShellUtil.exec(
                            "su -c 'mkdir -p $dst && cp -rf $src/. $dst/ 2>/dev/null'",
                            300_000
                        )
                        val after = statPath(work)
                        copied = after.files
                        bytes = after.bytes
                        onProgress(Progress(copied, total, bytes))
                    }
                }
            }
        }

        val staged = statPath(work)
        val count = staged.files
        if (count == 0) return null
        return work to count
    }

    /** 直接文件 IO 把一个目录拷进另一个目录,返回 (文件数, 字节数) */
    private fun copyFilesInto(
        src: File,
        dst: File,
        total: Int,
        onProgress: (Progress) -> Unit
    ): Pair<Int, Long> {
        if (!src.isDirectory) throw IllegalStateException("源不是目录")
        var copied = 0
        var bytes = 0L
        val stack = ArrayDeque<Pair<File, File>>()
        stack.addLast(src to dst)
        while (stack.isNotEmpty()) {
            val (s, d) = stack.removeLast()
            val children = s.listFiles() ?: continue
            for (child in children) {
                val out = File(d, child.name)
                if (child.isDirectory) {
                    if (!out.exists()) out.mkdirs()
                    stack.addLast(child to out)
                } else {
                    out.parentFile?.mkdirs()
                    child.inputStream().use { i ->
                        out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                    }
                    copied++
                    bytes += out.length()
                    onProgress(Progress(copied, maxOf(total, copied), bytes))
                }
            }
        }
        return copied to bytes
    }

    /** 目标走 SAF:同名文件删掉重建,可选先清空 */
    private fun writeToTree(
        context: Context,
        treeUri: Uri,
        stageDir: File,
        replaceAll: Boolean,
        total: Int,
        onProgress: (Progress) -> Unit
    ): Outcome {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: return Outcome(false, 0, 0, "none", "目标文件夹拿不到写权限,重新选一次")

        try {
            if (replaceAll) {
                for (kid in root.listFiles()) kid.delete()
            }
        } catch (t: Throwable) {
            return Outcome(false, 0, 0, "none", "清空目标文件夹失败:${t.message ?: "没有写权限"}")
        }

        var copied = 0
        var bytes = 0L
        val stack = ArrayDeque<Pair<File, DocumentFile>>()
        stack.addLast(stageDir to root)
        while (stack.isNotEmpty()) {
            val (s, d) = stack.removeLast()
            val children = s.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    val sub = findChild(d, child.name, isDir = true)
                        ?: try {
                            d.createDirectory(child.name)
                        } catch (t: Throwable) {
                            null
                        }
                    if (sub == null) continue
                    stack.addLast(child to sub)
                } else {
                    val created = try {
                        findChild(d, child.name, isDir = false)?.delete()
                        var doc = d.createFile(mimeOf(child.name), child.name)
                        if (doc == null) {
                            doc = d.createFile("application/octet-stream", child.name)
                        }
                        doc
                    } catch (t: Throwable) {
                        null
                    } ?: continue

                    try {
                        if (created.name != child.name) created.renameTo(child.name)
                        val out = context.contentResolver.openOutputStream(created.uri)
                        if (out != null) {
                            child.inputStream().use { i ->
                                out.use { o -> i.copyTo(o, 256 * 1024) }
                            }
                            copied++
                            bytes += child.length()
                            onProgress(Progress(copied, maxOf(total, copied), bytes))
                        }
                    } catch (t: Throwable) {
                        // 单个文件失败不影响整批
                    }
                }
            }
        }

        return if (copied == 0) {
            Outcome(false, 0, 0, "none", "一个文件都没写进去,目标文件夹可能没有写权限")
        } else {
            Outcome(true, copied, bytes, CHANNEL_SAF)
        }
    }

    private fun findChild(parent: DocumentFile, name: String, isDir: Boolean): DocumentFile? = try {
        parent.listFiles().firstOrNull { it.name == name && it.isDirectory == isDir }
    } catch (t: Throwable) {
        null
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"
    }

    /** 源和目标都是绝对路径:直接边读边写,失败(权限/空间)就返回 null 交给暂存+root 那条路 */
    private fun writeDirectTree(
        src: File,
        target: File,
        replaceAll: Boolean,
        total: Int,
        onProgress: (Progress) -> Unit
    ): Outcome? = try {
        if (!src.isDirectory) throw IllegalStateException("源不是目录")
        if (!target.exists() && !target.mkdirs() && !target.isDirectory) throw IllegalStateException("建不了目标目录")
        if (!target.isDirectory) throw IllegalStateException("目标不是目录")
        if (!target.canWrite()) throw IllegalStateException("目标没有写权限")

        if (replaceAll) {
            for (kid in target.listFiles() ?: emptyArray()) {
                if (!kid.deleteRecursively()) throw IllegalStateException("删不掉 " + kid.name)
            }
        }

        var copied = 0
        var bytes = 0L
        val stack = ArrayDeque<Pair<File, File>>()
        stack.addLast(src to target)
        while (stack.isNotEmpty()) {
            val (s, d) = stack.removeLast()
            for (child in s.listFiles() ?: emptyArray()) {
                val out = File(d, child.name)
                if (child.isDirectory) {
                    if (!out.exists() && !out.mkdirs()) continue
                    stack.addLast(child to out)
                } else {
                    out.parentFile?.mkdirs()
                    child.inputStream().use { i ->
                        out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                    }
                    copied++
                    bytes += out.length()
                    onProgress(Progress(copied, maxOf(total, copied), bytes))
                }
            }
        }
        if (copied == 0) null else Outcome(true, copied, bytes, CHANNEL_DIRECT)
    } catch (t: Throwable) {
        null
    }

    /** 目标走绝对路径,直写;写不了返回 null 让上层换 root */
    private fun writeToPathDirect(
        stageDir: File,
        target: File,
        replaceAll: Boolean,
        total: Int,
        onProgress: (Progress) -> Unit
    ): Outcome? = try {
        if (!target.exists() && !target.mkdirs() && !target.isDirectory) throw IllegalStateException("建不了目录")
        if (!target.isDirectory) throw IllegalStateException("目标不是目录")
        if (!target.canWrite()) throw IllegalStateException("没有写权限")

        if (replaceAll) {
            for (kid in target.listFiles() ?: emptyArray()) {
                if (!kid.deleteRecursively()) throw IllegalStateException("删不掉 ${kid.name}")
            }
        }

        var copied = 0
        var bytes = 0L
        val stack = ArrayDeque<Pair<File, File>>()
        stack.addLast(stageDir to target)
        while (stack.isNotEmpty()) {
            val (s, d) = stack.removeLast()
            for (child in s.listFiles() ?: emptyArray()) {
                val out = File(d, child.name)
                if (child.isDirectory) {
                    if (!out.exists() && !out.mkdirs()) continue
                    stack.addLast(child to out)
                } else {
                    out.parentFile?.mkdirs()
                    child.inputStream().use { i ->
                        out.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                    }
                    copied++
                    bytes += out.length()
                    onProgress(Progress(copied, maxOf(total, copied), bytes))
                }
            }
        }
        if (copied == 0) null else Outcome(true, copied, bytes, CHANNEL_DIRECT)
    } catch (t: Throwable) {
        null
    }

    /** 目标走特权通道(root 或 Shizuku):cp -rf,顺手把属主改回目标应用 */
    private fun writeToPathRoot(
        context: Context,
        stageDir: File,
        target: File,
        replaceAll: Boolean,
        total: Int
    ): Outcome? {
        val hasPrivilege = hasRoot() || ShizukuShell.granted()
        if (!hasPrivilege) return null
        return try {
            // 脚本和暂存目录都在外部目录:Shizuku 的 shell 身份读得到
            val scriptDir = context.getExternalFilesDir(null) ?: context.cacheDir
            val script = File(scriptDir, "zaka_import.sh")
            val pkg = packageFromPath(target.absolutePath)
            val uid = if (pkg != null) PackageUtil.uidOf(context, pkg) else -1
            val t = shq(target.absolutePath)
            val s = shq(stageDir.absolutePath)

            script.writeText(
                buildString {
                    appendLine("#!/system/bin/sh")
                    appendLine("TARGET=$t")
                    appendLine("STAGE=$s")
                    appendLine("mkdir -p \"\$TARGET\"")
                    if (replaceAll) {
                        appendLine("find \"\$TARGET\" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null")
                    }
                    appendLine("cp -rf \"\$STAGE/.\" \"\$TARGET/\" 2>/dev/null")
                    if (uid > 0) {
                        appendLine("chown -R $uid:$uid \"\$TARGET\" 2>/dev/null")
                    }
                    appendLine("chmod -R 0771 \"\$TARGET\" 2>/dev/null")
                    appendLine("restorecon -R \"\$TARGET\" 2>/dev/null")
                    appendLine("find \"\$TARGET\" -type f | wc -l")
                }
            )

            val channel = if (hasRoot()) CHANNEL_ROOT else CHANNEL_SHIZUKU
            val r = ShellUtil.execPrivileged(context, "sh ${shq(script.absolutePath)}", 300_000)
            if (r == null) return null
            val count = r.output.lineSequence()
                .mapNotNull { it.trim().toIntOrNull() }
                .lastOrNull() ?: 0
            if (count <= 0) {
                null
            } else {
                val after = statPath(target)
                Outcome(true, count, after.bytes, channel)
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** 从 /Android/data/<pkg>/… 或 /data/data/<pkg>/… 里把包名抠出来 */
    private fun packageFromPath(path: String): String? {
        val match = Regex("/(?:Android/(?:data|media|obb)|data/data)/([A-Za-z0-9_.]+)").find(path)
        return match?.groupValues?.get(1)
    }

    /** 单引号安全:路径里带单引号也不会把 sh 脚本打断 */
    private fun shq(raw: String): String = "'" + raw.replace("'", "'\\''") + "'"

    /**
     * 目标目录的属主 uid(数字)。
     *
     * 为什么不能用包名:chown 的属主参数只认数字 uid 或系统里的用户名,
     * 包名不是用户,传进去必然失败(shell 里还没回显,因为后面跟了 2>/dev/null)。
     * 先用 stat 问目录本身的属主,拿不到再按路径里的包名查 PackageManager。
     */
    private fun ownerUidOf(context: Context, dir: File): Int {
        val r = ShellUtil.execPrivileged(context, "stat -c %u ${shq(dir.absolutePath)}", 6000L)
        val fromStat = r?.output?.lineSequence()
            ?.map { it.trim() }
            ?.lastOrNull { it.toIntOrNull() != null }
            ?.toIntOrNull()
        if (fromStat != null && fromStat > 0) return fromStat
        val pkg = packageFromPath(dir.absolutePath)
        if (pkg != null) {
            val uid = PackageUtil.uidOf(context, pkg)
            if (uid > 0) return uid
        }
        return -1
    }

    /** 暂存目录:外部私有目录(shell 身份读得到),拿不到就退回 cache */
    fun stageDir(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.cacheDir, "import_stage")

    fun cleanupStage(context: Context) {
        try {
            stageDir(context).deleteRecursively()
        } catch (t: Throwable) {
        }
    }

    /** 什么都写不进去时,给一句能看懂的"为什么" */
    fun notReadyReason(context: Context, target: File): String {
        val state = channelState(context, target.absolutePath)
        return when {
            state.sdkInt >= 31 && !state.shizukuInstalled && !state.rootAvailable ->
                "尚未就绪:安卓 12 及以上写这个目录需要 Shizuku 或 root。装好 Shizuku 并在本应用里授权后即可导入。"
            state.sdkInt >= 31 && state.shizukuInstalled && !state.shizukuGranted ->
                "尚未就绪:Shizuku 已安装但还没授权,点「授权 Shizuku」后再导入。"
            else ->
                "目标目录写不进去:没有 root,也不是本应用能直接写的目录"
        }
    }

    /** 老接口保留 */
    fun cleanup(context: Context) = cleanupStage(context)
}
