package com.tengcd.czr.xposed

import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Process as AndroidProcess
import android.provider.Settings
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import com.tengcd.czr.util.SoVault
import com.tengcd.czr.util.ServiceState
import java.io.File
import java.util.zip.ZipFile

/**
 * 框架注入入口(assets/xposed_init 里写的类名就是它)。
 *
 * 这一版的触发方式完全对齐成熟的注入器做法:**只 hook 目标游戏的 Activity 生命周期**,
 * 在 Activity 真正建出来之后加载 so。不再 hook Application.attach / onCreate,
 * 也不再靠主线程轮询找 Application —— 这两条在 LSPosed 新版本和虚拟空间框架里都不可靠,
 * 时机一旦错过就永远不触发,表现就是「框架里勾了模块、游戏里什么都没有」。
 *
 * 另一个必须解决的问题是「第二次启动悬浮窗消失」:
 *
 *   虚拟空间框架(BlackBox / PINKBOX 那一系)会把游戏跑在它自己的虚拟进程里,
 *   游戏退出后这个虚拟进程常常**不会被销毁**。第二次启动游戏时进程还是同一个,
 *   而 so 里写死的 SONAME 是 libhonffx.so —— Android 的链接器是按 SONAME 去重的,
 *   同一个 SONAME 第二次 dlopen 直接把旧的句柄还回来,**构造函数和初始化段一次都不会再跑**,
 *   于是不会有新的悬浮窗。
 *
 *   这里的做法:每一轮启动都把 so 复制成一份新的槽位文件,并把 ELF 里的 SONAME
 *   一起改成槽位名(libhf0001.so 这种,长度和原串一致,原地替换不改结构)。
 *   SONAME 不同 = 链接器认成另一个库 = 真正重新 dlopen = 初始化段重跑 = 窗口重新建出来。
 *
 *   轮次怎么算:本进程第一次进 Activity 算第一轮;Activity 被销毁(且不是横竖屏那种
 *   配置变更)就把这一轮标记为结束,下次再建 Activity 就是新一轮。
 */
class HookInit : IXposedHookZygoteInit, IXposedHookLoadPackage {

    /** 本模块安装包路径,initZygote 时由框架给 */
    private var moduleApkPath: String? = null

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        moduleApkPath = startupParam?.modulePath
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        val pkg = lpparam?.packageName ?: return

        // 被注入的是我们自己的应用:这就是「框架认得模块」的证据。
        // 只标记「框架识别到模块」,绝不等于游戏里注入成功。
        // ⚠️ 这里只按包名判,不再用 classLoader 反查我们的类 ——
        //    虚拟空间里所有应用共用一个 ClassLoader,反查会把游戏进程误判成"自己的进程"然后直接返回。
        if (pkg == OUR_PACKAGE) {
            markSelfActive()
            return
        }
        if (pkg == "android" || pkg == "com.android.systemui") return

        // 偏好里读得到目标包、又不是它,直接跳过(马甲包除外)
        val cachedTarget = readTargetPackage()
        val isTarget = pkg == (cachedTarget?.takeIf { it.isNotBlank() } ?: DEFAULT_TARGET) ||
            pkg in SAME_GAME_PACKAGES
        if (!isTarget) return

        installActivityHooks(pkg, lpparam.classLoader)
    }

    // ---------------------------------------------------------------- 触发

    /**
     * 只挂 Activity 的 onCreate / onDestroy。
     *
     * 用 hookAllMethods 挂在 Activity 基类上,游戏主 Activity 叫什么名字都能命中,
     * 不用像固定类名那样一换包/换版本就失效。
     */
    private fun installActivityHooks(pkg: String, loader: ClassLoader?) {
        if (hooksInstalled) return
        hooksInstalled = true

        try {
            XposedBridge.hookAllMethods(
                Activity::class.java,
                "onCreate",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        // 任何异常都不许漏到游戏进程里,顶多是这次没注上
                        try {
                            val activity = param?.thisObject as? Activity ?: return
                            if (!belongsToTarget(activity, pkg, loader)) return
                            onRoundStart(activity, pkg)
                            openActivities.add(System.identityHashCode(activity))
                        } catch (t: Throwable) {
                            XposedBridge.log("[Tengcd] onCreate hook error: ${t.message}")
                        }
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked Activity.onCreate: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook onCreate failed: ${t.message}")
        }

        try {
            XposedBridge.hookAllMethods(
                Activity::class.java,
                "onDestroy",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam?) {
                        try {
                            val activity = param?.thisObject as? Activity ?: return
                            if (!belongsToTarget(activity, pkg, loader)) return
                            openActivities.remove(System.identityHashCode(activity))
                            // 横竖屏 / 分屏这种重建不算退出,窗口还在,别当成新一轮
                            if (activity.isChangingConfigurations) return
                            // 游戏里往往有多个 Activity(启动页 / 主界面 / 设置页),
                            // 只有全部退干净了才算这一轮结束
                            if (openActivities.isEmpty()) {
                                roundClosed = true
                                XposedBridge.log("[Tengcd] round closed: ${activity.javaClass.name}")
                            }
                        } catch (t: Throwable) {
                            XposedBridge.log("[Tengcd] onDestroy hook error: ${t.message}")
                        }
                    }
                }
            )
            XposedBridge.log("[Tengcd] hooked Activity.onDestroy: $pkg")
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] hook onDestroy failed: ${t.message}")
        }
    }

    /**
     * 这个 Activity 是不是目标游戏的。
     *
     * 虚拟空间里 Context 的包名经常是**宿主**的包名,拿它比会一路判 false,
     * 所以优先看 ClassLoader 是不是框架给游戏用的那一个。
     */
    private fun belongsToTarget(activity: Activity, pkg: String, loader: ClassLoader?): Boolean {
        try {
            if (loader != null && activity.javaClass.classLoader === loader) return true
        } catch (t: Throwable) {
        }
        val name = activity.javaClass.name
        if (name.startsWith("com.je.game")) return true
        return try {
            val actPkg = activity.packageName ?: ""
            actPkg == pkg || actPkg in SAME_GAME_PACKAGES
        } catch (t: Throwable) {
            false
        }
    }

    /** 新一轮游戏启动:重新把 so 载进去(每次都让链接器重新 dlopen) */
    private fun onRoundStart(activity: Activity, pkg: String) {
        // 本轮已经载过了,而且这一轮的窗口还没结束 —— 什么都不做
        if (loadedInThisRound && !roundClosed) return

        val seq = ++generation
        roundClosed = false
        val reasons = ArrayList<String>()

        val ok = loadModule(activity, pkg, seq, reasons)
        loadedInThisRound = ok

        if (!ok) {
            val detail = buildString {
                append(if (reasons.isEmpty()) "模块 so 没找到" else reasons.distinct().joinToString(" / "))
                if (!canDrawOverlay(activity)) {
                    append(" / 框架没有「显示在其他应用上层」权限,so 就算加载了悬浮窗也弹不出来")
                }
            }
            XposedBridge.log("[Tengcd] load failed (round $seq): $detail")
            report(activity, false, null, detail)
        }
    }

    /**
     * ? 这里不能直接判断 pkg 参数,虚拟空间下 pkg 可能是宿主包名。
     * 真正的目标包名以 Provider 给的为准,读不到再退回偏好里的。
     */
    private fun loadModule(context: Context, pkg: String, seq: Int, reasons: MutableList<String>): Boolean {
        val handoff = queryHandoff(context)
        val target = handoff?.target?.takeIf { it.isNotBlank() }
            ?: readTargetPackage()
            ?: DEFAULT_TARGET
        if (pkg != target && pkg !in SAME_GAME_PACKAGES) return false

        val variant = handoff?.variant?.takeIf { it.isNotBlank() }
            ?: readVariantFromPrefs()
            ?: ""

        // 找源 so:交接待定路径 -> 偏好里的路径 -> 模块私有目录 -> Provider -> 安装包
        val src = resolveSourceSo(context, variant, handoff?.path, reasons)
        if (src == null) return false

        // 每轮一份新槽位(改 SONAME),保证链接器真的重新加载
        val slot = prepareSlot(context, src, seq, reasons) ?: src
        if (attemptLoad(slot.absolutePath)) {
            report(context, true, slot.absolutePath, null)
            return true
        }
        reasons.add("${slot.name}:System.load 被拒")
        // 槽位这条路挂了就退回原文件再试一次(至少第一轮能用)
        if (slot != src && attemptLoad(src.absolutePath)) {
            report(context, true, src.absolutePath, null)
            return true
        }
        return false
    }

    /** 依次找能用的源 so */
    private fun resolveSourceSo(
        context: Context,
        variant: String,
        handoffPath: String?,
        reasons: MutableList<String>
    ): File? {
        // 1) 交接文件 / 偏好里的现成路径
        val candidates = listOfNotNull(
            handoffPath,
            readPathFromPrefs(),
            readHandoffPathFile(context)
        ).filter { it.isNotBlank() }.distinct()
        for (path in candidates) {
            val f = File(path)
            if (!f.isFile) {
                reasons.add("文件不存在:${f.name}")
                continue
            }
            if (!f.canRead()) {
                reasons.add("目标进程读不到:${f.name}")
                continue
            }
            val why = validateSo(f)
            if (why != null) {
                reasons.add("${f.name}:$why")
                continue
            }
            return f
        }

        // 2) 模块私有目录里可能放着 so 的地方(真实目录 + 虚拟空间盒内的映射目录)
        for (file in moduleDirCandidates(variant)) {
            if (!file.isFile || !file.canRead()) continue
            if (validateSo(file) != null) continue
            return file
        }

        // 3) 通过模块的 ContentProvider 把 so 拉过来(跨 uid 最稳的一条)
        fetchFromProvider(context, variant, reasons)?.let { return it }

        // 4) 从模块安装包里把选中的变体抽到目标进程自己的目录
        extractVariant(context, variant, reasons) { true }?.let { return it }

        return null
    }

    // ---------------------------------------------------------------- 槽位

    /**
     * 把源 so 复制成一份带唯一 SONAME 的槽位文件。
     *
     * SONAME 原串是 "libhonffx.so"(12 字节),槽位名 libhf0001.so 也是 12 字节,
     * 原地替换不改变任何偏移。找不到原串就返回 null,调用方退回用原文件。
     */
    private fun prepareSlot(context: Context, src: File, seq: Int, reasons: MutableList<String>): File? {
        val slotName = "libhf" + (seq % 10000).toString().padStart(4, '0') + ".so"
        val dirs = listOfNotNull(
            File(context.codeCacheDir, "honffx"),
            File(context.filesDir, "honffx")
        )
        val bytes = try {
            src.readBytes()
        } catch (t: Throwable) {
            reasons.add("读源 so 失败:${t.javaClass.simpleName}")
            return null
        }
        if (bytes.size <= 4096) {
            reasons.add("源 so 是空的/占位文件")
            return null
        }
        if (!patchSoname(bytes, slotName)) {
            reasons.add("so 里找不到 SONAME 字段,没法换槽位")
            return null
        }

        for (dir in dirs) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                // 清掉上一轮的槽位,只留这一轮的(已 dlopen 的文件删掉不影响运行)
                dir.listFiles()?.forEach { old ->
                    if (old.name.startsWith("libhf") && old.name != slotName) {
                        runCatching { old.delete() }
                    }
                }
                val dst = File(dir, slotName)
                val tmp = File(dir, "$slotName.tmp")
                tmp.outputStream().use { it.write(bytes) }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (validateSo(dst) == null) return dst
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    /**
     * 原地改写 ELF 的 SONAME 字符串。
     * 等长替换,不动任何偏移表,改完还是同一个合法的 ELF。
     */
    private fun patchSoname(bytes: ByteArray, newName: String): Boolean {
        val old = "libhonffx.so".toByteArray(Charsets.US_ASCII)
        val nn = newName.toByteArray(Charsets.US_ASCII)
        if (nn.size != old.size) return false
        var patched = false
        var i = 0
        while (i <= bytes.size - old.size) {
            if (bytes[i] == old[0]) {
                var match = true
                for (j in old.indices) {
                    if (bytes[i + j] != old[j]) {
                        match = false
                        break
                    }
                }
                if (match) {
                    System.arraycopy(nn, 0, bytes, i, nn.size)
                    patched = true
                }
            }
            i++
        }
        return patched
    }

    // ---------------------------------------------------------------- 自激活

    /**
     * 框架把本模块注入到我们自己的应用里 = 框架认得这个模块了。
     * 只置「框架识别到模块」这个标记,不写「游戏已注入」。
     */
    private fun markSelfActive() {
        try {
            ActiveCheck.markSelfHooked()
        } catch (t: Throwable) {
        }
        try {
            val cls = Class.forName("android.app.ActivityThread")
            val current = cls.getMethod("currentActivityThread").invoke(null)
            val app = cls.getMethod("getApplication").invoke(current) as? Application
            if (app != null) {
                ActiveCheck.writeMarker(app)
                ServiceState.onSelfLoaded()
            }
        } catch (t: Throwable) {
        }
        try {
            XposedBridge.log("[Tengcd] module injected into self (ver=" + ActiveCheck.xposedVersion() + ")")
        } catch (t: Throwable) {
        }
    }

    // ---------------------------------------------------------------- 加载

    private fun attemptLoad(path: String): Boolean = try {
        System.load(path)
        loadedPath = path
        XposedBridge.log("[Tengcd] module loaded: $path")
        true
    } catch (t: Throwable) {
        XposedBridge.log("[Tengcd] System.load($path) failed: ${t.message}")
        false
    }

    /** 返回 null = 这个 so 能加载,否则返回不能加载的原因 */
    private fun validateSo(file: File): String? {
        if (file.length() <= 4096L) return "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
        val head = ByteArray(20)
        val ok = try {
            file.inputStream().use { it.read(head) >= 20 }
        } catch (t: Throwable) {
            false
        }
        if (!ok) return "读不到 so 文件头"
        if (head[0] != 0x7F.toByte() || head[1] != 'E'.code.toByte() ||
            head[2] != 'L'.code.toByte() || head[3] != 'F'.code.toByte()
        ) {
            return "不是有效的 ELF 文件"
        }
        val soIs64 = head[4].toInt() == 2
        val targetIs64 = AndroidProcess.is64Bit()
        if (soIs64 != targetIs64) {
            return if (soIs64) "这个 so 是 64 位,目标进程是 32 位" else "这个 so 是 32 位,目标进程是 64 位"
        }
        return null
    }

    /** 模块私有目录里可能放着 so 的地方(真实目录 + 虚拟空间盒内的映射目录) */
    private fun moduleDirCandidates(variant: String): List<File> {
        val names = buildList {
            if (variant.isNotBlank()) add("libhonffx_$variant.so")
            add("libhonffx_local.so")
            add("libhonffx.so")
        }
        val dirs = listOf(
            "/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/10/$OUR_PACKAGE/files/module",
            "/data/user/999/$OUR_PACKAGE/files/module",
            // 虚拟空间盒子内的映射目录(模块也装进盒子时 so 会落在这里)
            "/data/data/$BOX_PACKAGE/virtual/data/data/$OUR_PACKAGE/files/module",
            "/data/user/0/$BOX_PACKAGE/virtual/data/data/$OUR_PACKAGE/files/module",
            "/data/data/$BOX_PACKAGE/virtual/data/user/0/$OUR_PACKAGE/files/module",
            "/data/user/0/$BOX_PACKAGE/virtual/data/user/0/$OUR_PACKAGE/files/module"
        )
        val out = ArrayList<File>()
        for (dir in dirs) {
            for (name in names) {
                out.add(File(dir, name))
            }
        }
        return out
    }

    /**
     * 从模块的 ContentProvider 拉 so。
     *
     * 模块 App 和游戏进程不是同一个 uid,直接读对方私有目录会被拒,
     * 但模块的 Provider 是导出的,openInputStream 能拿到字节流 —— 这是跨 uid 唯一稳的路。
     */
    private fun fetchFromProvider(context: Context, variant: String, reasons: MutableList<String>): File? {
        val dirs = listOfNotNull(
            File(context.codeCacheDir, "honffx"),
            File(context.filesDir, "honffx"),
            runCatching { File(context.createDeviceProtectedStorageContext().filesDir, "honffx") }.getOrNull()
        )
        val uris = buildList {
            if (variant.isNotBlank()) add(Uri.parse("content://$OUR_PACKAGE.so/variant/$variant"))
            add(Uri.parse("content://$OUR_PACKAGE.so/module"))
            add(Uri.parse("content://$OUR_PACKAGE.so"))
        }
        val tag = if (variant.isBlank()) "provider" else variant
        for (dir in dirs) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
            } catch (t: Throwable) {
                continue
            }
            for (uri in uris) {
                val tmp = File(dir, "libhonffx_$tag.so.tmp")
                try {
                    val input = context.contentResolver.openInputStream(uri) ?: continue
                    input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }
                } catch (t: Throwable) {
                    reasons.add("Provider 取不到:${t.javaClass.simpleName}")
                    tmp.delete()
                    continue
                }
                if (tmp.length() <= 4096L) {
                    reasons.add("Provider 给的 so 是空的/占位文件")
                    tmp.delete()
                    continue
                }
                val dst = File(dir, "libhonffx_$tag.so")
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    continue
                }
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (validateSo(dst) != null) {
                    reasons.add("Provider 的 so 校验不过")
                    continue
                }
                return dst
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽 assets/so/<variant>.so,写到目标进程自己的目录。
     */
    private fun extractVariant(
        context: Context,
        variant: String,
        reasons: MutableList<String>,
        accept: (File) -> Boolean
    ): File? {
        val apk = resolveModuleApk(context) ?: run {
            reasons.add("找不到模块安装包")
            return null
        }
        if (variant.isBlank()) {
            reasons.add("没拿到选中的 SO 版本")
            return null
        }

        val entryName = "assets/so/$variant.so${SoVault.ENC_SUFFIX}"
        val plainEntry = "assets/so/$variant.so"
        val targets = buildList {
            add(File(context.codeCacheDir, "honffx"))
            add(File(context.filesDir, "honffx"))
            try {
                add(File(context.createDeviceProtectedStorageContext().filesDir, "honffx"))
            } catch (t: Throwable) {
            }
        }

        if (!SoVault.signatureAllowed(context, OUR_PACKAGE)) {
            reasons.add("安装包签名校验失败,内置 so 拒绝解密")
            return null
        }

        for (dir in targets) {
            try {
                if (!dir.isDirectory && !dir.mkdirs()) continue
                val dst = File(dir, "libhonffx_$variant.so")
                if (!unzipEntry(apk, entryName, plainEntry, dst, reasons)) continue
                if (validateSo(dst) != null) continue
                SoVault.makeOwnerOnly(dst)
                dst.setReadable(true, false)
                if (accept(dst)) return dst
            } catch (t: Throwable) {
                reasons.add("写不进 ${dir.name}")
            }
        }
        return null
    }

    /**
     * 从模块安装包里抽一份 so 写到 dst。
     * 包里的资产是加密件(xxx.so.enc),这里读出来先解密再落盘;老包没有 .enc 的话退回读明文 .so。
     */
    private fun unzipEntry(
        apk: File,
        encEntry: String,
        plainEntry: String,
        dst: File,
        reasons: MutableList<String>
    ): Boolean {
        try {
            ZipFile(apk).use { zip ->
                var entry = zip.getEntry(encEntry)
                var encrypted = entry != null
                if (entry == null) {
                    entry = zip.getEntry(plainEntry)
                    encrypted = false
                }
                if (entry == null) {
                    reasons.add("安装包里没有 $encEntry")
                    return false
                }
                val raw = zip.getInputStream(entry).use { it.readBytes() }
                if (raw.isEmpty()) {
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                var bytes: ByteArray? = if (encrypted) {
                    SoVault.decrypt(raw, entry.name.substringAfterLast('/'))
                } else {
                    raw
                }
                if (bytes == null || !SoVault.isElf(bytes) || bytes.size <= 4096) {
                    val alt = zip.getEntry(plainEntry)
                    if (alt != null && alt.name != entry.name) {
                        val altRaw = zip.getInputStream(alt).use { it.readBytes() }
                        if (SoVault.isElf(altRaw) && altRaw.size > 4096) bytes = altRaw
                    }
                }
                val plainBytes = bytes
                if (plainBytes == null) {
                    reasons.add("内置 so 解密失败(安装包被改过或签名不对)")
                    return false
                }
                if (!SoVault.isElf(plainBytes)) {
                    reasons.add("抽出来的东西不是 so")
                    return false
                }
                val tmp = File(dst.parentFile, dst.name + ".tmp")
                tmp.outputStream().use { it.write(plainBytes) }
                if (tmp.length() <= 0L) {
                    tmp.delete()
                    reasons.add("解出来的 so 是空的")
                    return false
                }
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) {
                    tmp.delete()
                    reasons.add("落盘失败")
                    return false
                }
                return true
            }
        } catch (t: Throwable) {
            reasons.add("读安装包失败:${t.message}")
            return false
        }
    }

    /** 模块安装包路径:优先 initZygote 给的,拿不到就去问 PackageManager */
    private fun resolveModuleApk(context: Context): File? {
        moduleApkPath?.let { p ->
            val f = File(p)
            if (f.isFile) return f
        }
        return try {
            val info = context.packageManager.getApplicationInfo(OUR_PACKAGE, 0)
            File(info.sourceDir).takeIf { it.isFile }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- 取配置

    private data class Handoff(val path: String, val variant: String, val target: String)

    /** 问我们自己的 ContentProvider 要交接信息(最可靠的一条路) */
    private fun queryHandoff(context: Context): Handoff? = try {
        val bundle: Bundle? = context.contentResolver.call(
            Uri.parse("content://$OUR_PACKAGE.so"), "get_handoff", context.packageName, null
        )
        if (bundle == null) {
            null
        } else {
            Handoff(
                path = bundle.getString("path").orEmpty(),
                variant = bundle.getString("variant").orEmpty(),
                target = bundle.getString("target").orEmpty()
            )
        }
    } catch (t: Throwable) {
        null
    }

    /** 有没有「显示在其他应用上层」权限(so 的悬浮窗全靠它) */
    private fun canDrawOverlay(context: Context): Boolean = try {
        Settings.canDrawOverlays(context)
    } catch (t: Throwable) {
        true
    }

    private fun currentProcessName(): String = try {
        File("/proc/self/cmdline").readText().trim('\u0000', '\n', ' ')
    } catch (t: Throwable) {
        ""
    }

    private fun report(context: Context, ok: Boolean, path: String?, detail: String?) {
        try {
            context.contentResolver.call(
                Uri.parse("content://$OUR_PACKAGE.so"),
                "report_state",
                if (ok) "ok" else "error",
                Bundle().apply {
                    putString("package", context.packageName)
                    putString("process", currentProcessName())
                    putInt("pid", AndroidProcess.myPid())
                    putString("path", path)
                    putString("detail", detail)
                    putBoolean("overlay", canDrawOverlay(context))
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[Tengcd] report failed: ${t.message}")
        }
    }

    private fun readPrefs(): XSharedPreferences? = try {
        val xsp = XSharedPreferences(OUR_PACKAGE, PREFS_FILE)
        @Suppress("DEPRECATION")
        try {
            xsp.makeWorldReadable()
        } catch (t: Throwable) {
        }
        xsp.reload()
        xsp
    } catch (t: Throwable) {
        null
    }

    private fun readTargetPackage(): String? = try {
        readPrefs()?.getString("target_package", null)
    } catch (t: Throwable) {
        null
    }

    private fun readVariantFromPrefs(): String? = try {
        readPrefs()?.getString("so_variant", null)
    } catch (t: Throwable) {
        null
    }

    private fun readPathFromPrefs(): String? = try {
        readPrefs()?.getString("module_path", null)
    } catch (t: Throwable) {
        null
    }

    private fun readHandoffPathFile(context: Context): String? {
        val candidates = listOf(
            File("/sdcard/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/storage/emulated/0/Android/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/data/$OUR_PACKAGE/files/module_path.txt"),
            File("/data/user/0/$OUR_PACKAGE/files/module_path.txt")
        )
        for (f in candidates) {
            try {
                if (!f.isFile) continue
                val first = f.readLines().firstOrNull()?.trim()
                if (!first.isNullOrBlank()) return first
            } catch (t: Throwable) {
            }
        }
        return null
    }

    companion object {
        private const val OUR_PACKAGE = "com.tengcd.czr"
        private const val PREFS_FILE = "honffx_inject"
        private const val DEFAULT_TARGET = "com.pi.czrxdfirst"

        /** 虚拟空间框架的宿主包名(找盒内 so 映射目录用) */
        private const val BOX_PACKAGE = "top.niunaijun.blackbox"

        /**
         * 同一个游戏的不同马甲包。
         *
         * 换包名重新分发是很常见的做法(只差一两个字母),但模块的作用域和这里的
         * 目标判断都是写死包名的 —— 名字对不上,框架压根不会把模块送进游戏,
         * 界面上就会一直显示"没生效"。这里把知道的马甲都列上。
         */
        private val SAME_GAME_PACKAGES = setOf(
            "com.pi.czrxdfirst",
            "com.pi.ezrxdfirst",
        )

        /** 生命周期 hook 只挂一次 */
        @Volatile
        private var hooksInstalled = false

        /** 本轮(这一次游戏启动)的 so 有没有载成功 */
        @Volatile
        private var loadedInThisRound = false

        /** 本轮结束标记:游戏 Activity 被销毁(非配置变更)后置 true */
        @Volatile
        private var roundClosed = true

        /** 启动轮次,槽位名跟着它走 */
        @Volatile
        private var generation = 0

        /** 这一轮实际加载的路径 */
        @Volatile
        private var loadedPath: String? = null

        /** 当前还活着的目标 Activity(只有全部退干净才算这一轮结束) */
        private val openActivities: MutableSet<Int> =
            java.util.Collections.synchronizedSet(mutableSetOf<Int>())
    }
}
