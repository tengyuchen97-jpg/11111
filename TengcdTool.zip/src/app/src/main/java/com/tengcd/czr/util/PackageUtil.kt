package com.tengcd.czr.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.io.File

/**
 * 目标应用相关:装没装、跑没跑、uid 一不一样、数据目录能不能读。
 */
object PackageUtil {

    fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (t: Throwable) {
        false
    }

    fun versionName(context: Context, pkg: String): String? = try {
        context.packageManager.getPackageInfo(pkg, 0).versionName
    } catch (t: Throwable) {
        null
    }

    fun uidOf(context: Context, pkg: String): Int = try {
        context.packageManager.getApplicationInfo(pkg, 0).uid
    } catch (t: Throwable) {
        -1
    }

    fun selfUid(): Int = Process.myUid()

    /** 本应用在 manifest 里声明的 sharedUserId(没声明就是空串) */
    fun selfSharedUserId(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).sharedUserId ?: "未声明"
    } catch (t: Throwable) {
        "未声明"
    }

    /** 同一个 sharedUserId 下,两个包 uid 会一致;不一致就没法用进程注入 */
    fun sameUid(context: Context, pkg: String): Boolean {
        val other = uidOf(context, pkg)
        return other != -1 && other == selfUid()
    }

    fun sourceDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).sourceDir
    } catch (t: Throwable) {
        null
    }

    fun dataDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).dataDir
    } catch (t: Throwable) {
        null
    }

    fun nativeLibDir(context: Context, pkg: String): String? = try {
        context.packageManager.getApplicationInfo(pkg, 0).nativeLibraryDir
    } catch (t: Throwable) {
        null
    }

    /**
     * 启动目标,把失败原因带出来(null = 起来了)。
     *
     * 以前只走 getLaunchIntentForPackage,一堆「专属包 / 渠道包 / 更新包」被摘了
     * LAUNCHER 入口(或者入口被 pm disable 了),这个函数直接返回 null,
     * 上层就一路报「未找到目标游戏」,其实游戏装了、就是没人帮它起。
     * 现在按三档来:常规入口 -> 点名启动被隐藏的组件 -> root / Shizuku 用 am / monkey 起。
     */
    fun launchDetailed(context: Context, pkg: String): String? {
        if (pkg.isBlank()) return "目标包名为空"
        if (!isInstalled(context, pkg)) return "目标没安装"

        // ① 常规入口
        runCatching { context.packageManager.getLaunchIntentForPackage(pkg) }.getOrNull()?.let { it ->
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            if (runCatching { context.startActivity(it); true }.getOrDefault(false)) return null
        }

        // ② 入口被隐藏 / 禁用:把禁用组件一起搜出来,点名启动
        val comp = launcherComponent(context, pkg)
        if (comp != null) {
            val it = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(comp)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            if (runCatching { context.startActivity(it); true }.getOrDefault(false)) return null
        }

        // ③ 特权通道
        return launchPrivileged(context, pkg, comp)
    }

    fun launch(context: Context, pkg: String): Boolean = launchDetailed(context, pkg) == null

    /** 连被禁用的组件一起找,返回第一个能当入口的 Activity */
    private fun launcherComponent(context: Context, pkg: String): ComponentName? {
        val flags = PackageManager.MATCH_DISABLED_COMPONENTS or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PackageManager.MATCH_ALL else 0)
        val query = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setPackage(pkg)
        val found = runCatching { context.packageManager.queryIntentActivities(query, flags) }
            .getOrDefault(emptyList())
        val act = found.firstOrNull()?.activityInfo ?: return null
        return ComponentName(act.packageName, act.name)
    }

    /** 用 root / Shizuku 的身份起目标:am start / 先启用组件 / 再不行 monkey 兜底 */
    private fun launchPrivileged(
        context: Context,
        pkg: String,
        comp: ComponentName?
    ): String? {
        val steps = ArrayList<String>()
        if (comp != null) {
            val flat = comp.flattenToShortString()
            steps.add("am start -n $flat")
            steps.add("cmd package enable $flat")
            steps.add("am start -n $flat")
        }
        steps.add("cmd package resolve-activity --brief -c android.intent.category.LAUNCHER $pkg")
        steps.add("monkey -p $pkg -c android.intent.category.LAUNCHER 1")

        var last = ""
        for (cmd in steps) {
            val r = ShellUtil.execPrivileged(context, cmd, 12000L)
                ?: return "系统里没有可启动的入口,也没有 root / Shizuku 通道"
            last = r.output
            val failed = last.contains("Error", true) ||
                last.contains("Exception", true) ||
                last.contains("No activities", true) ||
                last.contains("aborted", true)
            if (cmd.startsWith("am start") && r.ok && !failed) return null
            if (cmd.startsWith("monkey") && r.ok && !failed) return null
            if (cmd.startsWith("cmd package resolve-activity") && r.ok && !failed) {
                val flat = last.lineSequence()
                    .map { it.trim() }
                    .lastOrNull { it.contains("/") && it.contains(pkg) }
                if (flat != null) {
                    val started = ShellUtil.execPrivileged(context, "am start -n $flat", 12000L)
                    if (started != null && started.ok &&
                        !started.output.contains("Error", true)
                    ) {
                        return null
                    }
                }
            }
        }
        val hint = last.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(80)
        return if (hint.isNullOrBlank()) "系统里没有可启动的入口" else "启动被拒绝:$hint"
    }

    /** 扫描 /proc,按 cmdline 找 pid;一个包可能有多个进程 */
    fun findPids(pkg: String): List<Int> = findPids(pkg, -1)

    /**
     * 扫描 /proc 找目标进程。
     *
     * 安卓 9 以后读别人的 /proc/<pid>/cmdline 经常被拦(返回空),
     * 老代码一读不到就 continue,于是目标明明在跑,界面上永远显示「未运行」。
     * 现在按两层来认:
     *   ① cmdline 直接等于包名 / 包名:xxx  —— 最准,读到就以此为准
     *   ② /proc/<pid>/status 里的 Name(comm,最多 15 字符)与包名一致 + Uid 对得上
     *
     * 以前还有第三层「只要 uid 对得上、进程名沾一点包名就算」,那一层是误报的根:
     * 共用 uid 的机器上,自己应用的进程名里也带着同一个片段(包名互含),
     * 于是目标根本没启动,界面照样报「有进程」。这层已经删掉。
     */
    fun findPids(pkg: String, uid: Int): List<Int> {
        val result = ArrayList<Int>()
        if (pkg.isBlank()) return result
        val entries = File("/proc").list() ?: return result
        val comm = pkg.take(15)                      // status 里的 Name 就是进程名截 15 字符
        val shortComm = pkg.substringAfterLast('.').take(15)
        for (name in entries) {
            val pid = name.toIntOrNull() ?: continue
            if (pid <= 1) continue
            // 进程目录都读不了就不算
            if (!procDirAccessible(pid)) continue

            // ① cmdline:能读到就以它为唯一依据
            val cmdline = readCmdlineFull(pid)
            if (!cmdline.isNullOrBlank()) {
                if (matchesPkg(cmdline, pkg)) result.add(pid)
                continue
            }

            // ② status:Name 必须和目标包名严格对上,再核对 uid
            val pname = readNameOfPid(pid)
            if (pname.isBlank()) continue
            val pidUid = readUidOfPid(pid)
            if (uid > 0 && pidUid != uid) continue
            if (pname == comm || pname == shortComm) {
                result.add(pid)
            }
        }
        result.sort()
        return result
    }

    /**
     * 进程名是不是目标包。
     *
     * 认这几种:主进程 pkg、子进程 pkg:unity / pkg:remote、
     * 双开分身给的后缀 pkg.xxx,以及 app_process 拉起时
     * 「/system/bin/app_process64 ... pkg」这种 cmdline 里带包名的形式。
     */
    fun matchesPkg(name: String, pkg: String): Boolean {
        if (pkg.isBlank() || name.isBlank()) return false
        val head = name.substringBefore(' ').trim()
        if (head.isEmpty()) return false
        if (head == pkg) return true
        if (head.startsWith("$pkg:")) return true
        if (head.startsWith("$pkg.")) return true
        if (name.contains("/$pkg")) return true
        return false
    }

    /**
     * 带上下文版:自己扫不到时,再用 root / Shizuku 扫一遍。
     *
     * 安卓 10 以后普通应用读别的 uid 的 /proc/<pid>/cmdline 一律被拦,
     * 结果就是游戏明明在跑、界面一直说「未运行 / 识别不到」。
     * 特权扫描比较慢(su 要 fork),所以 1.5 秒内只尝试一次。
     */
    fun findPidsWithContext(context: Context, pkg: String): List<Int> {
        val direct = findPids(pkg, uidOf(context, pkg))
        if (direct.isNotEmpty()) return direct
        val now = System.currentTimeMillis()
        if (now - lastPrivilegedScanAt < 1500L) return emptyList()
        lastPrivilegedScanAt = now
        return findPidsPrivileged(context, pkg)
    }

    @Volatile
    private var lastPrivilegedScanAt = 0L

    /** 用特权身份把全机 cmdline 读一遍,按包名挑出 pid */
    fun findPidsPrivileged(context: Context, pkg: String): List<Int> {
        if (pkg.isBlank()) return emptyList()
        val dump = privilegedProcDump(context) ?: return emptyList()
        val result = ArrayList<Int>()
        for (line in dump.lineSequence()) {
            val bar = line.indexOf('|')
            if (bar <= 0) continue
            val pid = line.substring(0, bar).trim().toIntOrNull() ?: continue
            if (pid <= 1) continue
            if (matchesPkg(line.substring(bar + 1).trim(), pkg)) result.add(pid)
        }
        result.sort()
        return result
    }

    /**
     * 扫不到目标时给一句人能看懂的现场:到底有没有相近的进程、是不是跑在别的空间里。
     * 没有特权通道就不硬猜,如实说读不到。
     */
    fun diagnoseMissingProcess(context: Context, pkg: String): String {
        val dump = privilegedProcDump(context)
            ?: return "本机没有 root / Shizuku 通道,读不到别的应用的进程列表"
        val tail = pkg.substringAfterLast('.')
        val near = ArrayList<String>()
        var total = 0
        for (line in dump.lineSequence()) {
            val bar = line.indexOf('|')
            if (bar <= 0) continue
            val cmd = line.substring(bar + 1).trim()
            if (cmd.isBlank()) continue
            total++
            if (tail.isNotBlank() && cmd.contains(tail, true) && near.size < 3) {
                near.add(cmd.substringBefore(' ').take(48))
            }
        }
        return if (near.isEmpty()) {
            "扫了 " + total + " 个进程,没有一个带 " + tail +
                "(游戏还没起来,或者跑在别的空间/双开里)"
        } else {
            "扫了 " + total + " 个进程,相近的有:" + near.joinToString("、")
        }
    }

    /** 全机 cmdline 一份:`pid|arg0 arg1 ...` 每行一个 */
    private fun privilegedProcDump(context: Context): String? {
        val cmd = "for f in /proc/[0-9]*/cmdline; do printf '%s|' \"\$f\"; " +
            "tr '\\0' ' ' < \"\$f\" 2>/dev/null; echo; done"
        val r = ShellUtil.execPrivileged(context, cmd, 15000L) ?: return null
        return if (r.ok) r.output else null
    }

    /**
     * 进程目录可不可访问:能列出 /proc/<pid> 里的东西就算能。
     * 界面上「运行中 / 未运行」就按这个判。
     */
    fun procDirAccessible(pid: Int): Boolean {
        if (pid <= 0) return false
        return try {
            val dir = File("/proc/$pid")
            dir.isDirectory && dir.list()?.isNotEmpty() == true
        } catch (t: Throwable) {
            false
        }
    }

    /** status 里的 Name: 字段(就是 comm,最多 15 字符) */
    fun readNameOfPid(pid: Int): String = try {
        val status = File("/proc/$pid/status").readLines()
        var name = ""
        for (line in status) {
            if (line.startsWith("Name:")) {
                name = line.substring(5).trim()
                break
            }
        }
        name
    } catch (t: Throwable) {
        ""
    }

    fun readCmdline(pid: Int): String? = try {
        val text = File("/proc/$pid/cmdline").readBytes()
        var end = 0
        while (end < text.size && text[end] != 0.toByte()) end++
        String(text, 0, end, Charsets.UTF_8).trim()
    } catch (t: Throwable) {
        null
    }

    /** 整条 cmdline(NUL 换成空格):app_process 拉起的目标,包名在第二个参数里 */
    fun readCmdlineFull(pid: Int): String? = try {
        val text = File("/proc/$pid/cmdline").readBytes()
        String(text, Charsets.UTF_8).replace('\u0000', ' ').trim()
    } catch (t: Throwable) {
        null
    }

    fun readUidOfPid(pid: Int): Int = try {
        val status = File("/proc/$pid/status").readLines()
        var uid = -1
        for (line in status) {
            if (line.startsWith("Uid:")) {
                val parts = line.substring(4).trim().split(Regex("\\s+"))
                uid = parts.firstOrNull()?.toIntOrNull() ?: -1
                break
            }
        }
        uid
    } catch (t: Throwable) {
        -1
    }

    /**
     * 这个进程是 64 位还是 32 位。
     *
     * 注入时按这个选 so:64 位进程只能吃 arm64 那份,32 位只能吃 armv7 那份。
     * 投错位数的那次会把目标所有线程冻住做一整轮远程调用,白折腾好几秒,
     * 游戏模块的注入就跟着废了,所以先判清楚再投。
     *
     * @return true = 64 位,false = 32 位,null = 判断不出来
     */
    fun isPid64(pid: Int): Boolean? {
        if (pid <= 0) return null
        // ① /proc/<pid>/exe -> /system/bin/app_process64 / app_process32
        try {
            val exe = File("/proc/$pid/exe").canonicalPath
            if (exe.contains("app_process64")) return true
            if (exe.contains("app_process32")) return false
        } catch (t: Throwable) {
        }
        // ② maps 里第一个带 /lib64/ 或 /lib/ 的库,定死架构
        try {
            val maps = File("/proc/$pid/maps")
            if (maps.canRead()) {
                var saw32 = false
                for (line in maps.readLines()) {
                    val path = line.substringAfterLast(' ', "").trim()
                    if (path.isEmpty()) continue
                    if (path.contains("/lib64/") || path.contains("linker64")) return true
                    // 注意:64 位游戏自己的库路径里也有 /lib/ 这一层(…/lib/arm64/…),
                    // 所以这里只记一笔、不立刻下定论,整份 maps 没有 lib64 才判 32 位
                    if (path.contains("/lib/") || path.contains("armeabi") ||
                        path.contains("linker")
                    ) {
                        saw32 = true
                    }
                }
                if (saw32) return false
            }
        } catch (t: Throwable) {
        }
        return null
    }

    fun processNameOfPid(pid: Int): String {
        val cmd = try {
            File("/proc/$pid/cmdline").readText(Charsets.UTF_8).replace('\u0000', ' ').trim()
        } catch (t: Throwable) {
            ""
        }
        // 安卓 10+ 读不到别人的 cmdline 时,退回 status 里的 Name,别在界面上显示空进程名
        return cmd.ifBlank { readNameOfPid(pid) }
    }

    fun isRunning(pkg: String): Boolean = findPids(pkg).isNotEmpty()

    fun installedTargets(context: Context): List<Pair<String, String>> {
        val pm: PackageManager = context.packageManager
        val list = ArrayList<Pair<String, String>>()
        val pkgs = pm.getInstalledPackages(0)
        for (info in pkgs) {
            val p = info.packageName
            if (p == context.packageName) continue
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            } catch (t: Throwable) {
                p
            }
            list.add(p to label)
        }
        return list
    }
}
