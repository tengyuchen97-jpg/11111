package com.tengcd.czr.inject

import android.content.Context
import com.tengcd.czr.util.InjectionPrefs
import com.tengcd.czr.util.PackageUtil
import com.tengcd.czr.xposed.XposedDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * 按当前模式选注入通道。UI 只调这里,不用关心底下走的是框架还是 ptrace。
 */
object InjectorRouter {

    suspend fun inject(
        context: Context,
        mode: InjectionMode,
        targetPkg: String,
        entry: String? = null
    ): PtraceInjectResult = withContext(Dispatchers.IO) {
        if (!PackageUtil.isInstalled(context, targetPkg)) {
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.TARGET_NOT_INSTALLED)
        }
        // 换过安装包也要先把内置 so 重新解包一遍,别拿旧的占位文件去加载
        ModuleStore.ensureBundled(context)

        if (!ModuleStore.isDownloaded(context)) {
            // 选中的这一版本机没有真 so、只有空文件占位时说清楚是哪一版,
            // 不再偷偷换成别的版本去注入(以前就是这么被换回 v0.24 的)。
            val f = ModuleStore.effectiveFile(context)
            val why = if (f.isFile) {
                "选中的 " + ModuleStore.sourceLabel() + " 本机还没有 so 文件(空文件占位)," +
                    "把这个版本的 so 放进私有目录或导入本机 SO 后再注入"
            } else {
                "选中的 " + ModuleStore.sourceLabel() + " 还没解包出文件"
            }
            return@withContext PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }
        ModuleStore.refreshPrefs(context)

        when (mode) {
            InjectionMode.FRAMEWORK -> frameworkInject(context, targetPkg)
            InjectionMode.PROCESS -> processInject(context, targetPkg, entry)
        }
    }

    /**
     * 框架注入:我们不需要自己动手,只要把"用哪个 so"写进交接文件,
     * 目标进程起来时由 HookInit 自己从安装包里抽出来加载。
     */
    private suspend fun frameworkInject(context: Context, targetPkg: String): PtraceInjectResult {
        if (!XposedDetector.isFrameworkInstalled(context)) {
            return PtraceInjectResult.Failure(PtraceInjectFailure.FRAMEWORK_NOT_INSTALLED)
        }
        val info = ModuleStore.currentInfo(context)
        if (!info.ready) {
            val why = when {
                !info.exists -> "还没解包出内置 SO"
                info.placeholder -> "内置 SO 是占位文件,把加密好的 so.enc 放进 assets/so 重新打包"
                !info.isElf -> "内置 SO 不是有效的 ELF 文件"
                else -> "内置 SO 不完整"
            }
            return PtraceInjectResult.Failure(PtraceInjectFailure.MODULE_NOT_READY, why)
        }

        // 每次重新注入都先把上次的状态抹掉,免得界面一直显示"已激活"
        InjectionPrefs.frameworkActive = false
        InjectionPrefs.frameworkError = null
        InjectionPrefs.frameworkPath = null

        val soPath = info.file.absolutePath
        ModuleStore.writeHandoff(context, soPath, targetPkg)

        val pids = PackageUtil.findPidsWithContext(context, targetPkg)
        if (pids.isEmpty()) {
            // 目标还没跑:这不叫失败,下次它启动时模块会自己载入
            return PtraceInjectResult.Success(
                pid = -1,
                soPath = soPath,
                detail = "已准备好(" + ModuleStore.sourceLabel() + "),启动目标后自动加载"
            )
        }

        // 目标在跑:等目标进程回报(它下次启动才会重新加载)
        delay(2500)
        if (InjectionPrefs.frameworkActive) {
            return PtraceInjectResult.Success(pids.first(), soPath, "已生效")
        }
        val error = InjectionPrefs.frameworkError
        return PtraceInjectResult.Success(
            pid = pids.first(),
            soPath = soPath,
            detail = if (error.isNullOrBlank()) {
                "已准备好(" + ModuleStore.sourceLabel() + "),重启目标后生效"
            } else {
                "已准备好,但目标加载失败:" + error
            }
        )
    }

    /**
     * 进程注入:目标在跑 -> 把 so 挪到目标数据目录 -> ptrace 附加 -> 远程 dlopen。
     */
    private fun processInject(
        context: Context,
        targetPkg: String,
        entry: String?
    ): PtraceInjectResult {
        // 进程注入是本应用自己去 ptrace,所以必须同 uid(sharedUserId 一致);
        // 不同 uid 时就算有 root 也没用 —— ptrace 发生在应用进程里,拿不到特权。
        if (!PackageUtil.sameUid(context, targetPkg)) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.SAME_UID_REQUIRED,
                "本应用与目标 uid 不一致:双方要声明同一个 sharedUserId(" +
                    PackageUtil.selfSharedUserId(context) + ")"
            )
        }
        val pids = PackageUtil.findPidsWithContext(context, targetPkg)
        if (pids.isEmpty()) {
            return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_NOT_FOUND,
                "目标没在跑:" + PackageUtil.diagnoseMissingProcess(context, targetPkg)
            )
        }
        val staged = ModuleStore.stageForTarget(context, targetPkg)
            ?: ModuleStore.stageForTargetPrivileged(context, targetPkg)
            ?: return PtraceInjectResult.Failure(
                PtraceInjectFailure.TARGET_DIR_NOT_ACCESSIBLE,
                "复制不进目标数据目录(权限不足)"
            )

        // 一个包可能有好几个进程(主进程 + :unity / :remote):
        // 每个都试,成功一个就收工;全失败就把每个 pid 上的原因都带出去,
        // 别只留最后一条(经常是"主进程 32 位注不了",而 64 位子进程其实能注)。
        val reasons = StringBuilder()
        var lastKind = PtraceInjectFailure.UNKNOWN
        for (pid in pids) {
            val r = PtraceInjector.inject(pid, staged.absolutePath, entry)
            if (r is PtraceInjectResult.Success) return r
            if (r is PtraceInjectResult.Failure) lastKind = r.kind
            val why = PtraceInjector.lastDetail ?: (r as? PtraceInjectResult.Failure)?.detail
            reasons.append("pid ").append(pid)
            if (r is PtraceInjectResult.Failure) reasons.append('(').append(r.kind.name).append(')')
            reasons.append(':').append(why ?: "注入失败").append("; ")
        }
        val detail = reasons.toString().trim().trimEnd(';').trim()
        return PtraceInjectResult.Failure(
            lastKind,
            detail.ifBlank { "注入失败" }
        )
    }
}
